/* WH.c source code  by Jody Hey & John Wakeley */

#include  "wh.h"


#define _FNSIZE  80


#define FP fprintf(rfile,
#define FPLINE fprintf(rfile,"-------------------------------------------------------------------------\n")


int numloci,nseqs1[MAXLOCI],nseqs2[MAXLOCI];
double Sx1[MAXLOCI],Sx2[MAXLOCI],Ss[MAXLOCI],Sf[MAXLOCI],pN[MAXLOCI], l[MAXLOCI], c1s[MAXLOCI], c2s[MAXLOCI],c1[MAXLOCI],c2[MAXLOCI], ca[MAXLOCI];

double ESx1[MAXLOCI],ESx2[MAXLOCI],ESs[MAXLOCI],ESf[MAXLOCI];

/* for debugging */
double OSx1[MAXLOCI],OSx2[MAXLOCI],OSs[MAXLOCI],OSf[MAXLOCI];
double MSx1[MAXLOCI],MSx2[MAXLOCI],MSs[MAXLOCI],MSf[MAXLOCI];

double an[MAXSEQS+1],choose2[MAXSEQS+1],*array1[MAXLOCI],*array2[MAXLOCI],**table1[MAXLOCI],**table2[MAXLOCI];

char species0[11],species1[11],locusname[MAXLOCI][11];
FILE  *dfile, *rfile;  /*data and results files*/
char  dname[80],rname[80],comment[101];
boolean  Ip,Rp,Mp,Sp, Ap, Lp;
char  extracomments[10][101];
char message[81];
int num_extracomments;
int        numsims,numsimsok,numsimsnofixed,numsimsnoshared;
float      mrate, gentime;
double    *aparams, afrac[MAXLOCI];  
double     frac[MAXLOCI];
double    *params;
int       numparams;
int   lowpoint, highpoint;
float lowpercent, highpercent;

float valconflimits[MAXLOCI+10+1][LIMITMAX];
float valstats[MAXLOCI+10+1][2];
char  valnames[MAXLOCI+10+1][16] = {
	"\0",
	"Theta1         \0",
	"Theta2         \0",
	"ThetaA         \0",
	"tau            \0",
	"T (tau/theta1 )\0",
	"N  Species 1   \0",
	"N  Species 2   \0",
	"N  Ancestor    \0",
	"Speciation(yrs)\0"
};
/* 95% confidence limits of estimated parameters.
positions 0-lowup are for low values, highdown-LimitMAx for high values 

val 1 thru 4 are basic theta1, theta1, thetaA, tau
val 5 is T = tau/theta1
val 6 is N for species 1
val 7 is N for species 2
val 8 is N for ancestor
val 9 is the time since the speciation event
val 10 thur 10 and numloci-1 are the scalars for the loci, the first of these must be calculated each time from the others
*/

/*4 measures of  LD, for each species
Among All sites
Among S's
Among O's
Between S's and O's
also test values read in from data file */
float LDobs_scores[SLESSOS+1][MAXLOCI][2];
float  LDscores_mean[2][SLESSOS+1],LDscores_std[2][SLESSOS+1];
float   LDtests_mean[2][SLESSOS+1][3], LDtests_std[2][SLESSOS+1][3]; /* 1st index - species; 2nd index, 1:simmean, 2:sim%high 3:sim% low*/
int ntests[2][SLESSOS+1];
int   LDtests_mean_count[2][SLESSOS+1], LDtests_std_count[2][SLESSOS+1];
float LDA[MAXLOCI][2],LDS[MAXLOCI][2],LDO[MAXLOCI][2],LDOS[MAXLOCI][2],LDSS[MAXLOCI][2];
/* AL- all, SL- shared, OL, non-shared, OSL, between shared and nonshared, SLESSOL  - SLESSO,   SLESSOSL - SLESSOS */
enum {AL,SL,OL,OSL,SLESSOL,SLESSOSL};
/* LDlocus_mean records mean values for each locus. LDlocus_test records the number of simulations higher than obs mean */;
float LDlocus_mean[SLESSOSL+1][MAXLOCI][2];
int   LDlocus_n[SLESSOSL+1][MAXLOCI][2],LDlocus_test[SLESSOSL+1][MAXLOCI][2];

/*
old types of comparisons 
SoverA  LD among shared polys divided by LD among all polys
SoverO  LD among Shared Polys divided by LD among non-shared Polys
SSoverO  LD among shared, and between shared and non-shared divided by LD among non-shared
SlessOS  LD among shared minus LD among non-shared
Shared   simply LD among shared
SDiff   The absolute value of the difference between LD among shared for one species and LD among shared for the second species
SlessOSoverA  (LD among shared minus LD among non-shared) divided by  LD among all.
*/

/* reduced set {SHARED, SLESSOS} */

float MLDA[2],MLDS[2],MLDO[2],MLDOS[2],MLDSS[2];
float VLDA[2],VLDS[2],VLDO[2],VLDOS[2],VLDSS[2];
int   nLDA[2],nLDS[2],nLDO[2],nLDOS[2],nLDSS[2];


int lowup, highdown;
/* for splitting valconflimits into two parts one for upper and one for lower */
double  avalcs, pavalcs, avalwh, pavalwh;
       
int LDmeasure = -1, LDi;
boolean LDtest[SLESSOS+1];

char templine[301];

/** prototype  **/ 

void MyError(error_text)
char  error_text[];
{
	fprintf(stderr,"\nJoe Mamas run-time error...\n");
	fprintf(stderr,"\n\t%s\n",error_text);
	fprintf(stderr,"\n...now exiting to system...\n\n");
	exit(1);
}



#ifdef EXTRADEBUG
void myassert(unsigned short isit){
   if (!isit){
      fclose(rfile);
      exit(0);
   }
}
#endif

void myFPEsig(int sig){
   if (rfile) {
      FP"\n floating point crash \n");
      fclose(rfile);
   }
   printf("floating point crash \n");
    exit(0);
}
void mySEGVsig(int sig){
   if (rfile) {
      FP"\n memory crash \n");
      fclose(rfile);
   }
   printf("memory crash \n");
    exit(0);
}

void establish_signal_handler(void){
   signal(SIGFPE,myFPEsig);
   signal(SIGSEGV,mySEGVsig);
}   

void AllocateGlobals(num)
int num;
{
	int i;

	for(i=0;i<num;i++) {
		if(!(array1[i] = (double *)malloc((size_t)(nseqs1[i]+1)*(nseqs1[i]+1)*sizeof(double)))) MyError("memory for array1");
		if(!(table1[i] = (double **)malloc((size_t)(nseqs1[i]+1)*sizeof(double *)))) MyError("memory for table1");
		if(!(array2[i] = (double *)malloc((size_t)(nseqs2[i]+1)*(nseqs2[i]+1)*sizeof(double)))) MyError("memory for array2");
		if(!(table2[i] = (double **)malloc((size_t)(nseqs2[i]+1)*sizeof(double *)))) MyError("memory for table2");
	}
}

void FreeGlobals(num)
int num;
{
	int i;
	for(i=0;i<num;i++) {
		free( (void *)table1[i] );
		free( (void *)table2[i] );
		free( (void *)array1[i] );
		free( (void *)array2[i] );
	}
}

double sum1over(n) 
int n;
{
	int i;
	double sum;

	sum = 0.0; 
	if(n > 1)
		for(i=1;i<n;i++) 
			sum += 1.0/((double)i);
	return sum;
}

double term(i,j)
int i,j;
{
	double di,dj;

	if(i < 2 || j < 2) MyError("problem in term");
	di = (double)i;
	dj = (double)j;
	return (di*(di-1.0))/(dj*(dj-1.0));
}

double myprod(n,nt,i) 
int n,nt,i;
{
	int j;
	double product;

	product = 1.0;
	for(j=nt;j<i;j++)
		product *= 1.0 - term(i,j);
	for(j=i+1;j<=n;j++)
		product *= 1.0 - term(i,j);

	return product;
}

double gammln(xx)
double xx;
{
	double x,y,tmp,ser;
	static double cof[6]={76.18009172947146,-86.50532032941677,
		24.01409824083091,-1.231739572450155,
		0.1208650973866179e-2,-0.5395239384953e-5};
	int j;

	y=x=xx;
	tmp=x+5.5;
	tmp -= (x+0.5)*log(tmp);
	ser=1.000000000190015;
	for (j=0;j<=5;j++) ser += cof[j]/++y;
	return -tmp+log(2.5066282746310005*ser/x);
}

double factln(n)
int n;
{
	static double a[101];

	if(n < 0) MyError("negative factorial in factln");
	if(n <= 1) return 0.0;
	if(n <= 100) return a[n] ? a[n] : (a[n]=gammln(n+1.0));
	else return gammln(n+1.0);
}

double bico(n,k)
int n,k;
{
	return floor(0.5+exp(factln(n)-factln(k)-factln(n-k)));
}

void MakeTables(num)
int num;
{
	int x,y,z;

	an[1] = 0.0; 
	for(x=2;x<=(MAXSEQS);x++) {
		an[x] = sum1over(x); 
		choose2[x] = bico(x,2);
	}
	for(z=0;z<num;z++) {
		for(x=0;x<(nseqs1[z]+1);x++) { 
			table1[z][x] = array1[z] + (x*(nseqs1[z]+1));
			if(x>=2)
				for(y=2;y<(nseqs1[z]+1);y++) 
					table1[z][x][y] = myprod(nseqs1[z],x,y); 
		}
		for(x=0;x<(nseqs2[z]+1);x++) { 
			table2[z][x] = array2[z] + (x*(nseqs2[z]+1));
			if(x>=2)
				for(y=2;y<(nseqs2[z]+1);y++) 
					table2[z][x][y] = myprod(nseqs2[z],x,y); 
		}
	}
}

double P1(num,n1,nt1,t1) 
int num,n1,nt1;
double t1;
{
	int i;
	double sum;

	sum = 0.0; 
	if(nt1 == 1) {
		for(i=2;i<=n1;i++)
			sum += exp(-choose2[i]*t1)/table1[num][2][i];
		return (1.0 - sum);
	} else {
		for(i=nt1;i<=n1;i++)
			sum += choose2[i]*exp(-choose2[i]*t1)/table1[num][nt1][i];
			return (sum/choose2[nt1]);
	}
}

double P2(num,n2,nt2,t2) 
int num,n2,nt2;
double t2;
{
	int i;
	double sum;

	sum = 0.0; 
	if(nt2 == 1) {
		for(i=2;i<=n2;i++)
			sum += exp(-choose2[i]*t2)/table2[num][2][i];
		return (1.0 - sum);
	} else {
		for(i=nt2;i<=n2;i++)
			sum += choose2[i]*exp(-choose2[i]*t2)/table2[num][nt2][i];
			return (sum/choose2[nt2]);
	}
}

void Calculate(num,n1,n2,theta1,theta2,thetaA,tau,ESx1p,ESx2p,ESsp,ESfp) 
int num,n1,n2;
double theta1,theta2,thetaA,tau;
double *ESx1p,*ESx2p,*ESsp,*ESfp;
{
	int i,n1t,n2t;
	double t1,t2,sumleft1,sumleft2,sum1,sum2,sumf,sums,prob,fix;

	t1 = 2.0*tau/theta1;
	t2 = 2.0*tau/theta2;
	sumleft1 = 0.0; 
	for(i=2;i<=n1;i++) 
		sumleft1 += (1.0 - exp(-choose2[i]*t1))/(choose2[i]*table1[num][2][i]);
	sumleft2 = 0.0; 
	for(i=2;i<=n2;i++) 
		sumleft2 += (1.0 - exp(-choose2[i]*t2))/(choose2[i]*table2[num][2][i]);
	sum1 = 0.0;
	sum2 = 0.0;
	sums = 0.0;
	sumf = 0.0;
	for(n1t=1;n1t<=n1;n1t++) 
		for(n2t=1;n2t<=n2;n2t++) {
			prob = P1(num,n1,n1t,2.0*tau/theta1)*P2(num,n2,n2t,2.0*tau/theta2); 
			fix = (1.0/((double)n1t) + 1.0/((double)n2t))/bico(n1t+n2t,n1t); 
			sum1 += prob*(an[n1t+n2t] - fix - an[n2t] - an[n1t]*theta1/thetaA); 
			sum2 += prob*(an[n1t+n2t] - fix - an[n1t] - an[n2t]*theta2/thetaA); 
			sums += prob*(an[n1t] + an[n2t] + fix - an[n1t+n2t]); 
			sumf += prob*fix; 
	}
	*ESx1p = theta1*an[n1] + thetaA*sum1;
	*ESx2p = theta2*an[n2] + thetaA*sum2;
	*ESsp = thetaA*sums;
	*ESfp = 2.0*tau - theta1*sumleft1/2.0 - theta2*sumleft2/2.0 + thetaA*sumf;
}

void FunkMe(int n,double *p,double *f)
{
	int x;
	double LESx1,LESx2,LESs,LESf;
	double S[MAXLOCI];
	double  all,localfrac[MAXLOCI];

	for(x=1;x<=n;x++) {
		p[x] = fabs(p[x]); 
		f[x] = 0.0;
	}
	all = 1.0;
	for(x=5;x<=n;x++)
		all += p[x];
	localfrac[0] = 1.0/all;
	for(x=5;x<=n;x++)
		localfrac[x-4] = p[x]/all;
	for(x=0;x<numloci;x++) {
		Calculate(x,nseqs1[x],nseqs2[x],localfrac[x]*pN[x]*p[1],localfrac[x]*pN[x]*p[2],localfrac[x]*pN[x]*p[3],localfrac[x]*p[4],&LESx1,&LESx2,&LESs,&LESf); 
		f[1] += LESx1 - Sx1[x];
		f[2] += LESx2 - Sx2[x];
		f[3] += LESs - Ss[x];
		f[4] += LESf - Sf[x]; 
		S[x] = LESx1 + LESx2 + LESs + LESf;
	}
	for(x=5;x<=n;x++) 
		f[x] += S[x-4] - (Sx1[x-4] + Sx2[x-4] + Ss[x-4] + Sf[x-4]);
} 

/* Delete the substring of length "len" at index "pos" from "s".
   Delete less if out-of-range. */
void strdelete(char *s,int pos,int len)
{
    int slen;

    if (--pos < 0)
        return;
    slen = strlen(s) - pos;
    if (slen <= 0)
        return;
    s += pos;
    if (slen <= len) {
        *s = 0;
        return;
    }
    while ((*s = s[len])) s++;
}

void getdata(int argc, char *argv[]){
static int i;
static char  ch,*chpt;
static char  pstr[256];
char LDmeasure_ch[1],tempch, *temp;
unsigned long seed_for_ran1;


Ip = _false;
Rp = _false;
Mp = _false;
Sp = _false;
Lp = _false;
Ap = _false;
numsims = 0;
numsimsok = 0;
numsimsnofixed = 0;
numsimsnoshared = 0;
for (i=0;i< SLESSOS + 1; i++) LDtest[i] = _false;
for (i = 1; i < argc; i++) {
    strcpy(pstr, argv[i]);
    ch = pstr[0];
    if (ch == '-' || ch == '/' || ch == '\\'){
     ch = pstr[1];
     strdelete(pstr,1,2);
    } else {
      ch = pstr[0];
      strdelete(pstr,1,1);
    }
    switch (toupper(ch)) {
	case 'M':
	  sprintf(message, "%s", pstr);
	  Mp = _true;
	  break;
    case 'I':
    case 'D':
      sprintf(dname, "%s", pstr);
	  Ip = _true;
      break;
    case 'R':
      sprintf(rname, "%s", pstr);
	  Rp = _true;
      break;
	case 'L':
		Lp = _true;
		LDtest[0] = _true;
		LDtest[1] = _true;
		LDtest[2] = _true;
		switch (toupper(pstr[0])){
		case 'R':
			LDmeasure = LDR;
			break;
		case 'S':
			LDmeasure = LDRS;
			break;
		case 'P' :
			LDmeasure = LDDP;
			break;
		case 'D' :
			LDmeasure = LDD;
			break;
		case 'B' :
			LDmeasure = LDABS;
			break;
		}
		break;
	case 'S':
       numsims = atoi(&pstr[0]);
	   if (numsims > 0) Sp = _true;
       break;
    case 'A' :
        seed_for_ran1 = atoi(&pstr[0]);
        if (!seed_for_ran1) seed_for_ran1 = 1;
		Ap = _true;
        /*srand(seed_for_ran1); */
        break;
	}
}
printf("*********  WH PROGRAM FOR ISOLATION MODEL FITTING *******\n\n");
if (!Ip) {
   printf("NAME OF INPUT DATA FILE : \n");
   gets(templine);
   if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
   sscanf(templine,"%s",dname);
}
if ((dfile = fopen(dname,"r")) == NULL){
	    printf("Error opening text file for reading\n"); exit(0);}

if (!Ap) seed_for_ran1 = time(NULL);;
idumval = - seed_for_ran1;
idum = &idumval;
ran1(idum);

if (!Rp) {
   printf("NAME OF RESULTS FILE : \n");
   gets(templine);
   if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
   sscanf(templine,"%s",rname);
}
if (strlen(rname) > (_FNSIZE-4)) strdelete(rname, _FNSIZE-3, _FNSIZE);
strcat(rname, ".wh");
	
if (!Sp){
		printf("ENTER THE NUMBER OF SIMULATIONS: \n");
		gets(templine);
		if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
		sscanf(templine,"%d",&numsims);
		if (numsims > 0) Sp = _true;
}
if (!Mp){
   *message = '\0';
   printf("TYPE A MESSAGE TO HEAD THE OUTPUT FILE : \n");
   /*scanf("%s",message); */
   fgets(message, 81, stdin);
   chpt = strchr(message, '\n');
   if (chpt != NULL) *chpt = 0; 
}


fgets(comment,100,dfile);
if (comment[strlen(comment)-1] == '\n') comment[strlen(comment)-1] = '\0';
num_extracomments=0;
do{
	do{fgets(templine, 300, dfile);
	} while (templine[0] == '\n');
	if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
	if (templine[0]=='#'){
		strcpy(extracomments[num_extracomments],&templine[1]);
		num_extracomments++;
	}
}while (templine[0]=='#');


/*fgets(comment,100,dfile);
num_extracomments=0;
do{
fgets(templine, 300, dfile);
temp = strchr(templine, '\n');
if (temp != NULL) *temp = 0;
   else  do{
          tempch = getc(dfile);
        } while (tempch != '\n');
if (templine[0]=='#'){
   strcpy(extracomments[num_extracomments],&templine[1]);
   num_extracomments++;
   }
} while (templine[0]=='#');
*/
mrate = -1.0;
gentime = -1.0;
sscanf(templine, "%d%f%f%s",&numloci,&mrate,&gentime);
/*sscanf(templine, "%d%f%f%s%*[^\n]",&numloci,&mrate,&gentime); */

if (Sp &&!Lp) {
	 printf("DO LINKAGE DISEQUILIBRIUM ANALYSIS y/n  \n");
	 gets(templine);
	 if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
	 sscanf(templine,"%c",&ch); 
/*
	 scanf("%c%*[^\n]", &ch);
	 getchar(); */
     if (toupper(ch) == 'Y'){
		 Lp = _true;
		 LDtest[0] = _true;
		 LDtest[1] = _true;
		 LDtest[2] = _true;
	 }
}
if (Lp && LDmeasure == -1){
	 printf("WHICH MEASURE OF LD? 'D','P','B','R' or 'S'  Enter appropriate letter:\n");
	 printf(" D - basic disequilibrium measure   P - D' = D/Dmax   B - Absolute Value |D|\n");
	 printf(" R- correlation coefficient  S - (correlation coefficient)^2 \n");
	 gets(templine);
	 if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
	 sscanf(templine,"%c",&ch); 
	 /*scanf("%c%*[^\n]", &ch);
	 getchar(); */
	 switch (toupper(ch)){
		case 'R':
			LDmeasure = LDR;
			break;
		case 'S':
			LDmeasure = LDRS;
			break;
		case 'P' :
			LDmeasure = LDDP;
			break;
		case 'D' :
			LDmeasure = LDD;
			break;
		case 'B' :
			LDmeasure = LDABS;
			break;
	}
}
printf("Simulation Number \n");
if (numloci > MAXLOCI) {
	printf("TOO MANY LOCI IN DATA FILE. LIMIT IS %d\n", MAXLOCI);
    exit(0);
    }
fgets(templine, 200, dfile);
if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
sscanf(templine,"%10s %10s",species0,species1);
/*fscanf(dfile,"%10s %10s \n",species0, species1); */

/*enum {SHARED,SLESSO,SLESSOS}; */

for (i=0;i<= numloci-1; i++){
	   if (Sp){
			 fgets(templine,300,dfile);
			 if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
			 sscanf(templine,"%10s %lf %lf %d %d %lf %lf %lf %lf %lf %lf %f %f %f %f %f %f",
			   &locusname[i],&pN[i],&l[i],&nseqs1[i],&nseqs2[i],&Sx1[i],&Sx2[i],&Ss[i],&Sf[i],&c1s[i],&c2s[i],
			   &LDobs_scores[SHARED][i][0],&LDobs_scores[SHARED][i][1],
			   &LDobs_scores[SLESSO][i][0],&LDobs_scores[SLESSO][i][1],
			   &LDobs_scores[SLESSOS][i][0],&LDobs_scores[SLESSOS][i][1]);
			 for(LDi = 0; LDi <= SLESSOS; LDi++){
				 if (LDobs_scores[LDi][i][0] <= -9.9) LDobs_scores[LDi][i][0] = Dfault;
				 if (LDobs_scores[LDi][i][1] <= -9.9) LDobs_scores[LDi][i][1] = Dfault;
			 }
	   }else {
  			 fgets(templine,300,dfile);
			 if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
			 sscanf(templine,"%10s %lf %lf %d %d %lf %lf %lf %lf",
			   &locusname[i],&pN[i],&l[i],&nseqs1[i],&nseqs2[i],&Sx1[i],&Sx2[i],&Ss[i],&Sf[i]);
	   }
   }
for(i=1; i<= numloci; i++) {
	strcpy(valnames[9+i],locusname[i-1]);
	strcat(valnames[9+i]," frac");
}

fclose(dfile);
} /* getdata */


int findparams(void){
	int i, checknewt, checkbroydn,check;
	double all;
	double *holdparams;

	
   	AllocateGlobals(numloci);
	MakeTables(numloci); 
	params = (double *)malloc( (numparams+1)*sizeof(double) );
	params[1] = 10.0; 
	params[2] = 10.0; 
	params[3] = 10.0; 
	params[4] = 10.0;
	for(i=1;i<numloci;i++) 
		params[4+i] = 1.0; 
	newt(params,numparams,&checknewt,FunkMe); 
	check= checknewt; 
	if (check != 0){ /* try another method */
		holdparams = (double *)malloc( (numparams+1)*sizeof(double) );
		for (i=1; i< numloci+4;i++) holdparams[i] = params[i];
		params[1] = 10.0; 
		params[2] = 10.0; 
		params[3] = 10.0; 
		params[4] = 10.0;
		for(i=1;i<numloci;i++) 
			params[4+i] = 1.0; 
		broydn(params,numparams,&checkbroydn,FunkMe); 
		check = checkbroydn; 
	}
 	all = 1.0; 
	for(i=1;i<numloci;i++) 
		all += params[4+i]; 
	frac[0] = 1.0/all;
	for(i=1;i<numloci;i++) 
		frac[i] = params[i+4]/all;
	for(i=0;i<numloci;i++) {
		Calculate(i,nseqs1[i],nseqs2[i],frac[i]*pN[i]*params[1],frac[i]*pN[i]*params[2],frac[i]*pN[i]*params[3],frac[i]*params[4],&ESx1[i],&ESx2[i],&ESs[i],&ESf[i]);
	}
	return(check);
}


void writestuff1(int check){
	int i;
	
	if ((rfile = fopen(rname,"w")) == NULL){
        printf("Error opening text file for writing\n"); exit(0);}
	FP"*********  WH PROGRAM FOR ISOLATION MODEL FITTING *******\n\n");
	FP"Wakeley, J., and J. Hey, 1997 Estimating ancestral population parameters. Genetics 145: 847-855.\n");
	FP"Wang, R. L., J. Wakeley and J. Hey, 1997	Gene flow and natural selection in the origin of Drosophila pseudoobscura and close relatives. Genetics 147: 1091-1106.\n\n");
	FP"Data file : %s     This output file : %s \n\n",dname,rname);
	FP"******** INPUT ********\n\n");
	FP"\nData file header : %s\n\n",comment);
	if (num_extracomments > 0){
		FP"Additional text from data file : \n");
		for (i=0;i< num_extracomments;i++){
			FP"  %s\n",extracomments[i]);
		}
		FP"\n\n");
	}
	FP"MESSAGE ADDED AT RUNTIME: \n %s \n\n", message);
	FP"Species, Loci, Sample Sizes and Polymorphism Counts\n");
	FP"---------------------------------------------------\n");
	FP"  Loci                ");
	for(i=0;i<numloci;i++) FP"%10s ",locusname[i]); 
	FP"\n");
	FP"species0 = %10s",species0);
	for(i=0;i<numloci;i++) FP"%11d",nseqs1[i]); 
	FP"\n");
	FP"species1 = %10s",species1);
	for(i=0;i<numloci;i++) FP"%11d",nseqs2[i]); 
	FP"\n");
	FP"  Sx1                 ");
	for(i=0;i<numloci;i++) FP"%11.1f",Sx1[i]); 
	FP"\n");
	FP"  Sx2                 ");
	for(i=0;i<numloci;i++) FP"%11.1f",Sx2[i]); 
	FP"\n");
	FP"  Ss                  ");
	for(i=0;i<numloci;i++) FP"%11.1f",Ss[i]); 
	FP"\n");
	FP"  Sf                  ");
	for(i=0;i<numloci;i++) FP"%11.1f",Sf[i]); 
	FP"\n\n");
	if (numsims>0){
		FP"Population recombination values (4Nc) given and used in simulations\n");
		FP"-------------------------------------------------------------------\n");
		FP"      Locus    species0: given  used   species1:  given used    Ancestor\n");
		for (i=0;i<=numloci-1;i++){
			FP" %10s        %8.4f %8.4f       %8.4f %8.4f    %8.4f \n",locusname[i],c1s[i],c1[i],c2s[i],c2[i],ca[i]);
		}
		FP"\n\n");
	}
	if (mrate < 0.0) FP"Total mutation rate per year not provided \n");
	else FP"Given total mutation rate per year : %e \n",mrate);
	if (gentime < 0.0) FP"Generation time not provided \n");
	else FP"Given generation time, in years : %6.1f \n\n",gentime);

	FP"******** MODEL FITTING RESULTS ********\n\n");
	FP"Basic Parameter Estimates \n");
	FP"------------------------- \n");
	FP"\n\tTheta1 est = %10.6f;\n",params[1]);
	FP"\tTheta2 est = %10.6f;\n",params[2]);
	FP"\tThetaA est = %10.6f;\n",params[3]);
	//FP"\ttau est    = %10.6f;\n",2.0*params[4]);
    // for some reason was printing out 2.0 * tau  - no sure why   jh 9/15/04
    FP"\ttau est    = %10.6f;\n",params[4]);
	for(i=0;i<numloci;i++) 
		FP"\tf[%d]    = %10.6f;\n",i,frac[i]);
	puts("\n");
	if( check != 0 ) FP"\n Warning: this is likely a local minimum!\n");
	FP"\n");
	FP"Locus Specific Parameter Values \n");
	for(i=0;i<numloci;i++) FP"\t%10s ",locusname[i]); 
	FP"\n");
	FP"Theta1:");
	for(i=0;i<numloci;i++) FP"\t%10.6f ",frac[i]*pN[i]*params[1]); 
	FP"\n");
	FP"Theta2:");
	for(i=0;i<numloci;i++) FP"\t%10.6f ",frac[i]*pN[i]*params[2]); 
	FP"\n");
	FP"ThetaA:");
	for(i=0;i<numloci;i++) FP"\t%10.6f ",frac[i]*pN[i]*params[3]); 
	FP"\n");
	FP"tau   :");
	//for(i=0;i<numloci;i++) FP"\t%10.6f ",2.0*frac[i]*params[4]); 
    // for some reason was printing out 2.0 * tau  - no sure why   jh 9/15/04
    for(i=0;i<numloci;i++) FP"\t%10.6f ",frac[i]*params[4]); 
	FP"\n\n");
	FP"Expected Polymorphism Levels \n");
	FP"----------------------------\n");
	FP"   Locus   \t%10s\t%10s\t%10s\t%10s\n\n","Sx1","Sx2","Ss","Sf"); 
	for(i=0;i<numloci;i++) {
		FP" %10s Obs.\t%10.6f\t%10.6f\t%10.6f\t%10.6f\n",locusname[i],Sx1[i],Sx2[i],Ss[i],Sf[i]); 
		FP" %10s Exp.\t%10.6f\t%10.6f\t%10.6f\t%10.6f\n\n",locusname[i],ESx1[i],ESx2[i],ESs[i],ESf[i]); 
	}
	puts("\n\n");
	FP"Other Calculations \n");
	FP"------------------ \n");
	FP"\t T est (tau/Theta1)= %12.4f \n",params[4]/params[1]);
	if (mrate >=0.0) FP"\t N Species 1       = %12.1f \n", params[1]/(mrate * gentime));
	if (mrate >=0.0) FP"\t N Species 2       = %12.1f \n", params[2]/(mrate * gentime));
	if (mrate >=0.0) FP"\t N Ancestral       = %12.1f \n", params[3]/(mrate * gentime));
	if (mrate >=0.0) FP"\t Speciation (years)= %12.1f \n", params[4]/(2*mrate));
	FP"\n\n");


	fflush(stdout); 
	fclose(rfile);
} /* writestuff1 */

/*
vals 1thru 4 are basic theta1, theta1, thetaA, tau
vals 5 is T = tau/theta1
vals  6 is N for species 1
vals 7 is N for species 2
vals 8 is N for ancestor
vals 9 is the time since the speciation event
vals 10 thur 10 and numloci-1 are the scalars for the loci, the first of these must be calculated each time from the others
*/

void findlimits(void){
 int i,j,k, numvals;
 float  all, vals[MAXLOCI+10];

 numvals = numloci + 9;
 for (i=1; i<= 4;i++) vals[i] = params[i];
 vals[5] = vals[4]/vals[1];
 vals[6] = vals[1]/(mrate*gentime);
 vals[7] = vals[2]/(mrate*gentime);
 vals[8] = vals[3]/(mrate*gentime);
 vals[9] = vals[4]/(2*mrate);
 all = 1.0;
 for(i=5;i<=numparams;i++) all += params[i];
 vals[10] = 1.0/all;
 for(i=11;i<=11+numloci-1;i++) vals[i] = params[i-6]/all;
		
 for (i=1;i <= numvals; i++){
     j = 0;
     while ( ( vals[i] >= valconflimits[i][j]) && (j<= lowpoint)) j++;
     if (j <= lowpoint){
         k = j;
         for(j=lowpoint;j > k; j--) valconflimits[i][j] = valconflimits[i][j-1];
         valconflimits[i][k] = vals[i];
         }
     j = LIMITMAX - 1;
     while ( (vals[i] <= valconflimits[i][j]) && (j>= highpoint)) j--;
      if (j >= highpoint){
         k=j;
         for(j=highpoint; j < k; j++) valconflimits[i][j] = valconflimits[i][j+1];
         valconflimits[i][k] = vals[i];
         }
     valstats[i][0] += vals[i];
     valstats[i][1] += SQR(vals[i]);
     }
} /* findlimits */

void  testval(int datatype){
	int i,j,k;
	double temp, sum;
	int hi_f,lo_f,hi_s,lo_s;
	float tma,tmo,tms,tmos,tmss,tms_less_o,tms_less_os;
	float tva,tvo,tvs,tvos,tvss,tvs_less_o,tvs_less_os;
	float na,no,ns,nos,nss,ns_less_o,ns_less_os;
	/*
	float tma,tmo,tms,tmos,tmss,tms_o,tms_a,tmss_o,tms_less_os,tmdiff,tms_less_os_a;
	float tva,tvo,tvs,tvos,tvss,tvs_o,tvs_a,tvss_o,tvs_less_os,tvdiff,tvs_less_os_a;
	float na,no,ns,nos,nss,ns_o,ns_a,nss_o,ns_less_os,ndiff,ns_less_os_a;
  */
	float testmean[2], teststd[2];
	float  om[2];
/*first calculate the chisq test stat*/
	sum = 0.0;
	for (i=0; i<= numloci-1;i++){
		temp = SQR(Sx1[i] - ESx1[i])/ ESx1[i];
		sum += temp;
		temp = SQR(Sx2[i] - ESx2[i])/ ESx2[i];
		sum += temp;
		temp = SQR(Ss[i] - ESs[i])/ ESs[i];
		sum += temp;
		temp = SQR(Sf[i] - ESf[i])/ ESf[i];
		sum += temp;
	}
	if (datatype ) {
		avalcs = sum;
		pavalcs = 0.0;
	}
	else pavalcs += sum > avalcs;
/* now calculate the wh test stat */
	hi_f = 0;hi_s=0;lo_f = 1000;lo_s=1000;
	for (i=0; i<= numloci-1;i++){
		if (Ss[i] > hi_s) hi_s = Ss[i];
		if (Ss[i] < lo_s) lo_s = Ss[i];
		if (Sf[i] > hi_f) hi_f = Sf[i];
		if (Sf[i] < lo_f) lo_f = Sf[i];
	}
	temp = (hi_f - lo_f) + (hi_s - lo_s);
	if (datatype) {
		avalwh = temp;
		pavalwh = 0.0;
	}
	else pavalwh += temp > avalwh;
/* now deal with LD measures */
	if (datatype){
		for (i=0;i< 2;i++){
			nLDA[i] = 0;
			nLDO[i] = 0;
			nLDS[i] = 0;
			nLDOS[i] = 0;
			nLDSS[i] = 0;
			for(LDi = 0; LDi <= SLESSOS; LDi++)
			if (LDtest[LDi]){
				ntests[i][LDi] = 0;
				LDtests_mean[i][LDi][0] = 0.0;
				LDtests_mean[i][LDi][1] = 0.0;
				LDtests_mean[i][LDi][2] = 0.0;
				LDscores_mean[i][LDi] = 0.0;
				LDscores_std[i][LDi] = 0.0;
				LDtests_std[i][LDi][0] = 0.0;
				LDtests_std[i][LDi][1] = 0.0;
				LDtests_std[i][LDi][2] = 0.0;
			}
			MLDA[i] = 0.0;
			MLDO[i] = 0.0;
			MLDS[i] = 0.0;
			MLDOS[i] = 0.0;
			MLDSS[i] = 0.0;
			VLDA[i] = 0.0;
			VLDO[i] = 0.0;
			VLDS[i] = 0.0;
			VLDOS[i] = 0.0;
			VLDSS[i] = 0.0;
			for (j = 0;j<=SLESSOSL;j++) for (k=0;k< MAXLOCI;k++){
				LDlocus_mean[j][k][i] = 0.0;
				LDlocus_test[j][k][i] = 0;
				LDlocus_n[j][k][i] = 0;
			}
		}
		for(LDi = 0; LDi <= SLESSOS; LDi++)
			if (LDtest[LDi]) {
				/*if (LDi != SDiff)*/
				  for (i=0;i< 2;i++){
					om[i] = 0;
					for (j=0;j<numloci;j++)	if (LDobs_scores[LDi][j][i] < Dfault_check){
							om[i]++;
							LDscores_mean[i][LDi] += LDobs_scores[LDi][j][i];
							LDscores_std[i][LDi] += SQR(LDobs_scores[LDi][j][i]);
						}
					if (om[i]>0){
						LDscores_mean[i][LDi] /= om[i];
						if (om[i]>1) LDscores_std[i][LDi] = sqrt((LDscores_std[i][LDi]- om[i]*SQR(LDscores_mean[i][LDi]))/(om[i]-1));
						  else LDscores_std[i][LDi] = 0.0;
					}
				  }
		} 
	}
	else {
		for (i=0;i< 2;i++){
			na = 0;no = 0;ns=0;nos=0;nss=0;ns_less_o=0;ns_less_os=0;
			tma =0.0;tmo=0.0;tms=0.0;tmos=0.0;tmss=0.0;tms_less_o=0.0;tms_less_os=0.0;
			tva =0.0;tvo=0.0;tvs=0.0;tvos=0.0;tvss=0.0;tvs_less_o=0.0;tvs_less_os=0.0;
			for (j=0;j <numloci;j++){
				if (LDA[j][i] < Dfault_check){
					na++;
					LDlocus_mean[AL][j][i] +=LDA[j][i];
					LDlocus_n[AL][j][i]++;
					tma +=LDA[j][i];
					tva +=SQR(LDA[j][i]);
				}
				if (LDO[j][i] < Dfault_check){
					no++;
					LDlocus_mean[OL][j][i] +=LDO[j][i];
					LDlocus_n[OL][j][i]++;
					tmo += LDO[j][i];
					tvo += SQR(LDO[j][i]);
				}
				if (LDS[j][i] < Dfault_check){
					ns++;
					LDlocus_mean[SL][j][i] +=LDS[j][i];
					LDlocus_n[SL][j][i]++;
					if (LDS[j][i] > LDobs_scores[SHARED][j][i]) LDlocus_test[SL][j][i]++;
					tms += LDS[j][i];
					tvs += SQR(LDS[j][i]);
				}
				if (LDOS[j][i] < Dfault_check){
					nos++;
					LDlocus_mean[OSL][j][i] +=LDOS[j][i];
					LDlocus_n[OSL][j][i]++;
					tmos += LDOS[j][i];
					tvos += SQR(LDOS[j][i]);
				}
				if (LDSS[j][i] < Dfault_check){
					nss++;
					tmss += LDSS[j][i];
					tvss += SQR(LDSS[j][i]);
				}
				if ((LDS[j][i]< Dfault_check)&&(LDO[j][i]< Dfault_check)){
					ns_less_o++;
					LDlocus_mean[SLESSOL][j][i] += LDS[j][i] - LDO[j][i];
					LDlocus_n[SLESSOL][j][i]++;
					if ((LDS[j][i] - LDO[j][i]) > LDobs_scores[SLESSO][j][i]) LDlocus_test[SLESSOL][j][i]++;
					tms_less_o += LDS[j][i] - LDO[j][i];
					tvs_less_o += SQR(LDS[j][i] - LDO[j][i]);
				}
				if ((LDS[j][i]< Dfault_check)&&(LDOS[j][i]< Dfault_check)){
					ns_less_os++;
					LDlocus_mean[SLESSOSL][j][i] += LDS[j][i] - LDOS[j][i];;
					LDlocus_n[SLESSOSL][j][i]++;
					if ((LDS[j][i] - LDOS[j][i]) > LDobs_scores[SLESSOS][j][i]) LDlocus_test[SLESSOSL][j][i]++;
					tms_less_os += LDS[j][i] - LDOS[j][i];
					tvs_less_os += SQR(LDS[j][i] - LDOS[j][i]);
				}
				
			}
			if (na>1) {MLDA[i] += tma/na;VLDA[i] += tva/na - SQR(tma/na-1);nLDA[i]++;}
			if (no>1) {MLDO[i] += tmo/no;VLDO[i] += tvo/no - SQR(tmo/no-1);nLDO[i]++;}
			if (ns>1) {MLDS[i] += tms/ns;VLDS[i] += tvs/ns - SQR(tms/ns-1);nLDS[i]++;}
			if (nos>1) {MLDOS[i] += tmos/nos;VLDOS[i] += (tvos - nos*SQR(tmos/nos))/(nos-1);nLDOS[i]++;}
			if (nss>1) {MLDSS[i] += tmss/nss;VLDSS[i] += (tvss - nss*SQR(tmss/nss))/(nss-1);nLDSS[i]++;}
			for(LDi = 0; LDi <= SLESSOS; LDi++)
				if (LDtest[LDi]){
					/* when testing SHARED */
					if (LDi==SHARED)
					  if (ns>1){
						testmean[i] = tms/ns;
						teststd[i] = sqrt(((tvs - ns*SQR(tms/ns))/(ns-1))) ;
						LDtests_mean[i][LDi][0] += testmean[i];
						LDtests_std[i][LDi][0] += teststd[i];
						ntests[i][LDi]++;
						if (testmean[i] > LDscores_mean[i][LDi]) LDtests_mean[i][LDi][1]++;
						if (testmean[i] < LDscores_mean[i][LDi]) LDtests_mean[i][LDi][2]++;
						if (teststd[i]  > LDscores_std[i][LDi])  LDtests_std[i][LDi][1]++;
						if (teststd[i]  < LDscores_std[i][LDi])  LDtests_std[i][LDi][2]++;
					}
					if (LDi==SLESSO)
					  if (ns_less_o>1){
						testmean[i] = tms_less_o/ns_less_o;
						teststd[i] = sqrt(((tvs_less_o - ns_less_o*SQR(tms_less_o/ns_less_o))/(ns_less_o-1))) ;
						LDtests_mean[i][LDi][0] += testmean[i];
						LDtests_std[i][LDi][0] += teststd[i];
						ntests[i][LDi]++;
						if (testmean[i] > LDscores_mean[i][LDi]) LDtests_mean[i][LDi][1]++;
						if (testmean[i] < LDscores_mean[i][LDi]) LDtests_mean[i][LDi][2]++;
						if (teststd[i]  > LDscores_std[i][LDi])  LDtests_std[i][LDi][1]++;
						if (teststd[i]  < LDscores_std[i][LDi])  LDtests_std[i][LDi][2]++;
					  }
					if (LDi==SLESSOS)
					  if (ns_less_os>1){
						testmean[i] = tms_less_os/ns_less_os;
						teststd[i] = sqrt(((tvs_less_os - ns_less_os*SQR(tms_less_os/ns_less_os))/(ns_less_os-1))) ;
						LDtests_mean[i][LDi][0] += testmean[i];
						LDtests_std[i][LDi][0] += teststd[i];
						ntests[i][LDi]++;
						if (testmean[i] > LDscores_mean[i][LDi]) LDtests_mean[i][LDi][1]++;
						if (testmean[i] < LDscores_mean[i][LDi]) LDtests_mean[i][LDi][2]++;
						if (teststd[i]  > LDscores_std[i][LDi])  LDtests_std[i][LDi][1]++;
						if (teststd[i]  < LDscores_std[i][LDi])  LDtests_std[i][LDi][2]++;
					  }
				}
				}
					
				}
} /* testval */

void writestuff2(void){
  int i,j,k, numvals;
  float all, vals[MAXLOCI+10];
  char LDstr[7],LDteststr[80],m;
  int check;

  numvals = numloci + 9;
  for (i=1; i<= 4;i++) vals[i] = aparams[i];
  vals[5] = vals[4]/vals[1];
  vals[6] = vals[1]/(mrate*gentime);
  vals[7] = vals[2]/(mrate*gentime);
  vals[8] = vals[3]/(mrate*gentime);
  vals[9] = vals[4]/(2*mrate);
  all = 1.0;
  for(i=5;i<=numparams;i++) all += aparams[i];
  vals[10] = 1.0/all;
  for(i=11;i<=11+numloci-1;i++) vals[i] = aparams[i-6]/all;
  /* find new points in confidence limit arrays, based on numsimsok rather than on numsims */
  if (numsimsok >0 ){
	lowup = (LIMITMAX - 2) / 2;
	highdown = lowup + 1;
	lowpoint = floor(numsimsok * 0.025) - 1;
	if (lowpoint > lowup) lowpoint = lowup;
	if (lowpoint <= 0) lowpoint = 0;
	lowpercent = ((lowpoint + 1)/ (float) numsimsok) * 100.0;
	highpoint = LIMITMAX - floor(numsimsok - (numsimsok * 0.975));
	if (highpoint >= LIMITMAX) highpoint = LIMITMAX-1;
	if (highpoint < highdown) highpoint = highdown;
	highpercent = ((numsimsok - (LIMITMAX - highpoint))/(float) numsimsok) * 100.0;
  }
  if ((rfile = fopen(rname,"a")) == NULL){
        printf("Error opening text file for appending\n"); exit(0);}
  FP"******** SIMULATION RESULTS ********\n\n");
  
  FP"Simulations attempted :  %d  \n",numsims);
  FP"\t# simulations that yielded estimates : %d  (%8.4f)\n",numsimsok, numsimsok/(float) numsims);
  FP"\t# with zero fixed differences        : %d  (%8.4f)\n",numsimsnofixed,numsimsnofixed/(float) numsims);  
  FP"\t# with zero shared differences       : %d  (%8.4f)\n\n",numsimsnoshared,numsimsnoshared/(float) numsims);  
  FP"ChiSquare test statistic value : %8.4f \n\t# successful simulations with higher values : %8.0f  (%8.4f)\n\n",avalcs,pavalcs,pavalcs/numsimsok);
  FP"wh test statistic value       : %8.4f \n\t# successful simulations with higher values : %8.0f  (%8.4f)\n\n",avalwh,pavalwh,pavalwh/numsimsok);
  if (numsimsok>0){
	FP"Estimated parameter values and statistics\n");
	FP"-----------------------------------------\n");
	FP"Parameter         Estimate   %4.1f%%   -   %4.1f%%     Mean      Variance\n",lowpercent, highpercent);
	FP"----------------  -------- --------------------  ---------   ----------\n");
	for (i=1; i <= numvals; i++)
		if (i <6 || i >9 || mrate >= 0.0) FP" %15s %9.3f %9.3f  %9.3f  %9.3f  %12.5f\n",valnames[i],vals[i],valconflimits[i][lowpoint],valconflimits[i][highpoint],\
			valstats[i][0]/numsimsok, valstats[i][1]/numsimsok - SQR(valstats[i][0]/numsimsok));
  }
  FP"\nCompare actual and simulated polymorphism levels \n");
  FP"------------------------------------------------\n");
  /*FP"      Locus    Sx1: Obs   Sim   Sx2:  Obs   Sim    Ss:  Obs    Sim   Sf:   Obs    Sim \n");
  FP"      -------      ------------     ------------       ------------       ------------ \n");
  for (i=0;i<=numloci-1;i++){
     FP" %10s        %5.1f %5.1f       %5.1f %5.1f        %5.1f %5.1f       %5.1f %5.1f\n",locusname[i],OSx1[i],MSx1[i]/numsimsok,OSx2[i],MSx2[i]/numsimsok,OSs[i],MSs[i]/numsimsok,OSf[i],MSf[i]/numsimsok);
	 }
					
  FP"\n"); */

  FP"   Locus   \t%10s\t%10s\t%10s\t%10s\n\n","Sx1","Sx2","Ss","Sf"); 
	for(i=0;i<numloci;i++) {
		FP" %10s Obs.\t%10.6f\t%10.6f\t%10.6f\t%10.6f\n",locusname[i],OSx1[i],OSx2[i],OSs[i],OSf[i]); 
		FP" %10s Sim.\t%10.6f\t%10.6f\t%10.6f\t%10.6f\n\n",locusname[i],MSx1[i]/numsimsok,MSx2[i]/numsimsok,MSs[i]/numsimsok,MSf[i]/numsimsok); 
	}
  FP"\n"); 
  if (Lp) {
	  FP"*************************\n");
	  FP"\n\nLinkage Disequilibrium Analysis\n");
	  FP"------- -------------- --------\n");

	#ifdef DEFINED_SHARED
	  FP"   - LD among polymorphisms 'Shared' between species \n");
	  FP"   - here 'Shared' includes classic shared polymorphisms, as well as those \n");
	  FP"   - for which the derived base is also fixed in the other species\n");
	  FP"   - this mimics what may appear to be an indicator of gene flow between species \n");
	#else
	  FP"   - LD among polymorphisms Shared between species \n");
	#endif
 
  
	  if (LDmeasure==LDR)  strcpy(LDstr," (r) ");
	  if (LDmeasure==LDRS) strcpy(LDstr,"(r^2)");
	  if (LDmeasure==LDD)  strcpy(LDstr," (D) ");
	  if (LDmeasure==LDDP) strcpy(LDstr," (D')");
	  if (LDmeasure==LDABS)strcpy(LDstr," (|D|)");

	  FP"\n\n Linkage Disequilibrium Measure : %s\n",LDstr);
	  FP" ------- -------------- -------    -----\n\n");
	  FP"   Simulated Mean Values of LD %s Among Polymorphic Sites\n",LDstr);
	  FP"     'A': all sites 'S': shared sites 'O': non-shared sites  'NS': pairs of shared and non-shared sites \n");
	  for (i=0;i<2 ;i++){
		if (nLDA[i]) MLDA[i] /=  nLDA[i];
		if (nLDO[i]) MLDO[i] /=  nLDO[i];
		if (nLDS[i]) MLDS[i] /=  nLDS[i];
		if (nLDOS[i]) MLDOS[i] /=  nLDOS[i];
		for (j = 0;j<=SLESSOSL;j++) for (k=0;k< numloci;k++){
			if (LDlocus_n[j][k][i]) LDlocus_mean[j][k][i] /= (float) LDlocus_n[j][k][i];
		}
	  }

	  FP"\nSpecies   A       S       O       NS \n"); 
	  for (i=0;i<2 ;i++){
		  FP" %d     % 7.3f % 7.3f % 7.3f % 7.3f\n",i,MLDA[i],MLDS[i],MLDO[i],MLDOS[i]);
	  }
	  FP"\n");

	  FP" Simulated Mean Values for each Locus \n");
	  FP" --------- ---- ------ --- ---- ----- \n");
	  FP" Species  Measure  |Loci : ");
	  for(i=0;i<numloci;i++) FP"%10s ",locusname[i]); 
	  FP"\n");
	  for (i=0;i<2;i++){
		for (j = 0;j<=OSL;j++) {
			if (j==0) m = 'A';if (j==1) m = 'S'; if (j==2) m = 'O'; if (j==3) m = 'N';
			FP" %d          %c               ",i,m);
			for(k=0;k<numloci;k++) {
				if (LDlocus_n[j][k][i])  FP"  % 7.3f  ",LDlocus_mean[j][k][i]); 
				else FP"  *******  ");
			}
			FP"\n");
		}
	  }

	  for(LDi = 0; LDi <= SLESSOS; LDi++)
	   if (LDtest[LDi]){
		  FP"\n");
  
		  if (LDi==SLESSOS) strcpy(LDteststr,"(S less OS: Difference, Both Shared less  One shared, One Not Shared)");
		  if (LDi==SLESSO) strcpy(LDteststr,"(S less O: Difference, Both Shared less  Both NON-shared)");
		  if (LDi==SHARED)  strcpy(LDteststr,"(SHARED :  LD between shared polymorphisms)");

		  /*if (LDi==SoverA) strcpy(LDteststr,"(S over A: Ratio, Both Shared over All)");
		  if (LDi==SoverO) strcpy(LDteststr,"(S over O: Ratio, Both Shared over Both Not Shared");
		  if (LDi==SSoverO) strcpy(LDteststr,"(SS over O: Ratio, Either Share over Both Not Shared)");
		  if (LDi==SlessOS) strcpy(LDteststr,"(S less O: Difference, Both Shared less  One shared, One Not Shared)");
		  if (LDi==Shared)  strcpy(LDteststr,"(SHARED :  LD between shared polymorphisms)");
		  if (LDi==SDiff)  strcpy(LDteststr,"(SHARED Diff: Difference between species for LD between shared polymorphisms)");
		  if (LDi==SlessOSoverA) strcpy(LDteststr,"(S Less O - over - A: Ratio Difference in Shareds over All)");
	*/
		  if (LDi==SHARED) j = SL;
		  if (LDi==SLESSO) j = SLESSOL;
		  if (LDi==SLESSOS) j = SLESSOSL;
		  FP"Test Statistic : %s \n\n",LDteststr);
		  FP"      Observed score values \n");
		  FP"      -------- ----- ------ \n");
		  FP"       Loci               ");
		  for(i=0;i<numloci;i++) FP"%10s ",locusname[i]); 
		  FP"\n");
		  FP"     species0 = %10s  ",species0);
		  for(i=0;i<numloci;i++) {
			  if (LDobs_scores[LDi][i][0] < Dfault_check) FP"  % 7.3f  ",LDobs_scores[LDi][i][0]); 
				else FP"  *******  ");
		  }
		  FP"\n");
		  FP"      simulated mean values:");
		  for(i=0;i<numloci;i++) {
			  if (LDlocus_n[j][i][0])  FP"  % 7.3f  ",LDlocus_mean[j][i][0]); 
				else FP"  *******  ");
		  }
		  FP"\n");
		  FP"      %% sims > observed   :");
		  for(i=0;i<numloci;i++) {
			  if (LDlocus_n[j][i][0])  FP"   % 6.1f  ",100.0 * (float) LDlocus_test[j][i][0]/ (float) LDlocus_n[j][i][0]); 
				else FP"  *******  ");
		  }
		  FP"\n");
		  FP"      # simulated values   :");
		  for(i=0;i<numloci;i++) {
			  FP"   % 4d    ",LDlocus_n[j][i][0]); 
		  }
		  FP"\n\n");

		  FP"     species1 = %10s  ",species1);
		  for(i=0;i<numloci;i++) {
			  if (LDobs_scores[LDi][i][1] < Dfault_check) FP"  % 7.3f  ",LDobs_scores[LDi][i][1]);  
				 else FP"  *******  ");
		  }
		  FP"\n");
		  FP"      simulated mean values:");
		  for(i=0;i<numloci;i++) {
			  if (LDlocus_n[j][i][1])  FP"  % 7.3f  ",LDlocus_mean[j][i][1]); 
				else FP"  *******  ");
		  }
		  FP"\n");
		  FP"      %% sims > observed   :");
		  for(i=0;i<numloci;i++) {
			  if (LDlocus_n[j][i][1])  FP"   % 6.1f  ",100.0 * (float) LDlocus_test[j][i][1]/ (float) LDlocus_n[j][i][1]); 
				else FP"  *******  ");
		  }
		  FP"\n");
		  FP"      # simulated values   :");
		  for(i=0;i<numloci;i++) {
			  FP"   % 4d    ",LDlocus_n[j][i][1]); 
		  }
		  FP"\n\n");
		  for (i=0;i<2;i++) if (ntests[i][LDi]) {
			  LDtests_mean[i][LDi][0] /= ntests[i][LDi];
			  LDtests_mean[i][LDi][1] = 100.0* LDtests_mean[i][LDi][1]/ntests[i][LDi];
			  LDtests_mean[i][LDi][2] = 100.0* LDtests_mean[i][LDi][2]/ntests[i][LDi];
			  LDtests_std[i][LDi][0] /= ntests[i][LDi];
			  LDtests_std[i][LDi][1] = 100.0* LDtests_std[i][LDi][1]/ntests[i][LDi];
			  LDtests_std[i][LDi][2] = 100.0* LDtests_std[i][LDi][2]/ntests[i][LDi];
		  }

		  FP" Tests of Observed Means and St.Dev. \n");
		  FP" ----- -- -------- ----- --- ------ \n\n");

		  FP"      Test of Mean Among Loci\n");
		  FP"      ---- -- ---- ----- ----\n");
		  FP"                              Obs Mean    Sim Avg Mean     %% Sims Higher %%Sims Lower  #Sims\n");
		  FP"     species0 = %10s    % 7.3f    % 7.3f         % 7.2f    % 7.2f      %4d\n",species0,LDscores_mean[0][LDi],LDtests_mean[0][LDi][0],LDtests_mean[0][LDi][1],LDtests_mean[0][LDi][2],ntests[0][LDi]);
		  /*if (LDi != SDiff) */
		  FP"     species1 = %10s    % 7.3f    % 7.3f         % 7.2f    % 7.2f      %4d\n",species1,LDscores_mean[1][LDi],LDtests_mean[1][LDi][0],LDtests_mean[1][LDi][1],LDtests_mean[1][LDi][2],ntests[1][LDi]);

		  FP"\n\n");
		  FP"      Test of St.Dev Among Loci\n");
		  FP"      ---- -- ------ ----- ----\n");
		  FP"                              Obs Std       Sim Avg Std    %% Sims Higher %%Sims Lower  #Sims\n");
		  FP"      species0 = %10s  % 10.3f  % 10.3f       % 7.2f    % 7.2f      %4d\n",species0,LDscores_std[0][LDi],LDtests_std[0][LDi][0],LDtests_std[0][LDi][1],LDtests_std[0][LDi][2],ntests[0][LDi]);
		  /*if (LDi != SDiff) */
		  FP"      species1 = %10s  % 10.3f  % 10.3f       % 7.2f    % 7.2f      %4d\n",species1,LDscores_std[1][LDi],LDtests_std[1][LDi][0],LDtests_std[1][LDi][1],LDtests_std[1][LDi][2],ntests[1][LDi]); 
	   }
	   FP"*************************\n");
	   }
  FP"\n\n  - WH  program by Jody Hey updated and compiled September 6, 2001 \n");
  fclose(rfile);
} /* writestuff2 */

void filllimits(void){
 int i,j;
 for (i=1;i<=MAXLOCI + 10 ; i++)
   for (j=0;j<=LIMITMAX-1;j++) valconflimits[i][j] = 0.0;
for (i=1;i<=MAXLOCI + 10 ; i++)
  for (j=0;j<=1;j++) valstats[i][j] = 0.0;
 if (numsims >0 ){
 lowup = (LIMITMAX - 2) / 2;
 highdown = lowup + 1;
 lowpoint = floor(numsims * 0.025) - 1;
 if (lowpoint > lowup) lowpoint = lowup;
 if (lowpoint <= 0) lowpoint = 0;
 lowpercent = ((lowpoint + 1)/ (float) numsims) * 100.0;
 highpoint = LIMITMAX - floor(numsims - (numsims * 0.975));
 if (highpoint >= LIMITMAX) highpoint = LIMITMAX-1;
 if (highpoint < highdown) highpoint = highdown;
 highpercent = ((numsims - (LIMITMAX - highpoint))/(float) numsims) * 100.0;
 for (i=1; i <= numparams; i++){
  for (j=0; j <= lowup; j++) valconflimits[i][j] = 1e6;
  for (j=highdown; j <= LIMITMAX-1; j++) valconflimits[i][j] = 1e-6;
  }
  }
 }/* filllimits */

void setcvals(void){
int i;
double chold;
/*John's instructions on setting 4Nc values
given 4Nc1i  and 4Nc2i  for species 1 and 2 at locus i
4Nc2i = 4Nc1i theta2/theta1 
4NcAi = 4Nc1i thetaA/theta1 

How I get 4Nc1i depends on whether our estimates exist for 
species 1 or species 2 or both.  If only 4Nc1i is available, 
then that's it.  If only 4Nc2i is available, then 
4Nc1i = 4Nc2i theta1/theta2.  If both are available, then 
4Nc1i = (4Nc1i + 4Nc2i theta1/theta2)/2.  Hope this helps.
*/
	for (i=0;i<=numloci-1;i++){
		if ((c1s[i] < 0.0) && (c2s[i]< 0.0)) 
			chold = 0.0;
		if ((c1s[i] < 0.0) && (c2s[i] >= 0.0)) 
			chold = c2s[i] * aparams[1]/aparams[2];
		if ((c1s[i] >= 0.0) && (c2s[i] >= 0.0)) 
			chold = (c1s[i] + c2s[i] * aparams[1]/aparams[2])/2.0;
		if ((c1s[i] >= 0.0) && (c2s[i] < 0.0)) 
			chold = c1s[i];
		c1[i] = chold;

		c2[i] = c1[i] * aparams[2]/aparams[1];

		ca[i] = c1[i] * aparams[3]/aparams[1];
		/* bump up values to check the effect of bias in recombination rates
		c1[i] *=2;
		c2[i] *=2;
		ca[i] *=2;
		*/
	}
}

int main(int argc, char *argv[])
{
	int i,fi,si,checkfit,dofit,simcount;
	float temp;
/*  some stuff that supposedly helps memory checking when debugging 
int tmpDbgFlag;
tmpDbgFlag = _CrtSetDbgFlag(_CRTDBG_REPORT_FLAG);
tmpDbgFlag |= _CRTDBG_CHECK_ALWAYS_DF;
_CrtSetDbgFlag(tmpDbgFlag); 
_CrtCheckMemory( );
*/
#ifdef  __MWERKS__
  argc = ccommand(&argv); 
  SIOUXSettings.autocloseonquit = _true;
  SIOUXSettings.asktosaveonclose = _false;
#endif

    establish_signal_handler();
    getdata(argc, argv); 
	numparams = 4 + numloci - 1;
	checkfit = findparams();
	testval(1);
    aparams = (double *)malloc( (numparams+1)*sizeof(double) );
	for (i=1;i<=numparams;i++) aparams[i] = params[i];
	for(i=4;i<=numparams;i++) afrac[i-4] = frac[i-4];

	for (i=0;i<=numloci-1;i++){
		OSx1[i] = Sx1[i]; OSx2[i] = Sx2[i]; OSs[i] = Ss[i]; OSf[i] = Sf[i];
	}
	for (i=0;i<=numloci-1;i++){
		MSx1[i] = 0.0; MSx2[i] = 0.0; MSs[i] = 0.0; MSf[i] = 0.0;
	}

	setcvals();
	writestuff1(checkfit);
	free( (void *)params );
	FreeGlobals(numloci);
	if (numsims) {
		filllimits();
		presim();
		for (simcount=1,numsimsok=0;simcount <= numsims;simcount++){
			dosim(Lp);
			for (i=0,fi=0,si=0;i<numloci;i++) {
				fi += Sf[i];
				si += Ss[i];
			}
			if (si == 0) numsimsnoshared++;
			if (fi == 0) numsimsnofixed++;
			if (si >0 && fi > 0) {
				dofit = 1;
				checkfit = findparams();
			}
			else dofit = 0;
			/* sometimes quite high values of params[1] come out of the model fitting */
		/*	if ((checkfit==0) && (params[1] > (5 * aparams[1]))){
				checkfit = 1;
			}  */
			if (dofit && (checkfit == 0)){
				numsimsok++;
 				testval(0);
				findlimits();
				for (i=0;i<=numloci-1;i++){
					MSx1[i] += Sx1[i]; MSx2[i] += Sx2[i]; MSs[i] += Ss[i]; MSf[i] += Sf[i];
					}

				printf("%d \n",simcount);
			}
			if (dofit) {
				free( (void *)params );
				FreeGlobals(numloci);
			}
		}

	}
	if (numsims>0) writestuff2();
	free( (void *)aparams );
}
