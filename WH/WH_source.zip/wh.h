#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <float.h>
#include <limits.h>
#include <ctype.h>
#include <signal.h>
#include <string.h>  
#include <time.h>
/*#include <crtdbg.h> */

#ifdef  __MWERKS__
#include <console.h>
#include "sioux.h"
#endif


/*  microsoft visual c has an integer data type with 64 bits called _int64 */

/* if compiled under Microsoft Visual C++, then _MSC_VER  is defined */
/* to find info under MVC++ help for other compiler predefinitions search help for
'predefined macros' */
/* if compiled under Metrowerks  CodeWarrior  then __MWERKS__ is defined */
/* to find info under Metrowerks Codewarrior  search the Codewarrior Manuals 
(not the basic help)  for 'Predefined Symbols */



/*#ifndef macintosh
#define  EXTRALONGSEGMENTS 
#else
#undef EXTRALONGSEGMENTS 
#endif


#ifdef EXTRALONGSEGMENTS
#define  SEGMENT_BITS  64
#define SEGMENT_TYPE  _int64
#else
#define SEGMENT_BITS  32
#define  SEGMENT_TYPE  unsigned long
#endif
*/

#ifdef _MSC_VER
#define SEGMENT_BITS  64
#define  SEGMENT_TYPE  unsigned __int64
#else
#define SEGMENT_BITS  32
#define  SEGMENT_TYPE  unsigned long
#endif 



#define MAXSEQS SEGMENT_BITS   /* usually 32 */
#define MAXLOCI 20 
#define  MAXSIMS  1000
#define LIMITMAX 52 /*MAXSIMS div 20 + 2 */


/*#define  DERIVED_SHARED  */  /* use this to switch between counting shared difference
in the routine LD_possibly_imported_stuff(void)
if DERIVED_SHARED is defined, then sites that are fixed in the 2nd species for a derived base are
counted as shared.
if not, then shared are just regular shared */


static double sqrarg; 
#define SQR(a) ((sqrarg=(a)) == 0.0 ? 0.0 : sqrarg*sqrarg) 

#define Dfault  FLT_MAX
#define Dfault_check  (Dfault / 10.0)


typedef enum {_false,_true} boolean;

/* LDR = r, LDRS = r squared  LDD = D  LDDP = D prime LDABS = ABS(D)*/
enum {LDR,LDRS,LDD,LDABS,LDDP};

/* old list of types of comparisons 
SoverA  LD among shared polys divided by LD among all polys
SoverO  LD among Shared Polys divided by LD among non-shared Polys
SSoverO  LD among shared, and between shared and non-shared divided by LD among non-shared
SlessOS  LD among shared minus LD among non-shared
Shared   simply LD among shared
SDiff   The absolute value of the difference between LD among shared for one species and LD among shared for the second species
SlessOSoverA  (LD among shared minus LD among non-shared) divided by  LD among all.
enum {SoverA,SoverO,SSoverO,SlessOS,Shared,SDiff,SlessOSoverA};
*/
enum {SHARED,SLESSO,SLESSOS};

extern int numloci,nseqs1[MAXLOCI],nseqs2[MAXLOCI];
extern double Sx1[MAXLOCI],Sx2[MAXLOCI],Ss[MAXLOCI],Sf[MAXLOCI],pN[MAXLOCI], l[MAXLOCI],c1[MAXLOCI],c2[MAXLOCI], ca[MAXLOCI];
extern double choose2[MAXSEQS+1];
extern double *aparams, afrac[MAXLOCI];
extern int numparams;
extern int count_malloc, count_free;
extern float LDA[MAXLOCI][2],LDS[MAXLOCI][2],LDO[MAXLOCI][2],LDOS[MAXLOCI][2],LDSS[MAXLOCI][2];
extern int LDmeasure;
extern boolean LDtest[SLESSOS+1];
extern long *idum, idumval;  /* used by ran1 */

/*#define EXTRADEBUG  this can be defined during debugging, either here or as a compiler directive */

#ifdef EXTRADEBUG

int count_malloc,count_free;
void myassert(unsigned short isit);
#else

#define myassert(a)
#endif



/* prototypes */


/* in whclsc.c */
void presim(void);
void dosim(boolean Lp);

	
/* in whnr.c */	
void newt(double x[], int n, int *check, void (*vecfunc)(int, double [], double []));
void broydn(double x[], int n, int *check,void (*vecfunc)(int, double [], double []));
float ran1(long *idum);


/* end prototypes */


