/* D67223267  code for my nr in c program download */

/* coalescent simualtions with recombination see notes at bottom */

#include "wh.h"
/* chromelength is the number of recombinational units */
#define CHROMELENGTH 51 /*51*/ /*251 */
#define MAXCHROMESIZE (long) CHROMELENGTH * (long)SEGMENT_BITS
#define MAXMUT   /* maximum number of mutations - only used for LD  */
#define  LDMINN  4 /* minimum number of LD measurements, to count within a simulation */
/* macros for set handling*/
#define single(i)  ((SEGMENT_TYPE) 1 << (i-1))
#define element(i,x)   ((single(i) & (x) )> 0)
#define isempty(x)  ((x) == (SEGMENT_TYPE) 0)
#define forall(i,x) \
 for ( (i) = 1; (i) <= SEGMENT_BITS; ++(i)) if(element((i),(x)))


/* random integer between 1 and x */
#define randint(x)  ((rand() % (x)) + 1)
/* absolute value */
#define absv(x)  (((x) < 0.0) ? -(x) : (x))


/* types of events during coalescent */

enum event {CO2,CO1,RE1,RE2,NOT};

/* basic data structure. s is an array for the placement of selected
         mutations.  n is for mutations that also
         have a pleiotropic effect on recombinaton */



struct chrome {
       SEGMENT_TYPE  b[CHROMELENGTH];
       struct chrome *l, *r;
       };

/* d tells the descendants, spot is the location along the chrome */
struct mutation{
       SEGMENT_TYPE d;
       int   spot;
       struct mutation *next;
       };


/* pointer to current node, left and right nodes for selected and neutral*/
struct chrome *nownode, *left2, *right2, *left1, *right1;

/*pointer to current mutation and first mutation */
struct mutation *nowmut, *firstmut, *othermut;

/* size of struct chrome, and size of just chromosome data part of structure */
unsigned int structchromesize, chromesize;

/* size of integer */
int intsize;

/* sample size, chromosome length in segments, bp per segment, number of gene copies 2N (g)*/
int sampsize,bp,g;

/* numbers of nodes in species 1 and species 2 */
int num2, num1;

/* array of segments representing each possible single sample item*/
SEGMENT_TYPE sampstandard[MAXSEQS+1];
/* segments representing full samples */
SEGMENT_TYPE fullsamp1, fullsamp2, fullsampa;



/* current time during coalcescence */
float nowtime;
/* during sweep. this is frequency of selected allele */
double sfreq;

/* array of chromosome positions for checking for complete clsc */
int clscchecklist[CHROMELENGTH],clistnum;

/* number of runs to do and number done */
int numruns, runsdone;

/* number of mutations */
int numuts;

long *idum, idumval;  /* used by ran1 */

double my_DBL_MAX, my_DBL_MIN;
float  my_FLT_MIN, my_FLT_MAX;


#ifdef EXTRADEBUG
void *watch_clsc_malloc(int size){
   void *p;
   count_malloc++;
   p = malloc(size);
   return(p);
}

void watch_clsc_free(void *p){
   count_free++;
   free(p);
}

#define malloc(size) watch_clsc_malloc(size)
#define free watch_clsc_free

int count_malloc, count_free;

#endif



/* FUNCTIONS */

long double ldouble_exp(long double value){
/* error trapping, and some code for handling
   an exponent up to about |1730| */
/* it can't really use extreme long double exponents */
#define ln10 2.3025850929940457
double nval, dval, temp;
long double output=1.0;
int i;
 if (absv(value)<690.0) {return(exp(value));
 } else {
 /*   if (value > 690.0) return(5e299);
    if (value < -690.0) return(3e-300); */
    temp = value/ln10;
    dval = modf(temp,&nval);
    /* can only have a double constant
     so these values are not as extreme as should be */
    if (nval < -1730)  return(1e-307);
    if (nval > 1730)   return (1e308);
    if (nval>0) {for (i=1;i<=nval;i++) output *= 10.0;
             } else { for (i=-1;i>=nval;i--) output /= 10.0;
             }
         output *= (long double) exp(dval*ln10);
         return(output); 
    } /*endif*/
 }



int pickpoisson(double param){
static 	long double randnum, raised;
static 	int   i;
 raised = ldouble_exp(-param);
  randnum =  ran1(idum) ;
  for (i=0; randnum > raised; i++){
        randnum *= ran1(idum) ;
        }
 return (i);
 }


int cardinality(SEGMENT_TYPE x){
   int count = 0;
   while (!isempty(x)) {
    x ^= (x & -x); ++count;
    }
 return(count);
}


void addnode(int whichspecies){
	/* if whichspecies ==1 then add the new node to that list
	otherwise to species 2 */
   /* assume nownode as been malloced and has data in the chromosome */
  
   if ( whichspecies == 2) {
      num2++;
      if ( left2==NULL ){
         left2=nownode;
         right2=nownode;
         left2->l = NULL;
         right2->r = NULL;
      } else {
         right2->r = nownode;
         nownode->l = right2;
         nownode->r = NULL;
         right2 = nownode;
      }
   }else{
      num1++;
      if ( left1==NULL ){
         left1=nownode;
         right1=nownode;
         left1->l = NULL;
         right1->r = NULL;
      } else {
         right1->r = nownode;
         nownode->l = right1;
         nownode->r = NULL;
         right1 = nownode;
      }
   }
}


void presim(void){
   /* split up real start from loop start */
int i;

sampstandard[0] = 0;
for ( i=1; i<= MAXSEQS ;i++ ){
   sampstandard[i] = single(i);
   }

structchromesize = sizeof(struct chrome);
chromesize = CHROMELENGTH*sizeof(SEGMENT_TYPE);
intsize = sizeof(int);


my_DBL_MAX = DBL_MAX;
my_DBL_MAX /= 1e20;
my_DBL_MIN = DBL_MIN;
my_DBL_MIN *= 1e20;
my_FLT_MAX = FLT_MAX;
my_FLT_MAX /= 1e10;
my_FLT_MIN = FLT_MIN;
my_FLT_MIN *= 1e10;


} /*presim*/

void loopinit(int locus){
int i,j;

num2 = 0; num1 = 0;
left2 = NULL;
right2 = NULL;
left1 = NULL;
right1 = NULL;
firstmut = NULL;
nowmut = NULL;

#ifdef EXTRADEBUG
count_malloc = 0;
count_free = 0;
#endif

/* create sample chromosomes and add to heap from left to right */
fullsamp1 = 0;
for ( i=1;i<= nseqs1[locus] ; i++ ){
   nownode = malloc(structchromesize);
   for (j=0 ;j<= CHROMELENGTH-1 ;j++ )nownode->b[j] = sampstandard[i];
   addnode(1);
   fullsamp1 |= sampstandard[i];
}
fullsamp2 = 0;
for (;i<=nseqs1[locus]+nseqs2[locus];i++){
   nownode = malloc(structchromesize);
   for (j=0 ;j<= CHROMELENGTH-1 ;j++ )nownode->b[j] = sampstandard[i];
   addnode(2);
   fullsamp2 |= sampstandard[i];
}
fullsampa = fullsamp1 | fullsamp2;
for ( i=0;i<CHROMELENGTH ; i++) clscchecklist[i]=i;
clistnum = CHROMELENGTH;

nowtime = 0.0;
numuts = 0;
}
 

void removenode(int whichspecies){
   /* free the space where nownode is pointing */
   /* this routine should not get called if there is only one node */
   /* if is_selected use the selected list, otherwise the non_selected */
   struct chrome *tnode;
if (whichspecies == 2){
   num2--;
   if ( (nownode==left2)&&(nownode==right2) ){
      left2=NULL;
      right2=NULL;
      free(nownode);
   }else{
   if (nownode == left2 ){
      tnode = left2->r;
      left2 = tnode;
      left2->l = NULL;
      free(nownode);
   }else {
      if ( nownode == right2 ){
         tnode = right2->l;
         right2 = tnode;
         free(nownode);
      } else {
         tnode = nownode->l;
         tnode->r = nownode->r;
         tnode = nownode->r;
         tnode->l = nownode->l;
         free(nownode);
      }
   }
   } 
}else{
   num1--;
   if ( (nownode==left1)&&(nownode==right1) ){
      left1=NULL;
      right1=NULL;
      free(nownode);
   }else{
   if (nownode == left1 ){
      tnode = left1->r;
      left1 = tnode;
      left1->l = NULL;
      free(nownode);
   }else {
      if ( nownode == right1 ){
         tnode = right1->l;
         right1 = tnode;
         free(nownode);
      } else {
         nownode->l->r = nownode->r;
         nownode->r->l = nownode->l;
         free(nownode);
      }
   }
   }
}
}

boolean checknode(struct chrome *nodetocheck){
   int i=0;
   boolean nodeok = _false;
   while ( !nodeok && (i < CHROMELENGTH) ){
      if ( nodetocheck->b[i] > 0 ) nodeok = _true;
      i++;
   }
   return(nodeok);
}

void addmut(SEGMENT_TYPE mutseg,int segspot){
   struct mutation *newmut;
   if ( mutseg < fullsampa ){
      newmut = malloc(sizeof(struct mutation));
      newmut->d = mutseg;
      newmut->spot = segspot; /* spot does not matter for basic simulations */
      newmut->next = NULL;
      if ( firstmut == NULL ){
         firstmut = newmut;
         nowmut=firstmut;
      } else {
         nowmut->next = newmut;
         nowmut = newmut;
      }
      numuts++;
   }
}

void dorec(enum event todo){
   int i, whichspecies;
   int pick, count, recspot, *num;

   unsigned short n1=0, n2=0;

   struct chrome tempc1, tempc2;
   if (todo==RE1){
	   num = &num1;
	   nownode = left1;
	   whichspecies =1;
   }else {
	   num = &num2;
	   nownode = left2;
	   whichspecies = 2;
   }
   pick = randint(*num);
   count = 1;
   while ( count < pick ){
      nownode = nownode ->r;
      count++;
   }
   myassert(nownode != NULL);
   recspot = randint(CHROMELENGTH) -1;
    /* n1 and n2 are the number of units that have between 1 and fullsampa
   items.  If n1 (or n2) is 0 then the chromosome is ignored and is not split up */
   for ( i=0;i<CHROMELENGTH ;i++ ){
      if ( i<= recspot){
         tempc1.b[i] = nownode->b[i];
         n1 += ((tempc1.b[i] >= 1) && (tempc1.b[i] < fullsampa));
         tempc2.b[i] = 0;
      }else {
         tempc2.b[i] = nownode->b[i];
         n2 += ((tempc2.b[i] >= 1) && (tempc2.b[i] < fullsampa));
         tempc1.b[i] = 0;
      }
   }
   if (n1 && n2){
	   removenode(whichspecies);
       nownode = malloc(structchromesize);
        memcpy(&(nownode->b[0]),&(tempc1.b[0]),chromesize);
        addnode(whichspecies);
	    nownode = malloc(structchromesize);
        memcpy(&(nownode->b[0]),&(tempc2.b[0]),chromesize);
        addnode(whichspecies);
   }
    myassert(count_free + num2 + num1 + numuts == count_malloc);
} /* dorec */

boolean checkclsc(void){
   int i,j;
   i=0;
   while ( i < clistnum ){
      if ( nownode->b[clscchecklist[i]]==fullsampa ){

         for ( j=i;j<clistnum ;j++ ) clscchecklist[j] = clscchecklist[j+1];
         clistnum--;
      }
      else i++;
   }
   if ( clistnum==0 ) return(_true);
   else return(_false);
}

boolean doco(enum event todo){
   struct chrome tempc, *ll;
   int pick,i, num, count;
   unsigned short n1=0;
   boolean is_clsc;
   int whichspecies;

   if ( todo==CO2 ) myassert( num2 >= 2);
   if ( todo==CO1 ) myassert( num1 >= 2);
   if ( todo==CO2 ){
      num = num2;
      ll = left2;
	  whichspecies = 2;
   }
   else {
      num = num1;
      ll = left1;
	  whichspecies = 1;
   }
   nownode = ll;
   pick = randint(num);
   count = 1;
   while ( count < pick ) {
      nownode = nownode->r;
      count++;
   }
   memcpy(&(tempc.b[0]),&(nownode->b[0]),chromesize);
   removenode(whichspecies);
   if ( todo==CO2 ){
      num = num2;
      ll = left2;
   }
   else {
      num = num1;
      ll = left1;
   }
   nownode = ll;
   pick = randint(num);
   count = 1;
   while ( count < pick ) {
      nownode = nownode->r;
      count++;
   }
   for ( i=0;i<CHROMELENGTH ;i++ ){
      tempc.b[i] |= nownode->b[i];
      n1 += ((tempc.b[i] >= 1) && (tempc.b[i] < fullsampa));
	/*  myassert(tempc.b[i] <= fullsampa);*/
   }
   removenode(whichspecies);
   nownode = malloc(structchromesize);
   memcpy(&(nownode->b[0]),&(tempc.b[0]),chromesize);
   addnode(whichspecies);
   is_clsc = checkclsc();
   myassert(count_free + num2 + num1 +numuts == count_malloc);
   return(is_clsc);
}


void clsc(int whichspecies, int locus){
  int muts, pick, i,k, j;
  int *num;
  double  nowtime,endtime, time_to_event, mutrate;
  enum event todo;
  float _uni,prob_co, erate;
  boolean done;
  struct chrome  *left, *right;
  SEGMENT_TYPE  segpick;
  boolean  checkco;
  double cval, theta, pairs;

#ifdef EXTRADEBUG
  struct chrome tempc;
  SEGMENT_TYPE tempcount;
#endif

  done = _false;
  nowtime = 0;
  switch (whichspecies){
		  case 1	: 
			theta = afrac[locus]*pN[locus]*aparams[1];
			mutrate = theta/2.0;
			cval = c1[locus]/2.0;
			endtime = 2.0*afrac[locus]*aparams[4]/theta;
			break;
		  case 2	:
			theta = afrac[locus]*pN[locus]*aparams[2];
			mutrate = theta/2.0;
			cval = c2[locus]/2.0;
			endtime = 2.0*afrac[locus]*aparams[4]/theta;
			break;
		  case 0	: 
			theta = afrac[locus]*pN[locus]*aparams[3];
			mutrate = theta/2.0;
			cval = ca[locus]/2.0;
			endtime = 1e200; /* something large */
			break;
	  }
   while (!done){
      switch (whichspecies){
		  case 1	: num = &num1;left = left1;right = right1; break;
		  case 2	: num = &num2;left = left2;right = right2;break;
		  case 0	: num = &num1;left = left1;right = right1;break;
	  }
	  pairs = *num *(*num - 1.0)/2.0;
      erate =  pairs + *num * cval;
      _uni = ran1(idum);
	  if (*num > 1) myassert(erate>0);
      if (erate > 0) time_to_event = log(_uni)/(-erate);
	  else time_to_event = endtime-nowtime;
      _uni = ran1(idum);
	  prob_co = pairs/erate;
      if ( _uni <= prob_co) {
		  if (whichspecies==2) todo = CO2;
		  else todo = CO1;
	  }
      else {
		  if (whichspecies==2) todo = RE2;
		  else todo = RE1;
	  }
	  
	  done = (time_to_event + nowtime >= endtime);
	  if (done) {
		  time_to_event = endtime - nowtime;
		  nowtime = endtime;
		  todo = NOT;
	  } else nowtime += time_to_event;

	  nownode = left;
      for ( i=1;i<= *num ;i++ ){
      muts = pickpoisson(time_to_event*mutrate);
      for ( k=0;k<=muts-1 ;k++ ){
         pick = randint(CHROMELENGTH)-1;
         segpick = nownode->b[pick];
         if ( segpick>0 ) addmut(segpick,pick);
	  }
	  myassert(nownode!=NULL);
	  nownode  = nownode -> r;
	  
      }
	  if (todo == RE1||todo == RE2) dorec(todo);
	  if (todo == CO1||todo == CO2){
		  checkco = doco(todo);
		  done = (done|| checkco);
	  }
#ifdef EXTRADEBUG
      switch (whichspecies){
		  case 1	: tempcount = fullsamp1; num = &num1;left = left1;right = right1; break;
		  case 2	: tempcount = fullsamp2; num = &num2;left = left2;right = right2;break;
		  case 0	: tempcount = fullsampa; num = &num1;left = left1;right = right1;break;
	  }
	  nownode = left;
	  for (i=0;i<CHROMELENGTH ;i++ ) tempc.b[i] =0;
	  for ( i=1;i<= *num ;i++ ){
		  for (j=0;j<CHROMELENGTH ;j++) tempc.b[j] |= nownode->b[j];
		 if (nownode->r != NULL) nownode  = nownode -> r;
	  }
	  for (i=0;i<CHROMELENGTH ;i++ ) myassert(tempc.b[i] == tempcount);
#endif


	  myassert(count_free + num2 + num1 +numuts == count_malloc);

	  done |= (*num == 1);
	  }

} /* end clsc */


void pool(void){
struct  chrome tempc;
	while (num2 > 0){
         nownode = right2;
         memcpy(&(tempc.b[0]),&(nownode->b[0]),chromesize);
         removenode(2);
         nownode = malloc(structchromesize);
         memcpy(&(nownode->b[0]),&(tempc.b[0]),chromesize);
         addnode(1);
      }
} /* pool */


void getsimdata(int locus){
struct mutation *lastmut;
int c1, c2,c1c,c2c,countmuts = 0;

Sx1[locus] = 0.0;
Sx2[locus] = 0.0;
Ss[locus] = 0.0;
Sf[locus] = 0.0;
if ( firstmut != NULL ){
   nowmut = firstmut;
   do{
	   c1 = cardinality(nowmut->d & fullsamp1);
	   c2 = cardinality(nowmut->d & fullsamp2);
	   c1c = nseqs1[locus]-c1;
	   c2c = nseqs2[locus]-c2;
	   Sx1[locus] += ((c1 && c1c)&&(c2==0|| c2 == nseqs2[locus]));
	   Sx2[locus] += ((c2 && c2c)&&(c1==0|| c1 == nseqs1[locus]));
	   Ss[locus] += (( c1 && c1c)&& (c2 && c2c));
	   Sf[locus] += ((c1==0 && c2 == nseqs2[locus])||(c2==0 && c1==nseqs1[locus]));
	   if ( nowmut->next ==NULL ){
         lastmut = nowmut;
         nowmut = NULL;
         free(lastmut);
      } else {
        lastmut = nowmut;
         nowmut = nowmut->next;
         free(lastmut);
      }
	  countmuts += (c1 || c2);
   }while ( nowmut != NULL );
}
firstmut = NULL;
myassert(countmuts ==numuts);  
myassert(Sx1[locus]+Sx2[locus]+Ss[locus]+Sf[locus] == numuts); 
myassert(count_free == count_malloc);
} /* get data */



float calcLD(unsigned int x[4]){
        float p1,q1,p2,q2;
        float xf[4];
        int  i;
		float n,D,denom,r,rsq, Dmax,Dprime;

	for (i=0,n=0;i< 4;i++) n += (float) x[i];
	if (n>0.0){
		for (i=0;i< 4;i++) xf[i] = (float) x[i] / n;
		p1 = (float) (x[0] + x[1])/n;
		p2 = (float) (x[2] + x[3])/n;
		q1 = (float) (x[0] + x[2])/n;
		q2 = (float) (x[1] + x[3])/n;
	}
	if (n<4.0 || p1 <= 0.0 || p2 <= 0.0 || q1 <= 0.0 || q2 <= 0.0) return(Dfault);
	else {
		if ((LDmeasure == LDDP)||(LDmeasure==LDD)||(LDmeasure==LDABS)){
			D = xf[0]*xf[3] - xf[1]*xf[2];
			if (D>0){
				if (p1*q2 < p2*q1) Dmax = p1*q2; else Dmax = p2*q1;
			} else{
				if (p1*q1 < p2*q2) Dmax = p1*q1; else Dmax = p2*q2;
			}
			Dprime = /*fabs(D/Dmax); */ D/Dmax;
			if (LDmeasure == LDDP)return(Dprime);
			else {
				if (LDmeasure == LDABS) return(fabs(D));
				else return(D);
			}
		} else { /*(LDmeasure==LDR)||(LDmeasure==LDRS) */
			denom = p1*q1*p2*q2;
			denom = sqrt(denom);
			D = xf[0]*xf[3] - xf[1]*xf[2];
			r = D/denom;
			rsq = r*r;
			if (LDmeasure == LDR)return(r);
			else return(rsq);
		}
	}
} /* calcLD */


/* since this is based on coalescent, the mutation is always derived
	coupling involves shared 2 derived mutations, or neither */

void doLD(locus){
unsigned int x[4];
int i,j;
unsigned species1_nowmut_count, species1_othermut_count,species1_nowmut_complement,species1_othermut_complement,species2_nowmut_count, species2_othermut_count,species2_nowmut_complement,species2_othermut_complement;
unsigned s1,s2;
unsigned ca1,ca2,cs1,cs2,co1,co2,cos1,cos2,css1,css2;
float LDval;
SEGMENT_TYPE  id;

 ca1 = 0;ca2 = 0;cs1 = 0;cs2 = 0;co1 = 0;co2 = 0; cos1=0; cos2 = 0; css1 = 0; css2 = 0;
 LDA[locus][0] = 0.0; LDA[locus][1] = 0.0;
 LDS[locus][0] = 0.0; LDS[locus][1] = 0.0;
 LDO[locus][0] = 0.0; LDO[locus][1] = 0.0;
 LDOS[locus][0] = 0.0; LDOS[locus][1] = 0.0;
 LDSS[locus][0] = 0.0; LDSS[locus][1] = 0.0;
 nowmut = firstmut;
 while (nowmut != NULL){
	othermut = nowmut->next;
	while (othermut != NULL){
		/* 2 sites, now and other */
		species1_nowmut_count = cardinality(nowmut->d & fullsamp1); /* # copies of now in species 1 */
		species1_othermut_count= cardinality(othermut->d & fullsamp1); /* # copies of other in species 1 */
		species1_nowmut_complement = nseqs1[locus]-species1_nowmut_count;  /* complment of  # copies of now in species 1 */
		species1_othermut_complement = nseqs1[locus]-species1_othermut_count;  /* complement of # copies of other  in species 1 */
		species2_nowmut_count = cardinality(nowmut->d & fullsamp2);
		species2_othermut_count= cardinality(othermut->d & fullsamp2);
		species2_nowmut_complement = nseqs2[locus]-species2_nowmut_count;
		species2_othermut_complement = nseqs2[locus]-species2_othermut_count;
		/* now is shared by both species  */
		s1 =  (( species1_nowmut_count && species1_nowmut_complement)&& (species2_nowmut_count && species2_nowmut_complement)); 
		/* other is shared by both species */
		s2 =  (( species1_othermut_count&& species1_othermut_complement)&& (species2_othermut_count&& species2_othermut_complement)); 
/* alternative that counts sites as shared if they are also derived and fixed in species 2 */
#ifdef DEFINED_SHARED
		s1 =  (( species1_nowmut_count && species1_nowmut_complement)&& species2_nowmut_count);
		s2 =  (( species1_othermut_count&& species1_othermut_complement)&& species2_othermut_count);  
#endif
		if (species1_nowmut_count && species1_othermut_count&& species1_nowmut_complement && species1_othermut_complement){ /* now and other are polymorphic in species 1 */
			x[0] = 0; x[1] = 0; x[2] = 0; x[3] = 0;
			for (i=0;i< nseqs1[locus];i++){
				id = sampstandard[i+1];
				x[0] += (id & nowmut->d) && (id & othermut->d);
				x[1] += (id & nowmut->d) && ((id & othermut->d)==0);
				x[2] += ((id & nowmut->d)==0) && (id & othermut->d);
				x[3] += ((id & nowmut->d)==0) && ((id & othermut->d)==0);
			}
			LDval = calcLD(x);
			if (LDval < Dfault_check){
				LDA[locus][0] += LDval;
				ca1 ++;
				if (s1 && s2){
					LDS[locus][0] += LDval;
					cs1++;
				}
				if ((s1==0) && (s2==0)){
					LDO[locus][0] += LDval;
					co1++;
				}	
				if ((s1 && (s2==0))||((s1==0)&&s2)){
					LDOS[locus][0] += LDval;
					cos1++;
				}	
				if (s1 || s2){
					LDSS[locus][0] += LDval;
					css1++;
				}	
			}

		}
#ifdef DEFINED_SHARED
		s1 =  (( species2_nowmut_count && species2_nowmut_complement)&& species1_nowmut_count);
		s2 =  (( species2_othermut_count&& species2_othermut_complement)&& species1_othermut_count); 
#endif
		if (species2_nowmut_count && species2_othermut_count&& species2_nowmut_complement && species2_othermut_complement){
			x[0] = 0; x[1] = 0; x[2] = 0; x[3] = 0;
			for (i=0;i< nseqs2[locus];i++){
				id = sampstandard[1+i+nseqs1[locus]];
				x[0] += (id & nowmut->d) && (id & othermut->d);
				x[1] += (id & nowmut->d) && ((id & othermut->d)==0);
				x[2] += ((id & nowmut->d)==0) && (id & othermut->d);
				x[3] += ((id & nowmut->d)==0) && ((id & othermut->d)==0);
			}
			LDval = calcLD(x);
			if (LDval < Dfault_check){
				LDA[locus][1] += LDval;
				ca2 ++;
				if (s1 && s2){
					LDS[locus][1] += LDval;
					cs2++;
				}
				if ((s1==0) && (s2==0)){
					LDO[locus][1] += LDval;
					co2++;
				}	
				if ((s1 && (s2==0))||((s1==0)&&s2)){
					LDOS[locus][1] += LDval;
					cos2++;
				}	
				if (s1 || s2){
					LDSS[locus][1] += LDval;
					css2++;
				}	
			}
		}

		othermut = othermut->next;
	}
	nowmut = nowmut->next;
  }
 /* calculate mean disequilibriums */
  if (ca1 >= LDMINN) LDA[locus][0] /= ca1; else LDA[locus][0] = Dfault;
  if (co1 >= LDMINN) LDO[locus][0] /= co1;else LDO[locus][0] = Dfault;
  if (cs1 >= LDMINN) LDS[locus][0] /= cs1;else LDS[locus][0] = Dfault;
  if (cos1 >= LDMINN) LDOS[locus][0] /= cos1;else LDOS[locus][0] = Dfault;
  if (css1 >= LDMINN) LDSS[locus][0] /= css1;else LDSS[locus][0] = Dfault;
  if (ca2 >= LDMINN) LDA[locus][1] /= ca2;else LDA[locus][1] = Dfault;
  if (co2 >= LDMINN) LDO[locus][1] /= co2;else LDO[locus][1] = Dfault;
  if (cs2 >= LDMINN) LDS[locus][1] /= cs2;else LDS[locus][1] = Dfault;
  if (cos2 >= LDMINN) LDOS[locus][1] /= cos2;else LDOS[locus][1] = Dfault;
  if (css2 >= LDMINN) LDSS[locus][1] /= css2;else LDSS[locus][1] = Dfault;

} /* doLD */
    
void dosim(boolean  Lp) {
int locus;
for (locus=0;locus<numloci;locus++){
	loopinit(locus);
	clsc(1,locus);
    clsc(2,locus);  /*do clsc on each group*/
	pool(); /*combine whats left of the two groups into one*/
    clsc(0,locus); /* do clsc for time before node*/

	/*empty the lists */
	nownode = left1;
    while (nownode){
		removenode(1);
		nownode = left1;
	}
	nownode = left2;
    while (nownode){
		removenode(2);
		nownode = left2;
	}
    myassert(count_free + numuts == count_malloc);
	if (Lp) doLD(locus);
	getsimdata(locus);
}
}


/* NOTES */
/* copied much of this file from selcoal.c 
  scrapped stuff for selection 
 every chromosome has a length of 32 units regardless of its actual length in bp 

 make use of 2 lists, selcoal had 1 for selected and the other for non-selectined
 in this we use 1 for species 1, the other for species 2 

 back before the speciation events, they get lumped into list 1
*/

/* this program is a backward coalscent simulation with recombination 

Data structure is a chromosome on the heap.  At each coalescent
event, two chromosomes are brought together and an ancestor is created.  Each 
descendent is discarded.  Each chromosome consists of multiple positions along 
an array. Each position is represented by a number that represents all of the  
descendants of that sequence at that position. 

Ordering of bits.  There are 32 positions, numbered from left
to right

31 30 29 28 27 26 25 24 23 22 21 20 19 18 17 16 15 14 13 12 11 10 9 8 7 6 5 4 3 2 1 0

A full segment is just 32 1's
11111111111111111111111111111111

A count of 1 is just one 1 on the end
00000000000000000000000000000001

The chromosomes are kept on a linked list, each has a pointer to left and 
right. New chromosomes are added to the right.  There are two linked lists.  
One for each population.

At each recombination event, a chromosome is split into two chromosomes.  The
original is discarded and the two new ones are added to the heap.

In effect assume that 2N = 1. Then the instantaneous probability of 
coalescence is  choose2[numnodes] + numnodes * c/2.0.   The choose2[numnodes] is 
the instantaneous rate of coalescence and numnodes*c/2.0 is the instantaneous 
rate of recombination (divide by 2 to convert 4N to 2N).


Each mutation is recorded as a copy of a chromosome position, and it shows
which descendants received that mutation. Also recorded is the position of the 
mutation.  There will be a data structure for the mutations, and a stack that 
can be read after the simulation is over.

/* may need to set the stack size higher. e.g.  /st:131072  in VAC++  
In gcc I think I use the -Zstack option, e.g.  '-Zstack 128 ' sets the stack to 
128 kilobytes, which is the same as 131072 bytes
*/


 /* the length of chromosomes in units of the length of SEGMENT_TYPE
 Thus if SEGMENT_TYPE has length 32, then a chromosome can have
 a length of 32*CHROMELENGTH bits*/

/* This is the maximum number of segments in a chromosome */
