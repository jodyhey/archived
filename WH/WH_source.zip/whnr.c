
#include "wh.h"

 
static double maxarg1,maxarg2; 
#define FMAX(a,b) (maxarg1=(a),maxarg2=(b),(maxarg1) > (maxarg2) ? (maxarg1) : (maxarg2)) 
 
#define SIGN(a,b) ((b) >= 0.0 ? fabs(a) : -fabs(a)) 

#define NR_END 1
#define FREE_ARG char* 
 
void nrerror(char error_text[]) 
/* Numerical Recipes standard error handler */ 
{ 
	fprintf(stderr,"Numerical Recipes run-time error...\n"); 
	fprintf(stderr,"%s\n",error_text); 
	fprintf(stderr,"...now exiting to system...\n"); 
	exit(1); 
} 
 
int *ivector(long nl, long nh) 
/* allocate an int vector with subscript range v[nl..nh] */ 
{ 
	int *v; 
 
	v=(int *)malloc((size_t) ((nh-nl+1+NR_END)*sizeof(int))); 
	if (!v) nrerror("allocation failure in vector()"); 
	return v-nl+NR_END; 
} 
 
double *vector(long nl, long nh) 
/* allocate a double vector with subscript range v[nl..nh] */ 
{ 
	double *v; 
 
	v=(double *)malloc((size_t) ((nh-nl+1+NR_END)*sizeof(double))); 
	if (!v) nrerror("allocation failure in vector()"); 
	return v-nl+NR_END; 
} 
 
double **matrix(long nrl, long nrh, long ncl, long nch) 
/* allocate a double matrix with subscript range m[nrl..nrh][ncl..nch] */ 
{ 
	long i, nrow=nrh-nrl+1,ncol=nch-ncl+1; 
	double **m; 
 
	/* allocate pointers to rows */ 
	m=(double **) malloc((size_t)((nrow+NR_END)*sizeof(double *))); 
	if (!m) nrerror("allocation failure 1 in matrix()"); 
	m += NR_END; 
	m -= nrl; 
 
	/* allocate rows and set pointers to them */ 
	m[nrl]=(double *) malloc((size_t)((nrow*ncol+NR_END)*sizeof(double))); 
	if (!m[nrl]) nrerror("allocation failure 2 in matrix()"); 
	m[nrl] += NR_END; 
	m[nrl] -= ncl; 
 
	for(i=nrl+1;i<=nrh;i++) m[i]=m[i-1]+ncol; 
 
	/* return pointer to array of pointers to rows */ 
	return m; 
} 
 
void free_ivector(int *v, long nl, long nh) 
/* free an int vector allocated with ivector() */ 
{ 
	free((FREE_ARG) (v+nl-NR_END)); 
} 
 
void free_vector(double *v, long nl, long nh) 
/* free a double vector allocated with vector() */ 
{ 
	free((FREE_ARG) (v+nl-NR_END)); 
} 
 
void free_matrix(double **m, long nrl, long nrh, long ncl, long nch) 
/* free a double matrix allocated by matrix() */ 
{ 
	free((FREE_ARG) (m[nrl]+ncl-NR_END)); 
	free((FREE_ARG) (m+nrl-NR_END)); 
} 

#define EPS 1.0e-4 /* 1.0e-4*/

void fdjac(int n, double x[], double fvec[], double **df,
	void (*vecfunc)(int, double [], double []))
{
	int i,j;
	double h,temp,*f;

	f=vector(1,n);
	for (j=1;j<=n;j++) {
		temp=x[j];
		h=EPS*fabs(temp);
		if (h == 0.0) h=EPS;
		x[j]=temp+h;
		h=x[j]-temp;
		(*vecfunc)(n,x,f);
		x[j]=temp;
		for (i=1;i<=n;i++) df[i][j]=(f[i]-fvec[i])/h;
	}
	free_vector(f,1,n);
}

#undef EPS

/* extern int nn; */
/* extern double *fvec; */
/* extern void (*nrfuncv)(int n, double v[], double f[]); */

int nn; 
double *fvec; 
void (*nrfuncv)(int n, double v[], double f[]); 

double fmin1(double x[])
{
	int i;
	double sum;

	(*nrfuncv)(nn,x,fvec);
	for (sum=0.0,i=1;i<=nn;i++) sum += SQR(fvec[i]);
	return 0.5*sum;
}

#define ALF 1.0e-4
#define TOLX 1.0e-7

void lnsrch(int n, double xold[], double fold, double g[], double p[], double x[],
	double *f, double stpmax, int *check, double (*func)(double []))
{
	int i;
	double a,alam,alam2,alamin,b,disc,f2,fold2,rhs1,rhs2,slope,sum,temp,test,tmplam;

	*check=0;
	for (sum=0.0,i=1;i<=n;i++) sum += p[i]*p[i];
	sum=sqrt(sum);
	if (sum > stpmax)
		for (i=1;i<=n;i++) p[i] *= stpmax/sum;
	for (slope=0.0,i=1;i<=n;i++)
		slope += g[i]*p[i];
	test=0.0;
	for (i=1;i<=n;i++) {
		temp=fabs(p[i])/FMAX(fabs(xold[i]),1.0);
		if (temp > test) test=temp;
	}
	alamin=TOLX/test;
	alam=1.0;
	for (;;) {
		for (i=1;i<=n;i++) x[i]=xold[i]+alam*p[i];
		*f=(*func)(x);
		if (alam < alamin) {
			for (i=1;i<=n;i++) x[i]=xold[i];
			*check=1;
			return;
		} else if (*f <= fold+ALF*alam*slope) return;
		else {
			if (alam == 1.0)
				tmplam = -slope/(2.0*(*f-fold-slope));
			else {
				rhs1 = *f-fold-alam*slope;
				rhs2 = f2-fold2-alam2*slope;
				a=(rhs1/(alam*alam)-rhs2/(alam2*alam2))/(alam-alam2);
				b=(-alam2*rhs1/(alam*alam)+alam*rhs2/(alam2*alam2))/(alam-alam2);
				if (a == 0.0) tmplam = -slope/(2.0*b);
				else {
					disc=b*b-3.0*a*slope;
					if (disc<0.0) nrerror("Roundoff problem in lnsrch.");
					else tmplam=(-b+sqrt(disc))/(3.0*a);
				}
				if (tmplam>0.5*alam)
					tmplam=0.5*alam;
			}
		}
		alam2=alam;
		f2 = *f;
		fold2=fold;
		alam=FMAX(tmplam,0.1*alam);
	}
}

#undef ALF
#undef TOLX

void lubksb(double **a, int n, int *indx, double b[])
{
	int i,ii=0,ip,j;
	double sum;

	for (i=1;i<=n;i++) {
		ip=indx[i];
		sum=b[ip];
		b[ip]=b[i];
		if (ii)
			for (j=ii;j<=i-1;j++) sum -= a[i][j]*b[j];
		else if (sum) ii=i;
		b[i]=sum;
	}
	for (i=n;i>=1;i--) {
		sum=b[i];
		for (j=i+1;j<=n;j++) sum -= a[i][j]*b[j];
		b[i]=sum/a[i][i];
	}
}

#define TINY 1.0e-20;

int ludcmp(double **a, int n, int *indx, double *d)
{
	int i,imax,j,k;
	double big,dum,sum,temp;
	double *vv;

	vv=vector(1,n);
	*d=1.0;
	for (i=1;i<=n;i++) {
		big=0.0;
		for (j=1;j<=n;j++)
			if ((temp=fabs(a[i][j])) > big) big=temp;
			if (big == 0.0) {
				/*nrerror("Singular matrix in routine ludcmp");*/
			    free_vector(vv,1,n);
				return(0);
			}
		vv[i]=1.0/big;
	}
	for (j=1;j<=n;j++) {
		for (i=1;i<j;i++) {
			sum=a[i][j];
			for (k=1;k<i;k++) sum -= a[i][k]*a[k][j];
			a[i][j]=sum;
		}
		big=0.0;
		for (i=j;i<=n;i++) {
			sum=a[i][j];
			for (k=1;k<j;k++)
				sum -= a[i][k]*a[k][j];
			a[i][j]=sum;
			if ( (dum=vv[i]*fabs(sum)) >= big) {
				big=dum;
				imax=i;
			}
		}
		if (j != imax) {
			for (k=1;k<=n;k++) {
				dum=a[imax][k];
				a[imax][k]=a[j][k];
				a[j][k]=dum;
			}
			*d = -(*d);
			vv[imax]=vv[j];
		}
		indx[j]=imax;
		if (a[j][j] == 0.0) a[j][j]=TINY;
		if (j != n) {
			dum=1.0/(a[j][j]);
			for (i=j+1;i<=n;i++) a[i][j] *= dum;
		}
	}
	free_vector(vv,1,n);
	return(1);
}

#define MAXITS 200 /* 200  50 seems to be enough*/
#define TOLF 1.0e-6 
#define TOLMIN 1.0e-8 
#define TOLX 1.0e-9 
#define STPMX 100.0

/* int nn; */
/* double *fvec; */
/* void (*nrfuncv)(int n, double v[], double f[]); */

#define FREERETURN {free_vector(fvec,1,n);free_vector(xold,1,n);free_vector(p,1,n);free_vector(g,1,n);free_matrix(fjac,1,n,1,n);free_ivector(indx,1,n);return;} 

void newt(double x[], int n, int *check, void (*vecfunc)(int, double [], double []))
{
	void fdjac(int n, double x[], double fvec[], double **df, void (*vecfunc)(int, double [], double []));
	double fmin1(double x[]);
	void lnsrch(int n, double xold[], double fold, double g[], double p[], double x[],
		 double *f, double stpmax, int *check, double (*func)(double []));
	void lubksb(double **a, int n, int *indx, double b[]);
	int ludcmp(double **a, int n, int *indx, double *d);
	int i,its,j,*indx;
	double d,den,f,fold,stpmax,sum,temp,test,**fjac,*g,*p,*xold;
	int ludcmpcheck;

	indx=ivector(1,n);
	fjac=matrix(1,n,1,n);
	g=vector(1,n);
	p=vector(1,n);
	xold=vector(1,n);
	fvec=vector(1,n);
	nn=n;
	nrfuncv=vecfunc;
	f=fmin1(x);
	test=0.0;
	for (i=1;i<=n;i++)
		if (fabs(fvec[i]) > test) test=fabs(fvec[i]);
		if (test<0.01*TOLF) {
			FREERETURN;
		}
	for (sum=0.0,i=1;i<=n;i++) sum += SQR(x[i]);
	stpmax=STPMX*FMAX(sqrt(sum),(double)n);
	for (its=1;its<=MAXITS;its++) {
		fdjac(n,x,fvec,fjac,vecfunc);
		for (i=1;i<=n;i++) {
			for (sum=0.0,j=1;j<=n;j++) sum += fjac[j][i]*fvec[j];
			g[i]=sum;
		}
		for (i=1;i<=n;i++) xold[i]=x[i];
		fold=f;
		for (i=1;i<=n;i++) p[i] = -fvec[i];
		ludcmpcheck = ludcmp(fjac,n,indx,&d);
		if (ludcmpcheck != 1){
			/* singular matrix in ludcmp */
			*check =3;
			FREERETURN;
		}
		lubksb(fjac,n,indx,p);
		lnsrch(n,xold,fold,g,p,x,&f,stpmax,check,fmin1);
		test=0.0;
		for (i=1;i<=n;i++)
			if (fabs(fvec[i]) > test) test=fabs(fvec[i]);
		if (test < TOLF) {
			*check=0;
			FREERETURN;
		}
		if (*check) {
			test=0.0;
			den=FMAX(f,0.5*n);
			for (i=1;i<=n;i++) {
				temp=fabs(g[i])*FMAX(fabs(x[i]),1.0)/den;
				if (temp > test) test=temp;
			}
			*check=(test < TOLMIN ? 1 : 0);
			FREERETURN;
		}
		test=0.0;
		for (i=1;i<=n;i++) {
			temp=(fabs(x[i]-xold[i]))/FMAX(fabs(x[i]),1.0);
			if (temp > test) test=temp;
		}
		if (test < TOLX) {
			FREERETURN;
		}
	}
	/* nrerror("MAXITS exceeded in newt"); */  *check = 2;
}

#undef MAXITS
#undef TOLF
#undef TOLMIN
#undef TOLX
#undef STPMX
#undef FREERETURN

/* (C) Copr. 1986-92 Numerical Recipes Software . */

/* stuff for a different method - broydn rather than newt, both seem to work*/


#define NRANSI
#define MAXITS 100 /*200 100 seems to be enough */
#define EPS 1.0e-7
#define TOLF 1.0e-4
#define TOLX EPS
#define STPMX 100.0
#define TOLMIN 1.0e-6
#define FREERETURN {free_vector(fvec,1,n);free_vector(xold,1,n);\
	free_vector(w,1,n);free_vector(t,1,n);free_vector(s,1,n);\
	free_matrix(r,1,n,1,n);free_matrix(qt,1,n,1,n);free_vector(p,1,n);\
	free_vector(g,1,n);free_vector(fvcold,1,n);free_vector(d,1,n);\
	free_vector(c,1,n);return;}

/*int nn;
double *fvec;
void (*nrfuncv)(int n, double v[], double f[]);
  */

double fmin2(double x[])
{
	int i;
	double sum;

	(*nrfuncv)(nn,x,fvec);
	for (sum=0.0,i=1;i<=nn;i++) sum += SQR(fvec[i]);
	return 0.5*sum;
}


void rotate(double **r, double **qt, int n, int i, double a, double b)
{
	int j;
	double c,fact,s,w,y;

	if (a == 0.0) {
		c=0.0;
		s=(b >= 0.0 ? 1.0 : -1.0);
	} else if (fabs(a) > fabs(b)) {
		fact=b/a;
		c=SIGN(1.0/sqrt(1.0+(fact*fact)),a);
		s=fact*c;
	} else {
		fact=a/b;
		s=SIGN(1.0/sqrt(1.0+(fact*fact)),b);
		c=fact*s;
	}
	for (j=i;j<=n;j++) {
		y=r[i][j];
		w=r[i+1][j];
		r[i][j]=c*y-s*w;
		r[i+1][j]=s*y+c*w;
	}
	for (j=1;j<=n;j++) {
		y=qt[i][j];
		w=qt[i+1][j];
		qt[i][j]=c*y-s*w;
		qt[i+1][j]=s*y+c*w;
	}
}



void qrdcmp(double **a, int n, double *c, double *d, int *sing)
{
	int i,j,k;
	double scale=0.0,sigma,sum,tau;

	*sing=0;
	for (k=1;k<n;k++) {
		for (i=k;i<=n;i++) scale=FMAX(scale,fabs(a[i][k]));
		if (scale == 0.0) {
			*sing=1;
			c[k]=d[k]=0.0;
		} else {
			for (i=k;i<=n;i++) a[i][k] /= scale;
			for (sum=0.0,i=k;i<=n;i++) sum += SQR(a[i][k]);
			sigma=SIGN(sqrt(sum),a[k][k]);
			a[k][k] += sigma;
			c[k]=sigma*a[k][k];
			d[k] = -scale*sigma;
			for (j=k+1;j<=n;j++) {
				for (sum=0.0,i=k;i<=n;i++) sum += a[i][k]*a[i][j];
				tau=sum/c[k];
				for (i=k;i<=n;i++) a[i][j] -= tau*a[i][k];
			}
		}
	}
	d[n]=a[n][n];
	if (d[n] == 0.0) *sing=1;
}


void qrupdt(double **r, double **qt, int n, double u[], double v[])
{
	void rotate(double **r, double **qt, int n, int i, double a, double b);
	int i,j,k;

	for (k=n;k>=1;k--) {
		if (u[k]) break;
	}
	if (k < 1) k=1;
	for (i=k-1;i>=1;i--) {
		rotate(r,qt,n,i,u[i],-u[i+1]);
		if (u[i] == 0.0) u[i]=fabs(u[i+1]);
		else if (fabs(u[i]) > fabs(u[i+1]))
			u[i]=fabs(u[i])*sqrt(1.0+SQR(u[i+1]/u[i]));
		else u[i]=fabs(u[i+1])*sqrt(1.0+SQR(u[i]/u[i+1]));
	}
	for (j=1;j<=n;j++) r[1][j] += u[1]*v[j];
	for (i=1;i<k;i++)
		rotate(r,qt,n,i,r[i][i],-r[i+1][i]);
}

void rsolv(double **a, int n, double d[], double b[])
{
	int i,j;
	double sum;

	b[n] /= d[n];
	for (i=n-1;i>=1;i--) {
		for (sum=0.0,j=i+1;j<=n;j++) sum += a[i][j]*b[j];
		b[i]=(b[i]-sum)/d[i];
	}
}


void broydn(double x[], int n, int *check,
	void (*vecfunc)(int, double [], double []))
{    
	void fdjac(int n, double x[], double fvec[], double **df, void (*vecfunc)(int, double [], double []));
	double fmin2(double x[]);
	void lnsrch(int n, double xold[], double fold, double g[], double p[], double x[],
		 double *f, double stpmax, int *check, double (*func)(double []));
	void qrdcmp(double **a, int n, double *c, double *d, int *sing);
	void qrupdt(double **r, double **qt, int n, double u[], double v[]);
	void rsolv(double **a, int n, double d[], double b[]);
	int i,its,j,k,restrt,sing,skip;
	double den,f,fold,stpmax,sum,temp,test,*c,*d,*fvcold;
	double *g,*p,**qt,**r,*s,*t,*w,*xold;

	c=vector(1,n);
	d=vector(1,n);
	fvcold=vector(1,n);
	g=vector(1,n);
	p=vector(1,n);
	qt=matrix(1,n,1,n);
	r=matrix(1,n,1,n);
	s=vector(1,n);
	t=vector(1,n);
	w=vector(1,n);
	xold=vector(1,n);
	fvec=vector(1,n);
	nn=n;
	nrfuncv=vecfunc;
	f=fmin2(x);
	test=0.0;
	for (i=1;i<=n;i++)
		if (fabs(fvec[i]) > test)test=fabs(fvec[i]);
	if (test<0.01*TOLF) FREERETURN
	for (sum=0.0,i=1;i<=n;i++) sum += SQR(x[i]);
	stpmax=STPMX*FMAX(sqrt(sum),(double)n);
	restrt=1;
	for (its=1;its<=MAXITS;its++) {
		if (restrt) {
			fdjac(n,x,fvec,r,vecfunc);
			qrdcmp(r,n,c,d,&sing);
			if (sing) /*nrerror("singular Jacobian in broydn");*/
			{
			*check =3;
			FREERETURN;
			}

			for (i=1;i<=n;i++) {
				for (j=1;j<=n;j++) qt[i][j]=0.0;
				qt[i][i]=1.0;
			}
			for (k=1;k<n;k++) {
				if (c[k]) {
					for (j=1;j<=n;j++) {
						sum=0.0;
						for (i=k;i<=n;i++)
							sum += r[i][k]*qt[i][j];
						sum /= c[k];
						for (i=k;i<=n;i++)
							qt[i][j] -= sum*r[i][k];
					}
				}
			}
			for (i=1;i<=n;i++) {
				r[i][i]=d[i];
				for (j=1;j<i;j++) r[i][j]=0.0;
			}
		} else {
			for (i=1;i<=n;i++) s[i]=x[i]-xold[i];
			for (i=1;i<=n;i++) {
				for (sum=0.0,j=i;j<=n;j++) sum += r[i][j]*s[j];
				t[i]=sum;
			}
			skip=1;
			for (i=1;i<=n;i++) {
				for (sum=0.0,j=1;j<=n;j++) sum += qt[j][i]*t[j];
				w[i]=fvec[i]-fvcold[i]-sum;
				if (fabs(w[i]) >= EPS*(fabs(fvec[i])+fabs(fvcold[i]))) skip=0;
				else w[i]=0.0;
			}
			if (!skip) {
				for (i=1;i<=n;i++) {
					for (sum=0.0,j=1;j<=n;j++) sum += qt[i][j]*w[j];
					t[i]=sum;
				}
				for (den=0.0,i=1;i<=n;i++) den += SQR(s[i]);
				for (i=1;i<=n;i++) s[i] /= den;
				qrupdt(r,qt,n,t,s);
				for (i=1;i<=n;i++) {
					if (r[i][i] == 0.0) nrerror("r singular in broydn");
					d[i]=r[i][i];
				}
			}
		}
		for (i=1;i<=n;i++) {
			for (sum=0.0,j=1;j<=n;j++) sum += qt[i][j]*fvec[j];
			g[i]=sum;
		}
		for (i=n;i>=1;i--) {
			for (sum=0.0,j=1;j<=i;j++) sum += r[j][i]*g[j];
			g[i]=sum;
		}
		for (i=1;i<=n;i++) {
			xold[i]=x[i];
			fvcold[i]=fvec[i];
		}
		fold=f;
		for (i=1;i<=n;i++) {
			for (sum=0.0,j=1;j<=n;j++) sum += qt[i][j]*fvec[j];
			p[i] = -sum;
		}
		rsolv(r,n,d,p);
		lnsrch(n,xold,fold,g,p,x,&f,stpmax,check,fmin2);
		test=0.0;
		for (i=1;i<=n;i++)
			if (fabs(fvec[i]) > test) test=fabs(fvec[i]);
		if (test < TOLF) {
			*check=0;
			FREERETURN
		}
		if (*check) {
			if (restrt) FREERETURN
			else {
				test=0.0;
				den=FMAX(f,0.5*n);
				for (i=1;i<=n;i++) {
					temp=fabs(g[i])*FMAX(fabs(x[i]),1.0)/den;
					if (temp > test) test=temp;
				}
				if (test < TOLMIN) FREERETURN
				else restrt=1;
			}
		} else {
			restrt=0;
			test=0.0;
			for (i=1;i<=n;i++) {
				temp=(fabs(x[i]-xold[i]))/FMAX(fabs(x[i]),1.0);
				if (temp > test) test=temp;
			}
			if (test < TOLX) FREERETURN
		}
	}
	/*nrerror("MAXITS exceeded in broydn"); */ *check = 2;
	FREERETURN
}
#undef MAXITS
#undef EPS
#undef TOLF
#undef TOLMIN
#undef TOLX
#undef STPMX
#undef FREERETURN
#undef NRANSI

/* (C) Copr. 1986-92 Numerical Recipes Software '$&'3$. */

#define IA 16807
#define IM 2147483647
#define AM (1.0/IM)
#define IQ 127773
#define IR 2836
#define NTAB 32
#define NDIV (1+(IM-1)/NTAB)
#define EPS 1.2e-38
#define RNMX (1.0-EPS)
float ran1(long *idum)
/*Minimal" random number generator of Park and Miller with Bays-Durham shuffe and added
safeguards. Returns a uniform random deviate between 0.0 and 1.0 (exclusive of the endpoint
values). Call with idum a negative integer to initialize; thereafter, do not alter idum between
successive deviates in a sequence. RNMX should approximate the largest oating value that is
less than 1. */
{
int j;
long k;
static long iy=0;
static long iv[NTAB];
float temp;
if (*idum <= 0 || !iy){
	if (-(*idum) < 1) *idum=1;  
	else *idum = -(*idum);
	for (j=NTAB+7;j>=0;j--){
		k=(*idum)/IQ;
		*idum=IA*(*idum-k*IQ)-IR*k;
		if (*idum < 0) *idum += IM;
		if (j < NTAB) iv[j] = *idum;
		}
	iy=iv[0];
}
k=(*idum)/IQ; 
*idum=IA*(*idum-k*IQ)-IR*k; 
if (*idum < 0) *idum += IM;
j=iy/NDIV; 
iy=iv[j];
iv[j] = *idum;
if ((temp=AM*iy) > RNMX) return RNMX; 
else return temp;
}
#undef IA
#undef IM 
#undef AM 
#undef IQ 
#undef IR
#undef NTAB 
#undef NDIV 
#undef EPS
#undef RNMX 
