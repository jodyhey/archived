/*
* Copyright 2002 by Jody Hey
* Rutgers University, Piscataway, NJ 08855
*
* This computer program and documentation may be freely copied
* and used by anyone, provided no fee is charged for it.
*/


#undef SITES_G 

#include "sites.h"
#define PFMax 4
#define itmax  1000

/*
observations
exclusive 1, exclusive 2, shared and fixed
parameters theta1, theta2, thetaA and t
use expressions 12-16 of Wakeley & Hey

for the case of sites frequencies
three observation classes 1,6 , 2, 5   3,4
parameters theta, thetaA, T
use expression 21.

*/

/* points to function to be maximized by amoeba */
static void (*fillfunc)(double []);
static double paramest[4];
static double func[4], datanums[4];
static double choose2[MaxS+1];
static double exp_ss, exp_sx1_before, exp_sx2_before, exp_sf_before;
static  double p[PFMax+1][PFMax+1];
static    double y[PFMax+1]; 
static  int iter;
static int n1, n2;

/*Prototypes*/
static double _exp(double exponent);

/*gets the probability of np given T and n, expressions 10 and 11 of Wakeley and Hey */
static double pn_np(int n, int np, double time);

/*expressions 12,14,15 are grouped into funcs12_14_15 */
/* ex 12 is the probability of S shared polymorphisms */
/* ex 14 is the probability of S before time tau/theta */
/* ex 15 is the probability of s fixed differences from before time tau/theta */
static void funcs12_14_15(double theta1, double theta2, double thetaa, double tau);

/* gets the probability of S after time tau/theta, expresssion 13 */
static double exp_s_ex_after(int n, double theta, double tau);


/* the probability of s fixed differences from after time tau/theta expression 16 */
static double exp_s_fix_after(double theta1, double theta2, double tau);

/* the probability that a mutatant of size k in the sample of size np
  goes to size i in the sample of n  - expression 18 */
static double pki(int n1, int n1p, int k, int ival);

/* the expected number of mutations in size class i  expression 20 */
static double exp_z_i(int n1, int ival, double theta1, double thetaa, double tau);

static double choose(int n,int i);
static void fillfunc_isolate(double params[]);
static void fillfunc_popsize(double params[]);
static double startamoebafunc(int nump,double params[]);
static double  amoebafunc(int nump, double params[]);
int amoeba( double tolerance, int ndim);

/* Functions */

static double _exp(double _exponent){
 if (_exponent < -300 ) return(0.0);
 else return(exp(_exponent));
} 

void fill_watterm(void){
static   int num;
   watterm[0]=0.0;
   watterm[1]=0.0;
   watterm[2]=1.0;
   for (num=3 ;num<=MaxS ;num++)
		watterm[num] = watterm[num-1] + 1.0/(num-1);
}


static double choose(int num,int pick){
   if (num>=pick)
		return(fact[num]/(fact[pick]*fact[num-pick]));
    else return(0.0);
}

void fill_choose2(void){
static  int kk;
  for (kk=2;kk<= MaxS; kk++) choose2[kk] = choose(kk,2);
}

static double pn_np(int n, int np, double time){
static   int i,j,k;
static   double numerator,tempdenom,denom,temp,sum;
   sum = 0.0;
   if (time <= 0.0 /*  0*/ ) return(0.0);
   else{
   if ( np==1 ){
      for (i=2 ;i<=n ;i++ ){
         numerator = _exp(-choose2[i]*time);
         denom = 1;
         for (j=2 ;j<=n ;j++ )
            if (j != i){
					tempdenom = 1.0-(( (double) (i*(i-1)))/ ((double) (j*(j-1))));
               denom *= tempdenom;
            }
         temp = numerator/denom;
         sum += temp;
      }
     temp = 1.0-sum;
	  return(temp);
   }
   else{
      for (i=np ;i<=n ;i++ ){
         numerator = choose2[i]*_exp(-choose2[i]*time);
         denom = 1;
         for (j=np ;j<=n ;j++ )
            if ( j != i ){
				 tempdenom = 1.0-(( (double) (i*(i-1)))/ ((double) (j*(j-1))));
               denom *= tempdenom;
            }
         temp = numerator/denom;
         sum += temp;
      }
      temp = 1.0/choose2[np];
      temp *= sum;
		return(temp);
   }
  }
}

/* gets the probability of S after time tau/theta, expresssion 13 */
static double exp_s_ex_after(int n, double theta, double tau){
 static  double sum, temp, value;
 static int np;
   if (/*(theta<=0.0)||(tau<=0.0)*/ 0) return(0.0);
   else{
   sum = 0.0;
   for (np=2 ;np<=n ; np++){
      temp = watterm[np];
      temp *= pn_np(n,np,tau/theta);
      sum += temp;
   }
   value = theta*(watterm[n]-sum);
   return(value);
}
}

/* the probability of s fixed differences from after time tau/theta expression 16 */
static double exp_s_fix_after(double theta1, double theta2, double tau){
 static int i,j,k,popnum,n;
 static double numerator,tempdenom,denom,temp,sum,sum1,theta, value;
   if (/* (theta1<=0.0)||(theta2<=0.0)||(tau<=0.0) */ 0) return(0.0);
   else{
   value = tau;
   sum = 0.0;
   for (popnum=1;popnum <=2 ;popnum++){
      if ( popnum==1 ){
         n=n1;
         theta=theta1;
      } else{
         n=n2;
         theta=theta2;
      }
      sum1 = 0.0;
      for (i=2 ;i<=n ;i++ ){
         numerator = 1.0 - _exp(-choose2[i]*tau/theta);
         denom = choose2[i];
         for (j=2 ;j<=n ;j++ ){
            if ( j != i ){ tempdenom = 1.0-(( (double) (i*(i-1)))/ ((double) (j*(j-1))));
               denom *= tempdenom;
            }
           }
         temp = numerator/denom;
         sum1 += temp;
      }
     temp = sum1* theta/2.0;
     sum += temp;
   }
   value -= sum;
   return(value);
}
}

/* the probability that a mutatant of size k in the sample of size np
  goes to size i in the sample of n  - expression 18 */
static double pki(int n, int np, int k, int ival){
 static double temp,temp1,value,prod;
 static int x,j,r;
   if ((k>ival)|| ((ival-k) > (n-np))) return(0.0);
   temp= choose((n-np),(ival-k));
   temp1 = 1.0;
   x=k;
   r = ival-k;
   prod = 1.0;
   for (j= x; j <= x+r-1;j++) prod *= j;
   temp1 *= prod;
   x=np-k;
   r=n-np-ival+k;
   prod = 1.0;
   for (j= x; j <= x+r-1;j++) prod *= j;
   temp1 *= prod;
   x=np;
   r=n-np;
   prod = 1.0;
   for (j= x; j <= x+r-1;j++) prod *= j;
   temp1 /= prod;
   value = temp*temp1;
   return(value);

}

/* the expected number of mutations in size class i  expression 20 */
static double exp_z_i(int n, int ival, double theta, double thetaa, double tau){
 static double sum1, sum2, temp1, temp2,value;
 static int np, k;
   sum1 =0.0;
   for ( np=2;np<=n;np++ ){
      temp1=pn_np(n,np,tau/theta);
      sum2 = 0.0;
      for (k=1;k<=np-1;k++){
         temp2 = pki(n,np,k,ival);
         temp2 /= k;
         sum2 += temp2;
      }
      sum1 += temp1 * sum2;
   }
   sum1 *= (thetaa-theta);
   value = theta/ival + sum1;
   return(value);

}


/* get the expected number of sites with frequency class fi,n-fi */
/* called by finish() */
float get_sitefreq_i(unsigned int groupi,int  fi)
    {
    double temp,sum,denom;
    int maxfreq;
    unsigned int i;
    /* group sizes of 6 and 7 are the smallest that can give frequencies in a
    folded distribution in classes 1 2 and 3 */
    if ( (groupsize[groupi] ==6 )||(groupsize[groupi]==7 )) return((float) polydist[SITESUM][groupi][fi-1]);
    else
        {
        maxfreq = groupsize[groupi]/2;
        sum = 0.0;
        denom = choose(groupsize[groupi],7);
        for ( i=1;i<=maxfreq ;i++ )
            {
           if (i==groupsize[groupi]-i) temp = choose(i,fi)*choose(groupsize[groupi]-i,7-fi)+choose(i,7-fi)*choose(groupsize[groupi]-i,fi);
            else  temp = choose(i,fi)*choose(groupsize[groupi]-i,7-fi);
           temp /= denom;
           temp *= polydist[SITESUM][groupi][i-1];
           sum += temp;
            }
       return((float) sum);
       }
    }


/* group expressions 12,twice 14 and 15 into 1 function because they all have
double sums of pn_np  - save time */

static void funcs12_14_15(double theta1, double theta2, double thetaa, double tau){
static int n1p,n2p;
static double temp12, temp14_1, temp14_2, temp15;
static double sum12, sum14_1, sum14_2, sum15;
static double phold, pp;
   sum12 = 0.0;
   sum14_1 = 0.0;
           n2p = 1;
           phold = pn_np(n2,n2p,tau/theta2);
           for (n1p=2;n1p <= n1; n1p++){
               pp = phold * pn_np(n1,n1p,tau/theta1);
               temp14_1 = watterm[n1p+n2p];
               temp14_1 -= watterm[n2p];
               temp14_1 -= ( (1.0/n1p) + (1.0/n2p))/choose((n1p+n2p),n1p);
               sum14_1 += temp14_1*pp;
               }
   sum14_2 = 0.0;
           n1p = 1;
           phold = pn_np(n1,n1p, tau/theta1);
           for (n2p=2;n2p <= n2; n2p++){
               pp = phold * pn_np(n2,n2p,tau/theta2);
               temp14_2 = watterm[n1p+n2p];
               temp14_2 -= watterm[n1p];
               temp14_2 -= ( (1.0/n1p) + (1.0/n2p))/choose((n1p+n2p),n2p);
               sum14_2 += temp14_2*pp;
               }
   sum15 = 0.0;
         n1p = 1;
         phold = pn_np(n1,n1p, tau/theta1);
         for (n2p=1 ;n2p<= n2 ;n2p++){
           pp =  phold * pn_np(n2,n2p,tau/theta2);
           temp15 =( (1.0/n1p) + (1.0/n2p))/choose((n1p+n2p),n1p);
           sum15 += pp*temp15;
           }
         n2p = 1;
         phold = pn_np(n2,n2p, tau/theta2);
         for (n1p=2 ;n1p<= n1 ;n1p++){
           pp =  phold * pn_np(n1,n1p,tau/theta1);
           temp15 =( (1.0/n1p) + (1.0/n2p))/choose((n1p+n2p),n1p);
           sum15 += pp*temp15;
           }
/* now do loops in common */
   for ( n1p=2;n1p<= n1 ;n1p++){
      phold = pn_np(n1,n1p, tau/theta1);
      for (n2p=2 ;n2p<= n2 ;n2p++){
         pp =  phold * pn_np(n2,n2p,tau/theta2);
         temp12 = watterm[n1p];
         temp12 += watterm[n2p];
         temp12 -= watterm[n1p+n2p];
         temp12 += ( (1.0/n1p) + (1.0/n2p))/choose((n1p+n2p),n1p);
         sum12 += temp12*pp;


         temp14_1 = watterm[n1p+n2p];
         temp14_1 -= watterm[n2p];
         temp14_1 -= ( (1.0/n1p) + (1.0/n2p))/choose((n1p+n2p),n1p);
         sum14_1 += temp14_1*pp;

         temp14_2 = watterm[n1p+n2p];
         temp14_2 -= watterm[n1p];
         temp14_2 -= ( (1.0/n1p) + (1.0/n2p))/choose((n1p+n2p),n2p);
         sum14_2 += temp14_2*pp;

         temp15 = ( (1.0/n1p) + (1.0/n2p))/choose((n1p+n2p),n1p);
         sum15 += temp15*pp;
       }

     }

   exp_ss = thetaa*sum12;
   exp_sx1_before = thetaa*sum14_1;
   exp_sx2_before = thetaa*sum14_2;
   exp_sf_before = thetaa*sum15;

}

static void fillfunc_isolate(double params[]){
static int j;
	double temp;
   /* first due functions that share double sums of pn_np */
   funcs12_14_15(fabs(params[0]),fabs(params[1]),fabs(params[2]),fabs(params[3]));
   /* now do sx1 */
   temp = exp_s_ex_after(n1,fabs(params[0]),fabs(params[3]));
   temp += exp_sx1_before;
   func[0] = temp;
    /* now do sx2 */
   temp = exp_s_ex_after(n2,fabs(params[1]),fabs(params[3]));
   temp += exp_sx2_before;
   func[1] = temp;
   /* now do ss */
   func[2] = exp_ss;
   /* now do sf */
   temp = exp_sf_before;
	temp += exp_s_fix_after(fabs(params[0]),fabs(params[1]),fabs(params[3]));
	func[3] = temp;
}

static void fillfunc_popsize(double params[]){
	int ival,n;
	double temp;
  n = n1;
	for (ival=1;ival<=3 ;ival++ ){
	 temp = exp_z_i(n,ival,fabs(params[0]),fabs(params[1]),fabs(params[2]))
        + exp_z_i(n,n-ival, fabs(params[0]),fabs(params[1]),fabs(params[2]));
	 if (( n==6) && (ival==3) ) temp /= 2.0;
	 func[ival-1] =/* fabs */(temp);
	}
}



double amoebafunc(int nump, double params[]){
static double temp,sum;
static int i;
  if (nump==4&&datanums[2]==0) params[2]=0.0;
  fillfunc(params);
  sum = 0.0;
  for (i=0;i<=nump -1;i++) sum += (func[i] - datanums[i])*(func[i] - datanums[i]);
  return(sum);

}

double startamoebafunc(int nump,double params[]){
static double temp,sum;
static int i;
/*  if (nump==4&&datanums[2]==0) params[2]=0.0; */
  fillfunc(params);
  sum = 0.0;
  for (i=0;i<=nump -1;i++) sum += (func[i] - datanums[i])*(func[i] - datanums[i]);
  return(sum);

}


int amoeba( double tolerance, int ndim){
 /* tolerance is the test criteria; ndim is the number of parameters */
/*modified from amoeba of Press et al */

 static  double alpha=1.0, beta=0.5,  gamma_ =2.0;
 static   int mpts,j,inhi,ilo,ihi,i;
   static double yprr,ypr;
  static double temp1,temp2, rtol;
  static double pr[PFMax+1],prr[PFMax+1],pbar[PFMax+1];
   mpts = ndim + 1;
   iter = 0;
   rtol = tolerance * 10;
   while (iter <= itmax) {
      ilo = 0;
      if (y[0] > y[1]){
         ihi = 0;
         inhi = 1;
         }
       else {
         ihi = 1;
         inhi = 0;
         }
      for (i=0; i<= mpts-1;i++){
         if (y[i] < y[ilo]) ilo = i;
         if (y[i] > y[ihi]){
            inhi = ihi;
            ihi = i;
            }
           else if (y[i] > y[inhi]){
            if (i != ihi) inhi = i;
            }
        }
      if ((fabs(y[ihi])+fabs(y[ilo]) == 0.0)/*||(fabs(y[ihi])+fabs(y[ilo]) == _INF)*/)
         rtol = 2.0;
        else rtol = 2.0*fabs(y[ihi]-y[ilo])/(fabs(y[ihi])+fabs(y[ilo]));
        if (rtol < tolerance) goto leave;
      iter++;
      for (j=0; j<= ndim-1;j++) pbar[j] = 0.0;
      for (i=0;i<= mpts-1;i++){
         if (i != ihi) for (j=0; j<=ndim-1;j++) pbar[j] += p[i][j];
         }
      for (j=0; j<=ndim-1;j++){
         pbar[j] /= ndim;
         pr[j] = (1.0+alpha)*pbar[j]-alpha*p[ihi][j];
         }
      ypr = amoebafunc(ndim,pr);
      if (ypr <= y[ilo]){
         for (j=0;j<= ndim-1;j++) prr[j] = gamma_* pr[j]+(1.0-gamma_)*pbar[j];
         yprr = amoebafunc(ndim,prr);
         if (yprr < y[ilo]){
            for (j=0;j<= ndim-1;j++) p[ihi][j] = prr[j];
            y[ihi] = yprr;
            }
          else {
            for (j=0;j<= ndim-1;j++) p[ihi][j] = pr[j];
            y[ihi] = ypr;
            }
         }
      else{
        if (ypr >= y[inhi]){
           if (ypr < y[ihi]) {
            for (j=0;j<=ndim-1;j++) p[ihi][j] = pr[j];
            y[ihi] = ypr;
            }
         for (j=0;j<=ndim-1;j++) prr[j] = beta*p[ihi][j]+(1.0-beta)*pbar[j];
         yprr = amoebafunc(ndim,prr);
         if (yprr < y[ihi]) {
            for (j=0;j<=ndim-1;j++) p[ihi][j] = prr[j];
            y[ihi] = yprr;
            }
          else {
            for (i=0;i<=mpts-1;i++)
               if (i != ilo) {
                  for (j=0;j<=ndim-1;j++) {
                     pr[j] = 0.5*(p[i][j]+p[ilo][j]);
                     p[i][j] = pr[j];
                     }
                  y[i] = amoebafunc(ndim,pr);
                }
             }
          }
          else {
            for (j=0;j<=ndim-1;j++) p[ihi][j] = pr[j];
            y[ihi] = ypr;
            }
          }
        }
 leave: return(iter);
   }




void doamoeba(int nump,int group1, int group2,float observations[],float expectations[],float parameters[]){
int i,j;
double tempparams[4];
double small = 1e-1;
double scale = 1.0;
  if (nump==4){
   fillfunc = fillfunc_isolate;
   n1 = groupsize[group1];
   n2 = groupsize[group2];
  } else{
   fillfunc = fillfunc_popsize;
   n1 = groupsize[group1];
	if (n1 > 7 ) n1 =7;
   }
   for (i=0;i<= nump-1;i++) datanums[i]= observations[i];
   for (i=0; i <= nump - 1; i++){ p[0][i] = 1.0 + i *0.1 ;

   for (j=1;j<=nump;j++) if (j==i+1) p[j][i] = scale;
             else p[j][i] = small;
   }
   for (j=0;j<=nump;j++){
      for (i=0;i<=nump-1;i++) tempparams[i] = p[j][i];
         y[j] = startamoebafunc(nump,tempparams);
         }
  amoeba(1e-8,nump); 
  for (i=0;i<=nump-1;i++) parameters[i] = (float) fabs(p[0][i]);
  for (i=0;i<= nump-1;i++) expectations[i] = (float) func[i];
/*  if (nump == 4) printf("AMOEBA Theta1: %10.8f Theta2: %10.8f ThetaA: %10.8f Tau: %10.8f Iter: %d\n",paramest[0],paramest[1],paramest[2],paramest[3],iter);
     else printf("AMOEBA Theta1: %10.8f ThetaA: %10.8f Tau: %10.8f Iter: %d\n",paramest[0],paramest[1],paramest[2],iter);*/
}


/*

Trouble
One of the four observations is zero.
High value of shared compared to exclusives or to fixed.

If the expected values are not very close to the observerd

If the estimated parameter values are very large or small, so they
are not within an order of magnitude of the observation values.


*/
