/*
* Copyright 2001 by Jody Hey
* Rutgers University, Piscataway, NJ 08855
*
* This computer program and documentation may be freely copied
* and used by anyone, provided no fee is charged for it.
*/

#undef SITES_G
#include "sites.h"

/* Function prototypes 
void pushchar(int col, char convert);
char popchar(int row,int col);
char popchar2(int row,int col);
void Findnowsit(unsigned int sitnum);
void Findnowsit1(unsigned int sitnum);
void FindnowIDsit(unsigned int sitnum);
boolean nowsitefit(site_rec checksite);
boolean nowIDsitfit(void); */


void clearscreen(void);
void clearmenu(void);
void writemenu(unsigned int lines);
void strdelete(char *s,int pos,int len);
char *strsub(char *ret, char *s,int  pos,int len);
void myASSERT(boolean putative_fact,int location);
long    *P_setunion  (long *d, long *s1, long *s2);
long *P_setint(long *d,long *s1,long *s2);
long    *P_setdiff   (long *d, long *s1, long *s2);
long    *P_setxor(long *d, long *s1, long *s2);
int  P_inset(unsigned val, long *s);
long    *P_addset(long *s, unsigned val);
long    *P_addsetr(long *s, unsigned v1, unsigned v2);
long    *P_remset(long *s, unsigned val);
int P_setequal(long * s1, long *s2);
int P_subset(long *s1, long *s2);
long    *P_setcpy(long *d, long *s);
long    *P_expset(long *d, long s);
long     P_packset(long *s);
int P_eof(FILE *f);
int P_eoln(FILE *f);  
/* functions */

void pushchar(unsigned int col, char convert)
{
  /*if num is odd put the character in the first 4 bits, if it is even
  put it in the last 4 bits*/
   uchar  shortchar, temp;
  int spot;
  switch (convert) {

  case 'A':
    temp = 1;
    break;

  case 'C':
    temp = 2;
    break;

  case 'G':
    temp = 3;
    break;

  case 'T':
    temp = 4;
    break;

  case 'N':
    temp = 5;
    break;

  case 'a':
    temp = 1;
    break;

  case 'c':
    temp = 2;
    break;

  case 'g':
    temp = 3;
    break;

  case 't':
    temp = 4;
    break;

  case 'n':
    temp = 5;
    break;

  case '.':
    temp = 6;
    break;

  case '-':
    temp = 7;
    break;

  case '*':
    temp = 7;
    break;

  default:
    temp = 5;
    printf("%c in column %d is not allowed as a character - change to N \n",
	   convert, col);
    break;
  }
  /*if odd then clear the first four positions and put
    temp in there. If even clear the last four positions and put temp
    in there.*/
  if (col & 1)
    spot = col / 2 + 1;
  else
    spot = col / 2;
  shortchar = nowseq_ptr->sequence[spot - 1];
  if (col & 1) {
    shortchar &= 240;
    shortchar |= temp;
  } else {
    temp <<= 4;
    shortchar &= 15;
    shortchar |= temp;
  }
  nowseq_ptr->sequence[spot - 1] = shortchar;
}


char popchar(unsigned int row,unsigned int col)
{
  uchar  shortchar;
  char temp;
  int spot;

  while (nowseq_ptr->n != row) {
    if (row < nowseq_ptr->n)
      nowseq_ptr = nowseq_ptr->last;
    else
      nowseq_ptr = nowseq_ptr->next;
  }

  if (col & 1) {
    spot = (((unsigned)col) >> 1) + 1;   /* (col DIV 2) + 1;*/
    shortchar = nowseq_ptr->sequence[spot - 1] & 15;
  } else {
    spot = ((unsigned)col) >> 1;   /*col DIV 2;*/
    shortchar = nowseq_ptr->sequence[spot - 1] & 240;
    shortchar >>= 4;
  }
  switch (shortchar) {

  case 1:
    temp = 'A';
    break;

  case 2:
    temp = 'C';
    break;

  case 3:
    temp = 'G';
    break;

  case 4:
    temp = 'T';
    break;

  case 5:
    temp = 'N';
    break;

  /*        6 : temp := '-';
          7 : temp := '-';*/
  case 6:
    temp = indelchar;
    break;

  case 7:
    temp = indelchar;
    break;
  }
  return temp;
}  /*popchar*/


char popchar2(unsigned int row,unsigned int col)
{
  uchar shortchar;
  char temp;
  int spot;

  while (nowseq2_ptr->n != row) {
    if (row < nowseq2_ptr->n)
      nowseq2_ptr = nowseq2_ptr->last;
    else
      nowseq2_ptr = nowseq2_ptr->next;
  }

  if (col & 1) {
    spot = (((unsigned)col) >> 1) + 1;   /* (col DIV 2) + 1;*/
    shortchar = nowseq2_ptr->sequence[spot - 1] & 15;
  } else {
    spot = ((unsigned)col) >> 1;   /*col DIV 2;*/
    shortchar = nowseq2_ptr->sequence[spot - 1] & 240;
    shortchar >>= 4;
  }
  switch (shortchar) {

  case 1:
    temp = 'A';
    break;

  case 2:
    temp = 'C';
    break;

  case 3:
    temp = 'G';
    break;

  case 4:
    temp = 'T';
    break;

  case 5:
    temp = 'N';
    break;

  /*        6 : temp := '-';
          7 : temp := '-';*/
  case 6:
    temp = indelchar;
    break;

  case 7:
    temp = indelchar;
    break;
  }
  return temp;
}  /*popchar*/

/* sitnum and sitn are order from 1 on up */
void Findnowsit(unsigned int sitnum)
{
  while (nowsite_ptr->sitn != sitnum) {
    if (sitnum < nowsite_ptr->sitn)
      nowsite_ptr = nowsite_ptr->last;
    else
      nowsite_ptr = nowsite_ptr->next;
  }
  nowsite = *nowsite_ptr;
}

/* for use when two sites are needed at same time - mostly for LD */
void Findnowsit1(unsigned int sitnum)
{
  if (nowsite1_ptr == NULL) nowsite1_ptr = nowsite_ptr;
  while (nowsite1_ptr->sitn != sitnum) {
    if (sitnum < nowsite1_ptr->sitn)
      nowsite1_ptr = nowsite1_ptr->last;
    else
      nowsite1_ptr = nowsite1_ptr->next;
  }
  nowsite1 = *nowsite1_ptr;
}

void FindnowIDsit(unsigned int sitnum)
{
  while (nowIDsite_ptr->sitn != sitnum) {
    if (sitnum < nowIDsite_ptr->sitn)
      nowIDsite_ptr = nowIDsite_ptr->last;
    else
      nowIDsite_ptr = nowIDsite_ptr->next;
  }
  nowIDsit = *nowIDsite_ptr;
}


boolean nowsitefit(site_rec checksite)
{
  boolean stillin;
  SITETYPE sitetypecase;

  stillin = _false;
  for (sitetypecase = EXN;
       (long)sitetypecase <= (long)DEL;
       sitetypecase = (SITETYPE)((long)sitetypecase + 1))
    stillin = (stillin || (whatsites[(long)sitetypecase - (long)EXN] &&
			   checksite.s[(long)sitetypecase - (long)EXN]));
  for (sitetypecase = INF;
       (long)sitetypecase <= (long)FOU;
       sitetypecase = (SITETYPE)((long)sitetypecase + 1)) {
    if (whatsites[(long)sitetypecase - (long)EXN])
      stillin = (stillin && whatsites[(long)sitetypecase - (long)EXN] &&
		 checksite.s[(long)sitetypecase - (long)EXN]);
  }
  return stillin;
}


boolean nowIDsitfit(void)
{
  boolean stillin;
  SITETYPE sitetypecase;

  stillin = _false;
  for (sitetypecase = EXN;
       (long)sitetypecase <= (long)DEL;
       sitetypecase = (SITETYPE)((long)sitetypecase + 1))
    stillin = (stillin || (whatsites[(long)sitetypecase - (long)EXN] &&
			   nowIDsit.s[(long)sitetypecase - (long)EXN]));
  for (sitetypecase = INF;
       (long)sitetypecase <= (long)FOU;
       sitetypecase = (SITETYPE)((long)sitetypecase + 1)) {
    if (whatsites[(long)sitetypecase - (long)EXN])
      stillin = (stillin && whatsites[(long)sitetypecase - (long)EXN] &&
		 nowIDsit.s[(long)sitetypecase - (long)EXN]);
  }
  return stillin;
}


void clearscreen(void)
{
  printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
}

void clearmenu(void)
{
  unsigned int i;
  for (i=0;i<25;i++) screentext[i][0] = '\0';
}

void writemenu(unsigned int lines)
{
  unsigned int i;
  for (i=0;i<lines;i++) printf("%s\n",screentext[i]);
  printf("%s",screentext[lines]);
}

/* Delete the substring of length "len" at index "pos" from "s".
   Delete less if out-of-range. */
void strdelete(char *s,int pos,int len)
{
    int slen;

    if (--pos < 0)
        return;
    slen = strlen(s) - pos;
    if (slen <= 0)
        return;
    s += pos;
    if (slen <= len) {
        *s = 0;
        return;
    }
    while ((*s = s[len])) s++;
}

char *strsub(char *ret, char *s,int  pos,int len)
{
  char *s2;

    if (--pos < 0 || len <= 0) {
        *ret = 0;
        return ret;
    }
    while (pos > 0) {
        if (!*s++) {
            *ret = 0;
            return ret;
        }
        pos--;
    }
    s2 = ret;
    while (--len >= 0) {
        if (!(*s2++ = *s++))
            return ret;
    }
    *s2 = 0;
    return ret;
}


void myASSERT(boolean putative_fact,int location)
{
  if (putative_fact)
    return;
  printf(" ***** ERROR NUMBER %4u\n", location);
  switch (location) {

  case 1:
    printf("Drop Site list too large, max is %ld\n", (long)MaxDropKeep);
    break;

  case 2:
    printf("Limit Site list too large, max is %ld\n", (long)MaxDropKeep);
    break;

  case 3:
    printf("Incorrect option choice \n");
    break;

  case 4:
    printf("Unspecified error in sequence data file \n");
    break;

  case 6:
    printf("Cannot simultanesouly DROP and LIMIT sites, options D and L\n");
    break;

  case 10:
    printf("Trouble reading sequences, lengths do not match \n");
    break;

  case 12:
    printf("Trouble making 4 item subsamples for Hey Wakely estimate of 4Nc\n");
    break;

  case 100:
    printf("error in counting in Hudson's estimate of 4NC \n");
    break;
  }
  exit(-1);
}


/* Sets are stored as an array of longs.  S[0] is the size of the set;
   S[N] is the N'th 32-bit chunk of the set.  S[0] equals the maximum
   I such that S[I] is nonzero.  S[0] is zero for an empty set.  Within
   each long, bits are packed from lsb to msb.  The first bit of the
   set is the element with ordinal value 0.  (Thus, for a "set of 5..99",
   the lowest five bits of the first long are unused and always zero.) */

/* (Sets with 32 or fewer elements are normally stored as plain longs.) */

long    *P_setunion  (long *d, long *s1, long *s2)
{
    long *dbase = d++;
    int sz1 = *s1++, sz2 = *s2++;
    while (sz1 > 0 && sz2 > 0) {
        *d++ = *s1++ | *s2++;
	sz1--, sz2--;
    }
    while (--sz1 >= 0)
	*d++ = *s1++;
    while (--sz2 >= 0)
	*d++ = *s2++;
    *dbase = d - dbase - 1;
    return dbase;
}


long *P_setint(long *d,long *s1,long *s2)           /* d := s1 * s2 */
{
    long *dbase = d++;
    int sz1 = *s1++, sz2 = *s2++;
    while (--sz1 >= 0 && --sz2 >= 0)
        *d++ = *s1++ & *s2++;
    while (--d > dbase && !*d) ;
    *dbase = d - dbase;
    return dbase;
}


long    *P_setdiff   (long *d, long *s1, long *s2)
{
    long *dbase = d++;
    int sz1 = *s1++, sz2 = *s2++;
    while (--sz1 >= 0 && --sz2 >= 0)
        *d++ = *s1++ & ~*s2++;
    if (sz1 >= 0) {
        while (sz1-- >= 0)
            *d++ = *s1++;
    }
    while (--d > dbase && !*d) ;
    *dbase = d - dbase;
    return dbase;
}


long    *P_setxor(long *d, long *s1, long *s2)
{
    long *dbase = d++;
    int sz1 = *s1++, sz2 = *s2++;
    while (sz1 > 0 && sz2 > 0) {
        *d++ = *s1++ ^ *s2++;
	sz1--, sz2--;
    }
    while (--sz1 >= 0)
	*d++ = *s1++;
    while (--sz2 >= 0)
	*d++ = *s2++;
    while (--d > dbase && !*d) ;
    *dbase = d - dbase;
    return dbase;
}


int  P_inset(unsigned val, long *s)
{
    int bit;
    bit = val % SETBITS;
    val /= SETBITS;
    if (val < *s++ && ((1L<<bit) & s[val]))
	return 1;
    return 0;
}

long    *P_addset(long *s, unsigned val)
{
    long *sbase = s;
    int bit, size;
    bit = val % SETBITS;
    val /= SETBITS;
    size = *s;
    if (++val > size) {
        s += size;
        while (val > size)
            *++s = 0, size++;
        *sbase = size;
    } else
        s += val;
    *s |= 1L<<bit;
    return sbase;
}


long    *P_addsetr(long *s, unsigned v1, unsigned v2)
{
    long *sbase = s;
    int b1, b2, size;
    if ((int)v1 > (int)v2)
	return sbase;
    b1 = v1 % SETBITS;
    v1 /= SETBITS;
    b2 = v2 % SETBITS;
    v2 /= SETBITS;
    size = *s;
    v1++;
    if (++v2 > size) {
        while (v2 > size)
            s[++size] = 0;
        s[v2] = 0;
        *s = v2;
    }
    s += v1;
    if (v1 == v2) {
        *s |= (~((-2L)<<(b2-b1))) << b1;
    } else {
        *s++ |= (-1L) << b1;
        while (++v1 < v2)
            *s++ = -1;
        *s |= ~((-2L) << b2);
    }
    return sbase;
}


long    *P_remset(long *s, unsigned val)
{
    int bit;
    bit = val % SETBITS;
    val /= SETBITS;
    if (++val <= *s) {
	if (!(s[val] &= ~(1L<<bit)))
	    while (*s && !s[*s])
		(*s)--;
    }
    return s;
}


int P_setequal(long * s1, long *s2)
{
    int size = *s1++;
    if (*s2++ != size)
        return 0;
    while (--size >= 0) {
        if (*s1++ != *s2++)
            return 0;
    }
    return 1;
}


int P_subset(long *s1, long *s2)
{
    int sz1 = *s1++, sz2 = *s2++;
    if (sz1 > sz2)
        return 0;
    while (--sz1 >= 0) {
        if (*s1++ & ~*s2++)
            return 0;
    }
    return 1;
}


long    *P_setcpy(long *d, long *s)
{
    long *save_d = d;

#ifdef SETCPY_MEMCPY
    memcpy(d, s, (*s + 1) * sizeof(long));
#else
    int i = *s + 1;
    while (--i >= 0)
        *d++ = *s++;
#endif
    return save_d;
}


/* s is a "smallset", i.e., a 32-bit or less set stored
   directly in a long. */

long    *P_expset(long *d, long s)
{
    if (s) {
	d[1] = s;
	*d = 1;
    } else
        *d = 0;
    return d;
}


long     P_packset(long *s)
{
    if (*s++)
        return *s;
    else
        return 0;
}



/* Check if at end of file, using Pascal "eof" semantics.  End-of-file for
   stdin is broken; remove the special case for it to be broken in a
   different way. */

int P_eof(FILE *f)
{
    register int ch;

    if (feof(f))
    return 1;
    if (f == stdin)
    return 0;    /* not safe to look-ahead on the keyboard! */
	if ((ch = getc(f)) == EOF) return 1;
	else {
		ungetc(ch, f);
		return 0;
	}
}


/* Check if at end of line (or end of entire file). */

int P_eoln(FILE *f)
{
    register int ch;

    
    if ((ch = getc(f)) == '\n') return 1;
	else{
		ungetc(ch, f);
		return (ch == '\n');
	}
}



