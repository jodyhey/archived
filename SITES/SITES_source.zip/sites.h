/*
* Copyright 2002 by Jody Hey
* Rutgers University, Piscataway, NJ 08855
*
* This computer program and documentation may be freely copied
* and used by anyone, provided no fee is charged for it.
*/

/* Header for sites */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <float.h>
#include <limits.h>
#include <time.h>
#include <ctype.h>
#include <assert.h>
#ifdef  __MWERKS__
#include <console.h>
#include "sioux.h"
#endif



/* CONSTANTS */

/* if compiled under Microsoft Visual C++, then _MSC_VER  is defined */
/* to find info under MVC++ help for other compiler predefinitions search help for
'predefined macros' */
/* if compiled under Metrowerks  CodeWarrior  then __MWERKS__ is defined */
/* to find info under Metrowerks Codewarrior  search the Codewarrior Manuals 
(not the basic help)  for 'Predefined Symbols */
/* use SHARE_POLY_DIST_OPTION  when the shared polymorphism distribution is to be printed out.
This requires a slot of memory. so it  enforces smaller compile by defining SITESSMALL
- see also the use of JHoption
*/

/* three sizes of compilations SITESSMALL, SITESMEDIUM  SITESBIG */
/*#define SHARE_POLY_DIST_OPTION */

/*
if SHARE_POLY_DIST_OPTION  it is usually best to compile small
#ifdef SHARE_POLY_DIST_OPTION
#define SITESSMALL
#endif
*/
/* maximum sequence length is currently at the limit of an unsigned short  65,535 */
/* 10/18/00  went thru and changed most short to int */
#define SITESBIG

#ifdef SITESSMALL /* smaller parameter values, total fits under 640K*/
#define MaxL            1500   /*can have sequence lengths up to 2 * MaxL*/
#define MaxS            45   /*can have up to MaxS sequences*/
#define MaxNoncods      10   /*number of stretchs of noncoding sequence*/
#define MaxDropKeep     1500   /*number of bases to drop or keep*/
#define MaxGroups       10   /*maximum numbers of groups of sequences*/
#define _FNSIZE         100
#define MaxGroupRecPairs   200  /*maximum numbers of distinct indels in alligned sequence*/
#define MaxIndels       100
#define MaxMatrixLineLength 256
#define Maxmultibase    40  /*the max # of base positions in which can count 3 or 4 bases  segregating */
#define Max4samps       500 /*for use in estimating population recombination rate*/
#define Maxxypair         100
#define  SETL       9            /*9 or MAXS div 32 + 1 */
/* end of SITESSMALL */

#else 
#ifdef  SITESBIG  /* Another range of parameter values, lots of long sequences*/
#define MaxL            6000
#define MaxS            700   
#define MaxNoncods      30   
#define MaxDropKeep     4000   
#define MaxGroups       50 
#define _FNSIZE         100
#define MaxGroupRecPairs   2000
#define MaxIndels      2000
#define MaxMatrixLineLength 1000
#define Maxmultibase    200
#define Max4samps        5000    
#define Maxxypair         200
#define  SETL              32
  /*end of SITESBIG parameter block */

/* default range of parameter values, works for most situations*/
/*#define SITESMEDIUM */
#else 
#define MaxL            10001   
#define MaxS            400   
#define MaxNoncods      12   
#define MaxDropKeep     5000  
#define MaxGroups       20   
#define _FNSIZE         100
#define MaxGroupRecPairs   500
#define MaxIndels        500
#define MaxMatrixLineLength 256
#define Maxmultibase    200
#define Max4samps        2000  
#define Maxxypair         200
#define SETL                13
#endif
#endif


#define MaxSitesforRec  MaxMatrixLineLength - 11
#define MaxCest            2.0   /*values bigger than 3 crash jwfunc*/
#define MaxGroupNameLength   12
#define MaxSeqNameLength  10
#define dashline  "_____________________________________________________________________________"
#define starline  "*****************************************************************************"
#define FP fprintf(rfile,
#define FPM fprintf(LDmatrixfile,
#define SETBITS         32
#define stepspace       10


/* MACROS */
 /* returns a random integer between 0 and num-1*/

#define random(num) (int) ( (long) rand() % (num)) 
#define round(X) (long) ((X)+0.5)

static double sqrarg;
#define SQR(a) ((sqrarg=(a)) == 0.0 ? 0.0 : sqrarg*sqrarg)

/* NEW TYPES */

typedef enum 
	{
	ALL=-1, EXN, INT, SYN, REP, SOR, DEL, INF, TRN, TRV, THREE, FOU
	} SITETYPE;
/*ALL - all sites
  EXN - exon sites
  INT - noncoding site
  SYN - synonymous site
  REP - replacement site
  SOR - unresolved whether SYN or REP   or multiple changes within a single
        codon, so that there may be both SYN and REP
  DEL - insertion or deletion
  INF - informative site
  TRN - transversion
  TRV - transition
  THREE - three bases
  FOU - all four base pairs
  */

typedef enum 
	{
	FULL, SIT, PEC, COD, PREF, DIF, REC, GCA, INDELS, LD, POPMOD
	} ANALYSISTYPE;
/*FULL - all analyses
  SIT  - sites table
  PEC  - table of details of sysnonymous and replacement changes
  COD  - codon usage tables
  PREF - prefered and non-prefered codons
  DIF  - Simple polymorphism analysis
  REC  - Recombination analysis
  GCA  - GC content
  INDELS  - apply analysis options to insertions and deletions
  LD - Linkage disequilibrium analyses
  POPMOD - isolation and popsize change model fitting
  */

typedef enum
	{
	GROUPS, NEWGROUP, DROPSITE, LIMITSITE, DROPSEQ, ALTCODE, FIRSTREF, SUPPAIR,SITSTYLE
	} OPTIONTYPE;

/*GROUPS - comparisons within groups
  NEWGROUP - change group designations
  DROPSITE - drop some sites
  LIMITSITE - use only some sites
  DROPSEQ - drop some sequences
  ALTCODE - alternate genetic code
  FIRSTREF - use first sequence as reference in site output (concensus is default)
  SUPPAIR  - suppress printout of large pairwise table
  SITSTYLE - use (. and -) instead of (- and *) for site output
  */

typedef enum
	{
	PSN, POL, CONS, DAT
	} linetype;
/*PSN - position number line
  POL - polymorphism type line
  CONS - consensus sequence line
  DAT - data line */

typedef enum bool {_false, _true} boolean;
typedef unsigned char uchar;
typedef boolean SiteBool[FOU +1];

typedef struct Stretch
	{
	unsigned int p5, p3;
	} Stretch;

typedef enum
	{
	A, C, G, T, D, INS, X
	} basetype;

typedef basetype codontype[3];

typedef struct site_rec
	{
	unsigned int sitn;   /*the polymorphic site number*/
	unsigned int seqn;   /*the base position along the sequence*/
	char t[6];   /*text representation of sequence base position*/
	SiteBool s;   /*type of site*/
    codontype *c; /* points to a listing of the all the codons from each line that include this site 
                    only used if prefered and unprefered codons are being analysed*/ 
	char p[MaxS];   /*base values*/
	struct site_rec *next, *last;
	} site_rec;


typedef struct seq_rec
	{
    unsigned int  n;
    unsigned int  sequence[MaxL];
	struct seq_rec *next, *last;
	} seq_rec;


typedef struct amino_acid_site_rec
	{
	int num;
	char TEXT[55];
	struct amino_acid_site_rec *next;
	} amino_acid_site_rec;

typedef enum
	{
	PHYLIPin, SITESin
	} inputtype;


typedef enum
    {
    SITESUM,
    NCODE,
    RDIST,
    SDIST,
    PREF_PREF,
    PREF_UPREF,
    UPREF_PREF,
    UPREF_UPREF,
    } polydistclass;

typedef enum
	{
	ALA, CYS, ASP, GLU, PHE, GLY, HIS, ILE, LYS, LEU, MET, ASN, PRO, GLN, ARG,
	SER, THR, VLN, TRP, XXX, TYR, STP
	} amino_acid;      /*changed VAL to VLN*/

typedef long lineset[SETL];

typedef enum
/* P - prefered, UNP - unprefered */
    {
    NOTCLEAR, P, UNP
    } codonclass;

/* LDR = r, LDRS = r squared  LDD = D  LDABS = ABS(D) LDPABS = ABS(D') LDDP = D prime */
enum LDtype {LDR,LDRS,LDD,LDABS,LDPABS,LDDP};
/* GLOBAL VARIABLES */

typedef struct LDaccumulate
	{
	float val;
	unsigned n;
	} ldacc_not_used;

/* global variables that are initialized in sitemain.c */
extern SiteBool FalseSites;
extern amino_acid codon_table[T + 1][T + 1][T + 1];
extern char codonstr[T + 1][T + 1][T + 1][12];
extern unsigned short codonsone[T + 1][T + 1][T + 1];
extern unsigned short codonsall[T + 1][T + 1][T + 1];
extern codonclass codonPtable[T + 1][T + 1][T + 1];
extern unsigned int numnocode, numyescode;
extern boolean skipindel,skipmultibase;
/* global variables that are not initialized */


/* if SITES_G is defined then vextern  ignored. This
causes the corresponding variable declarations to be definitions.
SITES_G is only defined in SITEMAIN.C.  If SITES_G is not defined,
as is the case at the beginning of the other files, then vextern
gets replaced by extern and the variable declarations are simply
declarations */

#ifdef SITES_G
#define vextern
#else
#define vextern extern
#endif

vextern Stretch noncods[MaxNoncods];
vextern char names[MaxS][MaxSeqNameLength+1];
vextern char sname[_FNSIZE+1], rname[_FNSIZE+1];
vextern char dropname[_FNSIZE+1], keepname[_FNSIZE+1], seqdropname[_FNSIZE+1];
vextern char sheader[81], message[81], extracomments[50][81];
vextern char command_line[200];
vextern char tempfilename[_FNSIZE];
vextern  int num_extra_comments;
vextern char sitetypelist[20];
vextern char outputlist[20];
vextern char optionlist[20];
vextern char jhoptionlist[2];
vextern char linestring[81];
vextern char screentext[25][81];
vextern int droplist[MaxDropKeep], keeplist[MaxDropKeep];
vextern int indeldroplist[MaxIndels*10],multibasedroplist[MaxDropKeep],seqdroplist[MaxS];
vextern unsigned int compbases[MaxS][MaxS];
vextern double groupdiffs[MaxGroups][MaxGroups], groupcompbases[MaxGroups][MaxGroups];
vextern unsigned int fixdiffs[MaxGroups][MaxGroups];
vextern double avpairfix[MaxGroups][MaxGroups];
vextern unsigned int polysite[MaxGroups];
vextern unsigned int totalpoly[MaxGroups], singleton[MaxGroups],singletonOG[MaxGroups];
vextern unsigned int  outgroup[MaxGroups];
vextern char TajD[MaxGroups][9], FuLiD[MaxGroups][9], FuLiDstar[MaxGroups][10];
vextern unsigned int sharepoly[MaxGroups][MaxGroups];
vextern unsigned int polydist[UPREF_UPREF+1][MaxGroups][MaxS / 2 + 1];
vextern unsigned int polydist_o[UPREF_UPREF+1][MaxGroups][MaxS];
vextern unsigned int gcdata[MaxS][5][2];
vextern char consensus[MaxL * 2];
vextern char IDconsensus[MaxIndels];
vextern unsigned int sicount;
vextern SiteBool whatsites;
vextern unsigned int  oframe, numnoncods;
vextern FILE *sfile, *rfile, *dropkeepfile, *seqdropfile, *regionLDfile, *LDmatrixfile, *mdivfile;
vextern unsigned int howlong;
vextern   unsigned int  nums;
vextern unsigned int scount, idcount;
vextern SITETYPE sitetypecase;
vextern boolean whichlines[MaxS];
vextern boolean iskeepfile, isdropfile, iskeeprange, isdroprange;
vextern boolean isseqdropfile,isseqdroprange;
vextern boolean screenupdate;
vextern unsigned int rangebegin, rangend, numdrop, numkeep, numindeldrop,nummultibasedrop;
vextern unsigned int seqrangebegin,seqrangend,numseqdrop;
vextern seq_rec *nowseq_ptr, *nowseq2_ptr, *firstseq_ptr, *holdseq_ptr;
vextern site_rec nowsite, nowsite1,tempsit, *nowsite_ptr,*nowsite1_ptr,*firstsite_ptr, *lastsite_ptr,
		 nowIDsit, tempIDsit, *nowIDsite_ptr, *firstIDsite_ptr, *lastIDsite_ptr;
vextern amino_acid_site_rec *site_info_last, *site_info_first, *site_info_temp, nowsite_info_;
vextern double synone, repone, synall, repall;
vextern inputtype indata;
vextern boolean analyses[(long)POPMOD - (long)SIT + 1];
vextern ANALYSISTYPE analysiscase;
vextern boolean options[(long)SITSTYLE - (long)GROUPS + 1];
vextern OPTIONTYPE optioncase;
vextern unsigned int numgroups, numgrouplines;
vextern   unsigned int grouplimits[MaxGroups][2];
vextern char groupnames[MaxGroups][MaxGroupNameLength+1];
vextern  unsigned int groupsize[MaxGroups];
vextern boolean INTLV;
vextern char samechar, indelchar;
vextern unsigned int indellengths[MaxIndels];
/* holds the # of sites that have 3 or 4 bases*/
vextern unsigned int groups_multibase[MaxGroups][Maxmultibase + 1];
/* holds position #'s of shared and fixed differences */
vextern unsigned int groups_sharedbase[MaxGroups][MaxGroups][Maxmultibase + 1];
vextern unsigned int groups_fixedbase[MaxGroups][MaxGroups][Maxmultibase + 1];
vextern unsigned int aacount[(long)STP - (long)ALA + 1];
vextern lineset ssets[Max4samps];
vextern  unsigned int ssetarrays[Max4samps][4];
vextern int num4samps;
vextern unsigned int xy1[Maxxypair], xy2[Maxxypair];
vextern unsigned int xyspot1, xyspot2;
vextern  double ax, bx, cx, fa, fb, fc;
vextern unsigned int paircount;
vextern double HudsonH[MaxGroups], HudsonH2[MaxGroups];
vextern char sfile_NAME[_FNSIZE+1];
vextern char rfile_NAME[_FNSIZE+1];
vextern char dropkeepfile_NAME[_FNSIZE+1];
vextern char seqdropfile_NAME[_FNSIZE+1];
vextern double gammarray[MaxGroups];

vextern struct LDaccumulate   LDA[LDDP+1][MaxGroups],LDO[LDDP+1][MaxGroups][MaxGroups],LDS[LDDP+1][MaxGroups][MaxGroups],LDOS[LDDP+1][MaxGroups][MaxGroups];
vextern struct LDaccumulate   LDSS[LDDP+1][MaxGroups][MaxGroups],LDS_over_O[LDDP+1][MaxGroups][MaxGroups],LDS_over_A[LDDP+1][MaxGroups][MaxGroups];
vextern struct LDaccumulate   LDSS_over_O[LDDP+1][MaxGroups][MaxGroups],LDS_less_OS[LDDP+1][MaxGroups][MaxGroups], LDSOS_over_A[LDDP+1][MaxGroups][MaxGroups];


vextern char linkageoptionlist[10];
vextern int LDmeasure;
vextern char LDstr[7];
vextern boolean LDdotypes[LDDP+1];
vextern boolean exclude_singletons;


/* stuff for doing LD between different parts of the sequence */
#define MaxregionLD   12
vextern FILE  *regionLDfile;
vextern char regionLDfile_NAME[_FNSIZE+1];
vextern char LDmatrixfile_NAME[_FNSIZE+1];
vextern boolean JHoption, DoSharePolyDist, DoMDIVoutput, DontaskPhylip;
vextern boolean doLDregion, doLDregiontest, doLDmatrix, doLDshared;
vextern unsigned int regionLD[MaxregionLD],numregionLD;

/* generate output lines for other programs */
vextern boolean doHKAoutput, doWHoutput;

/*extra stuff for new analyses in wakeley and hey  */
/* watterson's term, term i has the sum from j=1 to i-1 of 1/j */
vextern float watterm[2*MaxS+1];
vextern long double fact[MaxS + 1];

vextern char altcodestr[81];

#undef vextern

/* FUNCTION PROTOTYPES in SITEUTIL.C */
void pushchar(unsigned int col, char convert);
char popchar(unsigned int row,unsigned int col);
char popchar2(unsigned int row,unsigned int col);
void Findnowsit(unsigned int sitnum);
void Findnowsit1(unsigned int sitnum);
void FindnowIDsit(unsigned int sitnum);
boolean nowsitefit(site_rec checksite);
boolean nowIDsitfit(void);
void clearscreen(void);
void clearmenu(void);
void writemenu(unsigned int lines);
void strdelete(char *s,int pos,int len);
char *strsub(char *ret, char *s,int  pos,int len);
void myASSERT(boolean putative_fact,int location);
long    *P_setunion  (long *d, long *s1, long *s2);
long *P_setint(long *d,long *s1,long *s2);
long    *P_setdiff   (long *d, long *s1, long *s2);
long    *P_setxor(long *d, long *s1, long *s2);
int  P_inset(unsigned val, long *s);
long    *P_addset(long *s, unsigned val);
long    *P_addsetr(long *s, unsigned v1, unsigned v2);
long    *P_remset(long *s, unsigned val);
int P_setequal(long * s1, long *s2);
int P_subset(long *s1, long *s2);
long    *P_setcpy(long *d, long *s);
long    *P_expset(long *d, long s);
long     P_packset(long *s);
int P_eof(FILE *f);
int P_eoln(FILE *f);


/* FUNCTION PROTOTYPES for functions in SITEREAD.C */

void start(int argc, char *argv[]);
void ReadData(void);
void GetSites(void);
unsigned int  FindPlace(int spot);


/* Function Prototypes in SITEMOD */

void fill_watterm(void);
void fill_choose2(void);

/* FUNCTION PROTOTYPES FOR FUNCTIONS IN SITEREC.C  */
void GroupRECsites(unsigned int  groupi, unsigned int pass);
void insertindels(void);
void LD_possibly_imported_stuff(void);
void print_LD_matrix(int groupi);
void print_regionLD(int groupi);

/* get the expected number of sites with frequency class fi,n-fi */
/* this function is called by finish() in sites.c */
float get_sitefreq_i(unsigned int groupi,int  fi);

/* this function is called from finish() in sites.c */
void doamoeba(int nump,int group1, int group2, float observations[],float expectations[],float parameters[]);

/* End. */
