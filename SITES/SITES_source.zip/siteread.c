/*
* Copyright 2002 by Jody Hey
* Rutgers University, Piscataway, NJ 08855
*
* This computer program and documentation may be freely copied
* and used by anyone, provided no fee is charged for it.
*/

#undef SITES_G
#include "sites.h"


/* Local for start: */

/* possible command line flags */
static  boolean Ip,Rp,Mp,Sp,Ap,Op,Dp,Kp,Qp,Xp,Yp,Zp,Jp,Lp,Ep,Gp,Cp;

/* local for GetSites: */
static  boolean isSITE;
static  SiteBool what_this_site;
static  unsigned int sspot;
static  codontype clist[MaxS];
static  char stringc[MaxS][4];
static  unsigned int  nowframe;
static  unsigned int id;
static  unsigned int idlist[MaxIndels * 10];
static  char altcodechar[2], codonPchar[2];


/* prototypes in sites.h
void start(int argc, char *argv[]);
void ReadData(void);
void GetSites(void);
unsigned int  FindPlace(int spot);
*/


/* STATIC LOCAL FUNCTION PROTOTYPES */

static void getparams(int argc, char *argv[]);
static void Getintlv(void);
static unsigned int countchar(int templong);
static int seqchar(char ch);
static void poly(void);
static void fillclist(void);
static boolean codonok(  unsigned int  z);
static void SynorRep(void);
static void polyID(unsigned int *idspot,unsigned int *idlength);
static char droprangestring[12],keeprangestring[12],seqdroprangestring[12];

/* FUNCTIONS */

/* trap some exits when debugging.
#define  exit(num)   fexit( (num) )
static void fexit(int exitcode){
int i;
i=i;
}
*/

static void getparams(int argc, char *argv[])
	{
	  char pstr[256];
	  char ch;
	  unsigned int  i;

	  Ip = _false;
	  Rp = _false;
	  Mp = _false;
	  Sp = _false;
	  Ap = _false;
	  Op = _false;
	  Dp = _false;
	  Kp = _false;
	  Qp = _false;
	  Xp = _false;
	  Yp = _false;
	  Zp = _false;
	  Jp = _false;
	  Lp = _false;
	  Ep = _false;
	  Gp = _false;
	  Cp = _false;
  
	/* JHoption is so I can add things from time to time that only affect the 
	   ouput if I say so.  If a 'j' appears on the command line at runtime, then
	   JHoption becomes _true, otherwise it is _false */

	  JHoption = _false; 
	  doLDregion  = _false; 
	  doLDregiontest = _false; 
	  doLDmatrix = _false; 
	  doLDshared = _false; 
	  exclude_singletons = _false;  /* default state is to include singletons in LD analyses */
	  doHKAoutput = _false;
	  doWHoutput = _false;

	  for (i = 1; i < argc; i++)
		  {
			if (i==1) strcpy(command_line,argv[i]);
			else
				{
				strcat(command_line," ");
				strcat(command_line,argv[i]);
				}
			strcpy(pstr, argv[i]);
			ch = pstr[0];
			if (ch == '-' || ch == '/' || ch == '\\')
				{
				ch = pstr[1];
				strdelete(pstr,1,2);
				}
			else
				{
				ch = pstr[0];
				strdelete(pstr,1,1);
				}
			switch (toupper(ch))
				{
				case 'I':
				  sprintf(sname, "%s", pstr);
				  Ip = _true;
				  break;

				case 'R':
				  sprintf(rname, "%s", pstr);
				  Rp = _true;
				  break;

				case 'M':
				  sprintf(message, "%s", pstr);
				  Mp = _true;
				  break;

				case 'S':
				  sprintf(sitetypelist, "%s", pstr);
				  Sp = _true;
				  break;

				case 'A':
				  sprintf(outputlist, "%s", pstr);
				  Ap = _true;
				  break;

				case 'O':
				  sprintf(optionlist, "%s", pstr);
				  Op = _true;
				  break;
				case 'J':
				   sprintf(jhoptionlist, "%s", pstr);
				   JHoption = _true;
				   Jp = _true;
				  break;
				case 'L':
					sprintf(linkageoptionlist,"%s",pstr);
					Lp = _true;
					break;
			/* new options to allow entering data limitation specs to command line */

				case 'D':
				  sprintf(dropname, "%s",pstr);
				  Dp = _true;
				  break;
				case 'K':
				  sprintf(keepname, "%s",pstr);
				  Kp = _true;
				  break;
				case 'Q':
				  sprintf(seqdropname, "%s",pstr);
				  Qp = _true;
				  break;
				case 'X':
				  sprintf(droprangestring, "%s",pstr);
				  Xp = _true;
				  break;
				case 'Y':
				  sprintf(keeprangestring, "%s",pstr);
				  Yp = _true;
				  break;
				case 'Z':
				  sprintf(seqdroprangestring, "%s",pstr);
				  Zp = _true;
				  break;
			/* new command line options for Linkage Disequilibrium stuff */
				case 'E':
				  sprintf(LDmatrixfile_NAME, "%s",pstr);
				  Ep = _true;
				  analyses[LD - (long)SIT] = _true;
				  break;
				case 'G':
				  sprintf(regionLDfile_NAME,"%s",pstr);
				  Gp = _true;
				  break;
				case 'C':
					sprintf(altcodechar,"%s",pstr);
					options[ALTCODE] = _true;
					Cp = _true;
					break;
				}
			}
	}

void start(int argc, char *argv[])
	{
  unsigned int i, j, temp, temp1;
  char ch;
  char temps[11], tempname[50];
  unsigned int tempdrop, tempkeep;
  unsigned int valcode; 
  char *TEMP2;
  unsigned int FORLIM;
  int TEMP3;
  char tempch, templine[201];


  setbuf(stdout, NULL);
  clearscreen();
  getparams(argc,argv);
  printf("      SITES  version 1.1 ANALYSIS OF MULTIPLE ALIGNED DNA SEQUENCES \n\n");

  if (!Ip)
	  {
		printf("TYPE THE SEQUENCE FILENAME : \n");
		fgets(tempfilename,_FNSIZE+10, stdin);
		strncpy(sname, tempfilename,_FNSIZE);
		TEMP2 = strchr(sname, '\n');
		if (TEMP2 != NULL)
		  *TEMP2 = 0;
	  }
  strncpy(sfile_NAME, sname,_FNSIZE);
  if ((sfile = fopen(sname,"r")) == NULL)
	  {
      printf("\nError opening text file for reading\n"); 
	  exit(-1);
	  }
  if (!Rp)
	  {
      printf("TYPE THE OUTPUT FILENAME : \n");
      fgets(tempfilename,_FNSIZE+10,stdin);
      strncpy(rname,tempfilename,_FNSIZE);
      TEMP2 = strchr(rname, '\n');
	  if (TEMP2 != NULL)
		  *TEMP2 = 0;
	  }
#ifdef DOS
  /* check to see if an extension had been added, if so remove it */
  j = 0;
  TEMP2 = strchr(rname,'.');
  if (TEMP2 != NULL)
	{
	FORLIM = strlen(rname);
	for (i = 1; i <= FORLIM; i++)
		{
		if (rname[i - 1] == '.')
		j = i;
		}
	}
   else{
   j= 0;
  }
  if (j > 0) strdelete(rname, j, _FNSIZE);
#endif
  if (strlen(rname) > (_FNSIZE-4)) strdelete(rname, _FNSIZE-3, _FNSIZE);
  strcat(rname, ".SIT");
  if (!Mp)
	  {
      *message = '\0';
      printf("TYPE A MESSAGE TO HEAD THE OUTPUT FILE : \n");
      fgets(message, 81, stdin);
      TEMP2 = strchr(message, '\n');
      if (TEMP2 != NULL)
      *TEMP2 = 0;
	  }
  if (!Sp)
	  {
      clearscreen();
      clearmenu();
      strcpy(screentext[0], "");
      strcpy(screentext[1], "SITE OPTIONS ARE : a for All site types");
      strcpy(screentext[2], "                   i for all noncoding base changes");
      strcpy(screentext[3], "                   e for all coding base changes");
      strcpy(screentext[4], "                   s for synonymous coding sites ");
      strcpy(screentext[5], "                   r for replacement coding sites");
      strcpy(screentext[6], "                   o for ambiguous coding sites");
      strcpy(screentext[7], "                   d for insertion/deletion (indel) sites");
      strcpy(screentext[8], "                   f for only informative sites");
      strcpy(screentext[9], "                   n for only transitions");
      strcpy(screentext[10],"                   v for only transversions");
      strcpy(screentext[11],"");
      strcpy(screentext[12],"                   z to skip all positions with more than 2 base values");
      strcpy(screentext[13],"                   x to skip all positions within indels");

      strcpy(screentext[15],"TYPE THE LETTERS OF THE DESIRED SITE TYPES (no spaces): \n");
      writemenu(16);
      fgets(sitetypelist, 81, stdin);
      TEMP2 = strchr(sitetypelist, '\n');
      if (TEMP2 != NULL)
		*TEMP2 = 0;
	  }
  if (toupper(sitetypelist[0]) == 'F' && strlen(sitetypelist) == 1)
	/*make it easier to handle INF sites*/
	  strcpy(sitetypelist, "AF");
  memcpy(whatsites, FalseSites, sizeof(SiteBool));
  FORLIM = strlen(sitetypelist);
  for (i = 0; i < FORLIM; i++)
	  {
      switch (toupper(sitetypelist[i]))
		{
		case 'A':
		  whatsites[INT - (long)EXN] = _true;
		  whatsites[0] = _true;
		  whatsites[SYN - (long)EXN] = _true;
		  whatsites[REP - (long)EXN] = _true;
		  whatsites[SOR - (long)EXN] = _true;
		  whatsites[DEL - (long)EXN] = _true;
		  break;

		case 'I':
		  whatsites[INT - (long)EXN] = _true;
		  break;

		case 'E':
		  whatsites[0] = _true;
		  whatsites[SYN - (long)EXN] = _true;
		  whatsites[REP - (long)EXN] = _true;
		  whatsites[SOR - (long)EXN] = _true;
		  break;

		case 'S':
		  whatsites[SYN - (long)EXN] = _true;
		  break;

		case 'R':
		  whatsites[REP - (long)EXN] = _true;
		  break;

		case 'O':
		  whatsites[SOR - (long)EXN] = _true;
		  break;

		case 'D':
		  if (skipindel == _false) whatsites[DEL - (long)EXN] = _true;
		  break;

		case 'X':
		  skipindel = _true;
		  numindeldrop = 0;
		  whatsites[DEL - (long)EXN] = _false;
		  break;

        case 'Z':
		  skipmultibase = _true;
		  break;

		case 'F':
		  whatsites[INF - (long)EXN] = _true;
		  break;

		case 'N':
		  whatsites[TRN - (long)EXN] = _true;
		  break;

		case 'V':
		  whatsites[TRV - (long)EXN] = _true;
		  break;

		case '4':
		  whatsites[FOU - (long)EXN] = _true;
		  break;

		default:
		  assert(_false);
		  break;
		}
	  }
  if (!Ap)
	  {
		clearscreen();
		clearmenu();
		strcpy(screentext[0], "");
		strcpy(screentext[1], "ANALYSIS TYPES ARE:  a for all basic types (except r,b,m,g,l)");
		strcpy(screentext[2], "                     s for basic site table");
		strcpy(screentext[3], "                     e for coding change details");
		strcpy(screentext[4], "                     c for codon usage tables");
		strcpy(screentext[5], "                     p for polymorphism analysis");
		strcpy(screentext[6], "                     i for indel site table & indels in recombination analysis");
		strcpy(screentext[7], "");    
		strcpy(screentext[8], "                     r for recombination analysis");
        strcpy(screentext[9], "                     b for analysis of prefered and non-prefered codons");
		strcpy(screentext[10],"                     m for population model fitting");
		strcpy(screentext[11],"                     l (L) for linkage disequilibrium analyses (invokes r)");
		strcpy(screentext[12],"                     g for GC analyses");
		strcpy(screentext[13], "");
		strcpy(screentext[14], "TYPE THE LETTERS OF THE DESIRED ANALYSES (no spaces): \n");
		writemenu(15);
		fgets(outputlist, 81, stdin);
		TEMP2 = strchr(outputlist, '\n');
		if (TEMP2 != NULL)
		  *TEMP2 = 0;
	  }
  for (analysiscase = SIT; (long)analysiscase <= (long)POPMOD; analysiscase = (ANALYSISTYPE)((long)analysiscase + 1))
    analyses[analysiscase - (long)SIT] = _false;
  if (Lp == _true)
	  analyses[LD - (long)SIT] = _true;
  FORLIM = strlen(outputlist);
  for (i = 0; i < FORLIM; i++)
	  {
      switch (toupper(outputlist[i]))
		{
		case 'A':
		  analyses[0] = _true;
		  analyses[PEC - (long)SIT] = _true;
		  analyses[COD - (long)SIT] = _true;
		  analyses[DIF - (long)SIT] = _true;
		  analyses[INDELS - (long)SIT] = _true;
		  break;

		case 'S':
		  analyses[0] = _true;
		  break;

		case 'E':
		  analyses[PEC - (long)SIT] = _true;
		  break;

		case 'C':
		  analyses[COD - (long)SIT] = _true;
		  break;

		case 'P':
		  analyses[DIF - (long)SIT] = _true;
		  break;
		case 'I':
		  analyses[INDELS - (long)SIT] = _true;
		  break;
		case 'R':
		  analyses[REC - (long)SIT] = _true;
		  break;
        case 'B':
		  analyses[PREF - (long)SIT] = _true;
		  break;
		case 'G':
		  analyses[GCA - (long)SIT] = _true;
		  break;
		case 'M':
		  analyses[POPMOD - (long)SIT] = _true;
		  break;
		case 'L':
		  analyses[LD - (long)SIT] = _true;
		  analyses[REC - (long)SIT] = _true;
		  break;

		default:
		  assert(_false);
		  break;
		}
	  }
  fgets(sheader, 81, sfile);
  TEMP2 = strchr(sheader, '\n');
  if (TEMP2 != NULL)
    *TEMP2 = 0;
  i = 0;
  do
	  {
	  i++;
	  } while (sheader[i - 1] == ' ');
  if (isdigit(sheader[i - 1]))
    indata = PHYLIPin;
  else
    indata = SITESin;

  /*if (indata == SITESin)  */
    if (!Op)
		{
		  clearscreen();
		  clearmenu();
		  strcpy(screentext[0], "");
		  strcpy(screentext[1], "DATA OPTIONS:         g for comparisons within groups");
		  if (indata == SITESin) 
			  strcpy(screentext[2], "                      n for new group designations");
			else strcpy(screentext[2], "");
		  strcpy(screentext[3], "                      d for dropping some sites");
		  strcpy(screentext[4], "                      m for data limited to some sites");
		  strcpy(screentext[5], "                      x for dropping some sequences");
		  strcpy(screentext[6], "                      c for non-canonical genetic code");
		  strcpy(screentext[7], "");
		  strcpy(screentext[8], "OUTPUT OPTIONS:       s for no screen output during analysis");
		  strcpy(screentext[9], "                      p suppress large pairwise difference table");
		  strcpy(screentext[10],"                      h text line of input values for HKA program");
		  strcpy(screentext[11],"                      w text line of input values for WH program");

		  if (analyses[0] == _true)
			  {
			  strcpy(screentext[12],"                      f for first sequence reference in site table");
			  strcpy(screentext[13],"                      t for table style: (. and -) replace (- and *)");
			  }
		  else
			  {
				strcpy(screentext[12],"");
				strcpy(screentext[13],"");
			  }
		  strcpy(screentext[14],"");
		  strcpy(screentext[15],"TYPE THE LETTERS OF THE DESIRED OPTIONS (no spaces): \n");
          writemenu(16);
		  fgets(optionlist, 81, stdin);
		  TEMP2 = strchr(optionlist, '\n');
          if (TEMP2 != NULL)
       	      *TEMP2 = 0;
		}
    for (optioncase = GROUPS;
		(long)optioncase <= (long)SITSTYLE;
	optioncase = (OPTIONTYPE)((long)optioncase + 1))
    options[optioncase] = _false;
    screenupdate = _true;
    FORLIM = strlen(optionlist);
    for (i = 0; i < FORLIM; i++)
		{
		switch (toupper(optionlist[i]))
			{
		  case 'G':
				options[0] = _true;
				if (indata == PHYLIPin) options[NEWGROUP] = _true;
				break;

		  case 'N':
				options[0] = _true;
				options[NEWGROUP] = _true;
				break;

		  case 'D':
				options[DROPSITE] = _true;
				break;

		  case 'M':
				options[LIMITSITE] = _true;
				break;

		  case 'X':
				options[DROPSEQ] = _true;
				break;
		  case 'C':
				options[ALTCODE] = _true;
				break;

		  case 'F':
				options[FIRSTREF] = _true;
				break;

		  case 'T':
				options[SITSTYLE] = _true;
				break;

		  case 'S':
			   screenupdate = _false;
			   break;
		  case 'H':
			   doHKAoutput = _true;
			   break;
		  case 'W':
				doWHoutput = _true;
				break;
		  case 'P' :
				options[SUPPAIR] = _true;
				break;
			}
		}
   if (analyses[LD - (long)SIT] && !Lp)
	   {
		  clearscreen();
		  clearmenu();
		  strcpy(screentext[0], "");
		  strcpy(screentext[1], "Linkage Disequilibrium (LD) Analyses:");
		  strcpy(screentext[2], "         m print matrix of pairwise values and significance tests");
		  strcpy(screentext[3], "         y measure and compare average LD by regions ");
		  strcpy(screentext[4], "         t randomization tests of average LD by regions");
		  strcpy(screentext[5], "         s analyze LD among polymorphism shared between groups");
		  strcpy(screentext[6], "         x exclude singletons from all LD analyses");
		  strcpy(screentext[7],"");
		  strcpy(screentext[8], "Apply Analyses to the Following LD Measures");
		  strcpy(screentext[9], "         d  D - standard linkage disequilibrium (default)");
		  strcpy(screentext[10],"         p  D' -  D prime = D/Dmax ");
		  strcpy(screentext[11],"         b  |D| - absolute value of D ");
		  strcpy(screentext[12],"         a  |D'| - absolute value of D prime ");
		  strcpy(screentext[13],"         r  correlation coefficient");
		  strcpy(screentext[14],"         q  r^2 - squared correlation coefficient");
		  strcpy(screentext[15],"");
		  strcpy(screentext[16],"TYPE THE LETTERS OF DESIRED ANALYSES AND MEASURES (no spaces): \n");
		  writemenu(17);
		  fgets(linkageoptionlist, 81, stdin);
		  TEMP2 = strchr(optionlist, '\n');
		  if (TEMP2 != NULL)
       		*TEMP2 = 0;
		}
    if (analyses[PREF - (long)SIT] && whatsites[SYN - (long)EXN])
        {
        clearscreen();
        clearmenu();
        strcpy(screentext[0], "");
        strcpy(screentext[1], "Prefered and Non-Prefered Nuclear Codon Designations");
        strcpy(screentext[2], "         d Drosophila melanogaster (Duret & Mouchiroud 1999 PNAS 96:4482)");
        strcpy(screentext[3], "");
        strcpy(screentext[4],"TYPE THE LETTER OF THE DESIRED PREFERED/UNPREFERED CODON TABLE: \n");
		writemenu(4);
		gets(templine);
		if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
		    sscanf(templine,"%c",&codonPchar[0]);
		}
     switch (toupper(codonPchar[0]))
		  {
		  case 'D' :codonPtable[C][G][C]=P;
                    codonPtable[C][G][T]=P;
                    codonPtable[C][T][G]=P;
                    codonPtable[T][C][C]=P;
                    codonPtable[T][C][G]=P;
                    codonPtable[A][C][C]=P;
                    codonPtable[C][C][C]=P;
                    codonPtable[G][C][C]=P;
                    codonPtable[G][G][C]=P;
                    codonPtable[G][G][T]=P;
                    codonPtable[G][T][C]=P;
                    codonPtable[A][A][G]=P;
                    codonPtable[A][A][C]=P;
                    codonPtable[C][A][G]=P;
                    codonPtable[C][A][C]=P;
                    codonPtable[G][A][G]=P;
                    codonPtable[G][A][C]=P;
                    codonPtable[T][A][C]=P;
                    codonPtable[T][G][C]=P;
                    codonPtable[T][T][C]=P;
                    codonPtable[A][T][C]=P;
                    break;
         }

     /*assert(!(options[DROPSITE] &&
	   options[LIMITSITE])); */
  if (options[NEWGROUP])
	  {
      if (sfile != NULL)
		if ((sfile = freopen(sfile_NAME, "r", sfile)) == NULL)
			{
			printf("\nError opening text file for reading \n"); 
			exit(-1);
			}
		else
			if ((sfile = fopen(sfile_NAME, "r")) == NULL)
				{
				printf("\nError opening text file for reading \n"); 
				exit(-1);
				}
	   if (indata == PHYLIPin)
		   {
			fgets(templine, 200, sfile);
			if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
			sscanf(templine, "%d%u", &TEMP3, &temp);
			nums = TEMP3;
			}
	   else
		   {
			fgets(templine,200,sfile);
      /* now skip extra comment lines if they occur */
			do
				{
				fgets(templine, 200, sfile);
				TEMP2 = strchr(templine, '\n');
				if (TEMP2 != NULL) *TEMP2 = 0;
				else
					do
						{ 
						tempch = getc(sfile);
						} while (tempch != '\n');
				} while (templine[0]=='#');
			sscanf(templine, "%d%hd%*[^\n]", &TEMP3, &temp);
			nums = TEMP3;
			}
		printf("THE INPUT FILE CONTAINS %d SEQUENCES.  ENTER THE NUMBER OF GROUPS: \n",	   nums);
		gets(templine);
		if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
		sscanf(templine,"%d", &TEMP3);
		numgroups = TEMP3;
		temp = 0;
		FORLIM = numgroups;
		for (i = 0; i < FORLIM; i++)
			{
			printf("ENTER THE NAME OF THE GROUP BEGINNING AT SEQUENCE %2d : \n\n",
			temp + 1);
			fgets(tempname,100, stdin);
			TEMP2 = strchr(tempname, '\n');
			if (TEMP2 != NULL)
				*TEMP2 = 0;
			strncpy(groupnames[i],tempname,MaxGroupNameLength);
			while (strlen(groupnames[i]) < MaxGroupNameLength)
				{
				strcat(groupnames[i], " ");
				}
			if (i + 1 == numgroups)
				{
				grouplimits[i][0] = temp + 1;
				grouplimits[i][1] = nums;
				}
			if (i + 1 < numgroups)
				{
				grouplimits[i][0] = temp + 1;
				do
					{
					printf("ENTER THE LAST SEQUENCE NUMBER OF GROUP \"%s\" : \n\n", groupnames[i]);
					gets(templine);
					if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
					sscanf(templine,"%d",&grouplimits[i][1]);
					if (grouplimits[i][1] > nums)
						{
						printf("There are only %d sequences %d is too high.\n\n",
						nums, grouplimits[i][1]);
						temp1 = nums;
						}
					else
						{
						temp1 = nums - numgroups + i + 1;
						if (grouplimits[i][1] > temp1)
							{
							printf("There are more groups, %d is the highest possible value for group %u\\nn",nums - numgroups + i + 1, i + 1);
							}
						}
					} while (grouplimits[i][1] > temp1);
				temp = grouplimits[i][1];
				}
			}
		}
  if (!options[0])
	  {
		numgroups = 1;
		grouplimits[0][0] = 1;
		strcpy(groupnames[0], "ALL ");
		while (strlen(groupnames[0]) < MaxGroupNameLength) strcat(groupnames[0], " ");
	  }
  if (options[DROPSITE])
	  {
		if (!(Dp || Xp))
			{
			printf("DROPPING SOME SITES,  enter option :  r for range \n");
			printf("                                      f for file  \n");
			printf("                                      i for individual entry \n");
			ch = getchar();getchar();
			switch (toupper(ch))
				{
				case 'R':
				  isdropfile = _false;
				  isdroprange = _true;
				  printf("ENTER THE FIRST BASE OF THE RANGE TO DROP: \n");
				  i = 0;
				  gets(templine);
				  if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
				  sscanf(templine,"%u", &rangebegin);
				  printf("ENTER THE LAST BASE OF THE RANGE TO DROP: \n");
				  do
					  {
						 gets(templine);
						if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
						sscanf(templine,"%u", &rangend);
					  } while (rangend <= rangebegin);
				  assert(rangend - rangebegin + 1 <= MaxDropKeep);
				  j = 0;
				  FORLIM = rangend;
				  for (i = rangebegin; i <= FORLIM; i++)
					  {
						j++;
						droplist[j - 1] = i;
					  }
				  numdrop = j;
				  break;
				case 'F':
				  isdropfile = _true;
				  isdroprange = _false;
				  printf("TYPE THE NAME OF THE FILE : \n");
				  fgets(tempfilename,_FNSIZE+10, stdin);
				  strncpy(dropname,tempfilename,_FNSIZE);
				  TEMP2 = strchr(dropname, '\n');
				  if (TEMP2 != NULL)
					*TEMP2 = 0;
				  strcpy(dropkeepfile_NAME, dropname);
				  if (dropkeepfile != NULL)
						dropkeepfile = freopen(dropkeepfile_NAME, "r", dropkeepfile);
				  else
						dropkeepfile = fopen(dropkeepfile_NAME, "r");
				  if (dropkeepfile == NULL)
					  {
					  printf("\nError opening text file for reading \n");
					  exit(-1);
					  }
				  i = 1;
				  do
					  {
						fgets(templine, 200, dropkeepfile);
						if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
						sscanf(templine, "%d", &droplist[i - 1]);
						if (droplist[i - 1] > 0)
							i++;
						} while (!(P_eof(dropkeepfile) || i >= MaxDropKeep));
				  numdrop = i - 1;
				  if (dropkeepfile != NULL)
					fclose(dropkeepfile);
				  dropkeepfile = NULL;
				  break;
				case 'I':
				  isdropfile = _false;
				  isdroprange = _false;
				  printf("ENTER A POSITION TO BE IGNORED (hit CR if done): \n");
				  i = 0;
				  do	
					  {
						fgets(temps, 11, stdin);
						TEMP2 = strchr(temps, '\n');
						if (TEMP2 != NULL)
							*TEMP2 = 0;
						if (temps[0] == 0)  valcode = 1;
						else	valcode = (sscanf(temps, "%d", &tempdrop) == 0);
						if (valcode == 0)
							{
							i++;
							droplist[i - 1] = tempdrop;
							}
						} while (valcode == 0 && i < MaxDropKeep);
				  numdrop = i;
				  break;

				default:
				  assert(_false);
				  break;
				}
			}
	  else
		  {
		  if (Dp)
			  {
			  isdropfile = _true;
			  isdroprange = _false;
			  strcpy(dropkeepfile_NAME, dropname);
			  dropkeepfile = fopen(dropkeepfile_NAME, "r");
			   if (dropkeepfile == NULL)
				   {
					printf("\nError opening text file for reading \n");
					exit(-1);
				   }
			  i = 1;
			  do
				  {
				  fgets(templine, 200, dropkeepfile);
				  if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
				  sscanf(templine, "%d", &droplist[i - 1]);
       			  if (droplist[i - 1] > 0)
					i++;
				  } while (!(P_eof(dropkeepfile) || i >= MaxDropKeep));
			  numdrop = i - 1;
			  if (dropkeepfile != NULL) fclose(dropkeepfile);
			  dropkeepfile = NULL;
			  } 
		   if (Xp)
				{
				  isdropfile = _false;
				  isdroprange = _true;
				  TEMP2 = strchr(droprangestring,'-');
				  strncpy(temps,droprangestring, TEMP2-droprangestring+1);
				  rangebegin = atoi(temps);
				  TEMP2++;
				  rangend  = atoi(TEMP2);
				  j = 0;
				  FORLIM = rangend;
				  for (i = rangebegin; i <= FORLIM; i++)
					  {
      				  j++;
					  droplist[j - 1] = i;
					  }
				  numdrop = j;
				}   
		   }
	  }
  if (options[LIMITSITE])
	  {
		  /* should first check to see if sites were also dropped?*/ 
	   if (options[DROPSITE])
		   {
		   /* does nothing */
		   }
	   if (!(Kp || Yp))
		   {
			printf("ANALYSIS LIMITED TO SOME SITES,  enter option :  r for range \n");
			printf("                                                 f for file  \n");
			printf("                                                 i for individual entry\n");
			ch = getchar();getchar();
			switch (toupper(ch))
				{
				case 'R':
				  iskeepfile = _false;
				  iskeeprange = _true;
				  printf("ENTER THE FIRST BASE OF THE RANGE TO KEEP: \n");
  				  gets(templine);
				  if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
				  sscanf(templine, "%u", &rangebegin);
				  printf("ENTER THE LAST BASE OF THE RANGE TO KEEP: \n");
				  do {
				  gets(templine);
				  if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
				  sscanf(templine, "%u", &rangend);
				  } while (rangend <= rangebegin);
				  assert(rangend - rangebegin + 1 <= MaxDropKeep);
				  j = 0;
				  FORLIM = rangend;
				  for (i = rangebegin; i <= FORLIM; i++)
					  {
						j++;
						keeplist[j - 1] = i;
					  }
				  numkeep = j;
				  break;

				case 'F':
				  iskeepfile = _true;
				  iskeeprange = _false;
				  printf("TYPE THE NAME OF THE FILE : \n");
				  fgets(tempfilename,_FNSIZE+10, stdin);
				  strncpy(keepname,tempfilename,_FNSIZE);
				  TEMP2 = strchr(keepname, '\n');
				  if (TEMP2 != NULL)
					*TEMP2 = 0;
				  strcpy(dropkeepfile_NAME, keepname);
				  if (dropkeepfile != NULL)
					dropkeepfile = freopen(dropkeepfile_NAME, "r", dropkeepfile);
				  else
					dropkeepfile = fopen(dropkeepfile_NAME, "r");
				  if (dropkeepfile == NULL)
					  {
					  printf("\nError opening text file for reading \n");
					  exit(-1);
					  }
				  i = 1;
				  do
					  {
					  fgets(templine, 200, dropkeepfile);
					  if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
					  sscanf(templine, "%d", &keeplist[i - 1]);
					  if (keeplist[i - 1] > 0)
						i++;
						} while (!(P_eof(dropkeepfile) || i >= MaxDropKeep));
				  numkeep = i - 1;
				  if (dropkeepfile != NULL)
					fclose(dropkeepfile);
				  dropkeepfile = NULL;
				  break;

				case 'I':
				  iskeepfile = _false;
				  iskeeprange = _false;
				  printf("ENTER A POSITION TO BE KEPT (hit CR if done): \n");
				  i = 0;
				  do
					  {
						fgets(temps, 11, stdin);
						TEMP2 = strchr(temps, '\n');
						if (TEMP2 != NULL)
							*TEMP2 = 0;
						if (temps[0] == 0)  valcode = 1;
						else	valcode = (sscanf(temps, "%d", &tempkeep) == 0);
						if (valcode == 0)
							{
							  i++;
							  keeplist[i - 1] = tempkeep;
							}
					  } while (valcode == 0);
				  numkeep = i;
				  break;

				default:
				  assert(_false);
				  break;
				}
		   }
	   else
		   {
		   if (Kp)
			   {
			   iskeepfile = _true;
			   iskeeprange = _false;
			   strcpy(dropkeepfile_NAME, keepname);
			   dropkeepfile = fopen(dropkeepfile_NAME, "r");
			   if (dropkeepfile == NULL)
				   {
					printf("\nError opening text file for reading \n"); 
					exit(-1);
				   }
				i = 1;
				do
					{
					fgets(templine, 200, dropkeepfile);
					if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
					sscanf(templine, "%d", &keeplist[i - 1]);
       				if (keeplist[i - 1] > 0)
						i++;
					} while (!(P_eof(dropkeepfile) || i >= MaxDropKeep));
				numkeep = i - 1;
				if (dropkeepfile != NULL) fclose(dropkeepfile);
				dropkeepfile = NULL;
				} 
		   if (Yp)
			   {
			  iskeepfile = _false;
			  iskeeprange = _true;
			  TEMP2 = strchr(keeprangestring,'-');
			  strncpy(temps,keeprangestring, TEMP2-keeprangestring+1);
			  rangebegin = atoi(temps);
			  TEMP2++;
			  rangend  = atoi(TEMP2);
			  j = 0;
			  FORLIM = rangend;
			  for (i = rangebegin; i <= FORLIM; i++)
				  {
      			  j++;
				  keeplist[j - 1] = i;
				  }
			  numkeep = j;
			   }
			}
	  }
  if (options[SITSTYLE])
	  {
		samechar = '.';
		indelchar = '-';
	}
  else
	  {
		samechar = '-';
		indelchar = '*';
	  }
  
  if (options[ALTCODE] || Cp)
	  {
	  if (options[ALTCODE] == _false) options[ALTCODE] = _true;
	  if (!Cp)
		  {
		  clearscreen();
		  clearmenu();
		  strcpy(screentext[0], "");
		  strcpy(screentext[1], "Alternate (Non-Canonical) Genetic Code:");
		  strcpy(screentext[2], "         V  Vertebrate Mitochondrial Code ");
		  strcpy(screentext[3], "         Y  Yeast Mitochondrial Code ");
		  strcpy(screentext[4], "         M  Mold, Protozoan, and Coelenterate Mitochondrial Code");
		  strcpy(screentext[5], "         I  The Invertebrate Mitochondrial Code ");
		  strcpy(screentext[6], "         C  The Ciliate, Dasycladacean and Hexamita Nuclear Code ");;
		  strcpy(screentext[7], "         E  The Echinoderm Mitochondrial Code");
		  strcpy(screentext[8], "         P  The Euplotid Nuclear Code ");
		  strcpy(screentext[9], "         A  The Alternative Yeast Nuclear Code ");
		  strcpy(screentext[10],"         D  Ascidian Mitochondrial Code ");
		  strcpy(screentext[11],"         F  Flatworm Mitochondrial Code ");
		  strcpy(screentext[12],"");
		  strcpy(screentext[13],"TYPE THE LETTER OF THE DESIRED GENETIC CODE: \n");
		  writemenu(14);
		  gets(templine);
		  if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
		  sscanf(templine,"%c",&altcodechar[0]);
		  }
	  switch (toupper(altcodechar[0]))
		  {
		  case 'V' :codon_table[A][G][A] = STP;
					codon_table[A][G][G] = STP;
					codon_table[A][T][A] = MET;
					codon_table[T][G][A] = TRP;
					strcpy(codonstr[A][G][A],"AGA STP ");
					strcpy(codonstr[A][G][G],"AGG STP ");
					strcpy(codonstr[A][T][A],"AUA MET ");
					strcpy(codonstr[T][G][A],"AGA TRP ");
					strcpy(altcodestr,"Vertebrate Mitochondrial Code");
					break;
		  case 'Y' :codon_table[A][T][A] = MET;
					codon_table[C][T][T] = THR;
					codon_table[C][T][C] = THR;
					codon_table[C][T][A] = THR;
					codon_table[C][T][G] = THR;
					codon_table[T][G][A] = TRP;
					codon_table[C][G][A] = STP;
					codon_table[C][G][C] = STP;
					strcpy(codonstr[A][T][A],"AUA MET "); 
					strcpy(codonstr[C][T][T],"CUU THR "); 
					strcpy(codonstr[C][T][C],"CUC THR "); 
					strcpy(codonstr[C][T][A],"CUA THR "); 
					strcpy(codonstr[C][T][G],"CUG THR "); 
					strcpy(codonstr[T][G][A],"UGA TRP "); 
					strcpy(codonstr[C][G][A],"CGA STP "); 
					strcpy(codonstr[C][G][C],"CGC STP "); 
					strcpy(altcodestr,"Yeast Mitochondrial Code");
					break;
		  case 'M' :codon_table[T][G][A] = TRP;
					strcpy(codonstr[T][G][A],"UGA TRP "); 
					strcpy(altcodestr,"Mold, Protozoan, and Coelenterate Mitochondrial Code");
					break;
		  case 'I' :codon_table[A][G][A] = SER;
					codon_table[A][G][G] = SER;
					codon_table[A][T][A] = MET;
					codon_table[T][G][A] = TRP;
					strcpy(codonstr[A][G][A],"AGA SER ");
					strcpy(codonstr[A][G][G],"AGG SER ");
					strcpy(codonstr[A][T][A],"AUA MET ");
					strcpy(codonstr[T][G][A],"UGA TRP ");
					strcpy(altcodestr,"The Invertebrate Mitochondrial Code ");
					break;
		  case 'C' :codon_table[T][A][A] = GLN;
					codon_table[T][A][G] = GLN;
					strcpy(codonstr[T][A][A],"UAA GLN "); 
					strcpy(codonstr[T][A][G],"UAG GLN "); 
					strcpy(altcodestr,"The Ciliate, Dasycladacean and Hexamita Nuclear Code ");;
					break;
		  case 'E' :codon_table[A][A][A] = ASN;
					codon_table[A][G][A] = SER;
					codon_table[A][G][G] = SER;
					codon_table[T][G][A] = TRP;
					strcpy(codonstr[A][A][A],"AAA ASN ");
					strcpy(codonstr[A][G][A],"AGA SER ");
					strcpy(codonstr[A][G][G],"AGG SER ");
					strcpy(codonstr[T][G][A],"UGA TRP ");
					strcpy(altcodestr,"The Echinoderm Mitochondrial Code");
					break;
		  case 'P' :codon_table[T][G][A] = TRP;
					strcpy(codonstr[T][G][A],"UGA TRP ");
					strcpy(altcodestr,"The Euplotid Nuclear Code ");
					break;
		  case 'A' :codon_table[C][T][G] = SER;
					strcpy(codonstr[C][T][G],"CUG SER ");
					strcpy(altcodestr,"The Alternative Yeast Nuclear Code ");
					break;
		  case 'D' :codon_table[A][G][A] = GLY;
					codon_table[A][G][G] = GLY;
					codon_table[A][T][A] = MET;
					codon_table[T][G][A] = TRP;
					strcpy(codonstr[A][G][A],"AGA GLY ");
					strcpy(codonstr[A][G][G],"AGG GLY ");
					strcpy(codonstr[A][T][A],"AUA MET ");
					strcpy(codonstr[T][G][A],"UGA TRP ");
					strcpy(altcodestr,"Ascidian Mitochondrial Code ");
					break;
		  case 'F' :codon_table[A][A][A] = ASN;
					codon_table[A][G][A] = SER;
					codon_table[A][G][G] = SER;
					codon_table[T][A][A] = TYR;
					codon_table[T][G][A] = TRP;
					strcpy(codonstr[A][A][A],"AAA ASN ");
					strcpy(codonstr[A][G][A],"AGA SER ");
					strcpy(codonstr[A][G][G],"AGG SER ");
					strcpy(codonstr[T][A][A],"UAA TYR ");
					strcpy(codonstr[T][G][A],"UGA TRP ");
					strcpy(altcodestr,"Flatworm Mitochondrial Code ");
					break;
		  }
	  }
/* various JHoptions
P - does analysis of polymorphism frequency distributions
  this requires that SHARE_POLY_DIST_OPTION be defined, and data set not be too large, as lots of ram is called for.
Z - for printing out non-recombinant Blocks 
H - for phylip noninterleaved format - suppresses asking of questions  
Linkage Disequilbrium analyses 
	must have one of these -J options (Y, T, M, or S)
	must also specify an -L option  (r,s,d, p or b)
Y - measures LD between regions of the sequence 
T - does a test of the LD between those regions 
M - prints out a matrix of LD values within each group
S - does various assays of LD involving shared polymorphisms between grousp
- note that if YTM or S are used, then should also use the -L option to set the LD measure
	the default is r.
*/

  if (JHoption)
	  {
      TEMP2 = strchr(jhoptionlist, '\n');
      if (TEMP2 != NULL)
      	*TEMP2 = 0;
	  DoSharePolyDist = _false;
	  DoMDIVoutput = _false;
      DontaskPhylip = _false;
	  FORLIM = strlen(jhoptionlist);
	  for (i = 0; i < FORLIM; i++)
		  {
		  switch (toupper(jhoptionlist[i]))
			  {
			  /* 'z' (did not know what to call it )  causes the output file to include printed sequence,
			  broken up into blocks within which no recombination was observed.  This output region
			  should be suitable for input into the IM multilocus program on isolation model w/ migration 
              best to use this while excluding both indels and multibase sites  (site options z and x) */
			    case 'Z' :
					DoMDIVoutput = _true;
					break;
                case 'H' :
                    DontaskPhylip = _true;
                    break;
#ifdef SHARE_POLY_DIST_OPTION
				case 'P' :
					DoSharePolyDist = _true;
					break;
#endif
			  }
			}
		}
  if (analyses[LD - (long)SIT] )
	  {
	  for (i = LDR; i <= LDDP; i++) LDdotypes[i] = _false;
	  LDdotypes[LDD] = _true; 
      TEMP2 = strchr(linkageoptionlist, '\n');
      if (TEMP2 != NULL) *TEMP2 = 0;
	  for (i = LDR; i <= LDDP; i++) LDdotypes[i] = _false;
	  FORLIM = strlen(linkageoptionlist);
	  for (i = 0; i < FORLIM; i++)
		  {
			switch (toupper(linkageoptionlist[i])) {
		/* will invoke a diseqiulibrium analysis  - also requires that recombination analyses are done */
			case 'Y':
				doLDregion = _true;
				break;
			case 'T':
				doLDregiontest = _true;
				doLDregion = _true;
				break;
			case 'M':
				doLDmatrix = _true;
				break;
			case 'S':
				doLDshared = _true;
				break;
			case 'X':
				exclude_singletons = _true;
				break;
			case 'R':
				LDdotypes[LDR] = _true;
				break;
			case 'Q':
				LDdotypes[LDRS] = _true;
				break;
			case 'P' :
				LDdotypes[LDDP] = _true;
				break;
			case 'D' :
				LDdotypes[LDD] = _true;
				break;
			case 'B' :
				LDdotypes[LDABS] = _true;
				break;
			case 'A' :
				LDdotypes[LDPABS] = _true;
				break;
			}
		}
	  if (doLDregion)
		  {
	  	  if (!Gp)
			  {
				printf("FOR LD ANALYSES BY REGIONS, TYPE NAME OF FILE OF SEQUENCE REGIONS: \n");
				fgets(tempfilename,_FNSIZE+10, stdin); 
				strncpy(regionLDfile_NAME, tempfilename,_FNSIZE); 
				/*strcpy(regionLDfile_NAME,"genesizes"); */
				TEMP2 = strchr(regionLDfile_NAME, '\n');
				if (TEMP2 != NULL) *TEMP2 = 0;
			  }
  		  if ((regionLDfile = fopen(regionLDfile_NAME,"r")) == NULL)
			{
			printf("\nError opening text file for reading\n");
			exit(-1);
			}
		  j = 1;
		  do
			{
			fgets(templine, 200, regionLDfile);
			if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
			sscanf(templine, "%u", &regionLD[j - 1]);
			if (regionLD[j - 1] > 0) j++;
			} while (!(P_eof(regionLDfile) || j >= MaxregionLD));
		  numregionLD = j - 1;
		  fclose(regionLDfile);
		  }
	  if (doLDmatrix)
		  {
		  if (!Ep)
			  {
				printf("FOR LD MATRICES, TYPE OUTPUT FILENAME: \n");
				fgets(tempfilename,_FNSIZE+10, stdin); 
				strncpy(LDmatrixfile_NAME, tempfilename,_FNSIZE); 
				TEMP2 = strchr(LDmatrixfile_NAME, '\n');
				if (TEMP2 != NULL) *TEMP2 = 0;
			  } 
		  /* open new file or overwrite existing file- see that it works */
		  if ((LDmatrixfile = fopen(LDmatrixfile_NAME, "w")) == NULL)
			  {
				printf("\nError opening text file for writing \n"); 
				exit(-1);
			  }
		  fclose(LDmatrixfile);
		  }

	}
}  /*start*/


static void Getintlv(void)
{
  /*reads interleaved sequences in phylip 3.4 format. The first block of
lines has the names attached. After that there are no names. Each block
of lines is separated by an extra EOLN*/
  unsigned int h, i, j, sofar;
  char ch;
  unsigned int FORLIM;
  boolean nextsection, nextsequence;

  h = 1;
  FORLIM = nums;
  for (i = 1; i <= FORLIM; i++) {
    nowseq_ptr = (seq_rec *)malloc(sizeof(seq_rec));
    if (i == 1) {
      nowseq2_ptr = (seq_rec *)malloc(sizeof(seq_rec));
      nowseq2_ptr = nowseq_ptr;
    }
    nowseq_ptr->next = NULL;
    nowseq_ptr->last = NULL;
    nowseq_ptr->n = h;
    for (j = 0; j < MaxL; j++)
      nowseq_ptr->sequence[j] = 0;
    /*i indexes rows, the different sequences */
    if (P_eoln(sfile)) {
      fscanf(sfile, "%*[^\n]");
    }
    do {
      if (P_eoln(sfile)) {
      fscanf(sfile, "%*[^\n]");
      }
      ch = getc(sfile);
    } while (ch == ' ');
    sprintf(names[h - 1], "%c", ch);
    for (j = 2; j <= MaxSeqNameLength; j++) {
      ch = getc(sfile);
      sprintf(names[h - 1] + strlen(names[h - 1]), "%c", ch);
    }
    j = 0;
    /*j indexes along rows, i.e. the columns*/
    do {
      ch = getc(sfile);
      if (ch != ' ') {
	j++;
	pushchar(j, ch);
      }
    } while (!P_eoln(sfile));
    if (!whichlines[i - 1])
      free(nowseq_ptr);
    else {
      if (h == 1) {
	firstseq_ptr = nowseq_ptr;
	holdseq_ptr = NULL;
      }
      if (h == 2)
	firstseq_ptr->next = nowseq_ptr;
      if (holdseq_ptr != NULL)
	nowseq_ptr->last = holdseq_ptr;
      if (h != 1)
	holdseq_ptr->next = nowseq_ptr;
      holdseq_ptr = nowseq_ptr;
      h++;
    }
  }
  sofar = j;
  while (sofar < howlong) {
	do{ 
	  nextsection = !(((ch=getc(sfile)) != EOF) && (ch==' ' || ch =='\n'));
	  if (nextsection) ungetc(ch,sfile);
	}while (!nextsection);
    nowseq_ptr = firstseq_ptr;
    i = 1;
    while (i <= nums) {
		j = sofar;
		do {
		  ch = getc(sfile);
		  if (ch != ' ') {
			j++;
			if (whichlines[i-1]) pushchar(j, ch);
		  }
		} while (!P_eoln(sfile));
   	    do{ 
		  nextsequence = !(((ch=getc(sfile)) != EOF) && (ch==' ' || ch =='\n'));
		  if (nextsequence) ungetc(ch,sfile);
		}while (!nextsequence);
		i++;
		if (whichlines[i-1]) nowseq_ptr = nowseq_ptr->next;
    }
    sofar = j;
  }
  nowseq_ptr = firstseq_ptr;
}

#define numstep         20

static int seqchar(char ch){
	/* checks to see if ch is a letter, or an indel marker */
	if (isalpha(ch)) return(1);
	else 
	switch (ch) {
	case '.': return (1);
	case '*': return (1);
	case '-': return (1);
	default : return (0);
	}
}

static unsigned int countchar(int templong)
{
  unsigned int count, i;
  int chi, checkchi;

  count = 0;
  /* read in the name characters */
  for (i = 1; i <= 10; i++) {
	  chi = getc(sfile);
  }
  do {
	  checkchi = seqchar(chi = getc(sfile));
	  count += checkchi;
  }while (!(isdigit(chi) || (checkchi==0) || (chi==EOF)) || (chi==' '));

   assert(count == templong);
  /*
  do {
    while (!P_eoln(sfile)) {
      ch = getc(sfile);
      if (seqchar(ch)) count++;
    }
    fscanf(sfile, "%*[^\n]");
    ch = getc(sfile);
  } while (ch == ' ');
  */
  if (sfile != NULL)   fclose(sfile);
  sfile = NULL;
  sfile = fopen(sfile_NAME, "r");
  if (sfile == NULL){
        printf("\nError opening text file for reading \n"); exit(-1);}
  return count;
}


void ReadData(void)
{
  unsigned int h, i, j, k;
  char ch;
  int tempnums, valcode;
  char temps[4];
   unsigned int oldnumgroups;
  unsigned int templong;
    unsigned int  groupsdel[MaxGroups];
    unsigned int   checkgroupsum;
  int TEMP;
  int tempdrop;
  unsigned int FORLIM;
  int TEMP1;
  char *TEMP2;
  char tempname[50];
  char templine[201];
  char tempch;

  i = 0;
  if (indata == PHYLIPin) 
	  {
	    if (!DontaskPhylip)
            {
            printf("*PHYLIP STYLE INPUT*   ARE SEQUENCES INTERLEAVED? y/n  \n");
		    ch = getchar();getchar();
    		INTLV = (toupper(ch) == 'Y');
            }
        else
            INTLV = _false;
		if (sfile != NULL)
		  sfile = freopen(sfile_NAME, "r", sfile);
		else
		  sfile = fopen(sfile_NAME, "r");
		if (sfile == NULL){
			printf("\nError opening text file for reading \n"); exit(-1);}
		fgets(templine,200,sfile);
		if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
		sscanf(templine, "%d%u", &TEMP, &howlong);
		nums = TEMP;
		if (nums > MaxS) {
		  printf("TOO MANY SEQUENCES IN DATA FILE. LIMIT IS %ld \n", (long)MaxS);
		  exit(-2);
		}
		if (howlong > MaxL * 2) {
		  printf("SEQUENCES ARE TOO LONG. LIMIT IS %ld\n", MaxL * 2L);
		  exit(-3);
		}
        if (DontaskPhylip)
            {
            numnoncods = 1;
            noncods[0].p5 = 1;
            noncods[0].p3 = 2*MaxL;
            }
        else
            {
		    printf("Type the number of noncoding regions : \n");
		    gets(templine);
		    if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
		    sscanf(templine, "%d", &TEMP);
		    numnoncods = TEMP;
		    FORLIM = numnoncods;
		    for (i = 1; i <= FORLIM; i++)
                {
		        printf("Type the first and last base numbers of noncoding region %u : \n",i);
		        gets(templine);
		        if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
		        sscanf(templine,"%u%u", &noncods[i - 1].p5, &noncods[i - 1].p3);
                }
		    }
		if (numnoncods == 1 && noncods[0].p3 >= howlong) 
            oframe = 1;
		else 
            {
			printf("Type the position in the codon frame of the first coding base : \n");
			gets(templine);
			if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
			sscanf(templine,"%d", &TEMP);
			oframe = TEMP;
		    }
		if (!options[0])
		  grouplimits[0][1] = nums;
		} 
	else 
		{
		/*indata = SITESin;  */
		assert(indata==SITESin);
		if (sfile != NULL)
		  fclose(sfile);
		sfile = NULL;
		if (sfile != NULL)
		  sfile = freopen(sfile_NAME, "r", sfile);
		else
		  sfile = fopen(sfile_NAME, "r");
		if (sfile == NULL){
			printf("\nError opening text file for reading \n"); exit(-1);}
		fgets(templine,200,sfile);
		num_extra_comments=0;
		do	{
			fgets(templine, 80, sfile);
			TEMP2 = strchr(templine, '\n');
			if (TEMP2 != NULL) *TEMP2 = 0;
			   else  do{ 
					  tempch = getc(sfile);
					} while (tempch != '\n');
			if (templine[0]=='#'){
			   strcpy(extracomments[num_extra_comments],&templine[1]);
			   num_extra_comments++;
			   }
			}while (templine[0]=='#');

		sscanf(templine, "%d%d%*[^\n]", &TEMP, &templong);
		nums = TEMP;
		if (nums > MaxS) 
			{
			  printf("TOO MANY SEQUENCES IN DATA FILE. LIMIT IS %ld\n", (long)MaxS);
			  exit(-2);
			}
		if (templong > MaxL * 2) 
			{
			  printf("SEQUENCES ARE TOO LONG. LIMIT IS %ld\n", MaxL * 2L);
			  exit(-3);
			}
		fgets(templine,200,sfile);
		if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
		sscanf(templine, "%d%d%", &TEMP, &TEMP1);
		oframe = TEMP;
		numnoncods = TEMP1;
		FORLIM = numnoncods;
		for (i = 0; i < FORLIM; i++) 
			{
			fgets(templine,200,sfile);
			if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
			sscanf(templine, "%u%u", &noncods[i].p5, &noncods[i].p3);
			}
		fgets(templine,200,sfile);
		if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
		sscanf(templine, "%d", &TEMP);
		numgrouplines = TEMP;
		if (numgrouplines==1) 
			{
			 numgroups = 1;
			 grouplimits[0][0] = 1;
			 grouplimits[0][1] = nums;
			 strcpy(groupnames[0], "ALL ");
			 while (strlen(groupnames[0]) < MaxGroupNameLength) strcat(groupnames[0], " ");
			 }
		else {
			if (options[NEWGROUP] || !options[0]) 
				{
				FORLIM = numgrouplines;
				for (i = 1; i <= FORLIM; i++) 
					{
					fgets(templine,200,sfile);
					}
				}
			else 
				{
				numgroups = numgrouplines;
				checkgroupsum = 0;
				FORLIM = numgroups;
				for (i = 0; i < FORLIM; i++)
					{
					if (i + 1 == 1)
						grouplimits[i][0] = 1;
					else
						grouplimits[i][0] = grouplimits[i - 1][1] + 1;
					fgets(templine,200,sfile);
					if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
					sscanf(templine,"%s %d",tempname,&TEMP);
					strncpy(groupnames[i],tempname,MaxGroupNameLength);
					while (strlen(groupnames[i]) < MaxGroupNameLength) strcat(groupnames[i], " ");
					grouplimits[i][1] = TEMP;
					checkgroupsum += grouplimits[i][1];
					while (strlen(groupnames[i]) < MaxGroupNameLength) 
						{
						strcat(groupnames[i], " ");
						}
					grouplimits[i][1] += grouplimits[i][0] - 1;
					}
				if (checkgroupsum != nums) 
					{
					printf("Sum of group numbers does not equal number of sequences \n");
					exit(-4);
					}
				}
			}
		howlong = countchar(templong);
		FORLIM = numnoncods + 3 + num_extra_comments;
		/*now must repeatedly readlines to get to start of data*/
		for (i = 1; i <= FORLIM; i++) 
			{
			fgets(templine,500,sfile);
			}
		if (numgrouplines == 1) FORLIM = 1;
		else FORLIM = numgrouplines + 1;
		for (i = 1; i <= FORLIM; i++) 
			{
			fgets(templine,200,sfile);
			}
		}
    for (i = numnoncods; i < MaxNoncods; i++) 
		{
		noncods[i].p5 = 0;
		noncods[i].p3 = 0;
		}
    numseqdrop = 0;
    FORLIM = nums;
    for (i = 0; i < FORLIM; i++)  whichlines[i] = _true;
    if (options[DROPSEQ])
		{
		tempnums = nums;
		if (!(Qp || Zp))
			{
			printf("DROPPING SOME SEQUENCES,  enter option :  r for range \n");
			printf("                                            f for file  \n");
			printf("                                            i for individual entry \n");
			ch = getchar();getchar();
			switch (toupper(ch)) 
				{
				case 'R':
				  isseqdropfile = _false;
				  isseqdroprange = _true;
				  printf("ENTER THE NUMBER OF THE FIRST SEQUENCE OF THE RANGE TO DROP: \n");
				  i = 0;
				  gets(templine);
				  if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
				  sscanf(templine,"%u", &seqrangebegin);
				  printf("ENTER THE NUMBER OF THE LAST SEQUENCE OF THE RANGE TO DROP: \n");
				  do {
				  gets(templine);
				  if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
				  sscanf(templine,"%u", &seqrangend);
				  } while (seqrangend <= seqrangebegin);
				  assert(seqrangend - seqrangebegin + 1 <= MaxDropKeep);
				  if (seqrangend > nums)
					 FORLIM = nums;
					 else FORLIM=seqrangend;
				  for (j=0,i = seqrangebegin; i <= FORLIM; i++,j++)
					  {
					  whichlines[i-1] = _false;
					  seqdroplist[j] = i;
					  tempnums--;
					  numseqdrop++;
					  }
				  break;

				case 'F':
				  isseqdropfile = _true;
				  isseqdroprange = _false;
				  printf("TYPE THE NAME OF THE FILE : \n");
				  fgets(tempfilename, _FNSIZE+10, stdin);
				  strncpy(seqdropname,tempfilename,_FNSIZE);
				  TEMP2 = strchr(seqdropname, '\n');
				  if (TEMP2 != NULL)
					  *TEMP2 = 0;
				  strcpy(seqdropfile_NAME,seqdropname);
				  if (seqdropfile != NULL)
					  seqdropfile = freopen(seqdropfile_NAME, "r", seqdropfile);
				  else
					  seqdropfile = fopen(seqdropfile_NAME, "r");
				  if (seqdropfile == NULL)
					  {
					  printf("\nError opening text file for reading \n"); exit(-1);}
					  i=0;
					  do
						  {
						  fscanf(seqdropfile, "%d", &TEMP);
						  getc(seqdropfile);
						  whichlines[TEMP-1] = _false;
						  seqdroplist[i] = TEMP-1;
						  tempnums--;
						  i++;
						  numseqdrop++;
						  } while (!P_eof(seqdropfile));
					   fclose(seqdropfile);
					   seqdropfile = NULL;
					   break;

				case 'I':
				  isseqdropfile = _false;
				  isseqdroprange = _false;
				  printf("ENTER A SEQUENCE TO BE IGNORED (hit CR if done): \n");
				  i = 0;
				  do	
					  {
					  fgets(temps, 11, stdin);
					  TEMP2 = strchr(temps, '\n');
					  if (TEMP2 != NULL) *TEMP2 = 0;
					  if (temps[0] == 0)  valcode = 1;
					  else valcode = (sscanf(temps, "%d", &tempdrop) == 0);
					  if (valcode == 0)
						  {
						   whichlines[tempdrop-1]= _false;
						   seqdroplist[i] = tempdrop-1;
						   i++;
						   tempnums--;
						   numseqdrop++;
						   }
					  } while (valcode == 0);
					  break;

				default:
				  assert(_false);
				  break;
				}
			}
		else 
			{
		  if (Qp){
		   isseqdropfile = _true;
		   isseqdroprange = _false;
		   strcpy(seqdropfile_NAME,seqdropname);
			seqdropfile = fopen(seqdropfile_NAME, "r");
		   if (seqdropfile == NULL){
				printf("\nError opening text file for reading \n"); exit(-1);}
			  i=0;
		   do {
			if (fscanf(seqdropfile, "%d", &TEMP)==1)
                {
			    getc(seqdropfile);
		        whichlines[TEMP-1] = _false;
		        seqdroplist[i] = TEMP-1;
		        tempnums--;
		        i++;
		        numseqdrop++;
                }
            else
               getc(seqdropfile);
			  } while (!P_eof(seqdropfile));
		   fclose(seqdropfile);
		   seqdropfile = NULL;

		   } 

		   if (Zp)
			   {
				 isseqdropfile = _false;
				 isseqdroprange = _true;
				 TEMP2 = strchr(seqdroprangestring,'-');
				 strncpy(temps,seqdroprangestring, TEMP2-seqdroprangestring+1);
				 seqrangebegin = atoi(temps);
				 TEMP2++;
				 seqrangend  = atoi(TEMP2);
				 if (seqrangend > nums)
					 FORLIM = nums;
					 else FORLIM=seqrangend;
				 for (j=0,i = seqrangebegin; i <= FORLIM; i++,j++)
					 {
					  whichlines[i-1] = _false;
					 seqdroplist[j] = i;
					 tempnums--;
					 numseqdrop++;
					}
			   } 
			}  
		if (!options[0])
			{
			grouplimits[0][1] = nums;
			groupsize[0] = nums;
			}
		FORLIM = numgroups;
		for (i = 0; i < FORLIM; i++)
		  groupsdel[i] = 0;
		FORLIM = nums;
		for (i = 1; i <= FORLIM; i++)
			{
			if (!whichlines[i - 1])
				{
				j = 1;
				while (grouplimits[j - 1][1] < i)
				j++;
				groupsdel[j - 1]++;
				}
			}
		j = 0;
		k = 0;
		FORLIM = numgroups;
		for (i = 0; i < FORLIM; i++) 
			{
			  k += groupsdel[i];
			  grouplimits[i][0] -= j;
			  grouplimits[i][1] -= k;
			  j += groupsdel[i];
			}
		j = 0;
		FORLIM = numgroups;
		for (i = 0; i < FORLIM; i++)
			{
            if (grouplimits[i][0] > grouplimits[i][1])
				j++;
			}
		oldnumgroups = numgroups;
		numgroups -= j;
		i = 1;
		while (i <= numgroups)
			{
		    if (grouplimits[i - 1][0] <= grouplimits[i - 1][1])
				{
				i++;
				continue;
				}
			for (k = i; k < oldnumgroups; k++)
				{
				strcpy(groupnames[k - 1], groupnames[k]);
				grouplimits[k - 1][0] = grouplimits[k][0];
				grouplimits[k - 1][1] = grouplimits[k][1];
				}
			oldnumgroups--;
			}
		} 
	else 
		{
			*linestring = '\0';
			tempnums = nums;
			if (!options[0])
				{
			    grouplimits[0][1] = nums;
			    groupsize[0] = nums;
				}
		}
    if (options[0])
		{
		FORLIM = numgroups;
		for (i = 0; i < FORLIM; i++)
			  groupsize[i] = grouplimits[i][1] - grouplimits[i][0] + 1;
		}
	else
		groupsize[0] = grouplimits[0][1];
    h = 1;
    if (!INTLV)
		{
		FORLIM = nums;
		for (i = 1; i <= FORLIM; i++)
			{
			nowseq_ptr = (seq_rec *)malloc(sizeof(seq_rec));
			if (i == 1)
				{
				nowseq2_ptr = (seq_rec *)malloc(sizeof(seq_rec));
				nowseq2_ptr = nowseq_ptr;
				}
			nowseq_ptr->next = NULL;
			nowseq_ptr->last = NULL;
			nowseq_ptr->n = h;
			for (j = 0; j < MaxL; j++) 	nowseq_ptr->sequence[j] = 0;
		  /*i indexes rows, the different sequences */
			do
				{
				ch=getc(sfile);
				} while (!(isalpha(ch)||isdigit(ch)));
		
		  sprintf(names[h - 1], "%c", ch);
		  for (j = 2; j <= MaxSeqNameLength; j++)
			  {
				ch = getc(sfile);
				assert(ch != '\n');
				sprintf(names[h - 1] + strlen(names[h - 1]), "%c", ch);
			  }
		  j = 0;
		  /*j indexes along rows, i.e. the columns*/

		  templong = 0;
		  do
			  {
				if (seqchar(ch = getc(sfile)))
					{
	    			j++;
					pushchar(j, ch);
					}
			  } while(j <howlong);
		  if (!whichlines[i - 1]) 
			  free(nowseq_ptr);
		  else 
			  {
			  if (h == 1)
				  {
				  firstseq_ptr = nowseq_ptr;
				  holdseq_ptr = NULL;
				}
				if (holdseq_ptr != NULL)
				  nowseq_ptr->last = holdseq_ptr;
				else
				  firstseq_ptr->next = nowseq_ptr;
				if (h != 1)
				  holdseq_ptr->next = nowseq_ptr;
				holdseq_ptr = nowseq_ptr;
				h++;
			  }
		    nowseq_ptr = firstseq_ptr;
			}
		}
	else
		Getintlv();
    nums = tempnums;
    if (sfile != NULL)
		fclose(sfile);
    sfile = NULL;
}  /*ReadData*/

#undef numstep

unsigned int  FindPlace(int spot)
    {
    unsigned int  i, j;
    int POS;
    unsigned int figure;
    double DUMMY;

    i = 1;
    if (spot < noncods[i - 1].p5 || numnoncods == 0)
        i = 0;
    else
        {
        while (spot >= noncods[i].p5 && i < numnoncods && noncods[i].p5 > 0)
            i++;
        }
    if (i > 0 && spot <= noncods[i - 1].p3)
        {
        POS = 0;
        return POS;
        }
    figure = spot;
    if (i > 0)
        {
        for (j = 0; j < i; j++)
            figure += noncods[j].p5 - noncods[j].p3 - 1;
        }
    POS = (int)floor(modf(figure / 3.0, &DUMMY) * 3.0 + 0.5) - 1;
    POS = (int)floor(modf((oframe + POS) / 3.0, &DUMMY) * 3.0 + 0.5);
    if (POS == 0)
        POS = 3;
    return POS;
    }  /*Findplace*/

static void poly(void)
{
  char ch;
    unsigned int  basecount[X - (long)A + 1];
    unsigned int  numone, numtwo, numone_nodel;
  basetype btype;
  unsigned int i, j, FORLIM;

  for (btype = A; (long)btype <= (long)X; btype = (basetype)((long)btype + 1))
    basecount[btype - (long)A] = 0;
  FORLIM = nums;
  for (j = 1; j <= FORLIM; j++) {
    ch = popchar(j, sspot);
    /*here X is used for deletions and Ns are ignored*/
    switch (ch) {

    case 'A':
      basecount[0]++;
      break;

    case 'C':
      basecount[C - (long)A]++;
      break;

    case 'G':
      basecount[G - (long)A]++;
      break;

    case 'T':
      basecount[T - (long)A]++;
      break;

    case '-':
      basecount[D - (long)A]++;
      break;

    case '*':
      basecount[D - (long)A]++;
      break;
    }
  }
  numone = 0;
  numtwo = 0;
  numone_nodel = 0;
  for (btype = A; (long)btype <= (long)T; btype = (basetype)((long)btype + 1)) {
    if (basecount[btype - (long)A] >= 2)
      numtwo++;
    if (basecount[btype - (long)A] >= 1) {
      numone++;
      numone_nodel++;
    }
  }
  if (basecount[D - (long)A] >= 2)
    numtwo++;
  if (basecount[D - (long)A] >= 1)
    numone++;
  if (numone == 1)
    isSITE = _false;
  else {
    isSITE = _true;
    if (numtwo > 1)
      what_this_site[INF - (long)EXN] = _true;
    what_this_site[TRN - (long)EXN] = 
		((basecount[0] > 0 && basecount[G - (long)A] > 0) || basecount[C - (long)A] > 0 && basecount[T - (long)A] > 0);
    what_this_site[TRV - (long)EXN] =
      ((basecount[0] > 0 && basecount[C - (long)A] > 0) ||
       (basecount[0] > 0 && basecount[T - (long)A] > 0) ||
       (basecount[C - (long)A] > 0 && basecount[G - (long)A] > 0) ||
       (basecount[G - (long)A] > 0 && basecount[T - (long)A] > 0));
	what_this_site[THREE - (long) EXN] = (what_this_site[TRN - (long)EXN] &&  what_this_site[TRV - (long)EXN]);
    what_this_site[FOU - (long)EXN] = (basecount[0] > 0 &&
	basecount[G - (long)A] > 0 &&
	basecount[C - (long)A] > 0 && basecount[T - (long)A] > 0);
    FORLIM = numnoncods;
    for (i = 0; i < FORLIM; i++) {
      if (sspot >= noncods[i].p5 && sspot <= noncods[i].p3 &&
	  numone_nodel > 1)
	what_this_site[INT - (long)EXN] = _true;
    }
    if (!what_this_site[INT - (long)EXN] && numone_nodel > 1)
      what_this_site[0] = _true;
    if (basecount[D - (long)A] > 0)
      what_this_site[DEL - (long)EXN] = _true;
  }
  if (isSITE && what_this_site[DEL - (long)EXN]) {
    id++;
    idlist[id - 1] = sspot;
  }
}  /*poly procedure within GetSites procedure*/

static void fillclist(void)
    {
    unsigned int  i, j, intposition;
    unsigned int position;
    char ch;
    unsigned int  FORLIM, FORLIM1;

    if (nowframe != 1)
        {
        FORLIM = nums;
        for (j = 0; j < FORLIM; j++)
            {
            for (i = 0; i <= 2; i++)
                clist[j][i] = X;
            *stringc[j] = '\0';
            FORLIM1 = nowframe;
            for (i = 1; i < FORLIM1; i++)
                {
	            strcat(stringc[j], "X");
                }
            for (i = nowframe; i <= 3; i++)
                {
	            ch = popchar(j + 1, sspot + i - nowframe);
	            sprintf(stringc[j] + strlen(stringc[j]), "%c", ch);
                }
            }
        return;
        }
    FORLIM = nums;
    for (j = 0; j < FORLIM; j++)
        {
        ch = popchar(j + 1, sspot);
        sprintf(stringc[j], "%c", ch);
        switch (ch)
            {
            case 'A':
              clist[j][0] = A;
              break;

            case 'C':
              clist[j][0] = C;
              break;

            case 'G':
              clist[j][0] = G;
              break;

            case 'T':
              clist[j][0] = T;
              break;

            default:
              clist[j][0] = X;
              break;
            }
        }
      position = sspot + 1;
      intposition = 0;
      while (position >= noncods[intposition].p5 && intposition < numnoncods)
        intposition++;
      if (intposition > 0) {
        if (position <= noncods[intposition - 1].p3)
          position = noncods[intposition - 1].p3 + 1;
      }
      FORLIM = nums;
      for (j = 0; j < FORLIM; j++) {
        ch = popchar(j + 1, position);
        sprintf(stringc[j] + strlen(stringc[j]), "%c", ch);
        switch (ch) {
        case 'A':
          clist[j][1] = A;
          break;
        case 'C':
          clist[j][1] = C;
          break;
        case 'G':
          clist[j][1] = G;
          break;
        case 'T':
          clist[j][1] = T;
          break;
        default:
          clist[j][1] = X;
          break;
        }
      }
      position++;
      intposition = 0;
      while (position >= noncods[intposition].p5 && intposition < numnoncods)
        intposition++;
      if (intposition > 0) {
        if (position <= noncods[intposition - 1].p3)
          position = noncods[intposition - 1].p3 + 1;
      }
      FORLIM = nums;
      for (j = 0; j < FORLIM; j++) {
        ch = popchar(j + 1, position);
        sprintf(stringc[j] + strlen(stringc[j]), "%c", ch);
        switch (ch) {

        case 'A':
          clist[j][2] = A;
          break;

        case 'C':
          clist[j][2] = C;
          break;

        case 'G':
          clist[j][2] = G;
          break;

        case 'T':
          clist[j][2] = T;
          break;

        default:
          clist[j][2] = X;
          break;
        }
      }
    }  /*fillclist*/

static boolean codonok(  unsigned int  z)
{
  return (clist[z - 1][0] != X && clist[z - 1][1] != X &&
	  clist[z - 1][2] != X);
}

static void SynorRep(void)
{
  unsigned int numdifs, i, j, k;
  boolean repdone, syndone, rep1done, syn1done;
  char STR2[256];
  unsigned int FORLIM;
  amino_acid aas1, aas2, aar1, aar2;


/*  SORdone = _false; */
  repdone = _false;
  rep1done = _false;
  syn1done = _false;
  syndone = _false; 
  k = 0;
  do {
    k++;
  } while (!(codonok(k) || k == nums));
  if (k == nums) {
    what_this_site[SOR - (long)EXN] = _true;
    /*if (SORdone)
      return; */
    sicount++;
	 nowsite_info_.num = sspot;
    sprintf(nowsite_info_.TEXT, "%4u", sspot);
    strcat(nowsite_info_.TEXT, " unknown");
    sprintf(nowsite_info_.TEXT + strlen(nowsite_info_.TEXT), " %s",
	    stringc[k - 1]);
 /*   SORdone = _true; */
    nowsite_info_.next = NULL;
    site_info_temp = (amino_acid_site_rec *)malloc(sizeof(amino_acid_site_rec));
    *site_info_temp = nowsite_info_;
    if (sicount == 1) {
      site_info_first = site_info_temp;
      site_info_last = NULL;
    } else
      site_info_last->next = site_info_temp;
    site_info_last = site_info_temp;
    return;
  }
  FORLIM = nums;
  for (j = k; j < FORLIM; j++) {
    if (clist[j][0] != X && clist[j][1] != X && clist[j][2] != X &&
	     clist[j][nowframe - 1] != clist[k - 1][nowframe - 1])
        {
         if (codon_table[clist[j][0] - (long)A][clist[j][1] - (long)A][clist[j][2] - (long)A] == 
              codon_table[clist[k - 1][0] - (long)A][clist[k - 1][1] - (long)A][clist[k - 1][2] - (long)A])
              {
	          what_this_site[SYN - (long)EXN] = _true;
              if (!syn1done)
                 {
                 aas1 = codon_table[clist[j][0] - (long)A][clist[j][1] - (long)A][clist[j][2] - (long)A];
                 aas2 = codon_table[clist[k - 1][0] - (long)A][clist[k - 1][1] - (long)A][clist[k - 1][2] - (long)A];
                 }      
	          if (((!syn1done) 
                   || (aas1 != codon_table[clist[j][0] - (long)A][clist[j][1] - (long)A][clist[j][2] - (long)A]) 
                   || (aas2 != codon_table[clist[k - 1][0] - (long)A][clist[k - 1][1] - (long)A][clist[k - 1][2] - (long)A]))
                    && (!syndone))
                  {
	              sicount++;
	              nowsite_info_.num = sspot;
  	              sprintf(nowsite_info_.TEXT, "%4u", sspot);
	              strcat(nowsite_info_.TEXT, " synon  ");
	              sprintf(nowsite_info_.TEXT + strlen(nowsite_info_.TEXT), " %s", names[k - 1]);
	              sprintf(nowsite_info_.TEXT + strlen(nowsite_info_.TEXT), " %s",
		              strsub(STR2, codonstr[clist[k - 1][0] - (long)A]
			             [clist[k - 1][1] - (long)A]
			             [clist[k - 1][2] - (long)A], 5, 3));
	              sprintf(nowsite_info_.TEXT + strlen(nowsite_info_.TEXT), " %s -",stringc[k - 1]);
	              sprintf(nowsite_info_.TEXT + strlen(nowsite_info_.TEXT), " %s",stringc[j]);
	              sprintf(nowsite_info_.TEXT + strlen(nowsite_info_.TEXT), " %s",
		              strsub(STR2, codonstr[clist[j][0] - (long)A]
			             [clist[j][1] - (long)A]
			             [clist[j][2] - (long)A], 5, 3));
	              sprintf(nowsite_info_.TEXT + strlen(nowsite_info_.TEXT), " %s", names[j]);
	              if ( syn1done) 
                      syndone = _true; 
                  else 
                      syn1done = _true;
	              nowsite_info_.next = NULL;
	              site_info_temp = (amino_acid_site_rec *) malloc(sizeof(amino_acid_site_rec));
	              *site_info_temp = nowsite_info_;
	              if (sicount == 1)
                      {
	                  site_info_first = site_info_temp;
	                  site_info_last = NULL;
                      }
                  else
	                site_info_last->next = site_info_temp;
	              site_info_last = site_info_temp;
	              } 
              } 
          else
              {
              what_this_site[REP - (long)EXN] = _true;
              if (!rep1done)
                  {
                  aar1 = codon_table[clist[j][0] - (long)A][clist[j][1] - (long)A][clist[j][2] - (long)A];
                  aar2 = codon_table[clist[k - 1][0] - (long)A][clist[k - 1][1] - (long)A][clist[k - 1][2] - (long)A];
                  }      
              if (((!rep1done) 
                || (aar1 != codon_table[clist[j][0] - (long)A][clist[j][1] - (long)A][clist[j][2] - (long)A]) 
                || (aar2 != codon_table[clist[k - 1][0] - (long)A][clist[k - 1][1] - (long)A][clist[k - 1][2] - (long)A]))
                && (!repdone))
                    {
                    sicount++;
                    nowsite_info_.num = sspot;
                    sprintf(nowsite_info_.TEXT, "%4u", sspot);
                    strcat(nowsite_info_.TEXT, " replace");
                    sprintf(nowsite_info_.TEXT + strlen(nowsite_info_.TEXT), " %s",names[k - 1]);
                    sprintf(nowsite_info_.TEXT + strlen(nowsite_info_.TEXT), " %s",
                      strsub(STR2, codonstr[clist[k - 1][0] - (long)A]
	                     [clist[k - 1][1] - (long)A]
	                     [clist[k - 1][2] - (long)A], 5, 3));
                    sprintf(nowsite_info_.TEXT + strlen(nowsite_info_.TEXT), " %s -",stringc[k - 1]);
                    sprintf(nowsite_info_.TEXT + strlen(nowsite_info_.TEXT), " %s",stringc[j]);
                    sprintf(nowsite_info_.TEXT + strlen(nowsite_info_.TEXT), " %s",
                      strsub(STR2, codonstr[clist[j][0] - (long)A]
	                     [clist[j][1] - (long)A]
	                     [clist[j][2] - (long)A], 5, 3));
                    sprintf(nowsite_info_.TEXT + strlen(nowsite_info_.TEXT), " %s",names[j]);
                    if (rep1done) repdone = _true; 
                    else rep1done =_true;
                    nowsite_info_.next = NULL;
                    site_info_temp = (amino_acid_site_rec *)
	                       malloc(sizeof(amino_acid_site_rec));
                    *site_info_temp = nowsite_info_;
                    if (sicount == 1) 
                        {
                        site_info_first = site_info_temp;
                        site_info_last = NULL;
                        } 
                    else
                        site_info_last->next = site_info_temp;
                    site_info_last = site_info_temp;
                    } 
              }
        }
    numdifs = 0;
    for (i = 0; i <= 2; i++) {
      if (clist[j][i] != clist[k - 1][i] && clist[j][i] != X)
	numdifs++;
    }
    if (numdifs > 1)
      what_this_site[SOR - (long)EXN] = _true;
  }
 return;
}  /*SynorRep*/

static void polyID(unsigned int *idspot,unsigned int *idlength)
{
  /*identifies polymorphic Indels*/
  /*idspot is the current position in idlist*/
  char ch;
    unsigned int  basecount[X - (long)D + 1];
    unsigned int  numone, numtwo;
  basetype btype, btype1, btype2;
  unsigned int i, j;
  boolean matchsite;
  unsigned int spot1, spot2, FORLIM;

  spot1 = idlist[*idspot - 1];
  for (btype = D; (long)btype <= (long)X; btype = (basetype)((long)btype + 1))
    basecount[btype - (long)D] = 0;
  FORLIM = nums;
  for (j = 1; j <= FORLIM; j++) {
    ch = popchar(j, spot1);
    /*here X is used for N;s D for deletions and INS for others*/
    switch (ch) {

    case 'A':
      basecount[INS - (long)D]++;
      break;

    case 'C':
      basecount[INS - (long)D]++;
      break;

    case 'G':
      basecount[INS - (long)D]++;
      break;

    case 'T':
      basecount[INS - (long)D]++;
      break;

    case 'N':
      basecount[X - (long)D]++;
      break;

    case '*':
      basecount[0]++;
      break;

    case '-':
      basecount[0]++;
      break;
    }
  }
  numone = 0;
  numtwo = 0;
  for (btype = D; (long)btype <= (long)INS; btype = (basetype)((long)btype + 1)) {
    if (basecount[btype - (long)D] >= 2)
      numtwo++;
    if (basecount[btype - (long)D] >= 1)
      numone++;
  }
  if (numone == 1)
    isSITE = _false;
  else {
    isSITE = _true;
    if (numtwo > 1)
      what_this_site[INF - (long)EXN] = _true;
    FORLIM = numnoncods;
    for (i = 0; i < FORLIM; i++) {
      if (sspot >= noncods[i].p5 && sspot <= noncods[i].p3)
	what_this_site[INT - (long)EXN] = _true;
    }
    if (!what_this_site[INT - (long)EXN])
      what_this_site[0] = _true;
    what_this_site[DEL - (long)EXN] = _true;
  }
  *idlength = 1;
  if (idlist[*idspot] == idlist[*idspot - 1] + 1) {
    matchsite = _true;
    spot2 = idlist[*idspot];
    while (matchsite) {
      j = 0;
      while (matchsite && j < nums) {
	j++;
	ch = popchar(j, spot1);
	switch (ch) {

	case 'A':
	  btype1 = INS;
	  break;

	case 'C':
	  btype1 = INS;
	  break;

	case 'G':
	  btype1 = INS;
	  break;

	case 'T':
	  btype1 = INS;
	  break;

	case 'N':
	  btype1 = X;
	  break;

	case '*':
	  btype1 = D;
	  break;

	case '-':
	  btype1 = D;
	  break;
	}
	ch = popchar(j, spot2);
	switch (ch) {

	case 'A':
	  btype2 = INS;
	  break;

	case 'C':
	  btype2 = INS;
	  break;

	case 'G':
	  btype2 = INS;
	  break;

	case 'T':
	  btype2 = INS;
	  break;

	case 'N':
	  btype2 = X;
	  break;

	case '*':
	  btype2 = D;
	  break;

	case '-':
	  btype2 = D;
	  break;
	}
	matchsite = (btype1 == btype2 || btype1 == X || btype2 == X);
      }
      if (!matchsite)
	break;
      matchsite = (idlist[*idspot + *idlength] ==
		   idlist[*idspot - 1] + *idlength + 1);
      spot2 = idlist[*idspot + *idlength];
      (*idlength)++;
    }
  }
  *idspot += *idlength;
}  /*polyID procedure within GetSites procedure*/


void GetSites(void)
{
  basetype basei, basej;
    unsigned int  basecount[X - (long)A + 1];
    unsigned int  IDbasecount[X - (long)D + 1];
    unsigned int  basemax;
  unsigned int i, j;
  char ch, conschar;
  unsigned int idlength, FORLIM, FORLIM1;

  scount = 0;
  sicount = 0;
  idcount = 0;
  id = 0;
  site_info_first = NULL;
  sspot = 1;
  nowframe = FindPlace(sspot);
  if (nowframe > 0)
    fillclist();
  FORLIM = howlong;
  if (screenupdate) printf("Finding polymorphic sites at positions : \n");
  for (sspot = 1; sspot <= FORLIM; sspot++)
      {
      isSITE = _true;
      if (options[DROPSITE])
        {
        i = 1;
        while (i <= numdrop && sspot != droplist[i - 1])  i++;
        isSITE = (i > numdrop);
        }
      if (isSITE && options[LIMITSITE])
        {
        i = 1;
        while (i <= numkeep && sspot != keeplist[i - 1]) i++;
        isSITE = (i <= numkeep);
        }
      if (isSITE)
        {
        isSITE = _false;
        nowframe = FindPlace(sspot);
        if (sspot == 1 && nowframe != 1 && nowframe != 0)
	    numnocode++;
        if (nowframe == 1)
            {
	        fillclist();
	        FORLIM1 = nums;
	        for (j = 0; j < FORLIM1; j++)
                {
	            if (j + 1 == 1)
                    {
            	    if (codonok(1))
                        {
	                    codonsone[clist[j][0] - (long)A][clist[j][1] - (long)A][clist[j][2] - (long)A]++;
	                    numyescode++;
	                    }
                    else
	                    numnocode++;
	                }
	            if (codonok(j + 1))
                    codonsall[clist[j][0] - (long)A][clist[j][1] - (long)A][clist[j][2] - (long)A]++;
	            }
            }
        memcpy(what_this_site, FalseSites, sizeof(SiteBool));
        poly();
        if (skipindel) 
         if (what_this_site[DEL - (long)EXN])
             {
             isSITE = _false;
             indeldroplist[numindeldrop]=sspot;
             numindeldrop++;
             }
        if (skipmultibase) 
         if (what_this_site[TRN - (long)EXN] && what_this_site[TRV - (long)EXN])
             {
             isSITE = _false;
             multibasedroplist[nummultibasedrop]=sspot;
             nummultibasedrop++;
             }
        if (isSITE)
            {
	        scount++;
	        if (screenupdate) 
                printf(" %4u  \n", sspot);
	        if (what_this_site[0])
                SynorRep();
	        nowsite.sitn = scount;
	        nowsite.seqn = sspot;
	        memcpy(nowsite.s, what_this_site, sizeof(SiteBool));
	        sprintf(nowsite.t, "%5u", sspot);
	        if (!options[FIRSTREF])
                {
	            for (basei = A;(long)basei <= (long)X; basei = (basetype)((long)basei + 1))
                    basecount[basei - (long)A] = 0;
	            FORLIM1 = nums;
	            for (j = 1; j <= FORLIM1; j++)
                    {
	                ch = popchar(j, sspot);
	                switch (ch)
                        {
	                    case 'A':
	                      basecount[0]++;
	                      break;

	                    case 'C':
	                      basecount[C - (long)A]++;
	                      break;

	                    case 'G':
	                      basecount[G - (long)A]++;
	                      break;

	                    case 'T':
	                      basecount[T - (long)A]++;
	                      break;

	                    case 'N':
	                      basecount[X - (long)A]++;
	                      break;

	                    case '-':
	                      basecount[D - (long)A]++;
	                      break;

	                    case '*':
	                      basecount[D - (long)A]++;
	                      break;
	                    }
                    }
	            basemax = 0;
	            for (basei = A;(long)basei <= (long)T;basei = (basetype)((long)basei + 1))
                    {
	                if (basecount[basei - (long)A] > basemax) {
	                basej = basei;
	                basemax = basecount[basei - (long)A];
	                }
	            }
	            basei = D;
	            if (basecount[basei - (long)A] > basemax)
                    {
	                basej = basei;
	                basemax = basecount[basei - (long)A];
	                }
	            switch (basej)
                    {
	                case A:
	                    conschar = 'A';
	                    break;

	                case C:
	                    conschar = 'C';
	                    break;

	                case G:
	                    conschar = 'G';
	                    break;

	                case T:
	                    conschar = 'T';
	                    break;
                    case D:
	                    conschar = indelchar;
	                    break;
                    }
                consensus[scount - 1] = conschar;
	            FORLIM1 = nums;
	            for (j = 1; j <= FORLIM1; j++)
                    {
	                ch = popchar(j, sspot);
	                if (ch == conschar)
	                    nowsite.p[j - 1] = samechar;
	                else
                        {
	                    if (ch == indelchar)
		                    nowsite.p[j - 1] = indelchar;
	                    else
		                    nowsite.p[j - 1] = ch;
	                    }
	                 }
	            }
            else
                {
	            FORLIM1 = nums;
	            for (j = 1; j <= FORLIM1; j++)
                    {
	                ch = popchar(j, sspot);
	                if (j == 1)
                        {
	                    nowsite.p[j - 1] = ch;
	                    consensus[scount - 1] = ch;
	                    }
                    else
                        {
	                    if (ch != nowsite.p[0])
		                    nowsite.p[j - 1] = ch;
	                    else
		                    nowsite.p[j - 1] = samechar;
	                    }
	                }
	            }
            if (analyses[PREF - (long)SIT] == _true)
                {
                nowsite.c = malloc(sizeof(codontype) * nums);
                for (j = 0; j < nums; j++)
                    {
                    nowsite.c[j][0] = clist[j][0];
                    nowsite.c[j][1] = clist[j][1];
                    nowsite.c[j][2] = clist[j][2];
                    }

                }
	        nowsite_ptr = (site_rec *)malloc(sizeof(site_rec));
	        *nowsite_ptr = nowsite;
        	if (scount == 1)
                {
	            firstsite_ptr = nowsite_ptr;
	            lastsite_ptr = nowsite_ptr;
	            }
	        nowsite_ptr->last = lastsite_ptr;
	        nowsite_ptr->next = firstsite_ptr;
	        lastsite_ptr->next = nowsite_ptr;
	        firstsite_ptr->last = nowsite_ptr;
	        lastsite_ptr = nowsite_ptr;
            }
        }
      }
      if (!(whatsites[DEL - (long)EXN] && analyses[INDELS - (long)SIT]))
        return;
      i = 1;
      sspot = idlist[i - 1];
      idcount = 0;
      while (i <= id)
        {
        sspot = idlist[i - 1];
        isSITE = _true;
        if (options[DROPSITE])
            {
            j = 1;
            while (j <= numdrop && sspot != droplist[j - 1]) j++;
            isSITE = (j > numdrop);
            }
        if (isSITE && options[LIMITSITE])
            {
            j = 1;
            while (j <= numkeep && sspot != keeplist[j - 1])  j++;
            isSITE = (j <= numkeep);
            }
        if (!isSITE)
          continue;
        isSITE = _false;
        memcpy(what_this_site, FalseSites, sizeof(SiteBool));
        polyID(&i, &idlength);
        if (!isSITE)
          continue;

        idcount++;
        indellengths[idcount - 1] = idlength;
        nowIDsit.sitn = idcount;
        nowIDsit.seqn = sspot;
        memcpy(nowIDsit.s, what_this_site, sizeof(SiteBool));
        sprintf(nowIDsit.t, "%5u", sspot);
        if (!options[FIRSTREF])
            {
          /* this next little initializing loop may have a problem */
            for (basei = D; (long)basei <= (long)X; basei = (basetype)((long)basei + 1))
                IDbasecount[basei - (long)D] = 0;
            FORLIM = nums;
            for (j = 1; j <= FORLIM; j++)
                {
	            ch = popchar(j, sspot);
	            switch (ch)
                    {
	                case 'A':
	                  IDbasecount[INS - (long)D]++;
	                  break;

	                case 'C':
	                  IDbasecount[INS - (long)D]++;
	                  break;

	                case 'G':
	                  IDbasecount[INS - (long)D]++;
	                  break;

	                case 'T':
	                  IDbasecount[INS - (long)D]++;
	                  break;

	                case 'N':
	                  IDbasecount[X - (long)D]++;
	                  break;

	                case '-':
	                  IDbasecount[0]++;
	                  break;

	                case '*':
	                  IDbasecount[0]++;
	                  break;
	                }
                }
            if (IDbasecount[INS - (long)D] >= IDbasecount[0])
                {
	            conschar = 'I';
	            basei = INS;
                } 
            else
                {
	            conschar = indelchar;
	            basei = D;
                }
            IDconsensus[idcount - 1] = conschar;
            FORLIM = nums;
            for (j = 1; j <= FORLIM; j++)
                {
	            ch = popchar(j, sspot);
	            switch (ch)
                    {
	                case 'A':
	                  basej = INS;
	                  break;

	                case 'C':
	                  basej = INS;
	                  break;

	                case 'G':
	                  basej = INS;
	                  break;

	                case 'T':
	                  basej = INS;
	                  break;

	                case 'N':
	                  basej = X;
	                  break;

	                case '-':
	                  basej = D;
	                  break;

	                case '*':
	                  basej = D;
	                  break;
	                }
                if (basej == basei && basej != X)
	                nowIDsit.p[j - 1] = samechar;
	            else
                    {
	                if (basej == D)
	                    nowIDsit.p[j - 1] = indelchar;
	                if (basej == X)
	                    nowIDsit.p[j - 1] = 'N';
	                if (basej == INS)
	                    nowIDsit.p[j - 1] = 'I';
	                }
                }
            }
        else
            {
            FORLIM = nums;
            for (j = 1; j <= FORLIM; j++)
                {
	            ch = popchar(j, sspot);
	            switch (ch)
                    {
	                case 'A':
	                  ch = 'I';
	                  break;

	                case 'C':
	                  ch = 'I';
	                  break;

	                case 'G':
	                  ch = 'I';
	                  break;

	                case 'T':
	                  ch = 'I';
	                  break;
	                }
                if (j == 1)
                    {
	                nowIDsit.p[j - 1] = ch;
	                IDconsensus[idcount - 1] = ch;
	                }
                else
                    {
	                if (ch != nowIDsit.p[0])
	                    nowIDsit.p[j - 1] = ch;
	                else
	                    nowIDsit.p[j - 1] = samechar;
	                }
                }
            }
        nowIDsite_ptr = (site_rec *)malloc(sizeof(site_rec));
        *nowIDsite_ptr = nowIDsit;
        if (idcount == 1)
            {
            firstIDsite_ptr = nowIDsite_ptr;
            lastIDsite_ptr = nowIDsite_ptr;
            }
        nowIDsite_ptr->last = lastIDsite_ptr;
        nowIDsite_ptr->next = firstIDsite_ptr;
        lastIDsite_ptr->next = nowIDsite_ptr;
        firstIDsite_ptr->last = nowIDsite_ptr;
        lastIDsite_ptr = nowIDsite_ptr;
        }
}  /*GetSites*/

