/*
* Copyright 2002 by Jody Hey
* Rutgers University, Piscataway, NJ 08855
*
* This computer program and documentation may be freely copied
* and used by anyone, provided no fee is charged for it.
*/

/* do not compile using the optimizer in Visualage C++.  It cuases a problem
in defining the consensus sequence properly??*/

/*
some modifications  March 1999
- changinge the way Tajima D and Fu stats use sites w/ > 2 bases.
now those extra bases are not counted as extra polymorphic sites. this was the easy way out
- added another non-folded site frequency table
- modified the drop keep options.  now can do both 
  (but this may not be completely debugged)
*/


#define SITES_G
#include "sites.h"


/* INITIALIZED GLOBAL VARIABLES (others are in sitesm.h)*/

SiteBool FalseSites = {
  _false, _false, _false, _false, _false, _false, _false, _false, _false, _false
};

amino_acid codon_table[T + 1][T + 1][T + 1] = 
	{
	  { { LYS, ASN, LYS, ASN },
		{ THR, THR, THR, THR },
		{ ARG, SER, ARG, SER },
		{ ILE, ILE, MET, ILE } },
	  { { GLN, HIS, GLN, HIS },
		{ PRO, PRO, PRO, PRO },
		{ ARG, ARG, ARG, ARG },
		{ LEU, LEU, LEU, LEU } },
	  { { GLU, ASP, GLU, ASP },
		{ ALA, ALA, ALA, ALA },
		{ GLY, GLY, GLY, GLY },
		{ VLN, VLN, VLN, VLN } },
	  { { STP, TYR, STP, TYR },
		{ SER, SER, SER, SER },
		{ STP, CYS, TRP, CYS },
		{ LEU, PHE, LEU, PHE } }
	};

char codonstr[T + 1][T + 1][T + 1][12] = 
	{
	  { { "AAA LYS ", "AAC ASN ", "AAG LYS ", "AAU ASN " },
		{ "ACA THR ", "ACC THR ", "ACG THR ", "ACU THR " },
		{ "AGA ARG ", "AGC SER ", "AGG ARG ", "AGU SER " },
		{ "AUA ILE ", "AUC ILE ", "AUG MET ", "AUU ILE " } },
	  { { "CAA GLN ", "CAC HIS ", "CAG GLN ", "CAU HIS " },
		{ "CCA PRO ", "CCC PRO ", "CCG PRO ", "CCU PRO " },
		{ "CGA ARG ", "CGC ARG ", "CGG ARG ", "CGU ARG " },
		{ "CUA LEU ", "CUC LEU ", "CUG LEU ", "CUU LEU " } },
	  { { "GAA GLU ", "GAC ASP ", "GAG GLU ", "GAU ASP " },
		{ "GCA ALA ", "GCC ALA ", "GCG ALA ", "GCU ALA " },
		{ "GGA GLY ", "GGC GLY ", "GGG GLY ", "GGU GLY " },
		{ "GUA VAL ", "GUC VAL ", "GUG VAL ", "GUU VAL " } },
	  { { "UAA STP ", "UAC TYR ", "UAG STP ", "UAU TYR " },
		{ "UCA SER ", "UCC SER ", "UCG SER ", "UCU SER " },
		{ "UGA STP ", "UGC CYS ", "UGG TRP ", "UGU CYS " },
		{ "UUA LEU ", "UUC PHE ", "UUG LEU ", "UUU PHE " } }
	};

unsigned short codonsone[T + 1][T + 1][T + 1] = 
	{
		{ { 0, 0, 0, 0 },
		{ 0, 0, 0, 0 },
		{ 0, 0, 0, 0 },
		{ 0, 0, 0, 0 } },
		{ { 0, 0, 0, 0 },
		{ 0, 0, 0, 0 },
		{ 0, 0, 0, 0 },
		{ 0, 0, 0, 0 } },
		{ { 0, 0, 0, 0 },
		{ 0, 0, 0, 0 },
		{ 0, 0, 0, 0 },
		{ 0, 0, 0, 0 } },
		{ { 0, 0, 0, 0 },
		{ 0, 0, 0, 0 },
		{ 0, 0, 0, 0 },
		{ 0, 0, 0, 0 } }
	};

unsigned short codonsall[T + 1][T + 1][T + 1] = 
	{
	{ { 0, 0, 0, 0 },
	{ 0, 0, 0, 0 },
	{ 0, 0, 0, 0 },
	{ 0, 0, 0, 0 } },
	{ { 0, 0, 0, 0 },
	{ 0, 0, 0, 0 },
	{ 0, 0, 0, 0 },
	{ 0, 0, 0, 0 } },
	{ { 0, 0, 0, 0 },
	{ 0, 0, 0, 0 },
	{ 0, 0, 0, 0 },
	{ 0, 0, 0, 0 } },
	{ { 0, 0, 0, 0 },
	{ 0, 0, 0, 0 },
	{ 0, 0, 0, 0 },
	{ 0, 0, 0, 0 } }
	};

codonclass codonPtable[T + 1][T + 1][T + 1] = 
    {
	{ { UNP, UNP, UNP, UNP },
	{ UNP, UNP, UNP, UNP },
	{ UNP, UNP, UNP, UNP },
	{ UNP, UNP, UNP, UNP } },
	{ { UNP, UNP, UNP, UNP },
	{ UNP, UNP, UNP, UNP },
	{ UNP, UNP, UNP, UNP },
	{ UNP, UNP, UNP, UNP } },
	{ { UNP, UNP, UNP, UNP },
	{ UNP, UNP, UNP, UNP },
	{ UNP, UNP, UNP, UNP },
	{ UNP, UNP, UNP, UNP } },
	{ { UNP, UNP, UNP, UNP },
	{ UNP, UNP, UNP, UNP },
	{ UNP, UNP, UNP, UNP },
	{ UNP, UNP, UNP, UNP } }
	};


unsigned int numnocode = 0, numyescode = 0;

boolean skipindel = _false;
boolean skipmultibase = _false;

int /*unsigned short*/  maxpolyused, maxpolyused_o;
int sitefreqsum[MaxGroups][UPREF_UPREF+1],sitefreqsum_o[MaxGroups][UPREF_UPREF+1];

/*sharedpolydist is a massive array - only used with smaller data sets and SHARE_POLY_DIST_OPTION */

#ifdef SHARE_POLY_DIST_OPTION
unsigned short derivedpolydist[MaxGroups][MaxGroups][MaxS + 1][MaxS + 1]= {{{{0,0},{0,0}},{{0,0},{0,0}}},{{{0,0},{0,0}},{{0,0},{0,0}}}};
unsigned short foldedpolydist[MaxGroups][MaxGroups][MaxS + 1][MaxS + 1]= {{{{0,0},{0,0}},{{0,0},{0,0}}},{{{0,0},{0,0}},{{0,0},{0,0}}}};
unsigned int numquestionable_derivedbase[MaxGroups][MaxGroups],questionable_derivedbase[MaxGroups][MaxGroups][Maxmultibase + 1];
unsigned int numoutbaseisderived[MaxGroups][MaxGroups],outbaseisderived[MaxGroups][MaxGroups][Maxmultibase + 1];
unsigned int numrt[MaxGroups][MaxGroups],rt[MaxGroups][MaxGroups][Maxmultibase + 1];
unsigned int numft[MaxGroups][MaxGroups],ft[MaxGroups][MaxGroups][Maxmultibase + 1];
#endif



/* STATIC LOCAL FUNCTION PROTOTYPES */
static void DoDstats(void);
static   unsigned short  findgroup(  unsigned short  groupquery);
static void GetDiffs(void);
static void getgc(void);
static void Finish(void);
static void fillfact(void);
static float quicktajd(double n, double s, double pi);



/* FUNCTIONS */


static void DoDstats(void)
    {
    unsigned short i, j;
    unsigned short  groupi;
  /*tajima vars*/
    double a1, a2, n, b1, b2, e1, e2, c1, c2, s, t, pi, td;
  /*Fu and Li vars*/
    double nu, nue, nus, a, b, c, d, u, v, ustar, vstar, fl, flstar;
    int FORLIM;
    double TEMP, TEMP1;

    FORLIM = numgroups;
    for (groupi = 0; groupi < FORLIM; groupi++)
        {
        if (groupsize[groupi] >= 4)
            {
            /*first do tajimad*/
            n = groupsize[groupi];
            j = groupsize[groupi];
            s = totalpoly[groupi];
            pi = groupdiffs[groupi][groupi];
            a1 = 1.0;
            for (i = 2; i < j; i++)
                a1 += 1.0 / i;
            a2 = 1.0;
            for (i = 2; i < j; i++)
                {
                TEMP = 1.0 * i;
                a2 += 1.0 / (TEMP * TEMP);
                }
            b1 = (n + 1.0) / (3.0 * (n - 1.0));
            b2 = 2.0 * (n * n + n + 3.0) / (9.0 * n * (n - 1.0));
            c1 = b1 - 1 / a1;
            c2 = b2 - (n + 2.0) / (a1 * n) + a2 / (a1 * a1);
            e1 = c1 / a1;
            e2 = c2 / (a1 * a1 + a2);
            t = e1 * s + e2 * s * (s - 1);
            if (s > 0.0 && t > 0.0)
                td = (pi - s / a1) / sqrt(t);
            else
                td = -100.0;
            if (td > -99.0)
                {
                sprintf(TajD[groupi], "%7.4f", td);
                }
            else
                strcpy(TajD[groupi], "undef  ");
            strcat(TajD[groupi], " ");
            /*now do Fu and Li D*/
            if (outgroup[groupi] > 0)
                {
                nu = s;
                nue = singletonOG[groupi];
                a = a1;
                b = a2;
                c = 2 * (n * a - 2 * (n - 1)) / ((n - 1) * (n - 2));
                v = 1 + a * a / (b + a * a) * (c + (n + 1) / (1 - n));
                u = a - 1.0 - v;
                if (u * nu + v * nu * nu <= 0.0)
                    strcpy(FuLiD[groupi], "undef  ");
                else
                    {
                    fl = (nu - a * nue) / sqrt(u * nu + v * nu * nu);
                    sprintf(FuLiD[groupi], "% 7.4f", fl);
                    }
                strcat(FuLiD[groupi], " ");
                } 
            else
                strcpy(FuLiD[groupi], "no OutGp");

            /* now do Fu and Li D*, i.e. without an outgroup*/
            nu = s;
            a = a1;
            b = a2;
            c = 2 * (n * a - 2 * (n - 1)) / ((n - 1) * (n - 2));
            nus = singleton[groupi];
            TEMP = n - 1;
            d = c + (n - 2) / (TEMP * TEMP) + 2.0 / (n - 1) *(3.0 / 2.0 + (3.0 - 2 * (a + 1.0 / n)) / (n - 2.0) - 1.0 / n);
            TEMP = n / (n - 1);
            TEMP1 = n - 1;
            vstar = TEMP * TEMP * b + a * a * d - 2.0 * n * a * (a + 1.0) / (TEMP1 * TEMP1);
            vstar /= a * a + b;
            ustar = n / (n - 1.0) * (a + n / (1.0 - n)) - vstar;
            if (ustar * nu + vstar * nu * nu <= 0.0)
                strcpy(FuLiDstar[groupi], "undef  ");
            else
                {
                flstar = (n / (n - 1.0) * nu - a * nus) /    sqrt(ustar * nu + vstar * nu * nu);
                sprintf(FuLiDstar[groupi], " % 7.4f", flstar);
                }
            strcat(FuLiDstar[groupi], " ");
            }
        else
            {
            strcpy(TajD[groupi],     " low ss ");
            strcpy(FuLiD[groupi],     " low ss ");
            strcpy(FuLiDstar[groupi], " low ss ");
            }
      }
    }  /*tajimad*/
static float quicktajd(double n, double s, double pi)
    {
    double a1, a2, b1, b2, e1, e2, c1, c2, t, td, TEMP;
    unsigned short i, j;
    j = (int) n;
    if (j >= 4)
        {
        a1 = 1.0;
        for (i = 2; i < j; i++)
            a1 += 1.0 / i;
        a2 = 1.0;
        for (i = 2; i < j; i++)
            {
            TEMP = 1.0 * i;
            a2 += 1.0 / (TEMP * TEMP);
            }
        b1 = (n + 1.0) / (3.0 * (n - 1.0));
        b2 = 2.0 * (n * n + n + 3.0) / (9.0 * n * (n - 1.0));
        c1 = b1 - 1 / a1;
        c2 = b2 - (n + 2.0) / (a1 * n) + a2 / (a1 * a1);
        e1 = c1 / a1;
        e2 = c2 / (a1 * a1 + a2);
        t = e1 * s + e2 * s * (s - 1);
        if (s > 0.0 && t > 0.0)
            td = (pi - s / a1) / sqrt(t);
        else
            td = -100.0;
        if (td > -99.0)
            {
            return(td);
            }
        else
            return(-100);
        }
    else
        return(-100);
    } /* quicktajd */


static   unsigned short  findgroup(  unsigned short  groupquery)
/* find the group that a sequence falls in.  note - groupquery comes in numbered from 1 to nums 
   whereas the group that is found is numbered from 0 to numgroups */
    {
    unsigned short  i;
    i = 0;
    while (groupquery > grouplimits[i][1])
        i++;
    return i;
    }


static void fillfact(void)
{
  static unsigned short i;
  fact[0] = 1.0;
  for (i = 1; i <= MaxS; i++){
  fact[i] = (long double) i * fact[i-1];
 }
}

static void GetDiffs(void)
    {
    unsigned int i, j, k, tcount, spot;
    char chi, chj;
    unsigned short  groupi, groupj;
    unsigned int  basecounti[X + 1], basecountj[X + 1];
    unsigned int baseline[X+1];
    basetype basei, basej, base;
    unsigned int  maxpoly, thispoly, thispoly_o, ispoly, fixed_o;
    boolean countfix, IncludeBase;
    char checksharepoly[MaxGroups][T + 1];
    unsigned int  countsharedpoly;
    double tempd1, tempd2;
    unsigned int  tempgroup;
    char outchar;
    basetype outbase, lobase,hibase,inbase;
    unsigned int  FORLIM, FORLIM1, FORLIM2;
    unsigned int FORLIM3, FORLIM4;
    double TEMP;
    polydistclass  pdc;
    codontype  dcodon, acodon;
    

#ifdef SHARE_POLY_DIST_OPTION
    unsigned int derivedi, derivedj;
    int polyi, polyj;
    basetype lo1, hi1, lo2, hi2;
    unsigned int clo1,chi1,clo2,chi2;
    int temp;
#endif
  
  /*initializations*/
    maxpolyused = 0;
    maxpolyused_o = 0;
    nowseq2_ptr = nowseq_ptr;
    FORLIM = nums;
    for (i = 0; i < FORLIM; i++)
        {
        FORLIM1 = nums;
        for (j = 0; j < FORLIM1; j++)
          compbases[i][j] = 0;
        }
    FORLIM = numgroups;
    for (i = 0; i < FORLIM; i++)
        {
        FORLIM1 = numgroups;
        for (j = 0; j < FORLIM1; j++)
            {
            groupdiffs[i][j] = 0.0;
            fixdiffs[i][j] = 0;
            avpairfix[i][j] = 0.0;
            groupcompbases[i][j] = 0.0;
            sharepoly[i][j] = 0;
            }
        }
    FORLIM = numgroups;
    for (i = 0; i < FORLIM; i++)
        {
        polysite[i] = 0;
        for (j = 0; j <= MaxS / 2; j++)
          polydist[SITESUM][i][j] = 0;
        HudsonH[i] = 0.0;
        HudsonH2[i] = 0.0;
        }

    FORLIM = howlong;
    for (spot = 1; spot <= FORLIM; spot++)
        {
        IncludeBase = _true;
        if (options[DROPSITE - GROUPS])
            {
            k = 1;
            while (k <= numdrop && spot != droplist[k - 1]) k++;
            IncludeBase = (k > numdrop);
            }    
        if (IncludeBase&&options[LIMITSITE - GROUPS])
            {
            k = 1;
            while (k <= numkeep && spot != keeplist[k - 1]) k++;
            IncludeBase = (k <= numkeep);
            }      
        if (IncludeBase&&skipindel)
            {
            k=1;
            while (k <= numindeldrop && spot !=indeldroplist[k-1]) k++;
            IncludeBase = (k > numindeldrop);
            }
        if (IncludeBase&&skipmultibase)
            {
            k=1;
            while (k <= nummultibasedrop && spot !=multibasedroplist[k-1]) k++;
            IncludeBase = (k > nummultibasedrop);
            }
        if (IncludeBase)
            {
            FORLIM1 = nums;
            for (i = 0; i < FORLIM1; i++)
                {
                FORLIM2 = nums;
                for (j = i; j < FORLIM2; j++)
                    {
                    chi = popchar(i + 1, spot);
                    chj = popchar2(j + 1, spot);
             /*save time by using two different popchar routines*/
                    if (chi != 'N' && chj != 'N' && chi != indelchar && chj != indelchar)
                        compbases[i][j]++;
                    }
                }
            }
        }

    FORLIM = nums;
    /*get the average number of bases compared between groups*/
    for (i = 1; i < FORLIM; i++)
        {
        FORLIM1 = nums;
        for (j = i + 1; j <= FORLIM1; j++)
            {
            groupi = findgroup(i);
            groupj = findgroup(j);
            groupcompbases[groupi][groupj] += compbases[i - 1][j - 1];
            if (groupi != groupj)
                groupcompbases[groupj][groupi] += compbases[i - 1][j - 1];
            }
        }
    FORLIM = numgroups;
    for (i = 0; i < FORLIM; i++)
        {
        FORLIM1 = numgroups;
        for (j = 0; j < FORLIM1; j++)
            {
            if (i + 1 == j + 1)
                {
                if (groupsize[i] > 1)
                    groupcompbases[i][j] /= groupsize[i] * (groupsize[i] - 1) / 2.0;
                else
                    groupcompbases[i][j] = compbases[i][j];
                }
            else
                groupcompbases[i][j] /= 1.0 * groupsize[i] * groupsize[j];
            }
        }

    FORLIM = scount;
    /*begin loop for considering each site, to count pairwise differences*/
    for (tcount = 0; tcount < FORLIM; tcount++)
        {
        Findnowsit(tcount + 1);
        if (nowsitefit(nowsite))
            {
            FORLIM1 = nums - 2;
            for (i = 0; i <= FORLIM1; i++)
                {
                FORLIM2 = nums;
                for (j = i + 1; j < FORLIM2; j++)
                     {
                     groupi = findgroup(i+1);
                     groupj = findgroup(j+1);
                     /*      chi := popchar(i,nowsite.seqn);
                           chj := popchar(j,nowsite.seqn);*/
                     /*      if (i=1) and (j=2) then
                             begin
                             i := 1;
                             end;*/
                     if (nowsite.p[i] == samechar)
                       chi = consensus[tcount];
                     else
                       chi = nowsite.p[i];
                     if (nowsite.p[j] == samechar)
                       chj = consensus[tcount];
                     else
                       chj = nowsite.p[j];
                     if (chi != 'N' && chj != 'N' && chi != indelchar &&
                         chj != indelchar && chi != chj)
                         {
                         compbases[j][i]++;
                         groupdiffs[groupi][groupj] = 1.0 + groupdiffs[groupi][groupj];
                         }
                    }
                  }
            }
        }
    FORLIM = numgroups;
    for (i = 0; i < FORLIM; i++)
        {
        FORLIM1 = numgroups;
        for (j = i; j < FORLIM1; j++)
            {
            if (i + 1 == j + 1)
                {
                if (groupsize[i] > 1)
                    groupdiffs[i][j] /= (groupsize[i] * (groupsize[i] - 1) / 2.0);
                } 
            else
                groupdiffs[i][j] /= (1.0 * groupsize[i] * groupsize[j]);
            }
        }
    if (numgroups > 1)
        {
        FORLIM = numgroups - 2;
        for (i = 0; i <= FORLIM; i++)
            {
            FORLIM1 = numgroups;
            for (j = i + 1; j < FORLIM1; j++)
              groupdiffs[j][i] = groupdiffs[i][j] - (groupdiffs[i][i] + groupdiffs[j][j]) / 2.0;
            }
        }

    /*For each group find the most distant group to use as an outgroup*/
    if (numgroups == 1)
        outgroup[0] = 0;
    else 
        {
        FORLIM = numgroups;
        for (i = 1; i <= FORLIM; i++)
            {
            tempd1 = 0.0;
            tempgroup = i;
            FORLIM1 = numgroups;
            for (j = 1; j <= FORLIM1; j++)
                {
                if (i != j)
                    {
                     if (i > j)
                       tempd2 = groupdiffs[i - 1][j - 1];
                     else
                       tempd2 = groupdiffs[j - 1][i - 1];
                    } 
                else
                    tempd2 = 0.0;
                if (tempd2 > tempd1)
                    {
                    tempd1 = tempd2;
                    tempgroup = j;
                    }
                }
            outgroup[i - 1] = tempgroup;
            }
        }

    FORLIM3 = numgroups;
    /*loop for considering each site for site frequency table and fixed diffs*/
    /* also counts and records sites that have 3 or 4 bases segregating within
     a group*/
    for (groupi = 0; groupi < FORLIM3; groupi++)
        {
        groups_multibase[groupi][0] = 0;
        singleton[groupi] = 0;
        singletonOG[groupi] = 0;
        totalpoly[groupi] = 0;
        }
    FORLIM = scount;
    for (tcount = 0; tcount < FORLIM; tcount++)
        {  /*L1*/
        Findnowsit(tcount + 1);
        if (nowsitefit(nowsite))
            {  /*L2*/
            FORLIM3 = numgroups;
            for (groupi = 0; groupi < FORLIM3; groupi++)
                {
                maxpoly = groupsize[groupi] / 2;
                for (basei = A; basei <= X; basei = (basetype)(basei + 1))
                    {
                    basecounti[basei] = 0;
                    baseline[basei] = 0;
                    }
                FORLIM1 = grouplimits[groupi][1];
                for (i = grouplimits[groupi][0] - 1; i < FORLIM1; i++)
                    {
                     if (nowsite.p[i] == samechar)
                        chi = consensus[tcount];
                     else
                        chi = nowsite.p[i];
                     switch (chi)
                         {
                         case 'A':
                           basecounti[A]++;
                           baseline[A] = i;
                           break;

                         case 'C':
                           basecounti[C]++;
                           baseline[C] = i;
                           break;

                         case 'G':
                           basecounti[G]++;
                           baseline[G] = i;
                           break;

                         case 'T':
                           basecounti[T]++;
                           baseline[T] = i;
                           break;

                         case '*':
                           basecounti[D]++;
                           baseline[D] = i;
                           break;

                         case '-':
                           basecounti[D]++;
                           baseline[D] = i;
                           break;
                         }
                    }
                /* grouplimits[outgroup[groupi]-1][0] is the first sequence in the group that is the outgroup for group i 
                - must substract 1 then to get the place in the array*/
                if (numgroups > 1) 
                    {
                    outchar = nowsite.p[grouplimits[outgroup[groupi] - 1][0] - 1];
                    if (outchar==samechar) outchar = consensus[tcount];
                    switch (outchar)
                        {
                        case 'A':
                        outbase = A;
                        break;

                        case 'C':
                        outbase = C;
                        break;

                        case 'G':
                        outbase = G;
                        break;

                        case 'T':
                        outbase = T;
                        break;

                        case '*':
                        outbase = D;
                        break;

                        case '-':
                        outbase = D;
                        break;
                        default: outbase = D;
                         break;
                    } 
                    } 
                else
                    outbase = D;
                thispoly = 0;
                ispoly = 0;
                fixed_o = 0;
                for (basei = A;basei <= T; basei = (basetype)(basei + 1))
                    {
                    if (basecounti[basei] > 0)
                        {
                        ispoly++;
                        checksharepoly[groupi][basei] = '1';
                        }
                    else
                       checksharepoly[groupi][basei] = '0';
                    }
                /* if a polymorphism, return the count of the rarest base as thispoly 
                For  counts, return the sum of counts for all bases not equal to the outgroup
                usually there will be just one derived base.  this count is thispoly_o*/
                thispoly_o = 0;
                if (ispoly > 1)
                    {
                    lobase = D;
                    for (i = maxpoly; i >= 1; i--)
                        {   /*1 to maxpoly*/
                        for (basei = A;basei <= T;basei = (basetype)(basei + 1))
                            {
                            if (basecounti[basei] == i)
                                {
		                        thispoly = basecounti[basei];
                                lobase = basei;
                                }
                            }
                        }
                    hibase = D;
                    for (basei = A;basei <= T;basei = (basetype)(basei + 1))
                        if (basecounti[basei] >= maxpoly)
                            {
                            hibase = basei;
                            }
                    /* if the root has a deletion or does not match any base in the group, then use the count of the rare base as the count */
                    if ((outbase == D)||(basecounti[outbase] == 0)) 
                        {
                        thispoly_o = thispoly;
                        inbase = D;
                        }
                    else for (basei = A;basei <= T;basei = (basetype)(basei + 1))
	                        if (outbase != basei && basecounti[basei]) 
                                {
                                thispoly_o = basecounti[basei];
                                inbase = basei;
                                }
                    }
                else 
                    /* get outgroup and ingroup sequence in case of apparent fixed difference */
                    if (outbase != D)
                        for (basei = A;basei <= T;basei = (basetype)(basei + 1))
	                        if (outbase != basei && basecounti[basei]) 
                                {
                                inbase = basei;
                                fixed_o = 1;
                                }

                /* Difficult issue of how best to count polymorphisms where there are more than three bases segregating
                earlier versions of sites tried to use the # of segregating bases (minus 1)  as the count.  But this is
                also tricky, and it is not always clear how to root.
                As of March 6 1999, counts of polymorphic sites, and singleton counts will be based entirely on the premise
                of one count per site.  Users who need to adjust their counts can by using the listing of sites w/ multiple
                polymorphisms. */

                if (analyses[REC - SIT] && ispoly > 1)
                    {
                    tempd1 = 1.0;
                    if (groupsize[groupi] - basecounti[D] > 0)
                        {
                        for (basei = A;
                        basei <= T;
                        basei = (basetype)(basei + 1))
                            {
                            TEMP = 1.0 * basecounti[basei] / (groupsize[groupi] - basecounti[D]);
                            tempd1 -= TEMP * TEMP;
                            }
                        }
                    HudsonH[groupi] += tempd1;
                    HudsonH2[groupi] += tempd1 * tempd1;
                    }

                if (thispoly > 0)
                    {
                    polysite[groupi]++;
                    polydist[SITESUM][groupi][thispoly - 1]++;
                    if (nowsite.s[SYN] && !(nowsite.s[SOR]))
                        {
                        polydist[SDIST][groupi][thispoly - 1]++;
                        if (analyses[PREF - (long)SIT] == _true)
                            {
                            if (lobase != D  && hibase != D)
                                {
                                i = baseline[lobase];
                                j = baseline[hibase];
                                dcodon[0] = nowsite.c[i][0];
                                dcodon[1] = nowsite.c[i][1];
                                dcodon[2] = nowsite.c[i][2];
                                acodon[0] = nowsite.c[j][0];
                                acodon[1] = nowsite.c[j][1];
                                acodon[2] = nowsite.c[j][2];
                                if(codon_table[dcodon[0]][dcodon[1]][dcodon[2]] == codon_table[acodon[0]][acodon[1]][acodon[2]])
                                    {
                                    if (codonPtable[dcodon[0]][dcodon[1]][dcodon[2]] == UNP && codonPtable[acodon[0]][acodon[1]][acodon[2]] == UNP)
                                        polydist[UPREF_UPREF][groupi][thispoly - 1]++;
                                    if (codonPtable[dcodon[0]][dcodon[1]][dcodon[2]] == UNP && codonPtable[acodon[0]][acodon[1]][acodon[2]] == P)
                                        polydist[PREF_UPREF][groupi][thispoly - 1]++;
                                    if (codonPtable[dcodon[0]][dcodon[1]][dcodon[2]] == P && codonPtable[acodon[0]][acodon[1]][acodon[2]] == UNP)
                                        polydist[UPREF_PREF][groupi][thispoly - 1]++;
                                    if (codonPtable[dcodon[0]][dcodon[1]][dcodon[2]] == P && codonPtable[acodon[0]][acodon[1]][acodon[2]] == P)
                                        polydist[PREF_PREF][groupi][thispoly - 1]++;
                                    }
                                }
                            }
                        }
                    if (nowsite.s[REP] && !(nowsite.s[SOR]))
                        {
                        polydist[RDIST][groupi][thispoly - 1]++;
                        }
                    if (nowsite.s[INT])
                        {
                        polydist[NCODE][groupi][thispoly - 1]++;
                        }
                    if (thispoly > maxpolyused) maxpolyused = thispoly;
                    }
                if (thispoly_o > 0)
                    {
                    polydist_o[SITESUM][groupi][thispoly_o - 1]++;
                    if (nowsite.s[SYN] && !(nowsite.s[SOR]))
                        {
                        polydist_o[SDIST][groupi][thispoly_o - 1]++;
                        if (analyses[PREF - (long)SIT] == _true)
                            {
                            if (inbase != D && outbase != D)
                                {
                                i = baseline[inbase];
                                j = grouplimits[outgroup[groupi] - 1][0]-1;
                                dcodon[0] = nowsite.c[i][0];
                                dcodon[1] = nowsite.c[i][1];
                                dcodon[2] = nowsite.c[i][2];
                                acodon[0] = nowsite.c[j][0];
                                acodon[1] = nowsite.c[j][1];
                                acodon[2] = nowsite.c[j][2];
                                if(codon_table[dcodon[0]][dcodon[1]][dcodon[2]] == codon_table[acodon[0]][acodon[1]][acodon[2]])
                                    {
                                    if (codonPtable[dcodon[0]][dcodon[1]][dcodon[2]] == UNP && codonPtable[acodon[0]][acodon[1]][acodon[2]] == UNP)
                                        polydist_o[UPREF_UPREF][groupi][thispoly_o - 1]++;
                                    if (codonPtable[dcodon[0]][dcodon[1]][dcodon[2]] == UNP && codonPtable[acodon[0]][acodon[1]][acodon[2]] == P)
                                        polydist_o[PREF_UPREF][groupi][thispoly_o - 1]++;
                                    if (codonPtable[dcodon[0]][dcodon[1]][dcodon[2]] == P && codonPtable[acodon[0]][acodon[1]][acodon[2]] == UNP)
                                        polydist_o[UPREF_PREF][groupi][thispoly_o - 1]++;
                                    if (codonPtable[dcodon[0]][dcodon[1]][dcodon[2]] == P && codonPtable[acodon[0]][acodon[1]][acodon[2]] == P)
                                        polydist_o[PREF_PREF][groupi][thispoly_o - 1]++;
                                    }
                                }
                            }
                        }
                    if (nowsite.s[REP] && !(nowsite.s[SOR]))
                        {
                        polydist_o[RDIST][groupi][thispoly_o - 1]++;
                        }
                    if (nowsite.s[INT])
                        {
                        polydist_o[NCODE][groupi][thispoly_o - 1]++;
                        }
                    if (thispoly_o > maxpolyused_o) maxpolyused_o = thispoly_o; 
                    }
                if (fixed_o)
                    {
                    polydist_o[SITESUM][groupi][groupsize[groupi]-1]++;
                    if (nowsite.s[SYN] && !(nowsite.s[SOR]))
                        {
                        polydist_o[SDIST][groupi][groupsize[groupi]-1]++;
                        if (analyses[PREF - (long)SIT] == _true)
                            {
                            if (inbase != D && outbase != D)
                                {
                                i = baseline[inbase];
                                j = grouplimits[outgroup[groupi] - 1][0]-1;
                                dcodon[0] = nowsite.c[i][0];
                                dcodon[1] = nowsite.c[i][1];
                                dcodon[2] = nowsite.c[i][2];
                                acodon[0] = nowsite.c[j][0];
                                acodon[1] = nowsite.c[j][1];
                                acodon[2] = nowsite.c[j][2];
                                if(codon_table[dcodon[0]][dcodon[1]][dcodon[2]] == codon_table[acodon[0]][acodon[1]][acodon[2]])
                                    {
                                    if (codonPtable[dcodon[0]][dcodon[1]][dcodon[2]] == UNP && codonPtable[acodon[0]][acodon[1]][acodon[2]] == UNP)
                                        polydist_o[UPREF_UPREF][groupi][groupsize[groupi]-1]++;
                                    if (codonPtable[dcodon[0]][dcodon[1]][dcodon[2]] == UNP && codonPtable[acodon[0]][acodon[1]][acodon[2]] == P)
                                        polydist_o[PREF_UPREF][groupi][groupsize[groupi]-1]++;
                                    if (codonPtable[dcodon[0]][dcodon[1]][dcodon[2]] == P && codonPtable[acodon[0]][acodon[1]][acodon[2]] == UNP)
                                        polydist_o[UPREF_PREF][groupi][groupsize[groupi]-1]++;
                                    if (codonPtable[dcodon[0]][dcodon[1]][dcodon[2]] == P && codonPtable[acodon[0]][acodon[1]][acodon[2]] == P)
                                        polydist_o[PREF_PREF][groupi][groupsize[groupi]-1]++;
                                    }
                                }
                            }
                        }
                    if (nowsite.s[REP] && !(nowsite.s[SOR]))
                        {
                        polydist_o[RDIST][groupi][groupsize[groupi]-1]++;
                        }
                    if (nowsite.s[INT])
                        {
                        polydist_o[NCODE][groupi][groupsize[groupi]-1]++;
                        }
                    }
                

                if (ispoly > 2)
                    {   /*count sites with  >2 base values*/
                    if ((ispoly == 3 && basecounti[D] == 0) || (ispoly == 4))
                        {
                        groups_multibase[groupi][0]++;
                        groups_multibase[groupi][groups_multibase[groupi][0]] = nowsite.seqn;
                        }
                    }
                }
            
            if (numgroups > 1)
                { /* L3 */
                FORLIM3 = numgroups - 2;
                  /*countup shared polymorphisms*/
                for (groupi = 0; groupi <= FORLIM3; groupi++) 
                for (groupj = groupi + 1; groupj < numgroups; groupj++) {
                 countsharedpoly = 0;
                 for (basei = A;
                      basei <= T;
                      basei = (basetype)(basei + 1)) {
                   if (checksharepoly[groupi][basei] == checksharepoly[groupj][basei] 
                      && checksharepoly[groupi][basei] == '1')
                     countsharedpoly++;
                 }
                 if (countsharedpoly >= 2){
                   sharepoly[groupi][groupj]++;
                   groups_sharedbase[groupi][groupj][sharepoly[groupi][groupj]] = nowsite.seqn;
                 }
                }
                /*fixed diffs and sharedpolydist*/
                FORLIM3 = numgroups - 2;
                for (groupi = 0; groupi <= FORLIM3; groupi++)
                    { /* L4 */
                    FORLIM4 = numgroups;
                    for (groupj = groupi + 1; groupj < FORLIM4; groupj++)
                        { /* L5 */
	                     for (basei = A;basei <= X; basei = (basetype)(basei + 1))
	                        basecounti[basei] = 0;
	                     for (basej = A;basej <= X;basej = (basetype)(basej + 1))
	                        basecountj[basej] = 0;
	                     FORLIM1 = grouplimits[groupi][1];
	                     for (i = grouplimits[groupi][0] - 1; i < FORLIM1; i++)
                            {
                            if (nowsite.p[i] == samechar)
                            chi = consensus[tcount];
                            else
                            chi = nowsite.p[i];
                            switch (chi)
                                {
                                case 'A':
                                basecounti[0]++;
                                break;

                                case 'C':
                                basecounti[C]++;
                                break;

                                case 'G':
                                basecounti[G]++;
                                break;

                                case 'T':
                                basecounti[T]++;
                                break;

                                case '*':
                                basecounti[D]++;
                                break;

                                case '-':
                                basecounti[D]++;
                                break;

                                case 'N':
                                basecounti[X]++;
                                break;
                                }
                            }
	                     FORLIM1 = grouplimits[groupj][1];
                         for (j = grouplimits[groupj][0] - 1; j < FORLIM1; j++)
                             {
	                           if (nowsite.p[j] == samechar)
		                         chj = consensus[tcount];
	                           else
		                         chj = nowsite.p[j];
	                           switch (chj)
                                   {
	                               case 'A':
		                             basecountj[0]++;
		                             break;

	                               case 'C':
		                             basecountj[C]++;
		                             break;

	                               case 'G':
		                             basecountj[G]++;
		                             break;

	                               case 'T':
		                             basecountj[T]++;
		                             break;

	                               case '*':
		                             basecountj[D]++;
		                             break;

	                               case '-':
		                             basecountj[D]++;
		                             break;

	                               case 'N':
		                             basecountj[X]++;
		                             break;
	                               }
                             }


	                     countfix = (basecounti[X] < groupsize[groupi]/* - 1 */&&
			                    basecountj[X] < groupsize[groupj]/* - 1 */&&
			                    basecounti[D] < groupsize[groupi]/* - 1*/ &&
			                    basecountj[D] < groupsize[groupj]/* - 1*/);
	                     if (countfix)
                            {
                            for (basei = A; basei <= T; basei = (basetype)(basei + 1))
                             countfix = (countfix &&
                               (basecounti[basei] == 0 ||
	                            basecountj[basei] == 0));
                            countfix = (countfix && (basecounti[D] == 0 ||
		                             basecountj[D] == 0));
                            }
	                     if (countfix)
                             {
	                         fixdiffs[groupi][groupj]++;
	                         groups_fixedbase[groupi][groupj][fixdiffs[groupi][groupj]] = nowsite.seqn;
                             }
                    #ifdef SHARE_POLY_DIST_OPTION
	                     if ((DoSharePolyDist)&&(numgroups > 1))
                             {
		                     /* do rooted */
	                         if(outgroup[groupi]==outgroup[groupj])
                                 {
                                 outchar = nowsite.p[grouplimits[outgroup[groupi] - 1][0] - 1];
		                         temp = 0;
		                         if (outchar==samechar) outchar = consensus[tcount];
		                         switch (outchar)
                                     {
		                             case 'A':
		                               outbase = A;
		                               break;

		                             case 'C':
		                               outbase = C;
		                               break;

		                             case 'G':
		                               outbase = G;
		                               break;

		                             case 'T':
		                               outbase = T;
		                               break;

		                             case '*':
		                               outbase = D;
		                               break;

		                             case '-':
		                               outbase = D;
		                               break;
		                             default: outbase = D;
			                             break;
		                             } 
		                         polyi = (basecounti[T] > 0) + (basecounti[G] > 0) + (basecounti[C] > 0) + (basecounti[A] > 0);
		                         polyj = (basecountj[T] > 0) + (basecountj[G] > 0) + (basecountj[C] > 0) + (basecountj[A] > 0);
		                         if (polyi==0) polyi = -1; else { if (polyi > 1) polyi = 1; else polyi = 0;}
		                         if (polyj==0) polyj = -1; else {if (polyj > 1) polyj = 1; else polyj = 0;}
		                         basej = A;
		                         for (basei =  C; basei <= T; basei = (basetype)(basei + 1)) if (basecounti[basej] < basecounti[basei]) basej = basei;
                                 /* placement in the matrix depends entirely on the state of the outgroup.  If a base does not equal the outgroup
		                         then it is derived, otherwise it is ancestral. Thus multibase polymorphic sites are lumped into two states. 
		                         Deletions and N's are not counted in either state */

		                         if (outbase != D && polyi >=0 && polyj >= 0)
                                     {
			                         derivedi = 0;
			                         derivedj = 0;
			                         for (basei = A; basei <= T; basei = (basetype)(basei + 1))
                                         {
				                         if (basei != outbase)
                                            {
					                        derivedi += basecounti[basei];
					                        derivedj += basecountj[basei];
				                            }
                                         }
			                         if(derivedi || derivedj)
                                         {
				                         if ((countfix || polyi ||polyj)&& 
					                         ((derivedi + basecounti[D] + basecounti[X]) == groupsize[groupi])&&
					                         ((derivedj + basecountj[D] + basecountj[X]) == groupsize[groupj]))
                                             {
					                         temp = 1;
					                         numquestionable_derivedbase[groupi][groupj]++;
					                         questionable_derivedbase[groupi][groupj][numquestionable_derivedbase[groupi][groupj]] = nowsite.seqn;
                                             } 
                                         else
                                             {
					                         if (((basecounti[basej]+basecounti[D] + basecounti[X]) == groupsize[groupi])&&
						                         ((basecountj[basej]+basecountj[D] + basecountj[X]) == groupsize[groupj]))
                                                 {
						                         temp = 1;
						                         numoutbaseisderived[groupi][groupj]++;
						                         outbaseisderived[groupi][groupj][numoutbaseisderived[groupi][groupj]] = nowsite.seqn;
                                                 }
                                             else
                                                 {
						                         derivedpolydist[groupi][groupj][derivedi][derivedj]++;
						                         numrt[groupi][groupj]++;
						                         rt[groupi][groupj][numrt[groupi][groupj]] = nowsite.seqn;
						                         }
                                             }
                                         }
                                     }
                                 }
	                       /* do folded distribution */
	                       if (groupsize[groupi] > 1 && groupsize[groupj] > 1)
                               {
		                       polyi = (basecounti[T] > 0) + (basecounti[G] > 0) + (basecounti[C] > 0) + (basecounti[A] > 0);
		                       polyj = (basecountj[T] > 0) + (basecountj[G] > 0) + (basecountj[C] > 0) + (basecountj[A] > 0);
		                       /* little routines to drop bases that cause 3 or 4 base polymorphisms */
		                       /* if groupi as 3 or four bases while the other has 2, drop those bases in groupi not found in the other
                                    do same for groupj
			                      if groupi is polymorphic for 3 or four bases while the other has only one base, drop the lowest frequency 
			                      bases that are not found in the other group so that the polymorphism comes down to just 2 bases.
			                      do same for groupj
			                    */
		                       if (polyi > 2 && polyj == 2)
			                       for (basei = A;basei <= T; basei++) 
				                       if (basecounti[basei] > 0  && basecountj[basei]== 0)
                                           {
					                       basecounti[X] += basecounti[basei];
					                       basecounti[basei] = 0;
					                       polyi--;
                                           }
		                       if (polyi == 2 && polyj > 2)
			                       for (basei = A;basei <= T; basei++) 
				                       if (basecountj[basei] > 0  && basecounti[basei]== 0)
                                           {
					                       basecountj[X] += basecountj[basei];
					                       basecountj[basei] = 0;
					                       polyj--;
					                       }
		                       if (polyi > 2 && polyj == 1)
                                   {
			                       basej=A;
			                       for (basei = C; basei <= T; basei++)
                                       {
				                       if (basecounti[basej]==0 && basecounti[basei]> 0 && basecountj[basei] ==0) basej = basei;
				                       else if (basecounti[basei] > 0 && basecounti[basej] > basecounti[basei] && basecountj[basei]==0) basej = basei;
				                       }
  			                       basecounti[X] += basecounti[basej];
			                       basecounti[basej] = 0;
			                       polyi--;
			                       }
		                       if (polyj > 2 && polyi == 1)
                                   {
			                       basej=A;
			                       for (basei = C; basei <= T; basei++)
                                       {
				                       if (basecountj[basej]==0 && basecountj[basei]> 0 && basecounti[basei] ==0) basej = basei;
				                       else if (basecountj[basei] > 0 && basecountj[basej] > basecountj[basei] && basecounti[basei]==0) basej = basei;
				                       }
  			                       basecountj[X] += basecountj[basej];
			                       basecountj[basej] = 0;
			                       polyj--;
			                       }
		                       if (polyi > 2 && polyj == 1)
                                   {
			                       basej=A;
			                       for (basei = C; basei <= T; basei++)
                                       {
				                       if (basecounti[basej]==0 && basecounti[basei]> 0 && basecountj[basei] ==0) basej = basei;
				                       else if (basecounti[basei] > 0 && basecounti[basej] > basecounti[basei] && basecountj[basei]==0) basej = basei;
				                       }
  			                       basecounti[X] += basecounti[basej];
			                       basecounti[basej] = 0;
			                       polyi--;
			                       }
		                       if (polyj > 2 && polyi == 1)
                                   {
			                       basej=A;
			                       for (basei = C; basei <= T; basei++)
                                       {
				                       if (basecountj[basej]==0 && basecountj[basei]> 0 && basecounti[basei] ==0) basej = basei;
				                       else if (basecountj[basei] > 0 && basecountj[basej] > basecountj[basei] && basecounti[basei]==0) basej = basei;
				                       }
  			                       basecountj[X] += basecountj[basej];
			                       basecountj[basej] = 0;
			                       polyj--;
			                       }
		                       /* if site is a fixed diff,  count in bottom right of matrix [groupsize[groupi]][groupsize[groupj]]++; */
		                       /* if site is only polymorphic in one species, then the polymorphic base not found in the other species
                               is the 'derived base' then add to the matrix at the cell with counts in both species for 'derived base'; */
		                       /* if site is polymorphic in both species, find the lowest frequency base in either species 'lobase'. 
		                       add to the matrix at the cell with counts in both species for 'lobase'*/

		                       if (countfix)
                                   {
			                       foldedpolydist[groupi][groupj][groupsize[groupi]][groupsize[groupj]]++;
			                       numft[groupi][groupj]++;
			                       ft[groupi][groupj][numft[groupi][groupj]] = nowsite.seqn;
			                       }
		                       else
                                   {
			                       if (polyi>1 && polyj==1)
                                       {
				                       basej=A;
				                       while (!(basecounti[basej]>0 && basecountj[basej]==0)) basej++;
				                       foldedpolydist[groupi][groupj][basecounti[basej]][basecountj[basej]]++;
				                       numft[groupi][groupj]++;
				                       ft[groupi][groupj][numft[groupi][groupj]] = nowsite.seqn;
				                       }
			                       if (polyi == 1 && polyj > 1)
                                       {
				                       basej=A;
				                       while (!(basecountj[basej]>0 && basecounti[basej]==0)) basej++;
				                       foldedpolydist[groupi][groupj][basecounti[basej]][basecountj[basej]]++;
				                       numft[groupi][groupj]++;
				                       ft[groupi][groupj][numft[groupi][groupj]] = nowsite.seqn;
				                        }
			                       if (polyi == 2 && polyj ==2)
                                       {
				                       lo1=A;lo2 = A; hi1 = A, hi2 = A;
				                       for (basei = C; basei <= T; basei++)
                                           {
					                       if (basecounti[lo1] == 0 && basecounti[basei] > 0) lo1 = basei;
					                       else if (basecounti[basei] > 0 && basecounti[lo1] > basecounti[basei]) lo1 = basei;
					                       if (basecountj[lo2] == 0 && basecountj[basei] > 0) lo2 = basei;
					                       else if (basecountj[basei] > 0 && basecountj[lo2] > basecountj[basei]) lo2 = basei;
					                       if (basecounti[hi1] < basecounti[basei]) hi1 = basei;
					                       if (basecountj[hi2] < basecountj[basei]) hi2 = basei;
                                           }
				                       clo1 = basecounti[lo1]; 
				                       clo2 = basecountj[lo2];
				                       if (clo1 <= clo2) foldedpolydist[groupi][groupj][basecounti[lo1]][basecountj[lo1]]++;
				                       else foldedpolydist[groupi][groupj][basecounti[lo2]][basecountj[lo2]]++;
				                       numft[groupi][groupj]++;
				                       ft[groupi][groupj][numft[groupi][groupj]] = nowsite.seqn;
				                        }

			                       }
		                       }

	                        }
                    #endif
                         }    /* L5 */
                    } /* L4 */
                } /* L3 */
            }  /*L2*/
        }  /*L1*/
    /*new section as of March 6,1999  sets counts that get used by TajimaD and Fu and Li stats to be identical to those
            generated in the site frequency tables*/
    for (groupi = 0; groupi < numgroups; groupi++)
        {
        totalpoly[groupi] = polysite[groupi];
        singleton[groupi] = polydist[SITESUM][groupi][0];
        singletonOG[groupi] = polydist_o[SITESUM][groupi][0];
        for (pdc = SITESUM; pdc <= UPREF_UPREF; pdc++)
            {
            for (i=1;i<=groupsize[groupi]-1;i++)
                sitefreqsum[groupi][pdc] += polydist[pdc][groupi][i-1];
            for (i=1;i<=groupsize[groupi]-1;i++)
                sitefreqsum_o[groupi][pdc] += polydist_o[pdc][groupi][i-1];
            }
        }
    DoDstats();
    }  /*Getdiffs*/

   

static void getgc(void)
    {
    unsigned int i, j, k;
    unsigned int  frame;
    unsigned int spot;
    char ch;
    unsigned int FORLIM, FORLIM1;

    FORLIM = nums;
    for (i = 0; i < FORLIM; i++)
        {
        for (j = 0; j <= 4; j++)
            {
            for (k = 0; k <= 1; k++)
                gcdata[i][j][k] = 0;
            }
        }
    FORLIM = howlong;
    for (spot = 1; spot <= FORLIM; spot++)
        {
        frame = FindPlace(spot);
        if (frame == 0)
            frame = 4;
        FORLIM1 = nums;
        for (i = 0; i < FORLIM1; i++)
            {
            ch = popchar(i + 1, spot);
            if (ch != 'N' && ch != indelchar)
                {
                gcdata[i][4][1]++;
                gcdata[i][frame - 1][1]++;
                if (ch == 'G' || ch == 'C')
                    {
                    gcdata[i][4][0]++;
                    gcdata[i][frame - 1][0]++;
                    }
                }
            }
        }
    }  /*getgc*/


static void Finish(void)
{
  static char SiteTypechar[FOU - INT + 1] = {'I', 'S', 'R', '?', 'D', 'F', 'N', 'V','3','4'};
  static char SiteTypeLabel[FOU - INT + 1][11] = {
    "Noncode   ", "Synonyms  ", "Replacmnt ", "Uncertain ", "Ins/Del   ",
    "Informtv  ", "Transitn  ", "Transvrsn ", "Threebases","Fourbases "  };
  static char pdclabel[UPREF_UPREF+1][5] = {"All ","NC  ","Rep ","Syn ","PP  ","PU  ","UP  ","UU  "};
  static char IDTypechar[INF - EXN + 1] = {'E', 'I', ' ', ' ', ' ', ' ', 'F'};

  static char IDtypeLabel[3][11] = {"Noncode   ", "Exon      ", "Informtv  "};

  static basetype printhelp[4] = { A, G, C, T  };

  static unsigned short typecounts[FOU - INT + 1] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

  unsigned int linecount, i, ii,j,jj, k, l, pcount, tcount, tempcount;
  char temps[81];
  char hkas[120];
  linetype nowline;
  /*cla = consenslineadjust, pln = positionlinesnumber, iln = infolinesnumber*/
  unsigned int  cla, pln, iln;
  basetype b1, b2, b3, bt;
  char temps4[5];
  SITETYPE sitetypecase;
  char ch;
  unsigned short  groupi, groupj;
  unsigned int temp;
  double within, between, tempd;
  unsigned short  lcount1, lcount2, lcount3, lstep;
  unsigned int FORLIM, FORLIM1;
  long anyfixed, anyshared;
  int /*unsigned short*/  polygroup;
  float passdata[4],passparams[4],passexpected[4];
  boolean fitquality;
  char *TEMP2;
  polydistclass  pdc, lastpdc;
  
  strcpy(rfile_NAME, rname);
  if (rfile != NULL){
     if ((rfile = freopen(rfile_NAME, "w", rfile)) == NULL){
        printf("\nError opening text file for writing \n"); exit(0);}
}
  else{
    if ((rfile = fopen(rfile_NAME, "w")) == NULL){
        printf("\nError opening text file for writing \n"); exit(0);}
}                                              
  FP"**SITES**     -- DNA POLYMORPHISM ANALYSIS PROGRAM OUTPUT -- \n");
  FP"   - program written by Jody Hey, code last modified 6/26/02 \n");
  FP "%s\n%s\n\n",dashline,starline);
  FP "INPUT FILE : %s   OUTPUT TO THIS FILE: %s\n\n",
     sname, rname);
  FP "%s\n%s\n\n",dashline,starline);
  FP"SUMMARY OF RUNTIME PARAMETERS AND DATA SET CONFIGURATION\n");
  FP"--------------------------------------------------------\n");
  FP"\nCOMMAND LINE PARAMETER STRING: %s \n",command_line);
  if (indata == PHYLIPin)
    FP "\nINPUT FILE IN PHYLIP FORMAT\n");
  else {
    FP "\nCOMMENT LINES FROM SOURCE FILE:\n");
    FP "%s\n", sheader);
    for (i=0;i< num_extra_comments;i++){
       FP"  %s\n",extracomments[i]);
     }
    FP"\n");
  }
  if (INTLV)
    FP "INPUT FILE INTERLEAVED\n");
  putc('\n', rfile);
  if (*message != '\0') {
    FP "COMMENT ADDED AT RUNTIME :\n");
    FP "%s\n\n", message);
  }
  FP "RUN PARAMETERS \n");
  FP "--- ---------- \n");
  FP "    SITES INCLUSION STRING      : %s\n", sitetypelist);
  FP "    ANALYSIS STRING             : %s\n", outputlist);
  FP "    DATA AND OUPUT OPTION STRING: %s\n", optionlist);
  if (analyses[LD - SIT])
  FP "    LD STRING              : %s\n", linkageoptionlist);
  if (JHoption) {
	  FP"    JHoption specified at runtime \n");
	  FP"    JH OPTION STRING       : %s\n",jhoptionlist);
  }
  if (numyescode + numnocode > 0) if (options[ALTCODE]) FP"\nALTERNATE GENETIC CODE : %s\n",altcodestr);
  if (doLDmatrix) FP"\nLINKAGE DISEQUILIBRIUM MATRIX OUTPUT FILE NAME : %s\n",LDmatrixfile_NAME);
  if (skipindel)
      {
	  FP "\n***POSITIONS WITHIN INDELS WERE EXCLUDED*** \n");
	  strcpy(temps,"Positions excluded : ");
	  for (j = 0; j < numindeldrop; j++)
          {
	      if (strlen(temps) < 70)
              {
	          sprintf(temps + strlen(temps), "%u  ", indeldroplist[j]);
		      }
          else
              {
		      FP "%s\n", temps);
		      sprintf(temps, "%u  ", indeldroplist[j]);
              }
          }
      FP "%s\n", temps);
      FP "NUMBER OF POSITIONS EXCLUDED : %u\n\n",numindeldrop);
      }
  if (skipmultibase)
      {
	  FP "\n***POSITIONS WITH MORE THAN TWO BASE VALUES EXCLUDED*** \n");
	  strcpy(temps,"Positions excluded : ");
	  for (j = 0; j < nummultibasedrop; j++)
          {
	      if (strlen(temps) < 70)
              {
	          sprintf(temps + strlen(temps), "%u  ", multibasedroplist[j]);
		      }
          else
              {
		      FP "%s\n", temps);
		      sprintf(temps, "%u  ", multibasedroplist[j]);
              }
          }
      FP "%s\n", temps);
      FP "NUMBER OF POSITIONS EXCLUDED : %u\n\n",nummultibasedrop);
      }
  if (options[DROPSITE - GROUPS]) {
    FP "\n***SOME POSITIONS WERE DROPPED*** \n");
    if (isdropfile)FP "Positions dropped listed in file : %s\n", dropname);
    if (isdroprange) FP "Positions dropped in inclusive range : %5u - %5u\n",rangebegin, rangend);
    if (!isdroprange) {
    strcpy(temps,"Positions dropped  : ");
    for (j = 0; j < numdrop; j++) {
		if (strlen(temps) < 70) { sprintf(temps + strlen(temps), "%u  ", droplist[j]);
		} else {
		FP "%s\n", temps);
		sprintf(temps, "%u  ", droplist[j]);
		}
      }
    FP "%s\n", temps);
    }

   FP "Number of positions dropped : %u\n\n", numdrop);
  }
  if (options[LIMITSITE - GROUPS]) {
    FP "\n***ANALYSIS LIMITED TO A SUBSET OF POSITIONS***\n");
    if (iskeepfile)
      FP "Limited to positions listed in file : %s\n", keepname);
    if (iskeeprange)
      FP "Positions limited to inclusive range : %5u - %5u\n",rangebegin, rangend);
    if (!iskeeprange) {
   strcpy(temps,"Limited to positions : ");
   for (j = 0; j < numkeep; j++) {
   if (strlen(temps) < 70) {
    sprintf(temps + strlen(temps), "%u  ", keeplist[j]);
   } else {
     FP "%s\n", temps);
     sprintf(temps, "%u  ", keeplist[j]);
   }
      }
      FP "%s\n", temps);
    }
    FP "Number of positions included : %u\n\n", numkeep);
  }
  putc('\n', rfile);

  if (numseqdrop > 0){
    FP "***SOME INPUT SEQUENCES WERE EXCLUDED*** \n");
    if (isseqdropfile)
      FP "Sequences dropped listed in file : %s\n", seqdropname);
    if (isseqdroprange)
      FP "Sequences dropped in inclusive range : %5u - %5u\n",
         seqrangebegin, seqrangend);
    if (!isseqdroprange) {
   strcpy(temps,"Sequences dropped : ");
   for (j = 0; j < numseqdrop; j++) {
   if (strlen(temps) < 70) {
    sprintf(temps + strlen(temps), "%u  ", seqdroplist[j]+1);
   } else {
     FP "%s\n", temps);
     sprintf(temps, "%u  ", seqdroplist[j]);
   }
      }
      FP "%s\n", temps);
      }
    FP "Number of sequences dropped : %u\n\n", numseqdrop);
  }
  else   FP "ALL INPUT SEQUENCES INCLUDED \n");
  
  FP "\nNUMBER OF SEQUENCES : %d   LENGTH OF SEQUENCES : %u\n",nums, howlong);
  if (options[0]) {
    FP "\nGROUP NAMES AND SEQUENCE NAMES\n");
    FP "----- ----- --- -------- -----\n");
    FORLIM = numgroups;
    for (i = 0; i < FORLIM; i++) {
      FP "\n%s\n", groupnames[i]);
      for(j=1;j< MaxGroupNameLength;j++) FP "-");
      FP"\n");
      *temps = '\0';
      FORLIM1 = grouplimits[i][1];
      for (j = grouplimits[i][0] - 1; j < FORLIM1; j++) {
   if (strlen(temps) < 70) {
/*    if (whichlines[j])*/ sprintf(temps + strlen(temps), "%s  ", names[j]);
   } else {
     FP "%s\n", temps);
     sprintf(temps, "%s  ", names[j]);
   }
      }
      FP "%s\n", temps);
    }
    putc('\n', rfile);
  }
  tempcount = 0;
  FP "CODING AND NONCODING PARTITIONS\n");
  FP "------ --- --------- ----------\n");
  FP "  NUMBER OF NONCODING INTERVALS : %d\n", numnoncods);
  FORLIM = numnoncods;
  for (i = 0; i < FORLIM; i++) {
    FP "    NONCODING SEQUENCE # %u  FROM : %u  TO : %u\n",i + 1, noncods[i].p5, noncods[i].p3);
    tempcount += noncods[i].p3 - noncods[i].p5 + 1;
  }
  FP "   APPROXIMATE TOTAL NONCODING LENGTH : %u\n", tempcount);
  FP "   APPROXIMATE TOTAL CODING LENGTH    : %d\n\n", howlong - tempcount);
  if (howlong-tempcount > 0) FP"   CODON FRAME POSITION OF FIRST CODING BASE  : %d\n",oframe);
	  else FP"\n");
  if (analyses[0]) {
    if (screenupdate) printf("Generating Site Table\n");
    FP "%s\n%s\n\n",dashline,starline);
    FP "TABLE OF POLYMORPHIC SITES\n");
    FP "--------------------------\n");
	pln = 5;  /*1 + (int) log10(howlong); */
	iln = /*9 */ 10;
    if (options[FIRSTREF - GROUPS])
      cla = 0;
    else
      cla = 1;
    pcount = 1;
    while (pcount <= scount) {
      linecount = 0;
      while (linecount <= nums + cla + pln + iln - 1) {
         linecount++;
		 if (linecount <= pln) nowline = PSN;
		 if (linecount == pln + 1){
			nowline = POL;
			sitetypecase = INT;
		 }
		 if ((linecount > pln+1)&&(linecount <= pln+iln)){
			nowline = POL;
			sitetypecase = sitetypecase + 1;
		 }
		 if (linecount == pln+iln + 1) {
			 if (!options[FIRSTREF - GROUPS]) nowline = CONS; else nowline = DAT;
		 }
		 if (linecount > pln+iln+1) nowline = DAT;
   switch (nowline) {
   case PSN:
     strcpy(temps, "position  ");
     break;
   case POL:
     strcpy(temps, SiteTypeLabel[sitetypecase - INT]);
     break;
   case CONS:
     strcpy(temps, "Consensus ");
     break;
   case DAT:
     strcpy(temps, names[linecount - cla - (pln+iln+1)]);
     break;
   }
   tcount = pcount;
   Findnowsit(tcount);
   k = 0;
   while (k < 6 && tcount <= scount) {
     k++;
     l = 0;
     strcat(temps, " ");
     while (l < 10 && tcount <= scount) {
       if (!nowsitefit(nowsite)) 
		   {
		   tcount++;
		   if (tcount <= scount) 
			   Findnowsit(tcount);
           continue;
		   }
       l++;
       switch (nowline) {
       case PSN:
         sprintf(temps + strlen(temps), "%c", nowsite.t[linecount - 1]);
         break;

       case POL:
         if (nowsite.s[sitetypecase - EXN]) {
      sprintf(temps + strlen(temps), "%c", SiteTypechar[sitetypecase - INT]);
         } else if (options[SITSTYLE - GROUPS]) {
      strcat(temps, "=");
         } else {
      strcat(temps, "=");
         }
         break;

       case CONS:
         sprintf(temps + strlen(temps), "%c", consensus[tcount - 1]);
         break;

       case DAT:
         sprintf(temps + strlen(temps), "%c", nowsite.p[linecount - cla - (pln + iln +1)]);
         break;
       }
       tcount++;
       if (tcount <= scount)
         Findnowsit(tcount);
     }
   }
   if (*temps != '\0')
     FP "%s\n", temps);
      }
      pcount = tcount;
      putc('\n', rfile);
    }
    FORLIM = scount;
    for (tcount = 1; tcount <= FORLIM; tcount++) 
		{
		Findnowsit(tcount);
		if (nowsitefit(nowsite)) 
			  {
		  for (sitetypecase = INT; sitetypecase <= FOU; sitetypecase = (SITETYPE)(sitetypecase + 1))
			  {
			  if (nowsite.s[sitetypecase - EXN])
				  typecounts[sitetypecase - INT]++;
			  }
			}
		}
    FP "%s\n%s\n\n",dashline,starline);
    FP "COUNTS OF SITE TYPES IN TABLE\n");
    FP "-----------------------------\n");
    for (sitetypecase = INT;
    sitetypecase <= FOU;
    sitetypecase = (SITETYPE)(sitetypecase + 1))
      FP "%s  %3u\n",SiteTypeLabel[sitetypecase - INT],typecounts[sitetypecase - INT]);
  }
  putc('\n', rfile);
  if (whatsites[DEL - EXN] && analyses[INDELS - SIT]) {
    FP "%s\n%s\n\n",dashline,starline);
    FP "INDEL TABLES\n");
    FP "------------\n\n");
    FP "TABLE OF POLYMORPHIC INSERTIONS AND DELETIONS\n");
    FP "----- -- ----------- ---------- --- ---------\n");
  }
  if (whatsites[DEL - EXN] &&
      analyses[INDELS - SIT])  {
	pln = 5; /*1 + (int) log10(howlong); */
	iln = 3;
    if (options[FIRSTREF - GROUPS])
      cla = 0;
    else
      cla = 1;
    pcount = 1;
    while (pcount <= idcount) {
      linecount = 0;
      while (linecount <= nums + cla + pln + iln - 1) {
         linecount++;
		 if (linecount <= pln) nowline = PSN;
		 if (linecount == pln + 1){
			nowline = POL;
			sitetypecase = INT;
		 }
		 if (linecount == pln + 2){
			nowline = POL;
			sitetypecase = EXN;
		 }
		 if (linecount == pln + 3){
			nowline = POL;
			sitetypecase = INF;
		 }
		 if (linecount == pln+iln + 1) {
			 if (!options[FIRSTREF - GROUPS]) nowline = CONS; else nowline = DAT;
		 }
		 if (linecount > pln+iln+1) nowline = DAT;

   switch (nowline) {

   case PSN:
     strcpy(temps, "position  ");
     break;

   case POL:
     strcpy(temps, IDtypeLabel[linecount - (pln+1)]);
     break;

   case CONS:
     strcpy(temps, "Consensus ");
     break;

   case DAT:
     strcpy(temps, names[linecount - cla - (pln + iln +1)]);
     break;
   }
   tcount = pcount;
   FindnowIDsit(tcount);
   k = 0;
   while (k < 6 && tcount <= idcount) {
     k++;
     l = 0;
     strcat(temps, " ");
     while (l < 10 && tcount <= idcount) {
       if (!nowIDsitfit()) {
         tcount++;
         if (tcount <= idcount)
      FindnowIDsit(tcount);
         continue;
       }
       l++;
       switch (nowline) {

       case PSN:
         sprintf(temps + strlen(temps), "%c", nowIDsit.t[linecount - 1]);
         break;

       case POL:
         if (nowIDsit.s[sitetypecase - EXN]) {
      sprintf(temps + strlen(temps), "%c",IDTypechar[sitetypecase - EXN]);
         } else if (options[SITSTYLE - GROUPS]) {
      strcat(temps, "=");
         } else {
      strcat(temps, "=");
         }
         break;

       case CONS:
         sprintf(temps + strlen(temps), "%c", IDconsensus[tcount - 1]);
         break;

       case DAT:
         sprintf(temps + strlen(temps), "%c",nowIDsit.p[linecount - cla - (pln + iln +1)]);
         break;
       }
       tcount++;
       if (tcount <= idcount)
         FindnowIDsit(tcount);
     }
   }
   if (*temps != '\0')
     FP "%s\n", temps);
      }
      pcount = tcount;
      putc('\n', rfile);
    }
    FP "NUMBER OF DISTINCT INDELS : %u\n\n", idcount);
    FP "TABLE OF INDEL POSITIONS AND LENGTHS \n");
    FP "----- -- ----- --------- --- ------- \n");
    FP "INDEL #  FIRST BASE LENGTH INS LINE   INS SEQUENCE\n");
    FP "-------  ---------- ------ --------   ------------------------------------\n");
    FORLIM = idcount;
    for (i = 1; i <= FORLIM; i++) {
      FindnowIDsit(i);
      FP "  %3u        %5u     %3u",i, nowIDsit.seqn, indellengths[i - 1]);
      j = 0;
      do {
   j++;
      } while (!(nowIDsit.p[j - 1] == 'I' ||
       (nowIDsit.p[j - 1] == samechar &&
        !options[FIRSTREF - GROUPS] &&
        IDconsensus[i - 1] == 'I')));
      FP " %s ", names[j - 1]);
      FORLIM1 = nowIDsit.seqn + indellengths[i - 1];
      for (k = nowIDsit.seqn; k < FORLIM1; k++) {
   ch = popchar(j, k);
   putc(ch, rfile);
      }
      putc('\n', rfile);
    }
  }
  putc('\n', rfile);
  if (analyses[PEC - SIT]) {
    if (screenupdate) printf("Generating List of Exon Changes\n");
    if (whatsites[REP - EXN] || whatsites[SYN - EXN]) {
      site_info_last = site_info_first;
      if (site_info_last != NULL) {
   FP "%s\n%s\n\n",dashline,starline);
   FP"TABLE OF SYNONYMOUS, REPLACEMENT AND UNCERTAIN EXON CHANGES\n");
   FP"-----------------------------------------------------------\n");
      }
   if (numyescode + numnocode > 0) if (options[ALTCODE]) FP"   Alternate Genetic Code : %s\n",altcodestr);
  tempcount = 1;
  if (nowsite_ptr)  Findnowsit(tempcount);
  while (site_info_last != NULL) {
   tcount = site_info_last->num;
   while (nowsite.seqn != tcount) {
     tempcount++;
     Findnowsit(tempcount);
   }
   if (nowsitefit(nowsite)) FP "%s\n", site_info_last->TEXT);
   site_info_last = site_info_last->next;
      }
    }
    putc('\n', rfile);
  }
  if (analyses[COD - SIT]) {
    if (screenupdate) printf("Generating Codon Usage Information\n");
    synone = 0.0;
    synall = 0.0;
    repone = 0.0;
    repall = 0.0;
    temp = 0;
	for (b1 = A; b1 <= T; b1 = (basetype)(b1 + 1))
		for (b2 = A; b2 <= T; b2 = (basetype)(b2 + 1))
			for (b3 = A; b3 <= T; b3 = (basetype)(b3 + 1)){
				for (bt = A, temp = 0; bt <= T; bt = (basetype)(bt + 1)) 
					if (bt != b1) temp += (codon_table[b1][b2][b3]== codon_table[bt][b2][b3]);
				synone += temp * codonsone[b1][b2][b3] /3.0;
                synall += temp * codonsall[b1][b2][b3] /3.0;
				repone += (3-temp) * codonsone[b1][b2][b3] /3.0;
				repall += (3-temp) * codonsall[b1][b2][b3] /3.0;
				for (bt = A, temp = 0; bt <= T; bt = (basetype)(bt + 1)) 
					if (bt != b2) temp += codon_table[b1][b2][b3]== codon_table[b1][bt][b3];
				synone += temp * codonsone[b1][b2][b3] /3.0;
                synall += temp * codonsall[b1][b2][b3] /3.0;
				repone += (3-temp) * codonsone[b1][b2][b3] /3.0;
				repall += (3-temp) * codonsall[b1][b2][b3] /3.0;
				for (bt = A, temp = 0; bt <= T; bt = (basetype)(bt + 1)) 
					if (bt != b3) temp += codon_table[b1][b2][b3]== codon_table[b1][b2][bt];
				synone += temp * codonsone[b1][b2][b3] /3.0;
                synall += temp * codonsall[b1][b2][b3] /3.0;
				repone += (3-temp) * codonsone[b1][b2][b3] /3.0;
				repall += (3-temp) * codonsall[b1][b2][b3] /3.0;
			}
					

    if (numyescode + numnocode > 0) {
      FP "%s\n%s\n\n",dashline,starline);
      FP "CODON USAGE TABLE for %s\n", names[0]);
      FP "-------------------------------\n");
      for (b1 = A; b1 <= T; b1 = (basetype)(b1 + 1)) {
	   for (i = 0; i <= 3; i++) {
		 for (b2 = A; b2 <= T; b2 = (basetype)(b2 + 1)) {
		   sprintf(temps4, "%4u",
			  codonsone[b1][b2][printhelp[i]]);
		   FP "%s%s|",
			  codonstr[b1][b2][printhelp[i]], temps4);
		 }
		 putc('\n', rfile);
	   }
	   FP "---------------------------------------------------\n");
      }
      FP "NUMBER OF KNOWN CODONS: %3u\n", numyescode);
      FP"NUMBER OF UNKNOWN CODONS (including 3 base deletion sites): %3u\n",numnocode);
      FP"NUMBER OF SYN. SITES : %6.2f  REPLACEMENT SITES : %6.2f\n",synone, repone);
	  if (options[ALTCODE]) FP"Alternate Genetic Code : %s\n",altcodestr);
	  FP"\n");
      FP "CODON USAGE TABLE FOR ALL LINES\n");
      FP "----- ----- ----- --- --- -----\n");
      for (b1 = A; b1 <= T; b1 = (basetype)(b1 + 1)) {
	   for (i = 0; i <= 3; i++) {
		 for (b2 = A; b2 <= T; b2 = (basetype)(b2 + 1)) {
		   sprintf(temps4, "%4u",codonsall[b1][b2][printhelp[i]]);
		   FP "%s%s|", codonstr[b1][b2][printhelp[i]], temps4);
		 }
		 putc('\n', rfile);
	   }
      FP   "---------------------------------------------------\n");
      }
    }
    FP"AVERAGE NUMBER OF SYN. SITES : %6.2f  REPLACEMENT SITES : %6.2f\n",synall / nums, repall / nums);
	if (options[ALTCODE]) FP"Alternate Genetic Code : %s\n",altcodestr);
    FP"\n");
  }
   if ((analyses[DIF - SIT])|| 
       (analyses[POPMOD - SIT])||
       (analyses[REC - SIT])){
     if (screenupdate) printf("Assessing variation  - could take awhile...\n");
     fillfact();
     GetDiffs();
   }
  if (analyses[DIF - SIT]) {
    FP "%s\n%s\n\n",dashline,starline);
    FP "POLYMORPHISM ANALYSES\n");
    FP "---------------------\n\n");
	if (!options[SUPPAIR - GROUPS])
        {
		FP "BASE PAIR COMPARISONS - not including N's or indels\n");
		FP "---- ---- -----------\n");
		FP "    - above and on the diagnonal: number of bases compared\n");
		FP "    - below the diagonal: number of base differences\n");
		lcount1 = 0;
		lcount2 = 0;
		lcount3 = 0;
		lstep = stepspace;
		do  {
			lcount1 = lcount3 + 1;
			FP "               ");
			while (lcount1 <= lstep && lcount1 <= nums)
                {
		        groupj = findgroup(lcount1);
		        if (lcount1 == grouplimits[groupj][0])
			        FP "|  %3d ", lcount1);
		        else
			    FP "  %3d ", lcount1);
		        lcount1++;
			    }
			putc('\n', rfile);
			FORLIM = nums;
			for (i = 1; i <= FORLIM; i++)
                {
		        groupi = findgroup(i);
		        if (i == grouplimits[groupi][0])
                    {
			        FP "                 ");
			        for (j = 1; j <= stepspace; j++)
			            FP "------");
			        putc('\n', rfile);
		            }
		        FP "%3u:%s ", i, names[i - 1]);
		        lcount2 = lcount3 + 1;
		        while (lcount2 <= lstep && lcount2 <= nums)
                    {
			        groupj = findgroup(lcount2);
			        if (lcount2 == grouplimits[groupj][0])
			            FP "| %5u", compbases[i - 1][lcount2 - 1]);
			        else
			            FP " %5u", compbases[i - 1][lcount2 - 1]);
			        lcount2++;
		            }
		        putc('\n', rfile);
			    }
            putc('\n', rfile);
			lcount3 = lcount2 - 1;
			lstep += stepspace;
			} while (lcount3 != nums);
		FP "\nGROUP DIFFERENCES - not including N's or indels\n");
		FP "----- -----------\n");
		FP "  - above and on the diagonal: average pairwise differences\n");
		FP "  - below the diagonal: net average pairwise divergence\n");
		for (j=1; j < MaxGroupNameLength+6;j++) FP" ");
		FORLIM = numgroups;
		for (i = 1; i <= FORLIM; i++)
		  FP "     %2u   ", i);
		putc('\n', rfile);
		FORLIM = numgroups;
		for (i = 1; i <= FORLIM; i++)
            {
			for (j=1; j < MaxGroupNameLength+7;j++) FP" ");
			FORLIM1 = numgroups;
			for (j = 1; j <= FORLIM1; j++)
                {
		        if (j == i || j == i - 1)
			        FP "----------");
		        else
			        FP "          ");
			    }
			FP "\n%2u: %s  ", i, groupnames[i - 1]);
			FORLIM1 = numgroups;
			for (j = 1; j <= FORLIM1; j++)
                {
		        if (j == i || j == i + 1)
			        FP "| % 7.2f ", groupdiffs[i - 1][j - 1]);
		        else
			        FP "  % 7.2f ", groupdiffs[i - 1][j - 1]);
			    }
			    putc('\n', rfile);
			}
	    } /* base pair comparisons section */

    FP "\nGROUP DIFFERENCES PER BASE PAIR - not including N's or indels\n");
    FP "----- ----------- --- ---- ----\n");
    FP "  - above and on the diagonal: average pairwise differences\n");
    FP "  - below the diagonal: net average pairwise divergence\n");
    for (j=1; j < MaxGroupNameLength+6;j++) FP" ");
    FORLIM = numgroups;
    for (i = 1; i <= FORLIM; i++)
      FP "     %2u    ", i);
    putc('\n', rfile);
    FORLIM = numgroups;
    for (i = 1; i <= FORLIM; i++)
        {
        for (j=1; j < MaxGroupNameLength+7;j++) FP" ");
        FORLIM1 = numgroups;
        for (j = 1; j <= FORLIM1; j++)
            {
            if (j == i || j == i - 1)
                FP "-----------");
            else
                FP "           ");
            }
        FP "\n%2u: %s  ", i, groupnames[i - 1]);
        FORLIM1 = numgroups;
        for (j = 1; j <= FORLIM1; j++)
            {
            if (j == i || j == i + 1)
                FP "| % 7.5f ",groupdiffs[i - 1][j - 1] / groupcompbases[i - 1][j - 1]);
            else
                FP "  % 7.5f ", groupdiffs[i - 1][j - 1] / groupcompbases[i - 1][j - 1]);
            }
        putc('\n', rfile);
        }
    FP "\n\n");
   /* code for multiple groups polymorphism analyses */
    if (numgroups > 1)
        {
        anyfixed=0;
        anyshared=0;
        FP "FIXED DIFFERENCES - not including N's or indels\n");
        FP "----- ----------- \n");
        for (j=1; j < MaxGroupNameLength+5;j++) FP" ");
        FORLIM = numgroups;
        for (i = 1; i <= FORLIM; i++)
          FP "  %2u  ", i);
        FP "\n");
        for (j=1; j < MaxGroupNameLength+7;j++) FP" ");
        FORLIM = numgroups;
        for (i = 1; i <= FORLIM; i++)
            FP "------");
        putc('\n', rfile);
        FORLIM = numgroups;
        for (i = 1; i <= FORLIM; i++)
            {
            FP "%2u: %s ", i, groupnames[i - 1]);
            FORLIM1 = numgroups;
            for (j = 1; j <= FORLIM1; j++)
                {
                if (j > i)
                    {
                    FP "%4ld  ", fixdiffs[i - 1][j - 1]);
                    anyfixed += fixdiffs[i-1][j-1];
                    }
                else
                    FP "   -  ");
                }
            putc('\n', rfile);
            }
        if (anyfixed)
            {
            FP "\nSITES OF FIXED DIFFERENCES - not including N's or indels\n");
            FP " group1       group2 \n");
            for (i = 0; i < numgroups - 1; i++) 
            for (ii=i+1; ii< numgroups;ii++)
            if (fixdiffs[i][ii] > 0)
                {
                FP "-------------------------------- \n");
                FP "%s %s %2u: ", groupnames[i],groupnames[ii],fixdiffs[i][ii]);
                polygroup = fixdiffs[i][ii] / 8;
                if (fixdiffs[i][ii] % 8 > 0) polygroup++;
                if (polygroup == 0) putc('\n', rfile);
                FORLIM1 = polygroup;
                for (k = 1; k <= FORLIM1; k++)
                    {
                    j = (k - 1) * 8 + 1;
                    while (j <= k * 8 && j <= fixdiffs[i][ii])
                        {
                        FP "%6u", groups_fixedbase[i][ii][j]);
                        j++;
                        }
                    putc('\n', rfile);
                    if (k < polygroup) 
                    for (j=1; j < 2*MaxGroupNameLength+7;j++) FP" ");
                    }
                FP "-------------------------------- \n");
                }
            }
        FP"\n\nSHARED POLYMORPHISMS - not including N's or indels\n");
        FP "------ ------------- \n");
        for (j=1; j < MaxGroupNameLength+5;j++) FP" ");
        FORLIM = numgroups;
        for (i = 1; i <= FORLIM; i++)  FP "  %2u  ", i);
        FP "\n");
        for (j=1; j < MaxGroupNameLength+7;j++) FP" ");
        FORLIM = numgroups;
        for (i = 1; i <= FORLIM; i++)  FP "------");
        putc('\n', rfile);
        FORLIM = numgroups;
        for (i = 1; i <= FORLIM; i++)
            {
            FP "%2u: %s ", i, groupnames[i - 1]);
            FORLIM1 = numgroups;
            for (j = 1; j <= FORLIM1; j++)
                {
                if (j > i)
                    {
                    FP "%4u  ", sharepoly[i - 1][j - 1]);
                    anyshared += sharepoly[i - 1][j - 1];
                    }
                else
                    FP "   -  ");
                }
            putc('\n', rfile);
            }
        if (anyshared)
            {
            FP "\nSITES OF SHARED POLYMORPHISMS - not including N's or indels\n");
            FP " group1       group2 \n");
            for (i = 0; i < numgroups - 1; i++) 
            for (ii=i+1; ii< numgroups;ii++)
            if (sharepoly[i][ii] > 0)
                {
                FP "-------------------------------- \n");
                FP "%s %s %2u: ", groupnames[i],groupnames[ii],sharepoly[i][ii]);
                polygroup = sharepoly[i][ii]/ 8;
                if (sharepoly[i][ii] % 8 > 0) polygroup++;
                if (polygroup == 0) putc('\n', rfile);
                FORLIM1 = polygroup;
                for (k = 1; k <= FORLIM1; k++)
                    {
                    j = (k - 1) * 8 + 1;
                    while (j <= k * 8 && j <= sharepoly[i][ii])
                        {
                        FP "%6u", groups_sharedbase[i][ii][j]);
                        j++;
                        }
                    putc('\n', rfile);
                    if (k < polygroup) 
                       for (j=1; j < 2*MaxGroupNameLength+7;j++) FP" ");
                    }
                FP "-------------------------------- \n");
                }
            }
#ifdef SHARE_POLY_DIST_OPTION
        if (DoSharePolyDist && numgroups > 1){
        FP"\n\nJOINT SITE FREQUENCY DISTRIBUTIONS\n");
        FP"----- ---- --------- -------------\n");
        FP"      - For each Group Pair, list number of derived bases in each count class \n");
        FP"      - empty cells of matrix not listed \n");
        for (i = 0; i < numgroups - 1; i++) 
          if (groupsize[i] > 1) for (ii=i+1; ii< numgroups;ii++) if (groupsize[ii]>1)
              {
			  FP"SITES ROOTED BY COMMON OUTGROUP\n");
			  FP"----- ------ -- ------ --------\n");
			  FP"group 1: %12s  sample size: %3d    \n", groupnames[i],groupsize[i]);
			  FP"group 2: %12s  sample size: %3d\n",groupnames[ii],groupsize[ii]);
			  FP"-------- ------------  ------ ----- ---\n"); 
              FP"  %3u sites for which all bases are the same, except the outgroup\n",numoutbaseisderived[i][ii]);
			  if (numoutbaseisderived[i][ii] > 0){
                  polygroup = numoutbaseisderived[i][ii]/ 10;
                  if (numoutbaseisderived[i][ii] % 10 > 0) polygroup++;
                  if (polygroup == 0) putc('\n', rfile);
                  FORLIM1 = polygroup;
                  for (k = 1; k <= FORLIM1; k++) {
                     j = (k - 1) * 10 + 1;
                     while (j <= k * 10 && j <= numoutbaseisderived[i][ii]) {
                        FP "%6u", outbaseisderived[i][ii][j]);
                        j++;
                     }
                     putc('\n', rfile);
                  }
               }
			  FP"  %3u variable sites not used because of questionable rooting\n",numquestionable_derivedbase[i][ii]);
			  if (numquestionable_derivedbase[i][ii] > 0){
                  polygroup = numquestionable_derivedbase[i][ii]/ 10;
                  if (numquestionable_derivedbase[i][ii] % 10 > 0) polygroup++;
                  if (polygroup == 0) putc('\n', rfile);
                  FORLIM1 = polygroup;
                  for (k = 1; k <= FORLIM1; k++) {
                     j = (k - 1) * 10 + 1;
                     while (j <= k * 10 && j <= numquestionable_derivedbase[i][ii]) {
                        FP "%6u", questionable_derivedbase[i][ii][j]);
                        j++;
                     }
                     putc('\n', rfile);
                  }
               }
			  FP"sites used in rooted matrix \n");
			  if (numrt[i][ii] > 0){
                  polygroup = numrt[i][ii]/ 10;
                  if (numrt[i][ii] % 10 > 0) polygroup++;
                  if (polygroup == 0) putc('\n', rfile);
                  FORLIM1 = polygroup;
                  for (k = 1; k <= FORLIM1; k++) {
                     j = (k - 1) * 10 + 1;
                     while (j <= k * 10 && j <= numrt[i][ii]) {
                        FP "%6u", rt[i][ii][j]);
                        j++;
                     }
                     putc('\n', rfile);
                  }
               }
			  FP"   Group1 Count    Group2 Count    # Sites \n");
			  FP"   ------------    ------------    ------- \n");
			  temp = 0;
			  for (j=0;j< MaxS + 1; j++) 
				  for (k=0;k< MaxS +1;k++){
					  if (derivedpolydist[i][ii][j][k]>0) {
						  FP"     %3u               %3u          %4u\n",j,k,derivedpolydist[i][ii][j][k]);
						  temp += derivedpolydist[i][ii][j][k];
					  }
				  }
              FP"  Number of sites in matrix : %5u \n",temp);
			  FP "------------------------------------------ \n");
			  FP"FOLDED DISTRIBUTION - SITES ROOTED BY FREQUENCY\n");
			  FP"------ ------------   ----- ------ -- ---------\n");
			  FP"group 1: %12s  sample size: %3d    \n", groupnames[i],groupsize[i]);
			  FP"group 2: %12s  sample size: %3d\n",groupnames[ii],groupsize[ii]);
			  FP"-------- ------------  ------ ----- ---\n"); 
			  FP"sites used in folded matrix \n");
			  if (numrt[i][ii] > 0){
                  polygroup = numft[i][ii]/ 10;
                  if (numft[i][ii] % 10 > 0) polygroup++;
                  if (polygroup == 0) putc('\n', rfile);
                  FORLIM1 = polygroup;
                  for (k = 1; k <= FORLIM1; k++) {
                     j = (k - 1) * 10 + 1;
                     while (j <= k * 10 && j <= numft[i][ii]) {
                        FP "%6u", ft[i][ii][j]);
                        j++;
                     }
                     putc('\n', rfile);
                  }
               }
			  FP"   Group1 Count    Group2 Count    # Sites \n");
			  FP"   ------------    ------------    ------- \n");
			  temp=0;
			  for (j=0;j< MaxS + 1; j++) 
				  for (k=0;k< MaxS +1;k++){
					  if (foldedpolydist[i][ii][j][k]>0){
						  FP"     %3u               %3u          %4u\n",j,k,foldedpolydist[i][ii][j][k]);
						  temp += foldedpolydist[i][ii][j][k];
					  }
				  }
			  FP"  Number of sites in matrix : %5u \n",temp);
			  FP "------------------------------------------ \n\n");

		  }
	  }
#endif
    /*migration estimates using Nmf, espression 4 (except that 2 is replaced by 4 as if locus is diploid)
          in Hudson, et al, 1992 Genetcs 132:583-589*/
    FP "\n\nFst AND POPULATION MIGRATION RATES (Nm, assuming diploidy)\n");
    FP     "--- --- --------------------------\n");
    FP
       "  - above the diagonal: Nm estimates assuming diploidy\n");
    FP
       "  - below the diagonal: Fst estimates\n");
    for (j=1; j < MaxGroupNameLength+6;j++) FP" ");
    FORLIM = numgroups;
    for (i = 1; i <= FORLIM; i++)
      FP "     %2u   ", i);
    putc('\n', rfile);
    FORLIM = numgroups;
    for (i = 0; i < FORLIM; i++) {
      for (j=2; j < MaxGroupNameLength+8;j++) FP" ");
      FORLIM1 = numgroups;
      for (j = 0; j < FORLIM1; j++) {
         if (j == i || j == i - 1)  FP "----------");
                              else  FP "          ");
         }
      FP "\n%2u: %s  ", i+1, groupnames[i]);
      FORLIM1 = numgroups;
      for (j = 0; j < FORLIM1; j++) {
         within = (groupdiffs[i][i] + groupdiffs[j][j]) / 2.0;
         if (i<j) between = groupdiffs[i][j]; else between= groupdiffs[j][i];
         if (j == i ) FP "|         ");
         else{ if ( j>i ){
               if ((between - within) > 0.0) {
                   tempd = within / (4.0*(between - within));
                   if (j== i+1) FP "| %7.3f ", tempd); 
                           else FP "  %7.3f ", tempd);
                   } else if ( j==i+1) FP "|  undef  "); 
                                  else FP "   undef  ");
               } else{
                 if (between > 0.0) {
                     tempd = 1.0 -  within/between;
                     if (j== i+1) FP "| %7.3f ", tempd); 
                             else FP "  %7.3f ", tempd);
                     } else  if ( j==i+1) FP "|  undef  "); 
                                     else FP "   undef  ");
                  }
              }
         }
      putc('\n', rfile);
      }
     FP "\n\n");
    } /* end of code for multiple groups polymorphism analysis */

/* folded site frequency distribution */
    FP "POLYMORPHIC SITE FREQUENCIES - not including N's or indels\n");
    FP "----------- ---- ----------- \n");
    FP "  Types of sites: All - all summed; Rep  - replacement\n");
    FP "                  Syn - synonymous; NC - noncoding\n");
    if (analyses[PREF - (long)SIT] == _true)
        {
        FP "  Types of synonymous changes :\n");
        FP "                               UU - unprefered -> unprefered \n");
        FP "                               UP - unprefered -> prefered \n");
        FP "                               PU - prefered   -> unprefered \n");
        FP "                               PP - prefered   -> prefered \n");
        lastpdc = UPREF_UPREF;
        }
    else
        lastpdc = SDIST;
    FP "  Sites with 3 or 4 bases in a group are sorted into the 'rarest base' vs 'all others'\n");
    FP "  Sites that are ambiguous with regard to type are not counted \n");
    FP "  If an outgroup exists, both folded and rooted results are given, including fixed differences \n\n");
    for (j=0;j<MaxGroupNameLength;j++) FP" ");
    FP "                   FOLDED");if (outgroup[0]) FP"                    ROOTED \n"); else FP"\n");
    for (j=0;j<MaxGroupNameLength;j++) FP" ");
    FP "             --------------------");if (outgroup[0]) FP"  ---------------------------\n"); else FP"\n");
    FP "GROUP NAME");
    for (j=10;j<MaxGroupNameLength;j++) FP" ");
    FP " #seqs  Type #Sites  Mean   TajD");if (outgroup[0]) FP"   #Sites  Mean   TajD  #Fixed\n"); else FP"\n");
    for (j=1; j < MaxGroupNameLength;j++) FP"-");
    FP"  -----  ---- ------  ----- ------");if (outgroup[0]) FP"  ------  ----- ------ ------\n"); else FP"\n");
    
    for (i = 0; i < numgroups; i++)
        if (groupsize[i] > 1)
        {
        for (pdc = SITESUM;pdc <= lastpdc;pdc++)
            {
            FP "%s   ", groupnames[i]);
            FP "%3d   ", groupsize[i]);
            FP "%s  ",pdclabel[pdc]);
            FP "%3u  ", sitefreqsum[i][pdc]);
            if (sitefreqsum[i][pdc] > 0)
                {
                for (temp=0, j = 0;j < maxpolyused;j++)
                    temp += polydist[pdc][i][j] * (j+1);
                FP"%6.3f ",(float) temp / (float) sitefreqsum[i][pdc]);
                }
            else 
                FP"  -    ");
            if (sitefreqsum[i][pdc] > 0 && groupsize[i] > 3)
                {
                for (tempd=0, j = 0;j < maxpolyused;j++)
                    tempd += (float) polydist[pdc][i][j]*( (float) (j+1) * (float) (groupsize[i] - (j+1)) );
                tempd /= (float) groupsize[i] * ((float) groupsize[i]-1) / 2.0;
                tempd = quicktajd((double) groupsize[i], (double) sitefreqsum[i][pdc],tempd);
                if (tempd > -99)
                    FP"% .3f    ",tempd);
                else 
                    FP" undef    ");
                }
            else 
                FP" undef    ");
            if (outgroup[i])
                {
                FP "%3u  ", sitefreqsum_o[i][pdc]);
                if (sitefreqsum_o[i][pdc] > 0)
                    {
                    for (temp=0, j = 0;j < groupsize[i]-1;j++)
                        temp += polydist_o[pdc][i][j] * (j+1);
                    FP"%6.3f ",(float) temp / (float) sitefreqsum_o[i][pdc]);
                    }
                else 
                    FP"  -    ");
                if (sitefreqsum_o[i][pdc] > 0 && groupsize[i] > 3)
                    {
                    for (tempd=0, j = 0;j < groupsize[i]-1;j++)
                        tempd += (float) polydist_o[pdc][i][j]*( (float) (j+1) * (float) (groupsize[i] - (j+1)) );
                    tempd /= (float) groupsize[i] * ((float) groupsize[i]-1) / 2.0;
                    tempd = quicktajd((double) groupsize[i], (double) sitefreqsum_o[i][pdc],tempd);
                    if (tempd > -99)
                        FP"% .3f ",tempd);
                    else 
                        FP" undef ");
                    }
                else 
                    FP" undef ");
                FP" %3u ", polydist_o[pdc][i][groupsize[i]-1]);
                }
            FP"\n");
            }
        if (i < (numgroups - 1)) 
            FP"-----------\n");
        }
    FP"\n");

#define NUMCOLS  12

    polygroup = maxpolyused / NUMCOLS;
    if (maxpolyused % NUMCOLS > 0)
      polygroup++;
    FP "   FOLDED DISTRIBUTIONS\n");
    FP "   ------ -------------\n");
    FP"    The number of lines carrying the rarest base - bases not rooted by outgroup\n");
    FORLIM = polygroup;
    for (k = 1; k <= FORLIM; k++)
        {
        FP "GROUP NAME");
        for (j=10;j<MaxGroupNameLength;j++) FP" ");
        FP" Type ");
        i = (k - 1) * NUMCOLS + 1;
        while ((i <= k * NUMCOLS) && (i <= maxpolyused))
            {
            FP " %3u ", i);
            i++;
            }
        FP"\n");
        for (j=1; j < MaxGroupNameLength;j++) FP"-");
        FP "  ---- ");
        i = (k - 1) * NUMCOLS + 1;
        while ((i <= k * NUMCOLS) && (i <= maxpolyused))
            {
            FP " --- ");
            i++;
            }
        putc('\n', rfile);
        for (i = 0; i < numgroups; i++)
            if (groupsize[i] > 1)
            {
            for (pdc = SITESUM;pdc <= lastpdc;pdc++)
                {
                FP "%s  ", groupnames[i]);
                FP "%s",pdclabel[pdc]);
                j = (k - 1) * NUMCOLS + 1;
                while (j <= k * NUMCOLS && (j <= maxpolyused))
                    {
                    FP " %3u ", polydist[pdc][i][j - 1]);
                    j++;
                    }
                putc('\n', rfile);
                }
            if (i < (numgroups - 1)) 
                FP"-----------\n");
            }
        if (k < polygroup)
            FP "continued . . .\n\n");
        }

/* rooted site frequency distribution */
    if (numgroups > 1)
        {
        polygroup = maxpolyused_o / NUMCOLS;
        if (maxpolyused_o % NUMCOLS > 0)
          polygroup++;
        FP "\n");
        FP "   ROOTED DISTRIBUTIONS\n");
        FP "   ------ -------------\n");
	    FP "GROUP NAME  :  OUTGROUP   - selected by SITES by average group differences\n");
	    FP "----------     --------\n");
        FORLIM = numgroups;
        for (k = 1; k <= FORLIM; k++)
	      if (outgroup[k-1]>0 && groupsize[k-1] > 1) FP "%s   %s\n", groupnames[k-1],groupnames[outgroup[k-1]-1]);
        FP"  The number of lines carrying derived bases - bases rooted by outgroup\n");
        FORLIM = polygroup;
        for (k = 1; k <= FORLIM; k++)
           {
            FP "GROUP NAME");
            for (j=10;j<MaxGroupNameLength;j++) FP" ");
            FP" Type ");
            i = (k - 1) * NUMCOLS + 1;
            while ((i <= k * NUMCOLS) && (i <= maxpolyused_o))
                {
                FP " %3u ", i);
                i++;
                }
            FP"\n");
            for (j=1; j < MaxGroupNameLength;j++) FP"-");
            FP "  ---- ");
            i = (k - 1) * NUMCOLS + 1;
            while ((i <= k * NUMCOLS) && (i <= maxpolyused_o))
                {
                FP " --- ");
                i++;
                }
            putc('\n', rfile);
            for (i = 0; i < numgroups; i++)
                if (groupsize[i] > 1)
                {
                for (pdc = SITESUM;pdc <= lastpdc;pdc++)
                    {
                    FP "%s  ", groupnames[i]);
                    FP "%s",pdclabel[pdc]);
                    j = (k - 1) * NUMCOLS + 1;
                    while (j <= k * NUMCOLS && (j <= maxpolyused_o))
                        {
                        FP " %3u ", polydist_o[pdc][i][j - 1]);
                        j++;
                        }
                    putc('\n', rfile);
                    }
                if (i < (numgroups - 1)) 
                    FP"-----------\n");
                }
            if (k < polygroup)
                FP "continued . . .\n\n");
            }
            
	    }


    FP"\nSITES WITH MORE THAN TWO BASES SEGREGATING - not including N's or indels\n");
    FP"----- ---- ---- ---- --- ----- -----------\n");
    FORLIM = numgroups;
    for (i = 0; i < FORLIM; i++) {
      FP "%s  %2u :", groupnames[i], groups_multibase[i][0]);
      polygroup = groups_multibase[i][0] / 10;
      if (groups_multibase[i][0] % 10 > 0)   polygroup++;
      if (polygroup == 0)  putc('\n', rfile);
      FORLIM1 = polygroup;
      for (k = 1; k <= FORLIM1; k++) {
         j = (k - 1) * 10 + 1;
         while (j <= k * 10 && j <= groups_multibase[i][0]) {
            FP "%6u", groups_multibase[i][j]);
            j++;
         }
         putc('\n', rfile);
         if (k < polygroup)
            for (j=1; j < MaxGroupNameLength+7;j++) FP" ");
      }
    }
    FP"\nD STATISTICS - test selection within groups. * - without outgroup information\n");
	FP"         note - for a site segregating 3 or 4 bases: \n");
    FP"                  - the site is counted as only one polymorphic site\n");
    FP"                  - but, pairwise differences are calculated using all bases that occur\n");
    FP"GROUP NAME");
    for (j=10;j<MaxGroupNameLength;j++) FP" ");
    FP" #seqs TajimaD  Fu&LiD  Fu&LiD*  Total-u  Ext-u   Ext-u*\n");
    for (j=1; j < MaxGroupNameLength;j++) FP"-");
    FP"  -----  ------  ------- -------  -------  ------- ------\n");
    FORLIM = numgroups;
    for (i = 0; i < FORLIM; i++) {
      FP "%s   ", groupnames[i]);
      FP " %3d ", groupsize[i]);
      FP "% s", TajD[i]);
      fputs(FuLiD[i], rfile);
      fputs(FuLiDstar[i], rfile);
            FP " %3u     ", totalpoly[i]);
      if (outgroup[i] > 0)  FP " %3u     ", singletonOG[i]);
      else  FP "no OutGp   ");
      FP "%3u\n", singleton[i]);
    }
    FP "\n\nTHETA (4Nu) ESTIMATES\n");
    FP"GROUP NAME");
    for (j=10;j<MaxGroupNameLength;j++) FP" ");
    FP " #seqs #bases #SITES  ThetaW  ThetaW/bp  Thetapi  Thetapi/bp \n");
    for (j=1; j < MaxGroupNameLength;j++) FP"-");
    FP"  ----- ------ ------  ------- ---------  -------  ----------\n");
    
     FORLIM = numgroups;
     for (i = 0; i < FORLIM; i++) {
        if (groupsize[i] > 1) {
           tempd = 1.0;
           FORLIM1 = groupsize[i];
           for (j = 2; j < FORLIM1; j++)  tempd += 1.0 / j;
           FP "%s    ", groupnames[i]);
           FP "%3d ", groupsize[i]);
           FP "%6.1f  ", groupcompbases[i][i]);
           FP "%3u   ", polysite[i]);
           FP "%6.3f   ", polysite[i] / tempd);
           FP "%7.5f  ", polysite[i] / tempd / groupcompbases[i][i]);
           FP "%7.2f    ", groupdiffs[i][i]);
           FP "%7.5f  \n", groupdiffs[i][i] / groupcompbases[i][i]);
        }
     }
     putc('\n', rfile);
  }
  if (analyses[POPMOD - SIT]){
     if (screenupdate) printf("Historical Population Model Fitting  - could take awhile...\n");
     FP "%s\n%s\n\n",dashline,starline);
     FP "HISTORICAL POPULATION MODEL FITTING\n");
     FP "-----------------------------------\n\n");
     fill_watterm();
     fill_choose2();
     if ( numgroups > 1 ){
     FP"Isolation Speciation Model Fitting - Wakeley & Hey 1997 \n");
     FP  "--------- ---------- ----- -------  \n");
     FP " group1      group2      Sx1   Sx2   Ss    Sf   Theta1   Theta2   ThetaA   Tau\n");
     FP " ------      ------      ---  ----  ----  ----  ------   ------   ------   ---\n");
     for (i = 0; i < numgroups - 1; i++)
      for (ii=i+1; ii< numgroups;ii++){
         fitquality = _true;
         passdata[0] = (float) (polysite[i] - sharepoly[i][ii]);
         passdata[1] = (float) (polysite[ii] - sharepoly[i][ii]);
         passdata[2] =  (float) sharepoly[i][ii];
         passdata[3] = (float) fixdiffs[i][ii];
         FP "%s%s", groupnames[i],groupnames[ii]);
         for (j=0;j<=3 ;j++ ) FP"%5.1f ",passdata[j]);
         if (passdata[2]< 1.0 || passdata[3] < 1.0){
            FP" - na - zero Ss and/or Sf\n");
         }
         else { 
          doamoeba(4,i,ii,passdata,passexpected,passparams);
          for (j=0;j<=3 ;j++ ) FP"%7.4f ",passparams[j]);
          putc('\n',rfile);
          for (j=0;j<=3 ;j++ ) {
           if (passdata[j]==0.0){
              if (fabs(passexpected[j] - passdata[j]) > 0.01) fitquality = _false;
            }else{
               if (fabs(passexpected[j] - passdata[j])/passdata[j] > 0.01) fitquality = _false;
             }
             }
           
           FP"      expected        : ");
           for (j=0;j<=3 ;j++ ) FP"%5.1f ",passexpected[j]);
           if (!fitquality) FP" *caution* - model fits poorly");
           putc('\n',rfile);
         }
      } 
        }
     FP"\nPopulation Size Change Model Fitting- Wakeley & Hey 1997 \n");
     FP  "---------- ---- ------ ----- -------\n");
     FP"  group          S_1     S_2    S_3     Theta    ThetaA    Tau \n");
     FP" -------       ------  ------ --------  ------   ------    ----\n");
     for (i=0;i<=numgroups-1 ; i++){
       if ((polysite[i]>0) && (groupsize[i] >= 6)){
          fitquality = _true;
          passdata[0] = get_sitefreq_i(i,1);
          passdata[1] = get_sitefreq_i(i,2);
          passdata[2] = get_sitefreq_i(i,3);
          FP"%s   ",groupnames[i]);
          for (j=0;j<=2 ;j++ ) FP"%6.2f ",passdata[j]);
          doamoeba(3,i,0,passdata,passexpected,passparams);
          for (j=0;j<=2 ;j++ ) FP" %8.4f ",passparams[j]);
          putc('\n',rfile);
          for (j=0;j<=2 ;j++ ) {
           if (passdata[j]==0.0){
              if (fabs(passexpected[j] - passdata[j]) > 0.01) fitquality = _false;
            }else{
               if (fabs(passexpected[j] - passdata[j])/passdata[j] > 0.01) fitquality = _false;
            }
          }
       FP"   expected  : ");
       for (j=0;j<=2 ;j++ ) FP"%6.2f ",passexpected[j]);
       if (!fitquality) FP" *caution* - model fits poorly");
       putc('\n',rfile);
       }
       else {
         if (polysite[i] ==0)FP"%s      - no polymorphisms\n",groupnames[i]);
         else FP"%s         - sample size is too small \n",groupnames[i]);
        }
      }
    } /* population model fitting */
  if (analyses[REC - SIT]) {
	if (screenupdate) printf("Recombination Analyses\n");
    if (analyses[INDELS - SIT])
      insertindels();
    FP "%s\n%s\n\n",dashline,starline);
    FP "RECOMBINATION ANALYSES\n");
    FP "------------- --------\n\n");
    FP "POPULATION RECOMBINATION PARAMETER (4Nc) ESTIMATES\n");
    FP "---------- ------------- --------- ----- ---------\n");
    FP"     - for gamma see Hey&Wakeley (1997); for Hud4Nc - see Hudson(1987)\n");
    FP"GROUP NAME");
    for (j=10;j<MaxGroupNameLength;j++) FP" ");
    FP" #seqs #subsamp  gamma   gamma/bp  c/u       Hud4Nc   Hud4Nc/bp \n");
    for (j=1; j < MaxGroupNameLength;j++) FP"-");
    FP" ----- --------  ------  -------- ------     -------  ---------\n");
    for (i=1;i<= numgroups;i++) GroupRECsites(i-1,1);
    FP "\nCONGRUENCY AND INTERVAL TABLES\n");
    FP  "---------- --- -------- ------\n");
    for (i=1;i<= numgroups;i++)
		{
        FP "\n%s\n", groupnames[i - 1]);
        for (j=1; j < MaxGroupNameLength;j++) FP"-");
        FP"\n");
        GroupRECsites(i-1,2);
        putc('\n',rfile);
		}
   }
  if (analyses[LD - SIT]) {
    FP"\n\n");
	if (screenupdate) printf("Linkage Disequilibrium Analyses\n");
    FP "%s\n%s\n\n",dashline,starline);
	FP"LINKAGE DISEQUILIBRIUM ANALYSES \n");
	FP"------------------------------- \n\n");
	if (exclude_singletons){
		FP"\n     Singletons are excluded from all LD analyses \n");
		FP"     --------------------------------------------\n\n");
	}
 	for (i=1;i<= numgroups;i++) {
		if (groupsize[i - 1] > 3){
			if (doLDregion) {
				FP"Average Linkage Diseqiulibrium Between Regions \n");
				FP"------- ------- -------------- ------- ------- \n");
				print_regionLD(i-1);
			}
		}
	}
	if (doLDmatrix)	{
		FP" Matrices of Linkage Disequilibrium Values and Tests\n");
		FP" -------- -- ------- -------------- ------ --- -----\n\n");
		FP"  Matrices Printed to File : %s\n\n",LDmatrixfile_NAME);
		if ((LDmatrixfile = fopen(LDmatrixfile_NAME, "a")) == NULL){
					printf("\nError opening text file for writing \n"); exit(0);}
		FPM"**SITES**   -- LINKAGE DISEQUILIBRIUM MATRIX OUTPUT --\n");
		FPM "%s\n%s\n\n",dashline,starline);
		FPM "THIS FILE  : %s     INPUT FILE : %s  MAIN SITES OUTPUT FILE: %s\n\n", LDmatrixfile_NAME,  sname, rname);
		if (exclude_singletons){
			FPM"\n     Singletons are excluded from all LD analyses \n");
			FPM"     --------------------------------------------\n\n");
		}
		for (i=1;i<= numgroups;i++) {
			if (groupsize[i - 1] > 3) print_LD_matrix(i-1); 
		}
		FPM "%s\n%s\n\n",dashline,starline);
		fclose(LDmatrixfile);
	}
	
	if (doLDshared) LD_possibly_imported_stuff();
	
  }/* LINKAGE 	ANALYSIS */
  if (analyses[GCA - SIT]) {
    if (screenupdate) printf("Generating GC Usage Table\n");
    getgc();
    FP "%s\n%s\n\n",dashline,starline);
    FP "GC CONTENT ANALYSIS\n");
    FP "-------------------\n\n");
    FP
      "Sequence  #1:GC%%  bp   #2:GC%%  bp   #3:GC%%  bp  Int:GC%%  bp  All:GC%%   bp\n");
    FP
      "--------  ------ ---   ------ ---   ------ ---  ------- ---  -------  ---\n");
    FORLIM = nums;
    for (i = 0; i < FORLIM; i++) {
      fputs(names[i], rfile);
      for (j = 0; j <= 4; j++) {
   if (gcdata[i][j][1] > 0)
     FP "  %4.1f %4u  ", 100.0 * gcdata[i][j][0] / (1.0 * gcdata[i][j][1]), gcdata[i][j][1]);
   else
     FP "             ");
      }
      putc('\n', rfile);
    }
  }
  if (doHKAoutput){
	  FP "%s\n%s\n\n",dashline,starline);
	  FP" Formatted Values for Input to HKA Program \n");
	  FP" --------- ------ --- ----- -- --- ------- \n");
	  FP"\n Lines are generated for each ordered species pair, and also with each 2nd species as single sequence\n");
	  FP"\n  Value Order : \n");
	  FP"           locus identifier (input data filename upto 10 characters)\n");
	  FP"           inheritance scalar (1.0 for autosomal is default - this must be edited: 0.75 X -linked; 0.25 mitochondrial or Y-linked)\n");
	  FP"           mean sequence length group1 \n");
	  FP"           mean sequence length group2 \n");
	  FP"           mean sequence length between group \n");
	  FP"           # of sequences group1 \n");
	  FP"           # of sequences group2 \n");
	  FP"           # of polymorphic sites group1 \n");
	  FP"           # of polymorphic sites group2 \n");
	  FP"           mean pairwise divergence between group \n");
	  FP"           Tajima D  for group 1 \n");
	  FP"           Tajima D  for group 2 \n");
	  FP"           Fu & Li D for group 1 \n");
	  FP"           Fu & Li D for group 2 \n");
	  for (i=0;i< numgroups; i++)
		  for (j=0;j<numgroups; j++)
			if(i != j){
				if (i<j){
					ii = i; jj = j;
				}else {
					ii = j; jj = i;
				}
			    FP"%s %s \n",groupnames[i],groupnames[j]);
			    strcpy(hkas,sname); 
				TEMP2 = strchr(hkas,'.');
				if (TEMP2 != NULL) *TEMP2 = '\0';
				if (strlen(hkas) < 10){
					for (k=strlen(hkas); k<10;k++) hkas[k] = ' ';
					hkas[k] = '\0';
				} else hkas[10] = '\0';
				strcat(hkas," 1.0 ");
				sprintf(temps,"%8.0f %8.0f %8.0f ",groupcompbases[i][i],groupcompbases[j][j],groupcompbases[ii][jj]);
				strcat(hkas,temps);
				sprintf(temps,"%3d %3d ",groupsize[i],groupsize[j]);
				strcat(hkas,temps);
				sprintf(temps,"%3d %3d %6.0f ",polysite[i],polysite[j],groupdiffs[ii][jj]);
				strcat(hkas,temps);
				sprintf(temps,"%s %s ",TajD[i],TajD[j]);
				strcat(hkas,temps);
				sprintf(temps,"%s %s ",FuLiD[i],FuLiD[j]);
				strcat(hkas,temps);
				FP"%s\n",hkas);
				FP"%s    %s (single line)\n",groupnames[i],groupnames[j]);
				strcpy(hkas,sname); 
				TEMP2 = strchr(hkas,'.');
				if (TEMP2 != NULL) *TEMP2 = '\0';
				if (strlen(hkas) < 10){
					for (k=strlen(hkas); k<10;k++) hkas[k] = ' ';
					hkas[k] = '\0';
				} else hkas[10] = '\0';
				strcat(hkas," 1.0 ");
				sprintf(temps,"%8.0f %8.0f %8.0f ",groupcompbases[i][i],groupcompbases[j][j],groupcompbases[ii][jj]);
				strcat(hkas,temps);
				sprintf(temps,"%3d   1 ",groupsize[i]);
				strcat(hkas,temps);
				sprintf(temps,"%3d   0 %6.0f ",polysite[i],groupdiffs[ii][jj]);
				strcat(hkas,temps);
				sprintf(temps,"%s %s ",TajD[i],TajD[j]);
				strcat(hkas,temps);
				sprintf(temps,"%s %s ",FuLiD[i],FuLiD[j]);
				strcat(hkas,temps);
				FP"%s\n",hkas);
		  }

  }
  if (doWHoutput){
	  FP "%s\n%s\n\n",dashline,starline);
	  FP" Formatted Values for Input to WH Program \n");
	  FP" --------- ------ --- ----- -- -- ------- \n");
	  FP"\n Lines are generated for each ordered group pair\n");
	  FP"\n  Value Order : \n");
	  FP"           locus identifier (input data filename upto 10 characters)\n");
	  FP"           inheritance scalar (1.0 for autosomal is default - this must be edited: 0.75 X -linked; 0.25 mitochondrial or Y-linked)\n");
	  FP"           mean sequence length within group \n");
	  FP"           # of sequences group1 \n");
	  FP"           # of sequences group2 \n");
	  FP"           Sx1 - exclusive polymorphisms group1 \n");
	  FP"           Sx2 - exclusive polymorphisms group2 \n");
	  FP"           Ss  - shared polymorphisms between group\n");
	  FP"           Sf  - fixed differences between group \n");
	  FP"           gamma total group1 \n");
	  FP"           gamma total group2 \n");
	  FP"           LD among shared polymorphisms for group1\n");
      FP"           LD among shared polymorphisms for group2\n");
	  FP"           LD among shared polymorphisms  minus LD among and non-shared polymorphisms for group1\n");
	  FP"           LD among shared polymorphisms  minus LD among non-shared polymorphisms for group2\n");
	  FP"           LD among shared polymorphisms  minus LD between shared and non-shared polymorphisms for group1\n");
	  FP"           LD among shared polymorphisms  minus LD between shared and non-shared polymorphisms for group2\n");
	  for (i=0;i< numgroups; i++)
		  for (j=0;j<numgroups; j++)
			if(i != j){
				if (i<j){
					ii = i; jj = j;
				}else {
					ii = j; jj = i;
				}
			    FP"%s %s \n",groupnames[i],groupnames[j]);
			    strcpy(hkas,sname); 
				TEMP2 = strchr(hkas,'.');
				if (TEMP2 != NULL) *TEMP2 = '\0';
				if (strlen(hkas) < 10){
					for (k=strlen(hkas); k<10;k++) hkas[k] = ' ';
					hkas[k] = '\0';
				} else hkas[10] = '\0';
				strcat(hkas," 1.0 ");
				sprintf(temps,"%8.0f ",groupcompbases[ii][jj]);
				strcat(hkas,temps);
				sprintf(temps,"%3d %3d ",groupsize[i],groupsize[j]);
				strcat(hkas,temps);
				sprintf(temps,"%3d %3d %3d %3d ",polysite[i]-sharepoly[ii][jj],polysite[j]-sharepoly[ii][jj],sharepoly[ii][jj],fixdiffs[ii][jj]);
				strcat(hkas,temps);
				sprintf(temps,"%8.3f %8.3f ",gammarray[i],gammarray[j]);
				strcat(hkas,temps);
				if (LDdotypes[LDDP]){
					sprintf(temps,"% 7.3f % 7.3f ",LDS[LDDP][i][j].val,LDS[LDDP][j][i].val);
					strcat(hkas,temps);
					sprintf(temps,"% 7.3f % 7.3f ",LDS[LDDP][i][j].val - LDO[LDDP][i][j].val,LDS[LDDP][j][i].val - LDO[LDDP][j][i].val);
					strcat(hkas,temps);
					sprintf(temps,"% 7.3f % 7.3f ",LDS_less_OS[LDDP][i][j].val,LDS_less_OS[LDDP][j][i].val);
					strcat(hkas,temps);
				}
				FP"%s\n",hkas);
			}

  }
  if (rfile != NULL)
    FP "%s\n%s\n\n",dashline,starline);
    FP"\n\n  - end of SITES  program output\n");
    fclose(rfile);
  rfile = NULL;
}  /*finish*/


main(int argc, char *argv[])
{
#ifdef  __MWERKS__
  argc = ccommand(&argv); 
  SIOUXSettings.autocloseonquit = _true;
  SIOUXSettings.asktosaveonclose = _false;
#endif
  start(argc,argv);
  ReadData();
  GetSites();
  Finish();
  exit(0);

}


/* End. */


