/*
* Copyright 2002 by Jody Hey
* Rutgers University, Piscataway, NJ 08855
*
* This computer program and documentation may be freely copied
* and used by anyone, provided no fee is charged for it.
*/
#undef SITES_G
#include "sites.h"

#define Dfault  FLT_MAX
#define Dfault_check  (Dfault / 10.0)
#define MINUS10 -10.0
#define  LDVALINTS  10
/*#define  DERIVED_SHARED  */  /* use this to switch between counting shared difference
in the routine LD_possibly_imported_stuff(void)
if DERIVED_SHARED is defined, then sites that are fixed in the 2nd species for a derived base are
counted as shared.
if not, then shared are just regular shared */

/* local variables, used mostly by GroupRECsites: */

typedef long site[(long)D - (long)A + 1][SETL];
static site sitesforREC[MaxSitesforRec];
static unsigned int siteseqnums[MaxSitesforRec];
static char rareclass[MaxSitesforRec][4];
static  int  numseq;
static unsigned int gcount;
static  int  grouplimitlow, grouplimithigh;
static basetype tempb1, tempb2;
static  unsigned int  tempsetarray[4];
static long double tempnterm;
static unsigned int pickarraylength;
static  unsigned int  pickarray[MaxS];
static  boolean  randompicksset;
static boolean doLDtest;  /* LD test is on */
static char fetchar, chisquarechar;
/* debugging LD 
static float tempx[4],meanx[4]; */
/* LDtestcode
    '-'  could not do test
    '0' p> 0.9
    '1' p< 0.1
    '2' p< 0.05
    '3' p< 0.01
    '4' p< 0.005
    '5' p< 0.001
    '6' p< 0.0001
    '7' p< 0.00001
    '8' p< 0.000001 */
static char LDtestcode[LDVALINTS] = {'-','0','1','2','3','4','5','6','7','8'};
static float LDfettestval[LDVALINTS] = {0, 0.9999999, 0.05, 0.01, 0.005, 0.001, 0.0001, 0.00001, 0.000001, 0.0000001};
static float LDchisquareval[LDVALINTS] = {0.0, 0.0000001, 2.71, 3.84, 6.63, 7.88, 10.83, 11.76, 13.79, 14.88}; 

static char LDvalcode[LDVALINTS] = {'0','1','2','3','4','5','6','7','8','9'};


/* local, used by HW4NC: */
static double nterm, thetabpest, thetabpsq;


/* local function prototypes */
static double cfunc(double leftside,  unsigned int  n,double c);
static double rtbis(double x1,double x2,double xacc,double leftside,  unsigned int  n,boolean *ffound);
static double Hudson4NC(  unsigned int  groupi);
static double jwfunc(double c,double n,unsigned int groupi);
static double maxlike(double a,unsigned int groupi);
static double mymax(double a, double b);
static double sign(double a,double b);
static boolean mnbrak(double *ax,double *bx,double *cx,double *fa,double *fb,double *fc,unsigned int groupi);
static double golden(double ax,double  bx,double cx,double tol_,double *xmin,unsigned int groupi);
static void HW4NC(  unsigned int  groupi,double  *tempsetc);
static void pickrandom(long *makeset);
static boolean isnewset(long *checkset,unsigned int current);
static void MakeSamples(void);
static basetype makebase(char ch);
static void print_congruency_matrix(void);
static void prep_rec_analysis(unsigned int groupi, int cutoff, boolean cleansites);
static double make_gamma(unsigned int groupi);
static void   print_rec_intervals(void);
static double logfact(int n);
void calcLD(unsigned int x[4], float *LD);
void calcLDtest(unsigned int x[4], char *fetchar,char *chisquarechar);
boolean GetLD(int groupi, float *LDval);
void regionLDscramble(int groupi);
static void print_for_mdiv(int groupi);


#define goldtol         0.001
#define s97             9.8488578017961047217
#define jmax            40
#define randint(x)  (rand() % (x))

static double cfunc(double leftside,  unsigned int  n,double c)
{
  double temp, temp1, temp2, temp3, temp4, final, nd, c2, n2;

  if (c == 0.0)
    return (leftside - 0.7777777);
  else {
    nd = 1.0 * n;
    n2 = nd * nd;
    c2 = c * c;
    temp = s97 * (nd - 1) * (c * (n2 * (s97 - 15) + 8 * nd - 2 * s97 - 2) -
        n2 * (s97 + 49) + nd * (4 * s97 + 52) - 14 * s97 - 110);
    temp = temp * log(2 * c + s97 + 13) / (97 * c2 * nd * nd * nd);
    temp1 = s97 * (nd - 1) * (c * (n2 * (s97 + 15) - 8 * nd - 2 * s97 + 2) +
         n2 * (49 - s97) + nd * (4 * s97 - 52) - 14 * s97 + 110);
    temp1 = temp1 * log(2 * c - s97 + 13) / (97 * c2 * nd * nd * nd);
    temp2 = s97 * (1 - nd) * (c * (n2 * (s97 - 15) + 8 * nd - 2 * s97 - 2) -
         n2 * (s97 + 49) + nd * (4 * s97 + 52) - 14 * s97 - 110);
    temp2 = temp2 * log(s97 + 13) / (97 * c2 * nd * nd * nd);
    temp3 = s97 * (1 - nd) * (c * (n2 * (s97 + 15) - 8 * nd - 2 * s97 + 2) +
         n2 * (49 - s97) + nd * (4 * s97 - 52) - 14 * s97 + 110);
    temp3 = temp3 * log(13 - s97) / (97 * c2 * nd * nd * nd);
    temp4 = (nd - 1) * (c * nd - 2 * (n2 - 2)) / (c * nd * nd * nd);
    final = temp + temp1 + temp2 + temp3 + temp4;
    return (leftside - final);
  }
}  /*cfunc*/

#undef s97

static double rtbis(double x1,double x2,double xacc,double leftside,  unsigned int  n,boolean *ffound)
{
  /* Programs using routine RTBIS must externally define a FUNCTION
  fx(x:REAL):REAL which is TO be analyzed FOR roots. */
  double dx, f, fmid, xmid, rtb;
  int j;

  fmid = cfunc(leftside, n, x2);
  f = cfunc(leftside, n, x1);
  if (f * fmid >= 0.0) {
    /*        writeln('pause in RTBIS');
            writeln('Root must be bracketed for bisection.'); readln*/
    *ffound = _false;
    rtb = -1.0;
    goto _L99;
  }
  if (f < 0.0) {
    rtb = x1;
    dx = x2 - x1;
  } else {
    rtb = x2;
    dx = x1 - x2;
  }
  for (j = 1; j <= jmax; j++) {
    dx *= 0.5;
    xmid = rtb + dx;
    fmid = cfunc(leftside, n, xmid);
    if (fmid <= 0.0)
      rtb = xmid;
    if (fabs(dx) < xacc || fmid == 0.0) {
      *ffound = _true;
      goto _L99;
    }
  }
  *ffound = _false;
  rtb = -1.0;
  printf("pause in RTBIS - too many bisections\n");
  scanf("%*[^\n]");
  getchar();
_L99:
  return rtb;
}

#undef jmax


static double Hudson4NC(  unsigned int  groupi)
{
  long numcomp;
  double tempsum, S, kbar, H, H2, leftside;
  float sizreal;
  double x1, x2, xacc;
  boolean found;
  double H4NC;
    unsigned int  i, j, numseq, grouplimitlow, grouplimithigh;
  double TEMP;

  tempsum = 0.0;
  numcomp = 0;
  numseq = groupsize[groupi];
  grouplimitlow = grouplimits[groupi][0];
  grouplimithigh = grouplimits[groupi][1];
  for (i = grouplimitlow; i <= grouplimithigh; i++) {
    for (j = grouplimitlow; j <= grouplimithigh; j++) {
      numcomp++;
      if (j > i)
   tempsum += compbases[j - 1][i - 1];
      if (j < i)
   tempsum += compbases[i - 1][j - 1];
    }
  }
  assert(numseq * numseq == numcomp);
  kbar = tempsum / numcomp;
  tempsum = 0.0;
  for (i = grouplimitlow; i <= grouplimithigh; i++) {
    for (j = grouplimitlow; j <= grouplimithigh; j++) {
      if (j > i) {
   TEMP = compbases[j - 1][i - 1] - kbar;
   tempsum += TEMP * TEMP;
      }
      if (j < i) {
   TEMP = compbases[i - 1][j - 1] - kbar;
   tempsum += TEMP * TEMP;
      }
      if (j == i)
   tempsum += kbar * kbar;
    }
  }
  S = tempsum / numcomp;
  if (numseq < 4 || S == 0) {
    /*FP
      "Hudson's 4NC (1987) not estimated because of low variation or low sample size \n");
      */
    return (-1);
  }
  H = 0.0;
  H2 = 0.0;
  sizreal = numseq;
  /*       temptop := TRUNC(numseq/2.0);
         FOR j := 1 TO temptop DO
             begin
             H := H+ polydist[groupi,j]*(1.0-SQR(j/sizreal)-SQR((sizreal-j)/sizreal));
             H2:= H2+polydist[groupi,j]*SQR(1.0-SQR(j/sizreal)-SQR((sizreal-j)/sizreal));
             END;*/
  H = HudsonH[groupi];
  H2 = HudsonH2[groupi];
  TEMP = H * sizreal / (sizreal - 1.0);
  leftside = (S - H + H2) / (TEMP * TEMP);
  x1 = 0.0;
  x2 = 10000.0;
  xacc = 0.05;
  H4NC = rtbis(x1, x2, xacc, leftside, numseq, &found);
  if (!found ) H4NC = -1.0;
  return(H4NC);
}

#undef goldtol
#define tol             0.001
#define two3rd          0.666666666
#define gold            1.618034
#define glimit          100.0
#define tiny            1.0e-20
#define r               0.61803399


static double jwfunc(double c,double n,unsigned int groupi)
{
  /*implements the function Pn designed by John Wakeley and Jody Hey*/
  double temp, p0num, p0denom;
    unsigned int  i, FORLIM;
  double TEMP1;

  if (c < 0.0)
    c = fabs(c);
  if (n == 0) {
    nterm = 1.0;
    FORLIM = groupsize[groupi];
    for (i = 2; i < FORLIM; i++)
      nterm += 1.0 / i;
    thetabpest = polysite[groupi] /
             (nterm * groupcompbases[groupi][groupi]);
    thetabpsq = thetabpest * thetabpest;
    p0denom = thetabpsq *
         (177.0 * c * c * c + 1091.0 * c * c + 2234.0 * c + 1800.0);
    p0denom /= 360.0 * (c + 1.0) * (c + 2.0) * (c + 3.0);
    p0num = c * thetabpsq / (20.0 * (c + 3.0));
    return (p0num / p0denom);
  } else {
    TEMP1 = c / (c + 3.0) - 2.0;
    temp = TEMP1 * TEMP1 * exp(-3.0 * c * (n - 1.0) / (5.0 * (c + 3))) / 6.0;
    return (two3rd - temp);
  }
}
#undef two3rd

static double maxlike(double a,unsigned int groupi)
{
  double temp, temp1;

  temp1 = jwfunc(a, (double)xy2[xyspot1 - 1], groupi);
  if (xy1[xyspot1 - 1] == 1)
    temp = log(temp1);
  else
    temp = log(1 - temp1);
  temp1 = jwfunc(a, (double)xy2[xyspot2 - 1],groupi);
  if (xy1[xyspot2 - 1] == 1)
    temp += log(temp1);
  else
    temp += log(1 - temp1);
  return (-temp);
}

static double mymax(double a,double b)
{
  if (a > b)
    return a;
  else
    return b;
}

static double sign(double a,double b)
{
  if (b > 0.0)
    return fabs(a);
  else
    return (-fabs(a));
}

static boolean mnbrak(double *ax,double *bx,double *cx,double *fa,double *fb,double *fc,unsigned int groupi)
{
  /* Programs using routine MNBRAK must supply an EXTERNAL
  FUNCTION func(x:REAL):REAL FOR which a minimum is TO be found */
  /* I converted this to a function and included code to check for
     a failure to find a braket*/
  double ulim, u, rr, q, fu, dum;
  boolean found;

  *fa = maxlike(*ax,groupi);
  *fb = maxlike(*bx,groupi);
  if (*fb > *fa) {
    dum = *ax;
    *ax = *bx;
    *bx = dum;
    dum = *fb;
    *fb = *fa;
    *fa = dum;
  }
  *cx = fabs(*bx + gold * (*bx - *ax));
  *fc = maxlike(*cx,groupi);
_L1:
  if (*fb >= *fc) {
    rr = (*bx - *ax) * (*fb - *fc);
    q = (*bx - *cx) * (*fb - *fa);
    u = *bx - ((*bx - *cx) * q - (*bx - *ax) * rr) /
         (2.0 * sign(mymax(fabs(q - rr), tiny), q - rr));
    ulim = *bx + glimit * (*cx - *bx);
    if ((*bx - u) * (u - *cx) > 0.0) {
      if (u > MaxCest) {
   found = _false;
   goto _L2;
      }
      fu = maxlike(u,groupi);
      if (fu < *fc) {
   *ax = *bx;
   *fa = *fb;
   *bx = u;
   *fb = fu;
   goto _L1;
      }
      if (fu > *fb) {
   *cx = u;
   *fc = fu;
   goto _L1;
      }
      u = *cx + gold * (*cx - *bx);
      if (u > MaxCest) {
   found = _false;
   goto _L2;
      }
      fu = maxlike(u,groupi);
    } else if ((*cx - u) * (u - ulim) > 0.0) {
      if (u > MaxCest) {
   found = _false;
   goto _L2;
      }
      fu = maxlike(u,groupi);
      if (fu < *fc) {
   *bx = *cx;
   *cx = u;
   u = *cx + gold * (*cx - *bx);
   *fb = *fc;
   *fc = fu;
   if (u > MaxCest) {
     found = _false;
     goto _L2;
   }
   fu = maxlike(u,groupi);
      }
    } else if ((u - ulim) * (ulim - *cx) >= 0.0) {
      u = ulim;
      if (u > MaxCest) {
   found = _false;
   goto _L2;
      }
      fu = maxlike(u,groupi);
    } else {
      u = *cx + gold * (*cx - *bx);
      if (u > MaxCest) {
   found = _false;
   goto _L2;
      }
      fu = maxlike(u,groupi);
    }
    *ax = *bx;
    *bx = *cx;
    *cx = u;
    *fa = *fb;
    *fb = *fc;
    *fc = fu;
    goto _L1;
  }
  found = _true;
_L2:
  return found;
}

#undef gold
#undef glimit
#undef tiny


static double golden(double ax,double  bx,double cx,double tol_,double *xmin,unsigned int groupi)
{
  /* Programs using routine GOLDEN must supply an EXTERNAL
  FUNCTION func(x:REAL):REAL whose minimum is TO be found. */
  double Result, f1, f2, c, x0, x1, x2, x3;

  c = 1.0 - r;
  x0 = ax;
  x3 = cx;
  if (fabs(cx - bx) > fabs(bx - ax)) {
    x1 = bx;
    x2 = bx + c * (cx - bx);
  } else {
    x2 = bx;
    x1 = bx - c * (bx - ax);
  }
  f1 = maxlike(x1,groupi);
  f2 = maxlike(x2,groupi);
  while (fabs(x3 - x0) > tol_ * (fabs(x1) + fabs(x2))) {
    if (f2 < f1) {
      x0 = x1;
      x1 = x2;
      x2 = r * x1 + c * x3;
      f1 = f2;
      f2 = maxlike(x2,groupi);
      continue;
    }
    x3 = x2;
    x2 = x1;
    x1 = r * x2 + c * x0;
    f2 = f1;
    f1 = maxlike(x1,groupi);
  }
  if (f1 < f2) {
    Result = f1;
    *xmin = x1;
  } else {
    Result = f2;
    *xmin = x2;
  }
  return Result;
}                            

#undef r

static void HW4NC(  unsigned int  groupi,double  *tempsetc)
{
  boolean brakfind;
  ax = 1e-8;
  bx = 1e-1;
  brakfind = mnbrak(&ax, &bx, &cx, &fa, &fb, &fc,groupi);
  if (brakfind)
    golden(ax, bx, cx, tol, tempsetc,groupi);
  else
    *tempsetc = -1.0;
}  /*HW4NC*/

#undef tol

static void pickrandom(long *makeset)
{
  long pickset[SETL];
  unsigned int pick, i, j;
  unsigned int FORLIM;
  unsigned int FORLIM1;
  long SET[SETL], SET1[SETL];

  P_expset(pickset, 0L);
  j = 0;
  if (pickarraylength < 4) {   /* (groupsize[groupi] div 3)*/
    FORLIM = grouplimithigh;
    for (i = grouplimitlow; i <= FORLIM; i++) {
      j++;
      pickarray[j - 1] = i;
    }
    pickarraylength = j;
    pickarray[j] = 0;
  }
  /*                assert(j=groupsize[groupi],12);*/
  for (i = 0; i <= 3; i++) {
    pick = random((long)pickarraylength) + 1;
    assert(*P_setint(SET1,P_addset(P_expset(SET, 0L), pickarray[pick - 1]),
           pickset) == 0L);
    P_addset(pickset, pickarray[pick - 1]);
    tempsetarray[i] = pickarray[pick - 1];
    FORLIM1 = pickarraylength;
    for (j = pick; j <= FORLIM1; j++)
      pickarray[j - 1] = pickarray[j];
    pickarraylength--;
  }
  P_setcpy(makeset, pickset);
}  /*pickrandom*/

static boolean isnewset(long *checkset,unsigned int current)
{ int i;
  if (current > 1) {
    i = 1;
    while (i < current && !P_setequal(checkset, ssets[i - 1]))
      i++;
    return (i == current);
  } else
    return _true;
}  /*isnewset*/

/*asymptote, overall linear, initial slope , max slope by last base, 4NC/bp, 4NC overall*/
static void MakeSamples(void)
{
  /*fill up the array of 4 sequence samples*/
  unsigned int j;
  long newset[SETL];
  long rcount;
    unsigned int ii, i1, i2, i3, i4, FORLIM, FORLIM1, FORLIM2, FORLIM3;
  unsigned int FORLIM4;
  long FORLIM5;

  
  rcount = 0;
  if (!randompicksset){
    FORLIM = grouplimithigh - 3;
    for (i1 = grouplimitlow; i1 <= FORLIM; i1++) {
      FORLIM1 = grouplimithigh - 2;
      for (i2 = i1 + 1; i2 <= FORLIM1; i2++) {
   FORLIM2 = grouplimithigh;
   for (i3 = i2 + 1; i3 < FORLIM2; i3++) {
     FORLIM3 = grouplimithigh;
     for (i4 = i3 + 1; i4 <= FORLIM3; i4++) {
       rcount++;
       ssetarrays[rcount - 1][0] = i1;
       ssetarrays[rcount - 1][1] = i2;
       ssetarrays[rcount - 1][2] = i3;
       ssetarrays[rcount - 1][3] = i4;
     }
   }
      }
    }
    assert(rcount == num4samps);
    return;
  }
  else{
  srand(time(NULL));
  pickarraylength = 0;
  FORLIM4 = num4samps;
  for (ii = 1; ii <= FORLIM4; ii++)
    P_expset(ssets[ii - 1], 0L);
  FORLIM5 = num4samps;
  for (rcount = 1; rcount <= FORLIM5; rcount++) {
    do {   /*block out if num4samples is very large (e.g. > 5000)*/
      pickrandom(newset);
    } while (!isnewset(newset, (int)rcount));
   /*block out if num4samples is very large (e.g. > 5000)*/
    P_setcpy(ssets[rcount - 1], newset);
    for (j = 0; j <= 3; j++)
      ssetarrays[rcount - 1][j] = tempsetarray[j];
  }
  }
}  /*MakeSamples*/

static basetype makebase(char ch)
{
  basetype tempbase;

  switch (toupper(ch)) {

  case 'A':
    tempbase = A;
    break;

  case 'C':
    tempbase = C;
    break;

  case 'G':
    tempbase = G;
    break;

  case 'T':
    tempbase = T;
    break;

  case '-':
    tempbase = D;
    break;

  case '*':
    tempbase = D;
    break;

  case 'N':
    tempbase = X;
    break;
  }
  return tempbase;
}

#define MAXRECINTERVALS   30

static void print_for_mdiv(groupi)
/* this is called if -JZ is on the command line, which actives DoMDIVoutput */
/* generates code suitable for input to the multilocus mdiv program */
/*go thru data, get length of each region to print, and the number of regions */
    {
    int numblocks, tcount,curint;
    int i, j,k;
    int numinfsite,numsite;
    int recintervals[MAXRECINTERVALS][4];
    int **rpair;
    basetype b11, b12, b21, b22,tempb1;
    boolean intok;
    long dset;
    long SET[SETL], SET1[SETL], SET2[SETL], SET3[SETL];
    char  chi,*chp,mdivfilename[200],temps[11];



    if (skipindel && skipmultibase)
        prep_rec_analysis(groupi, 1, _true);
    else 
        prep_rec_analysis(groupi, 1, _false);
    tcount=0;
    curint = 0;
    rpair = malloc(gcount*(sizeof(int *)));
	for (i=0; i<gcount; i++)
        rpair[i] = malloc(gcount*(sizeof(int)));
    for (i=0;i<gcount-1;i++)
        for (rpair[i][i] = 1,j=i+1;j<gcount;j++)
            {
            rpair[i][j] = rpair[j][i]= 1;
            for (b11 = A; (long)b11 <= (long)G; b11 = (basetype)((long)b11 + 1))
                 {
                 if (*sitesforREC[i][(long)b11 - (long)A] != 0L)
                     {
                     tempb1 = b11;
                     tempb1 = (long)tempb1 + 1;
                     for (b12 = tempb1;(long)b12 <= (long)T;b12 = (basetype)((long)b12 + 1))
                         {
                         if (*sitesforREC[i][(long)b12 - (long)A] != 0L)
                             {
                             for (b21 = A;(long)b21 <= (long)G;b21 = (basetype)((long)b21 + 1))
                                 {
                                 if (*sitesforREC[j][(long)b21 - (long)A] != 0L)
                                     {
                                      tempb2 = b21;
                                      tempb2 = (long)tempb2 + 1;
                                      for (b22 = tempb2;(long)b22 <= (long)T;b22 = (basetype)((long)b22 + 1))
                                          {
                                          if (*sitesforREC[j][(long)b22 - (long)A] != 0L)
                                              {
                                              if (*sitesforREC[i][(long)b11 - (long)A] != 0L && 
                                                 *sitesforREC[i][(long)b12 - (long)A] != 0L &&
                                                 *sitesforREC[j][(long)b21 - (long)A] != 0L &&
                                                 *sitesforREC[j][(long)b22 - (long)A] != 0L)
                                                 {
                                                 dset = *P_setint(SET, sitesforREC[i][(long)b11 - (long)A],sitesforREC[j][(long)b21 - (long)A]);
                                                 dset = *P_setint(SET1, sitesforREC[i][(long)b11 - (long)A],sitesforREC[j][(long)b22 - (long)A]);
                                                 dset = *P_setint(SET2, sitesforREC[i][(long)b12 - (long)A],sitesforREC[j][(long)b21 - (long)A]);
                                                 dset = *P_setint(SET3, sitesforREC[i][(long)b12 - (long)A],sitesforREC[j][(long)b22 - (long)A]);
                                                 if ((*P_setint(SET, sitesforREC[i][(long)b11 - (long)A],
                                                     sitesforREC[j][(long)b21 - (long)A]) != 0L &&
                                                    *P_setint(SET1, sitesforREC[i][(long)b11 - (long)A],
                                                     sitesforREC[j][(long)b22 - (long)A]) != 0L &&
                                                    *P_setint(SET2, sitesforREC[i][(long)b12 - (long)A],
                                                    sitesforREC[j][(long)b21 - (long)A]) != 0L &&
                                                    *P_setint(SET3, sitesforREC[i][(long)b12 - (long)A],
                                                 sitesforREC[j][(long)b22 - (long)A]) != 0L) != _false)
                                                   {
                                                   rpair[i][j] = rpair[j][i]= 0;
                                                   }
                                                 }
                                                }
                                            }
                                     }
                                 }
                             }
                         }
                     }
                  }
           }
        i =0;
        recintervals[curint][0] = 1;
        recintervals[curint][2] = 0;
        while (i<gcount-1)
            {
            numinfsite = (atoi(rareclass[i]) > 1);
            numsite = 1;
            j=i+1;
            intok = rpair[i][j];
            if (intok) 
                {
                numinfsite += (atoi(rareclass[j]) > 1);
                numsite++;
                }
            while(intok && j < gcount-1)
                {
                j++;
                intok = rpair[i][j];
                k=i+1;
                while (intok && k < j)
                    {
                    intok = rpair[k][j];
                    k++;
                    }
                if (intok)
                    {
                    numinfsite += (atoi(rareclass[j]) > 1);
                    numsite++;
                    }
                }
            j--;
            if (j-i > 0 && numinfsite > /*1 */ 0)
                {
                recintervals[curint][1] = siteseqnums[j];
                recintervals[curint][3] = numsite;
                curint++;
                j++;
                recintervals[curint][0] = siteseqnums[j];
                recintervals[curint][2] = j;
                }
            else
                {
                j++;
                recintervals[curint][0] = siteseqnums[j];
                recintervals[curint][2] = j;
                }
            i = j;
            }
        numblocks = curint;
        for (i=0; i<gcount; i++)
		    free(rpair[i]);
	    free(rpair);
        strcpy(mdivfilename,rname);
        if (chp=strchr(mdivfilename,'.'))
            *chp = '\0';
        strcat(mdivfilename,"_");
        strcat(mdivfilename,groupnames[groupi]);
        while(chp=strchr(mdivfilename,' '))
            *chp = '\0';
        strcat(mdivfilename,".mdiv");
        if ((mdivfile = fopen(mdivfilename, "w")) == NULL){
            printf("\nError opening text file for writing \n"); exit(0);}
        fprintf(mdivfile,"%s\n",mdivfilename);
        fprintf(mdivfile,"pop1?  pop2?\n");
        fprintf(mdivfile,"%d\n",numblocks);
        for (i=0;i<numblocks;i++)
            {
            fprintf(mdivfile,"Block_%d_%d   ?    ?    %d\n",recintervals[i][0],recintervals[i][1],recintervals[i][3]);

            for (j=grouplimitlow-1; j< grouplimithigh;j++)
                {
                strcpy(temps, names[j]);
                while (strlen(temps)<10) strcat(temps," ");
                fprintf(mdivfile,"%s",temps);
                tcount = 1;
                Findnowsit(tcount);
                for (k=recintervals[i][2]; (k<(recintervals[i][2]+recintervals[i][3]))&& (k<gcount);k++)
                    {
                    while (nowsite.seqn != siteseqnums[k]) 
                        {
                        tcount++;
                        Findnowsit(tcount);
                        }
                    assert(nowsite.seqn == siteseqnums[k]);
                    if (nowsite.p[j] == samechar)
                        chi = consensus[tcount-1];
                    else
                        chi = nowsite.p[j];
                    fprintf(mdivfile,"%c",chi);
                    }
                fprintf(mdivfile,"\n");
                }
            }
        fclose(mdivfile);
    }/* print_for_mdiv */

static void print_congruency_matrix(void)
  {
  unsigned int pcount, tcount, lcount, i;
  char linestr[MaxMatrixLineLength], temps[MaxMatrixLineLength];
  basetype b11, b12, b21, b22;
  unsigned int linecount, dataline;
  linetype nowline;
  char ch;
  boolean breakcheck;
  unsigned int FORLIM;
  long SET[SETL], SET1[SETL], SET2[SETL], SET3[SETL];

  FP"\nTable of informative sites. '*' or '+' indicates congruency\n\n");
  if (gcount >= MaxSitesforRec)
      {
      lcount = MaxSitesforRec;
      FP"too many informative sites ( > %d)------ table truncated\n",lcount);
      }
  else lcount = gcount;
  for (linecount = 0; linecount <= 2; linecount++)
      {
      strcpy(linestr, "rarecount ");
      for (i = 0; i < lcount; i++) sprintf(linestr + strlen(linestr), "%c", rareclass[i][linecount]);
      FP "%s\n", linestr);
      }
  FORLIM = numseq + lcount + 6;
  for (linecount = 1; linecount <= FORLIM; linecount++)
      {
      if (linecount <= 6)    nowline = PSN;
      if (linecount <= numseq + 6 && linecount > 6) nowline = DAT;
      if (linecount > numseq + 6)  nowline = POL;
      switch (nowline)
          {
          case PSN:
              strcpy(linestr, "position  ");
              for (i = 0; i < lcount; i++)
                  {
                  sprintf(temps, "%6u", siteseqnums[i]);
                  sprintf(linestr + strlen(linestr), "%c", temps[linecount - 1]);
                  }
              break;
          case DAT:
              strcpy(linestr, names[linecount + grouplimitlow - 8]);
              for (i = 0; i < lcount; i++)
                  {
                  dataline = linecount + grouplimitlow - 7;
                  ch = popchar(dataline, siteseqnums[i]);
                  switch (toupper(ch))
                      {
                      case 'A':
                          strcat(linestr, "A"); break;
                       case 'C':
                         strcat(linestr, "C");  break;
                       case 'G':
                         strcat(linestr, "G");  break;
                       case 'T':
                         strcat(linestr, "T"); break;
                       case 'N':
                         strcat(linestr, "N"); break;
                       case '-':
                         strcat(linestr, "D"); break;
                       case '*':
                         strcat(linestr, "D"); break;
                        }
                    }
                 break;
            case POL:
              pcount = linecount - numseq - 6;
              sprintf(linestr, "%6u", siteseqnums[pcount - 1]);
              for (i = 1; i <= lcount + 4; i++) strcat(linestr, " ");
              linestr[pcount + 9] = 'S';
              breakcheck = _false;
              for (tcount = pcount - 1; tcount >= 1; tcount--)
                  {
                  if (breakcheck)
                    ch = '+';
                  else
                    ch = '*';
                  for (b11 = A; (long)b11 <= (long)G; b11 = (basetype)((long)b11 + 1))
                     {
                     if (*sitesforREC[pcount - 1][(long)b11 - (long)A] != 0L)
                         {
                         tempb1 = b11;
                         tempb1 = (long)tempb1 + 1;
                         for (b12 = tempb1;(long)b12 <= (long)T;b12 = (basetype)((long)b12 + 1))
                             {
                             if (*sitesforREC[pcount - 1][(long)b12 - (long)A] != 0L)
                                 {
                                 for (b21 = A;(long)b21 <= (long)G;b21 = (basetype)((long)b21 + 1))
                                     {
                                     if (*sitesforREC[tcount - 1][(long)b21 - (long)A] != 0L)
                                         {
                                          tempb2 = b21;
                                          tempb2 = (long)tempb2 + 1;
                                          for (b22 = tempb2;(long)b22 <= (long)T;b22 = (basetype)((long)b22 + 1))
                                              {
                                              if (*sitesforREC[tcount - 1][(long)b22 - (long)A] != 0L)
                                                  {
                                                  if (*sitesforREC[pcount - 1][(long)b11 - (long)A] != 0L && 
                                                     *sitesforREC[pcount - 1][(long)b12 - (long)A] != 0L &&
                                                     *sitesforREC[tcount - 1][(long)b21 - (long)A] != 0L &&
                                                     *sitesforREC[tcount - 1][(long)b22 - (long)A] != 0L)
                                                     {
                                                     if ((*P_setint(SET, sitesforREC[pcount - 1][(long)b11 - (long)A],
                                                         sitesforREC[tcount - 1][(long)b21 - (long)A]) != 0L &&
                                                        *P_setint(SET1, sitesforREC[pcount - 1][(long)b11 - (long)A],
                                                         sitesforREC[tcount - 1][(long)b22 - (long)A]) != 0L &&
                                                        *P_setint(SET2, sitesforREC[pcount - 1][(long)b12 - (long)A],
                                                        sitesforREC[tcount - 1][(long)b21 - (long)A]) != 0L &&
                                                        *P_setint(SET3, sitesforREC[pcount - 1][(long)b12 - (long)A],
                                                     sitesforREC[tcount - 1][(long)b22 - (long)A]) != 0L) != _false)
                                                       {
                                                       breakcheck = _true;
                                                       ch = ' ';
                                                       }
                                                     }
                                                    }
                                                }
                                         }
                                     }
                                 }
                             }
                         }
                      }
                  linestr[tcount + 9] = ch;
                  }
              breakcheck = _false;
              for (tcount = pcount + 1; tcount <= lcount; tcount++)
                  {
                   if (breakcheck)
                     ch = '+';
                   else
                     ch = '*';
                   for (b11 = A; (long)b11 <= (long)G; b11 = (basetype)((long)b11 + 1))
                       {
                       if (*sitesforREC[pcount - 1][(long)b11 - (long)A] != 0L)
                           {
                            tempb1 = b11;
                            tempb1 = (long)tempb1 + 1;
                            for (b12 = tempb1;(long)b12 <= (long)T;b12 = (basetype)((long)b12 + 1))
                                {
                                if (*sitesforREC[pcount - 1][(long)b12 - (long)A] != 0L)
                                    {
                                    for (b21 = A;(long)b21 <= (long)G; b21 = (basetype)((long)b21 + 1))
                                        {
                                        if (*sitesforREC[tcount - 1][(long)b21 - (long)A] != 0L)
                                            {
                                            tempb2 = b21;
                                            tempb2 = (long)tempb2 + 1;
                                            for (b22 = tempb2;(long)b22 <= (long)T;b22 = (basetype)((long)b22 + 1))
                                                {
                                                if (*sitesforREC[tcount - 1][(long)b22 - (long)A] != 0L)
                                                    {
                                                     if (*sitesforREC[pcount - 1][(long)b11 - (long)A] != 0L &&
                                                         *sitesforREC[pcount - 1][(long)b12 - (long)A] != 0L &&
                                                         *sitesforREC[tcount - 1][(long)b21 - (long)A] != 0L &&
                                                         *sitesforREC[tcount - 1][(long)b22 - (long)A] != 0L)
                                                         {
                                                         if ((*P_setint(SET,sitesforREC[pcount - 1][(long)b11 - (long)A],sitesforREC[tcount - 1][(long)b21 - (long)A]) != 0L
                                                            &&
                                                            *P_setint(SET1,sitesforREC[pcount - 1][(long)b11 - (long)A],sitesforREC[tcount - 1][(long)b22 - (long)A]) != 0L
                                                            &&
                                                            *P_setint(SET2,sitesforREC[pcount - 1][(long)b12 - (long)A],sitesforREC[tcount - 1][(long)b21 - (long)A]) != 0L
                                                            &&
                                                            *P_setint(SET3,sitesforREC[pcount - 1][(long)b12 - (long)A],sitesforREC[tcount - 1][(long)b22 - (long)A]) != 0L) != _false)
                                                             {
                                                              breakcheck = _true;
                                                              ch = ' ';
                                                             }
                                                         }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                           }
                       }
                    linestr[tcount + 9] = ch;
                    }
              break;
          }/*big case statement*/
      FP "%s\n", linestr);
      }
  }  /*print_congruency_matrix*/

static void prep_rec_analysis(unsigned int groupi, int cutoff, boolean cleansites){
/* generates stuff needed for polymorphic sites, for printing matrices
  if cutoff==2, uses only informative sites, 
  if cutoff==1, uses all polymorphic sites within igroup 
  Fills up an array, one element per polymorphic site
    each element is an array of sets, with one element for each base
    the set contains the info on which sequences have which base
    this can be used by other functions to consider pairwise base values (LD etc)
    */
  static site full = {0, 0, 0, 0, 0};
  char temprareclass[4];
  unsigned int i, j, tcount;
  char ch;
  unsigned int  numone, numtwo, rarecount;
  unsigned int spot;
  basetype tempbase;
  unsigned int FORLIM;
  unsigned int  basecount[(long)X - (long)A + 1];
  boolean  siteisclean;
 
    if (groupi >= numgroups)
        {
        numseq = nums;
        grouplimitlow = 1;
        grouplimithigh = nums;
        } 
    else
        {
        numseq = groupsize[groupi];
        grouplimitlow = grouplimits[groupi][0];
        grouplimithigh = grouplimits[groupi][1];
        }
    FORLIM = numseq;
    for (i = 1; i <= FORLIM; i++)
        {
        for (tempbase = A;(long)tempbase <= (long)T;tempbase = (basetype)((long)tempbase + 1))
            P_addset(full[(long)tempbase - (long)A], i);
        }
    gcount = 0;
    tcount = 1;
    while (gcount < MaxSitesforRec && tcount <= scount)
        {
        Findnowsit(tcount);
        siteisclean = _true;
        if (cleansites)
            {
            for (i=0;i<= numindeldrop;i++)
                if (nowsite.seqn == indeldroplist[i]) siteisclean= _false;
            if (siteisclean)
                for (i=0;i<= numindeldrop;i++)
                    if (nowsite.seqn == multibasedroplist[i]) siteisclean= _false;
            }
        if ((cutoff==2 && nowsite.s[(long)INF - (long)EXN] && nowsitefit(nowsite))||(cutoff==1 && nowsitefit(nowsite)))
            {
            spot = nowsite.seqn;
            for (tempbase = A;(long)tempbase <= (long)X;tempbase = (basetype)((long)tempbase + 1))
                basecount[(long)tempbase - (long)A] = 0;
            FORLIM = grouplimithigh;
            for (j = grouplimitlow; j <= FORLIM; j++)
                {
                ch = popchar(j, spot);
                switch (ch)
                    {
                    case 'A':
                     basecount[0]++;
                     break;
                    case 'C':
                     basecount[(long)C - (long)A]++;
                     break;
                    case 'G':
                     basecount[(long)G - (long)A]++;
                     break;
                    case 'T':
                     basecount[(long)T - (long)A]++;
                     break;
                    case '*':
                     basecount[(long)D - (long)A]++;
                     break;
                    case '-':
                     basecount[(long)D - (long)A]++;
                     break;
                    default:
                     basecount[(long)X - (long)A]++;
                     break;
                    }
                }
            numtwo = 0;
            numone = 0;
            rarecount = MaxS / 2;
            for (tempbase = A;(long)tempbase <= (long)D;tempbase = (basetype)((long)tempbase + 1))
                {
                if (((long)tempbase <= (long)T) ||(tempbase == D && nowsite.s[0] && nowsite.s[(long)INT - (long)EXN]))
                    {
                    if ( basecount[(long)tempbase - (long)A] >= cutoff && basecount[(long)tempbase - (long)A] < rarecount)
                        rarecount = basecount[(long)tempbase - (long)A];
                    if (basecount[(long)tempbase - (long)A] >= 1)  numone++;
                    if (basecount[(long)tempbase - (long)A] >= 2)  numtwo++;
                    }
                }
            tempbase = D;
            if ((cutoff ==1 && numone > 1)||(cutoff==2 && numtwo > 1))
                {
                gcount++;
                siteseqnums[gcount - 1] = spot;
                if (rarecount >= 100)
                    {
                    sprintf(rareclass[gcount - 1], "%3d", rarecount);
                    }
                else 
                    if (rarecount >= 10)
                        {
                        sprintf(temprareclass, "%2d", rarecount);
                        sprintf(rareclass[gcount - 1], " %s", temprareclass);
                        }
                    else
                        {
                        sprintf(temprareclass, "%d", rarecount);
                        sprintf(rareclass[gcount - 1], "  %s", temprareclass);
                        }
                for (tempbase = A;(long)tempbase <= (long)D;tempbase = (basetype)((long)tempbase + 1))
                    P_expset(sitesforREC[gcount - 1][(long)tempbase - (long)A], 0L);
                FORLIM = grouplimithigh;
                for (i = grouplimitlow; i <= FORLIM; i++)
                    {
                    for (tempbase = A;(long)tempbase <= (long)T;tempbase = (basetype)((long)tempbase + 1))
                        {
                        if (makebase(popchar(i, spot)) == tempbase)
                            P_addset(sitesforREC[gcount - 1][(long)tempbase - (long)A], i);
                        }
                    tempbase = D;
                    if (popchar(i, spot) == indelchar)
                        P_addset(sitesforREC[gcount - 1][(long)tempbase - (long)A], i);
                    }
                }
            }
        tcount++;
        }
    }/* prep_rec_analysis */

static double make_gamma(unsigned int groupi){
  unsigned int  j, S1, S2;
  unsigned int spot, spot1, spot2;
  boolean founds1;
  long nowsamp;
  double sumsetc, sumc, tempsetc, tempc;
  unsigned int countsetc, countc, FORLIM;
  long FORLIM1;
  unsigned int FORLIM2;
  char ch;
  unsigned int  basecount[(long)X - (long)A + 1];
  char rcp[4][3];
  char rcp1[4];
  unsigned int  numtwo;
  basetype tempbase;

  if (groupsize[groupi] > 100) tempnterm= Max4samps+1;
   else tempnterm = fact[groupsize[groupi]] /
      (fact[4] * fact[groupsize[groupi] - 4]);
  if (tempnterm > Max4samps) {
       randompicksset = _true;
       num4samps = Max4samps;
   }
   else {
       randompicksset= _false;
       num4samps = (int) tempnterm;
   }
    
  MakeSamples();
  countc = 0;
  sumc = 0.0;
  if (gcount > 1) {
    FORLIM1 = num4samps;
    for (nowsamp = 0; nowsamp < FORLIM1; nowsamp++) {
      S1 = 1;
      paircount = 0;
      do {
   do {
     founds1 = _false;
     spot = siteseqnums[S1 - 1];
     for (tempbase = A;
          (long)tempbase <= (long)X;
          tempbase = (basetype)((long)tempbase + 1))
       basecount[(long)tempbase - (long)A] = 0;
     for (j = 0; j <= 3; j++) {
       ch = popchar(ssetarrays[nowsamp][j], spot);
       rcp1[j] = ch;
       switch (ch) {

       case 'A':
         basecount[0]++;
         break;

       case 'C':
         basecount[(long)C - (long)A]++;
         break;

       case 'G':
         basecount[(long)G - (long)A]++;
         break;

       case 'T':
         basecount[(long)T - (long)A]++;
         break;

       case '*':
         basecount[(long)D - (long)A]++;
         break;

       case '-':
         basecount[(long)D - (long)A]++;
         break;

       default:
         basecount[(long)X - (long)A]++;
         break;
       }
     }
     numtwo = 0;
     for (tempbase = A;
          (long)tempbase <= (long)T;
          tempbase = (basetype)((long)tempbase + 1))
     {   /*D*/
       if (basecount[(long)tempbase - (long)A] == 2)
         numtwo++;
     }
     if (numtwo == 2)
       founds1 = _true;
     else
       S1++;
   } while (!(founds1 || S1 >= gcount));
   if (founds1 && S1 < gcount) {
     S2 = S1 + 1;
     do {
       spot = siteseqnums[S2 - 1];
       for (tempbase = A;
       (long)tempbase <= (long)X;
       tempbase = (basetype)((long)tempbase + 1))
         basecount[(long)tempbase - (long)A] = 0;
       for (j = 0; j <= 3; j++) {
         ch = popchar(ssetarrays[nowsamp][j], spot);
         sprintf(rcp[j], "%c%c", rcp1[j], ch);
         switch (ch) {

         case 'A':
      basecount[0]++;
      break;

         case 'C':
      basecount[(long)C - (long)A]++;
      break;

         case 'G':
      basecount[(long)G - (long)A]++;
      break;

         case 'T':
      basecount[(long)T - (long)A]++;
      break;

         case '*':
      basecount[(long)D - (long)A]++;
      break;

         case '-':
      basecount[(long)D - (long)A]++;
      break;

         default:
      basecount[(long)X - (long)A]++;
      break;
         }
       }
       numtwo = 0;
       for (tempbase = A;
       (long)tempbase <= (long)T;
       tempbase = (basetype)((long)tempbase + 1))
       {   /*D*/
         if (basecount[(long)tempbase - (long)A] == 2)
      numtwo++;
       }
       if (numtwo == 2) {
         spot1 = siteseqnums[S1 - 1];
         spot2 = siteseqnums[S2 - 1];
         paircount++;
         xy2[paircount - 1] = abs(spot2 - spot1);
         if (strcmp(rcp[0], rcp[1]) && strcmp(rcp[0], rcp[2]) &&
        strcmp(rcp[0], rcp[3]) && strcmp(rcp[1], rcp[2]) &&
        strcmp(rcp[1], rcp[3]) && strcmp(rcp[2], rcp[3]))
      xy1[paircount - 1] = 1;
         else
      xy1[paircount - 1] = 0;
         S1 = S2;
       } else
         S2++;
     } while (numtwo != 2 && S2 <= gcount);
   } else
     S2 = gcount + 1;
      } while (S2 <= gcount && S1 < gcount);

      if (paircount >= 2) {
   sumsetc = 0.0;
   countsetc = 0;
   FORLIM = paircount;
   for (xyspot1 = 1; xyspot1 < FORLIM; xyspot1++) {
     FORLIM2 = paircount;
     for (xyspot2 = xyspot1 + 1; xyspot2 <= FORLIM2; xyspot2++) {
       if (xy1[xyspot1 - 1] == 1 && xy1[xyspot2 - 1] == 1)
         tempsetc = -1.0;
       else if (xy1[xyspot1 - 1] == 0 && xy1[xyspot2 - 1] == 0)
         countsetc++;
       else {
         HW4NC(groupi, &tempsetc);
         /*                    ax := 1e-8;
                             bx := 1e-1;
                             brakfind := mnbrak(ax,bx,cx,fa,fb,fc);
                             if brakfind then  minimaxi := golden(ax,bx,cx,tol,tempsetc)
                                else tempsetc := -1.0;*/
         if (tempsetc >= 0.0) {
      sumsetc += tempsetc;
      countsetc++;
         }
       }
     }  /*xyspot2 loop*/
   }  /*xyspot1 loop*/
   if (countsetc > 0)
     tempc = sumsetc / countsetc;
   else
     tempc = -1.0;
   if (tempc >= 0.0) {
     sumc += tempc;
     countc++;
   }
      }

    }
  }
  if (countc > 0)
    tempc = sumc / countc;
  else
    tempc = -1.0;
  return(tempc);
} /*make_gamma*/

static void   print_rec_intervals(void){
  unsigned int GroupRecpairs[MaxGroupRecPairs][2];
  unsigned int i, S1, S2;
  int   FORLIM;
   basetype b11, b12, b21, b22;
  boolean news1;
 int tpair, next, numpair, lesspair;
    long SET[SETL], SET1[SETL];
  long SET2[SETL], SET3[SETL];

   numpair = 0;
  if (gcount > 1) {
    FORLIM = gcount - 2;
    for (S1 = 0; S1 <= FORLIM; S1++) {
      news1 = _true;
      for (S2 = gcount - 1; S2 >= S1 + 1; S2--) {
   for (b11 = A; (long)b11 <= (long)G; b11 = (basetype)((long)b11 + 1)) {
     tempb1 = b11;
     tempb1 = (long)tempb1 + 1;
     for (b12 = tempb1;
          (long)b12 <= (long)T;
          b12 = (basetype)((long)b12 + 1)) {
       for (b21 = A; (long)b21 <= (long)G; b21 = (basetype)((long)b21 + 1)) {
         tempb2 = b21;
         tempb2 = (long)tempb2 + 1;
         for (b22 = tempb2;
         (long)b22 <= (long)T;
         b22 = (basetype)((long)b22 + 1)) {
      if (*sitesforREC[S1][(long)b11 - (long)A] != 0L &&
          *sitesforREC[S1][(long)b12 - (long)A] != 0L &&
          *sitesforREC[S2][(long)b21 - (long)A] != 0L &&
          *sitesforREC[S2][(long)b22 - (long)A] != 0L) {
        if (*P_setint(SET, sitesforREC[S1]
           [(long)b11 - (long)A], sitesforREC[S2]
           [(long)b21 - (long)A]) != 0L &&
            *P_setint(SET1, sitesforREC[S1]
           [(long)b11 - (long)A], sitesforREC[S2]
           [(long)b22 - (long)A]) != 0L &&
            *P_setint(SET2, sitesforREC[S1]
           [(long)b12 - (long)A], sitesforREC[S2]
           [(long)b21 - (long)A]) != 0L &&
            *P_setint(SET3, sitesforREC[S1]
           [(long)b12 - (long)A], sitesforREC[S2]
           [(long)b22 - (long)A]) != 0L) {
          if (news1) {
            numpair++;
            news1 = _false;
          }
          GroupRecpairs[numpair - 1][0] = siteseqnums[S1];
          GroupRecpairs[numpair - 1][1] = siteseqnums[S2];
        }
      }
         }
       }
     }
   }
      }
    }
  }
  GroupRecpairs[numpair][0] = 0;
  GroupRecpairs[numpair][1] = 0;
  /*now screen for smallest intervals beginning with second site*/
  tpair = numpair;
  next = tpair - 1;
  lesspair = 0;
  while (next >= 1) {
    if (GroupRecpairs[tpair - 1][1] == GroupRecpairs[next - 1][1] &&
   GroupRecpairs[tpair - 1][0] > GroupRecpairs[next - 1][0]) {
      GroupRecpairs[next - 1][0] = 0;
      GroupRecpairs[next - 1][1] = 0;
      next--;
      lesspair++;
    } else {
      tpair = next;
      next = tpair - 1;
    }
  }
  tpair = numpair;
  numpair -= lesspair;
  lesspair = 0;
  next = 1;
  do {
    if (GroupRecpairs[next - 1][0] == 0) {
      FORLIM = tpair - lesspair;
      for (i = next; i <= FORLIM; i++) {
   GroupRecpairs[i - 1][0] = GroupRecpairs[i][0];
   GroupRecpairs[i - 1][1] = GroupRecpairs[i][1];
      }
      lesspair++;
    } else
      next++;
  } while (next != numpair + 1);

  /*now screen for overlapping intervals*/
  tpair = 1;
  next = 2;
  lesspair = 0;
  while (next <= numpair) {
    if (GroupRecpairs[next - 1][0] > GroupRecpairs[tpair - 1][0] &&
   GroupRecpairs[tpair - 1][1] > GroupRecpairs[next - 1][0]) {
      GroupRecpairs[next - 1][0] = 0;
      GroupRecpairs[next - 1][1] = 0;
      next++;
      lesspair++;
    } else {
      tpair = next;
      next = tpair + 1;
    }
  }
  tpair = numpair;
  numpair -= lesspair;
  lesspair = 0;
  next = 1;
  do {
    if (GroupRecpairs[next - 1][0] == 0) {
      FORLIM = tpair - lesspair;
      for (i = next; i <= FORLIM; i++) {
   GroupRecpairs[i - 1][0] = GroupRecpairs[i][0];
   GroupRecpairs[i - 1][1] = GroupRecpairs[i][1];
      }
      lesspair++;
    } else
      next++;
  } while (next != numpair + 1);
 /*FP "%s\n", groupnames[groupi - 1]);
  for (j=1; j < MaxGroupNameLength;j++) FP"-"); */
  FP"  Minimal set of recombination intervals  - # of Intervals : %3d \n",numpair);
  FP"       Site 1   -  Site 2 \n");
  for (i = 0; i < numpair; i++)
    FP "         %4u       %u\n",
       GroupRecpairs[i][0], GroupRecpairs[i][1]);
} /* print_rec_intervals */

void GroupRECsites(unsigned int  groupi,unsigned int pass)
/* 0<= groupi <= numgroups-1 */
    {
    unsigned int j;
    double gammabp, hud,hudbp, c_per_u, watterm;
 
    prep_rec_analysis(groupi,2,_false);
    if (groupsize[groupi] <= 3)
        {
        if (pass==1)
            {
            FP "%s ", groupnames[groupi]);
            FP"%3d ", groupsize[groupi]);
            FP"   Too few sequences for recombination analysis\n");
            }
        else /*pass==2 */
            FP"      Too few sequences for recombination analysis\n");
        }
    else
       {
       prep_rec_analysis(groupi,2,_false);
       if ( pass==1 )
           {
           /*gammabp = make_gamma(groupi);
           hud = Hudson4NC(groupi);
           FP "%s ", groupnames[groupi]);
           FP"%3d ", groupsize[groupi]);
           if ( gammabp >= 0.0 )
               {
               gammarray[groupi] = gammabp * groupcompbases[groupi][groupi];
               watterm = 1.0;
               for (j = 2; j < groupsize[groupi]; j++)
                   watterm += 1.0 / j;
               c_per_u = gammarray[groupi] / (polysite[groupi] / watterm);
               FP"%5d ", num4samps);
               FP"%10.3f ",gammarray[groupi]);
               FP"%10.6f ", gammabp);
               FP"%8.4f ", c_per_u);
               }
           else FP"        -  could not estimate gamma  ");
           if ( hud > 0.0 )
               {
               hudbp  = hud / groupcompbases[groupi][groupi];
               FP "%10.3f ", hud);
               FP "%10.6f ",hudbp);
               }
           else FP"-could not estimate hud4Nc "); */
           putc('\n',rfile);
            }
       else /*pass==2 */
           {
            print_congruency_matrix();
            print_rec_intervals();
            if (DoMDIVoutput)
                print_for_mdiv(groupi);
            }
        }
    }  /*GroupRECsites*/

void insertindels(void)
{
  /*this finds those insertions that are not tangled in adjacent insertions.
Once found then the middle of the insertion is found.
Then that position in the linked list of polymorphic sites is altered.
The [EXN] and [INT] positions are both set to _true;
This is a signal to the recombination analysis program to use the site*/
  unsigned int i, j, k, IDsnum, IDlength, IDspot;
  boolean frontOK, backOK;
  long nowdset[SETL], frontdset[SETL], backdset[SETL];
  char ch;
  long SET[SETL];
  unsigned int FORLIM, FORLIM1;

  j = 0;
  if (nowsite_ptr) Findnowsit(1);
  P_expset(frontdset, 0L);
  P_expset(backdset, 0L);
  P_expset(nowdset, 0L);
  FORLIM = idcount;
  for (i = 0; i < FORLIM; i++) {
    FindnowIDsit(i + 1);
    IDsnum = nowIDsit.seqn;
    IDlength = indellengths[i];
    P_setcpy(backdset, nowdset);
    P_setcpy(nowdset, frontdset);
    P_expset(frontdset, 0L);
    if (i + 1 == idcount)
      frontOK = _true;
    else {
      FORLIM1 = nums;
      for (k = 1; k <= FORLIM1; k++) {
   if (nowIDsite_ptr->next->p[k - 1] == samechar)
     ch = IDconsensus[i + 1];
   else
     ch = nowIDsite_ptr->next->p[k - 1];
   if (ch == indelchar)
     P_addset(frontdset, k);
      }
      frontOK = (*P_setint(SET, frontdset, nowdset) == 0L ||
       IDsnum + IDlength < nowIDsite_ptr->next->seqn);
    }
    if (i + 1 == 1) {
      backOK = _true;
      FORLIM1 = nums;
      for (k = 1; k <= FORLIM1; k++) {
   if (nowIDsite_ptr->p[k - 1] == samechar)
     ch = IDconsensus[i];
   else
     ch = nowIDsite_ptr->p[k - 1];
   if (ch == indelchar)
     P_addset(nowdset, k);
      }
    } else
      backOK = (*P_setint(SET, backdset, nowdset) == 0L ||
      nowIDsite_ptr->last->seqn + indellengths[i - 1] < IDsnum);
    if (frontOK && backOK) {
      IDspot = IDsnum + indellengths[i] / 2;
      do {
   j++;
   Findnowsit(j);
      } while (nowsite.seqn != IDspot);
      nowsite_ptr->s[0] = _true;
      nowsite_ptr->s[(long)INT - (long)EXN] = _true;
    }
  }
}  /*insertindels*/


/* need to measure LD between pairs of sites, and take the average for a species
    must assess it for all polymorphisms within each species, 
    also separately for those that are shared with each other species,
    and for those that are not shared with each other species 
This means that every set of average LD measures for a species is done with respect 
    to each other species 
*/

void calcLD(unsigned int x[4], float *LD){
    float p1,q1,p2,q2;
    float xf[4];
    int  i;
    float n,D,denom,r,rsq, Dmax,Dprime;
/*enum {LDR,LDRS,LDD,LDABS,LDPABS,LDDP}; */
    for (i=0,n=0;i< 4;i++) n += x[i];
    if ((n<4)||(x[0] + x[1] == 0) ||(x[0] + x[2] == 0)||(x[2] + x[3] == 0)||(x[1] + x[3] == 0)) {
        LD[LDR] = Dfault;LD[LDRS] = Dfault;LD[LDD] = Dfault;LD[LDABS] = Dfault;LD[LDPABS] = Dfault;LD[LDDP] = Dfault;
    } else {
    for (i=0;i< 4;i++) xf[i] = (float) x[i] /(float) n;
    p1 = xf[0] + xf[1];
    p2 = xf[2] + xf[3];
    q1 = xf[0] + xf[2];
    q2 = xf[1] + xf[3];
    D = xf[0]*xf[3] - xf[1]*xf[2];
    if (D>0){
        if (p1*q2 < p2*q1) Dmax = p1*q2; else Dmax = p2*q1;
    } else{
        if (p1*q1 < p2*q2) Dmax = p1*q1; else Dmax = p2*q2;
    }
    Dprime = D/Dmax;
    LD[LDD] = D;
    LD[LDABS] = fabs(D);
    LD[LDDP] = Dprime;
    LD[LDPABS] = fabs(Dprime);
    denom = p1*q1*p2*q2;
    if (n > 0.0 && denom > 0.0){
        denom = sqrt(denom);
        r = D/denom;
        rsq = r*r;
        LD[LDR] = r;
        LD[LDRS] = rsq;
    }else {
        LD[LDR] = Dfault;
        LD[LDRS] = Dfault;
    }
    }
} /* calcLD */

double logfact(int n)
{
  int i;
  double sum;
  sum=.0;
  for (i=1;i<=n;i++) {
     sum=sum+log(i+.0);

  }
return(sum);
}

  /* debugging LD 
static float tempx[4],meanx[4]; */
/* LDtestcode
    '-'  could not do test
    '0' p> 0.9
    '1' p< 0.1
    '2' p< 0.05
    '3' p< 0.01
    '4' p< 0.005
    '5' p< 0.001
    '6' p< 0.0001
    '7' p< 0.00001
    '8' p< 0.000001 */

void calcLDtest(unsigned int x[4], char *fetchar, char *chisquarechar){
  int a,b,c,d,a1,b1,c1,d1,i,n;
  float af,bf,cf,df;
  double p,q,sum;
  double logfact(int);
  a = x[0];b=x[1];c=x[2];d=x[3];
  sum=.0;
  if (a*b*c*d==0) {
        if (d==0)  {a1=a; a=b; b=a1; a1=c; c=d; d=a1;}
  }
  else if ((a+.0)/(b+.0)<(c+.0)/(d+.0)) {a1=a; a=b; b=a1; a1=c; c=d; d=a1;}
  p=logfact(a+b)+logfact(a+c)+logfact(b+d)+logfact(c+d)-logfact(a+b+c+d);
  for (i=b;i>=0; i--) {
   b1=i; a1=a+b-b1; c1=a+c-a1; d1=b+d-b1;

   q=logfact(a1)+logfact(b1)+logfact(c1)+logfact(d1);

   sum=exp(p-q)+sum;
   if(a1*b1*c1*d1==0) goto out100;
  }
out100:;
  i = 1;
  while ((sum < LDfettestval[i]) && (i < LDVALINTS)) i++;
  *fetchar = LDtestcode[i-1];

  a = x[0];b=x[1];c=x[2];d=x[3];
  n = a+b+c+d;
  af = (a+b)*(a+c)/(float) n;
  bf = (a+b)*(b+d)/(float) n;
  cf = (c+d)*(a+c)/(float) n;
  df = (c+d)*(b+d)/(float) n;
  if (af*bf*cf*df > 0.0){
      sum = SQR(a - af)/af + SQR(b - bf)/bf + SQR(c - cf)/cf + SQR(d - df)/df;
  } else sum = 0.0;
  i = 1;
  while ((sum > LDchisquareval[i]) && (i < LDVALINTS)) i++;
  *chisquarechar = LDtestcode[i-1];
} /* calcLDtest */

boolean GetLD(int groupi, float *LDval){
/* makes use of variation at nowsite and nowsite1, both must be set and checked before getLD is called */
/* checks to see if the two sites are both polymorphic in groupi, if so returns LD */
/* sites must be polymorphic for bases A,C,G,T  - gaps are not counted */
/* if the outgroup has a gap at a base, the most common base is used for rooting */
/* cannot deal with indel variation, */

  unsigned int  basecount1[(long)X - (long)A + 1], basecount2[(long)X - (long)A + 1];
  basetype base, commonbase1,commonbase2;
  char chi,chj, ancestralchar1,ancestralchar2;
  unsigned short  ispoly1, ispoly2;
  char  basechar[5] = {'A','C','G','T','D'};
  unsigned int x[4];
  char outchar;
  basetype outbase;
  boolean  oksofar, outbaseok;
  int i;
  int localLDmeasure;

oksofar = _true;

/* get info on 1st site */
for (base = A; (long)base <= (long)X; base = (basetype)((long)base + 1))
        basecount1[(long)base - (long)A] = 0;
for (i = grouplimits[groupi][0] - 1; i < grouplimits[groupi][1]; i++) {
    if (nowsite.p[i] == samechar)   chi = consensus[nowsite.sitn-1];
        else   chi = nowsite.p[i];
    switch (chi) {
        case 'A':basecount1[0]++;break;
        case 'C':basecount1[(long)C - (long)A]++;break;
        case 'G':basecount1[(long)G - (long)A]++;break;
        case 'T':basecount1[(long)T - (long)A]++;break;
        case '*':basecount1[(long)D - (long)A]++;break;
        case '-':basecount1[(long)D - (long)A]++;break;
        case 'N':basecount1[(long)X - (long)A]++;break;
        }
  }
ispoly1 = 0;
for (base = A;(long)base <= (long)T; base = (basetype)((long)base + 1)){
    if (basecount1[(long)base - (long)A] > exclude_singletons /* _false (= 0) when singletons are included, _true=1 if excluded */) ispoly1++;
}
if ((basecount1[(long)D - (long)A] > exclude_singletons /* _false (= 0) when singletons are included, _true=1 if excluded */)&& nowsite.s[EXN] && nowsite.s[INT]) ispoly1++;
if (ispoly1==1) ispoly1 = 0;
    else  if (ispoly1>1) ispoly1 = 1;
if (ispoly1){ /*4: loop 1st site is polymorphic */
    /* figure out which is the ancestral base, if not found make it the common base */
    if (outgroup[groupi] > 0) {
        outchar = nowsite.p[grouplimits[outgroup[groupi] - 1][0] - 1];
        if (outchar=='N') outchar = nowsite.p[grouplimits[outgroup[groupi] - 1][1] - 1];
        if (outchar==samechar) outchar = consensus[nowsite.sitn-1];
        switch (outchar) {
            case 'A': outbase = A; break;
            case 'C': outbase = C; break;
            case 'G': outbase = G; break;
            case 'T': outbase = T; break;
            case '*': outbase = D; outchar = 'D'; break;
            case '-': outbase = D; outchar = 'D'; break;
            default: outbase = D; break;
        } 
    } else outbase = X;
    if  (outbase < D /* don't use D's or X's to root */ && basecount1[outbase] > 0) outbaseok = _true;
     else outbaseok = _false;
    /* debug  outbaseok = _false; */
    if (!outbaseok){
        commonbase1 = A;
        for (base = C;(long)base <= (long)D; base = (basetype)((long)base + 1)){
            if ((basecount1[(long)base - (long)A] > 0)&&(basecount1[(long)commonbase1 - (long)A] < basecount1[(long)base - (long)A])) commonbase1 = base;
        }
        ancestralchar1 = basechar[commonbase1];
    } else {
        ancestralchar1 = outchar;
    }

   /* now get info on 2nd site */            
   for (base = A;(long)base <= (long)X; base = (basetype)((long)base + 1))
    basecount2[(long)base - (long)A] = 0;
   for (i = grouplimits[groupi][0] - 1; i < grouplimits[groupi][1]; i++) {
    if (nowsite1.p[i] == samechar)   chi = consensus[nowsite1.sitn-1];
        else   chi = nowsite1.p[i];
    switch (chi) {
        case 'A':basecount2[0]++;break;
        case 'C':basecount2[(long)C - (long)A]++;break;
        case 'G':basecount2[(long)G - (long)A]++;break;
        case 'T':basecount2[(long)T - (long)A]++;break;
        case '*':basecount2[(long)D - (long)A]++;break;
        case '-':basecount2[(long)D - (long)A]++;break;
        case 'N':basecount2[(long)X - (long)A]++;break;
        }
    }
    ispoly2 = 0;
    for (base = A;(long)base <= (long)T; base = (basetype)((long)base + 1)){
        if (basecount2[(long)base - (long)A] > exclude_singletons /* _false (= 0) when singletons are included, _true=1 if excluded */) ispoly2++;
    }
    if ((basecount2[(long)D - (long)A] > exclude_singletons /* _false (= 0) when singletons are included, _true=1 if excluded */)&& nowsite1.s[EXN] && nowsite1.s[INT]) ispoly2++;
    if (ispoly2==1) ispoly2 = 0; else  if (ispoly2>1) ispoly2 = 1;
    if (ispoly2){   /*7: 2nd site is polymorphic */
    /* figure out which is the ancestral base, if not found make it the common base */
        if (outgroup[groupi] > 0) {
            outchar = nowsite1.p[grouplimits[outgroup[groupi] - 1][0] - 1];
            if (outchar=='N') outchar = nowsite1.p[grouplimits[outgroup[groupi] - 1][1] - 1];
            if (outchar==samechar) outchar = consensus[nowsite1.sitn-1];
            switch (outchar) {
                case 'A': outbase = A; break;
                case 'C': outbase = C; break;
                case 'G': outbase = G; break;
                case 'T': outbase = T; break;
                case '*': outbase = D; outchar = 'D'; break;
                case '-': outbase = D; outchar = 'D'; break;
                default: outbase = X; break;
            } 
        } else outbase = X;
        if (outbase < D /* don't use D's or X's to root */ && basecount2[outbase] > 0) outbaseok = _true;
         else outbaseok = _false;
         /* debug  outbaseok = _false; */
        if (!outbaseok){
            commonbase2 = A;
            for (base = C;(long)base <= (long)D; base = (basetype)((long)base + 1)){
                if ((basecount2[(long)base - (long)A] > 0)&&(basecount2[(long)commonbase2 - (long)A] < basecount2[(long)base - (long)A])) commonbase2 = base;
            }
            ancestralchar2 = basechar[commonbase2];
        } else {
            ancestralchar2 = outchar;
        }
        /* now fill x */
        for (i=0;i< 4;i++) x[i] = 0;
        for (i = grouplimits[groupi][0] - 1; i < grouplimits[groupi][1]; i++) {
            if (nowsite.p[i] == samechar)   chi = consensus[nowsite.sitn-1];
                else   chi = nowsite.p[i];
            if (nowsite1.p[i] == samechar)   chj = consensus[nowsite1.sitn-1];
                else   chj = nowsite1.p[i];
            if ((chi != 'N') && (chj != 'N')){
             if ((analyses[(long)INDELS - (long)SIT])&&((chi == indelchar) || (chj == indelchar))){
                if ((chi == indelchar) && (chj == indelchar)){
                    if ((ancestralchar1 =='D')&&(ancestralchar2 == 'D')) x[0]++;
                    if ((ancestralchar1 =='D')&&(ancestralchar2 != 'D')) x[1]++;
                    if ((ancestralchar1 !='D')&&(ancestralchar2 == 'D')) x[2]++;
                    if ((ancestralchar1 !='D')&&(ancestralchar2 != 'D')) x[4]++;
                }
                if ((chi == indelchar) && !(chj == indelchar)){
                    if ((ancestralchar1 =='D')&&(chj == ancestralchar2)) x[0]++;
                    if ((ancestralchar1 =='D')&&(chj != ancestralchar2)) x[1]++;
                    if ((ancestralchar1 !='D')&&(chj == ancestralchar2)) x[2]++;
                    if ((ancestralchar1 !='D')&&(chj != ancestralchar2)) x[4]++;
                }
                if (!(chi == indelchar) && (chj == indelchar)){
                    if ((chi == ancestralchar1)&&(ancestralchar2 == 'D')) x[0]++;
                    if ((chi == ancestralchar1)&&(ancestralchar2 != 'D')) x[1]++;
                    if ((chi != ancestralchar1)&&(ancestralchar2 == 'D')) x[2]++;
                    if ((chi != ancestralchar1)&&(ancestralchar2 != 'D')) x[4]++;
                }

             } else {
                if ((chi==ancestralchar1)&&(chj ==ancestralchar2)) x[0]++;
                if ((chi==ancestralchar1)&&(chj !=ancestralchar2)) x[1]++;
                if ((chi!=ancestralchar1)&&(chj ==ancestralchar2)) x[2]++;
                if ((chi!=ancestralchar1)&&(chj !=ancestralchar2)) x[3]++;
             }
            }
        }
        /*for (i=0;i<4;i++) tempx[i] = x[i]; */
        calcLD(x, &LDval[0]);
        if (doLDtest == _true)  calcLDtest(x,&fetchar,&chisquarechar);
    } else oksofar = _false; /* 2nd site is polymorphic */
} else oksofar = _false; /*4: loop 1st site is polymorphic */
if (oksofar){
    for (localLDmeasure = LDR;localLDmeasure <= LDDP; localLDmeasure++) oksofar = (oksofar && (LDval[localLDmeasure] < Dfault_check)) ;
} 

return(oksofar);
} /* GetLD */

#define LDMINN   4

void LD_possibly_imported_stuff(void)
/* measure LD between pairs of sites.
Those sites that may be imported from another species are called shared
However in this routine shared actually includes classic shared polymorphisms, as well
as those that are between two bases and for which the derived base is also fixed in another species.
Each polymorphic site is grouped into a common base (A,C,G,T) and others (anything,including gaps, but not N's)
*/
{
  int i,j;
  unsigned int  tcount1,tcount2;
  unsigned int groupi,groupj;
  unsigned int  basecount1[(long)X - (long)A + 1], basecount2[(long)X - (long)A + 1];
  unsigned int basecount1o[(long)X - (long)A + 1], basecount2o[(long)X - (long)A + 1];
  basetype base;
  char chi;
  unsigned short  isshared1, isshared2;
  float  LDval[LDDP+1];
  boolean LDok;
  
  /*initializations*/
  /*
  LDA[i]  = average LD within group i
  LDS[i][j] = Average LD within group i, but only among sites that are also shared with group j
  LDO[i][j] = Average LD within group i, but only among sites that are also not shared with group j
  LDSS[i][j] = Average LD within group i, but only among pairs of sites in which at least one sites is shared with group j
  LDOS[i][j] = Average LD within group i, but only among pairs of sites in which exactly one sites is shared with group j
   */
  for (i = 0; i < numgroups; i++){
      for (LDmeasure = LDR;LDmeasure <= LDDP; LDmeasure++) if (LDdotypes[LDmeasure]){
          LDA[LDmeasure][i].val = 0.0;
          LDA[LDmeasure][i].n = 0;
      }
  }

  for (i = 0; i < numgroups; i++) for(j=0;j< numgroups;j++){
      for (LDmeasure = LDR;LDmeasure <= LDDP; LDmeasure++) if (LDdotypes[LDmeasure]){
          LDO[LDmeasure][i][j].val = 0.0;
          LDS[LDmeasure][i][j].val = 0.0;
          LDSS[LDmeasure][i][j].val = 0.0;
          LDOS[LDmeasure][i][j].val = 0.0;
          /*LDS_over_O[LDmeasure][i][j].val = 0.0;
          LDS_over_A[LDmeasure][i][j].val = 0.0;
          LDSS_over_O[LDmeasure][i][j].val = 0.0; */
          LDO[LDmeasure][i][j].n = 0;
          LDS[LDmeasure][i][j].n = 0;
          LDSS[LDmeasure][i][j].n = 0;
          LDOS[LDmeasure][i][j].n = 0;
          /*LDS_over_O[LDmeasure][i][j].n = 0;
          LDS_over_A[LDmeasure][i][j].n = 0;
          LDSS_over_O[LDmeasure][i][j].n = 0;
          LDSOS_over_A[LDmeasure][i][j].n = 0;
          LDSOS_over_A[LDmeasure][i][j].val = 0.0; */
      }

  }
  nowsite1_ptr = nowsite_ptr;
  for (groupi = 0; groupi < numgroups; groupi++) if (groupsize[groupi]>1) 
  for (tcount1 = 0; tcount1 < scount-1; tcount1++) { /*1: loop tcount1 */
    for (tcount2 = tcount1+1; tcount2 < scount; tcount2++) { /*2: loop tcount2 */
      Findnowsit(tcount1+1);
      Findnowsit1(tcount2+1);
      if (nowsitefit(nowsite) && nowsitefit(nowsite1)) LDok = GetLD(groupi,&LDval[0]);
      else LDok = _false;
      if (LDok){
        for (base = A; (long)base <= (long)X; base = (basetype)((long)base + 1)) basecount1[(long)base - (long)A] = 0;
        for (i = grouplimits[groupi][0] - 1; i < grouplimits[groupi][1]; i++) {
            if (nowsite.p[i] == samechar)   chi = consensus[tcount1];
                else   chi = nowsite.p[i];
            switch (chi) {
                case 'A':basecount1[0]++;break;
                case 'C':basecount1[(long)C - (long)A]++;break;
                case 'G':basecount1[(long)G - (long)A]++;break;
                case 'T':basecount1[(long)T - (long)A]++;break;
                case '*':basecount1[(long)D - (long)A]++;break;
                case '-':basecount1[(long)D - (long)A]++;break;
                case 'N':basecount1[(long)X - (long)A]++;break;
            }
        }
          for (base = A;(long)base <= (long)X; base = (basetype)((long)base + 1)) basecount2[(long)base - (long)A] = 0;
        for (i = grouplimits[groupi][0] - 1; i < grouplimits[groupi][1]; i++) {
            if (nowsite1.p[i] == samechar)   chi = consensus[tcount2];
                else   chi = nowsite1.p[i];
            switch (chi) {
                case 'A':basecount2[0]++;break;
                case 'C':basecount2[(long)C - (long)A]++;break;
                case 'G':basecount2[(long)G - (long)A]++;break;
                case 'T':basecount2[(long)T - (long)A]++;break;
                case '*':basecount2[(long)D - (long)A]++;break;
                case '-':basecount2[(long)D - (long)A]++;break;
                case 'N':basecount2[(long)X - (long)A]++;break;
            }
        }
        for (groupj=0; groupj < numgroups;groupj++) if (groupsize[groupj]>1) 
            if (groupi != groupj){ /* 3 loop groups, check if shared at each site, do calcs */
                for (base = A;(long)base <= (long)X; base = (basetype)((long)base + 1))
                    basecount1o[(long)base - (long)A] = 0;
                for (i = grouplimits[groupj][0] - 1; i < grouplimits[groupj][1]; i++) {
                    if (nowsite.p[i] == samechar)   chi = consensus[tcount1];
                        else   chi = nowsite.p[i];
                    switch (chi) {
                        case 'A':basecount1o[0]++;break;
                        case 'C':basecount1o[(long)C - (long)A]++;break;
                        case 'G':basecount1o[(long)G - (long)A]++;break;
                        case 'T':basecount1o[(long)T - (long)A]++;break;
                        case '*':basecount1o[(long)D - (long)A]++;break;
                        case '-':basecount1o[(long)D - (long)A]++;break;
                        case 'N':basecount1o[(long)X - (long)A]++;break;
                    }
                }
            for (base = A;(long)base <= (long)X; base = (basetype)((long)base + 1)) basecount2o[(long)base - (long)A] = 0;
                for (i = grouplimits[groupj][0] - 1; i < grouplimits[groupj][1]; i++) {
                    if (nowsite1.p[i] == samechar)   chi = consensus[tcount2];
                        else   chi = nowsite1.p[i];
                    switch (chi) {
                    case 'A':basecount2o[0]++;break;
                    case 'C':basecount2o[(long)C - (long)A]++;break;
                    case 'G':basecount2o[(long)G - (long)A]++;break;
                    case 'T':basecount2o[(long)T - (long)A]++;break;
                    case '*':basecount2o[(long)D - (long)A]++;break;
                    case '-':basecount2o[(long)D - (long)A]++;break;
                    case 'N':basecount2o[(long)X - (long)A]++;break;
                    }
                }
        
            isshared1 = 0;
            for (base = A;(long)base <= (long)T; base = (basetype)((long)base + 1)){
                if ((basecount1[(long)base - (long)A] > 0)&&(basecount1o[(long)base - (long)A] > 0)) isshared1++;
            }
            if (isshared1==1) isshared1 = 0;
                else  if (isshared1>1) isshared1 = 1;
            isshared2 = 0;
            for (base = A;(long)base <= (long)T; base = (basetype)((long)base + 1)){
                if ((basecount2[(long)base - (long)A] > 0)&&(basecount2o[(long)base - (long)A] > 0)) isshared2++;
            }
            if (isshared2==1) isshared2 = 0;
                else  if (isshared2>1) isshared2 = 1;
/* check to see for each sites
  is the other species fixed for a derived site, if that base is also polymorphic within groupi
  then include the sites as shared  */
#ifdef  DERIVED_SHARED
            ofixed1 = 0;
            for (base = A;(long)base <= (long)T; base = (basetype)((long)base + 1))
                if (basecount1o[(long)base - (long)A] > 0){
                    ofixed1++;
                    fixbase1 = base;
                }
            if (ofixed1==1){
                if (outgroup[groupj] > 0) {
                    outchar = nowsite.p[grouplimits[outgroup[groupj] - 1][0] - 1];
                    if (outchar=='N') outchar = nowsite.p[grouplimits[outgroup[groupj] - 1][1] - 1];
                    if (outchar==samechar) outchar = consensus[nowsite.sitn-1];
                            switch (outchar) {
                                case 'A': outbase1 = A; break;
                                case 'C': outbase1 = C; break;
                                case 'G': outbase1 = G; break;
                                case 'T': outbase1 = T; break;
                                case 'N': outbase1 = X; break;
                                case '*': outbase1 = X; break;
                                case '-': outbase1 = X; break;
                            } 
                } else outbase1 = X;
                if ((outbase1 == fixbase1) || (basecount1[(long) fixbase1 - (long) A] == 0) || (basecount1[(long) outbase1 - (long) A] == 0)) ofixed1 = 0;
            }
            ofixed2 = 0;
            for (base = A;(long)base <= (long)T; base = (basetype)((long)base + 1))
                if (basecount2o[(long)base - (long)A] > 0){
                    ofixed2++;
                    fixbase2 = base;
                }
            if (ofixed2==1){
                if (outgroup[groupj] > 0) {
                    outchar = nowsite1.p[grouplimits[outgroup[groupj] - 1][0] - 1];
                    if (outchar=='N') outchar = nowsite1.p[grouplimits[outgroup[groupj] - 1][1] - 1];
                    if (outchar==samechar) outchar = consensus[nowsite1.sitn-1];
                            switch (outchar) {
                                case 'A': outbase2 = A; break;
                                case 'C': outbase2 = C; break;
                                case 'G': outbase2 = G; break;
                                case 'T': outbase2 = T; break;
                                case 'N': outbase2 = X; break;
                                case '*': outbase2 = X; break;
                                case '-': outbase2 = X; break;
                            } 
                } else outbase2 = X;
                if ((outbase2 == fixbase2) || (basecount2[(long) fixbase2 - (long) A] == 0) || (basecount2[(long) outbase2 - (long) A] == 0)) ofixed2 = 0;
            }
            if (ofixed1==1) isshared1 = 1;
            if (ofixed2==1) isshared2 = 1;
#endif
/* end of section that includes derived bases in other species as shared */

            for (LDmeasure = LDR;LDmeasure <= LDDP; LDmeasure++) if (LDdotypes[LDmeasure]){
                if (LDok){
                    /* only pairs of shared sites */
                    if (isshared1 && isshared2){
                        LDS[LDmeasure][groupi][groupj].val += LDval[LDmeasure];
                        LDS[LDmeasure][groupi][groupj].n++;
                    }
                    /* only pairs of nonshared sites */
                    if (!isshared1 && !isshared2){
                        LDO[LDmeasure][groupi][groupj].val += LDval[LDmeasure];
                        LDO[LDmeasure][groupi][groupj].n++;
                    }
                    /* onnly pairs in which at least one of the sites is shared*/
                    if (isshared1 || isshared2){
                        LDSS[LDmeasure][groupi][groupj].val += LDval[LDmeasure];
                        LDSS[LDmeasure][groupi][groupj].n++;
                    }
                    /* only pairs in which just one of the sites is shared */
                    if ((isshared1 && !isshared2)||(!isshared1 && isshared2)){
                        LDOS[LDmeasure][groupi][groupj].val += LDval[LDmeasure];
                        LDOS[LDmeasure][groupi][groupj].n++;
                    }
                }
            }
        }  /* 3: loop groups */
        else  {/* measure LD between all pairs of sites within groups */
            if (LDok){
                /* all pairs of sites */
                for (LDmeasure = LDR;LDmeasure <= LDDP; LDmeasure++) if (LDdotypes[LDmeasure]){
                    LDA[LDmeasure][groupi].val += LDval[LDmeasure];
                    LDA[LDmeasure][groupi].n++;
                }
            }
        }
      } /*LDok */
    }  /*2: loop tcount2 */
  }  /*1: loop tcount1 */
  for (groupi = 0; groupi < numgroups; groupi++) if (groupsize[groupi]>1){
      for (LDmeasure = LDR;LDmeasure <= LDDP; LDmeasure++) if (LDdotypes[LDmeasure]){
        if(LDA[LDmeasure][groupi].n >= LDMINN) LDA[LDmeasure][groupi].val /= LDA[LDmeasure][groupi].n;  
           else LDA[LDmeasure][groupi].val = MINUS10;
      }
  }
  for (LDmeasure = LDR;LDmeasure <= LDDP; LDmeasure++) if (LDdotypes[LDmeasure]){
      for (groupi = 0; groupi < numgroups; groupi++) if (groupsize[groupi]>1)
       for (groupj=0; groupj < numgroups;groupj++) if (groupsize[groupj]>1) 
        if (groupi != groupj){
            if(LDO[LDmeasure][groupi][groupj].n >= LDMINN) LDO[LDmeasure][groupi][groupj].val /= LDO[LDmeasure][groupi][groupj].n;
              else LDO[LDmeasure][groupi][groupj].val = MINUS10;
            if(LDS[LDmeasure][groupi][groupj].n >= LDMINN) LDS[LDmeasure][groupi][groupj].val /= LDS[LDmeasure][groupi][groupj].n;
              else LDS[LDmeasure][groupi][groupj].val = MINUS10;
            if(LDSS[LDmeasure][groupi][groupj].n >= LDMINN) LDSS[LDmeasure][groupi][groupj].val /= LDSS[LDmeasure][groupi][groupj].n;
              else LDSS[LDmeasure][groupi][groupj].val = MINUS10;
            if(LDOS[LDmeasure][groupi][groupj].n >= LDMINN) LDOS[LDmeasure][groupi][groupj].val /= LDOS[LDmeasure][groupi][groupj].n;
              else LDOS[LDmeasure][groupi][groupj].val = MINUS10;
            /*if(LDO[LDmeasure][groupi][groupj].n >= LDMINN && LDS[LDmeasure][groupi][groupj].n >= LDMINN) LDS_over_O[LDmeasure][groupi][groupj].val = LDS[LDmeasure][groupi][groupj].val/LDO[LDmeasure][groupi][groupj].val;
            if(LDO[LDmeasure][groupi][groupj].n >= LDMINN && LDSS[LDmeasure][groupi][groupj].n >= LDMINN) LDSS_over_O[LDmeasure][groupi][groupj].val = LDSS[LDmeasure][groupi][groupj].val/LDO[LDmeasure][groupi][groupj].val;
            if(LDA[LDmeasure][groupi].n >= LDMINN && LDS[LDmeasure][groupi][groupj].n >= LDMINN) LDS_over_A[LDmeasure][groupi][groupj].val = LDS[LDmeasure][groupi][groupj].val/LDA[LDmeasure][groupi].val;*/
            if(LDS[LDmeasure][groupi][groupj].n >= LDMINN && LDOS[LDmeasure][groupi][groupj].n >= LDMINN) LDS_less_OS[LDmeasure][groupi][groupj].val = LDS[LDmeasure][groupi][groupj].val - LDOS[LDmeasure][groupi][groupj].val;
              else LDS_less_OS[LDmeasure][groupi][groupj].val = MINUS10;
            /*if(LDS[LDmeasure][groupi][groupj].n >= LDMINN && LDOS[LDmeasure][groupi][groupj].n >= LDMINN && LDA[LDmeasure][groupi].n >= LDMINN) LDSOS_over_A[LDmeasure][groupi][groupj].val = fabs(LDS_less_OS[LDmeasure][groupi][groupj].val)/fabs(LDA[LDmeasure][groupi].val); */
        } 
    }
/* now print it all */
    FP"\n\n");
#ifdef DERIVED_SHARED
    FP"Analyses of LD Among Polymorphisms 'Shared' (possibly imported) Between Groups\n");
    FP"-------- -- -- ----- ------------- -------- ------------------- ------- ------\n\n");
    FP" - here 'Shared' includes classic shared polymorphisms, as well as those \n");
    FP"   for which the derived base is also fixed in the other group\n");
#else 
    FP"Analyses of LD Among Polymorphisms Shared Between Groups\n");
    FP"-------- -- -- ----- ------------- ------ ------- ------\n\n");
#endif
    i = LDMINN;
    FP" - reported values are averages among all pairs of sites. There must be \n");
    FP"   at least %d pairs of sites for the mean to be reported \n",i);


    for (LDmeasure=LDR;LDmeasure<= LDDP;LDmeasure++) if (LDdotypes[LDmeasure]){
            if (LDmeasure==LDR)  strcpy(LDstr," (r) ");
            if (LDmeasure==LDRS) strcpy(LDstr,"(r^2)");
            if (LDmeasure==LDD)  strcpy(LDstr," (D) ");
            if (LDmeasure==LDDP) strcpy(LDstr," (D')");
            if (LDmeasure==LDABS)  strcpy(LDstr,"(|D|)");
            if (LDmeasure==LDPABS)  strcpy(LDstr,"(|D'|)");
            FP"\n\n");

            FP"LD Analyses Among  Shared  Polymorphisms - using %s\n",LDstr); 
            FP"-- -------- ----- -------- -------------   ----- -----\n");
            FP"     Overall Linkage Disequilibrium within Groups\n"); 
            FP"     Group Name      Value\n");
            FP"     ----------     -------\n");
            for (i=0;i< numgroups;i++) if (groupsize[i]>1) FP"     %s  %8.5f \n", groupnames[i],LDA[LDmeasure][i].val);

            FP "\n  %s  Linkage Disequilibrium Among Shared Polymorphisms  \n",LDstr);
            FP "     - Values are for row groups. LD considered for every pair of groups\n");
           for (j=1; j < MaxGroupNameLength+6;j++) FP" ");
           for (i = 1; i <= numgroups; i++)FP "     %2u   ",i);
           putc('\n', rfile);
            for (i = 1; i <= numgroups; i++) {
              for (j=1; j < MaxGroupNameLength+7;j++) FP" ");
              for (j = 1; j <= numgroups; j++) {
           if (j == i || j == i - 1)
             FP "----------");
           else
             FP "          ");
              }
              FP "\n%2u: %s  ", i, groupnames[i - 1]);
              for (j = 1; j <= numgroups; j++) {
                if (j==i) FP"|        ");
                    else  {
                    if (j==i+1) FP"|");
                        else if (j<i) FP" ");
                            else if (j>i) FP" ");
                    if (LDS[LDmeasure][i-1][j-1].n >= LDMINN) FP" % 7.3f ",LDS[LDmeasure][i-1][j-1].val);
                          else FP"         ");
                    }
              }
              putc('\n', rfile);
            }

            FP "\n  %s  Linkage Disequilibrium Among NON-Shared Polymorphisms \n",LDstr);
            FP "     - Values are for row groups. LD considered for every pair of groups\n");
            for (j=1; j < MaxGroupNameLength+6;j++) FP" ");
            for (i = 1; i <= numgroups; i++)
              FP "     %2u   ",i);
            putc('\n', rfile);
            for (i = 1; i <= numgroups; i++) {
              for (j=1; j < MaxGroupNameLength+7;j++) FP" ");
              for (j = 1; j <= numgroups; j++) {
           if (j == i || j == i - 1)
             FP "----------");
           else
             FP "          ");
              }
              FP "\n%2u: %s  ", i, groupnames[i - 1]);
              for (j = 1; j <= numgroups; j++) {
                if (j==i) FP"|        ");
                    else  {
                        if (j==i+1) FP"|");
                            else if (j<i) FP" ");
                                else if (j>i) FP" ");
                        if(LDO[LDmeasure][i-1][j-1].n >= LDMINN) FP" % 7.3f ",LDO[LDmeasure][i-1][j-1].val);
                        else  FP"         ");
                    }
              }
              putc('\n', rfile);
            }
            FP "\n  %s  Linkage Disequilibrium Between Shared and NON-Shared Polymorphisms \n",LDstr);
            FP "     - Values are for row groups. LD considered for every pair of groups\n");
            for (j=1; j < MaxGroupNameLength+6;j++) FP" ");
            for (i = 1; i <= numgroups; i++)
              FP "     %2u   ",i);
            putc('\n', rfile);
            for (i = 1; i <= numgroups; i++) {
              for (j=1; j < MaxGroupNameLength+7;j++) FP" ");
              for (j = 1; j <= numgroups; j++) {
           if (j == i || j == i - 1)
             FP "----------");
           else
             FP "          ");
              }
              FP "\n%2u: %s  ", i, groupnames[i - 1]);
              for (j = 1; j <= numgroups; j++) {
                if (j==i) FP"|        ");
                    else  {
                        if (j==i+1) FP"|");
                            else if (j<i) FP" ");
                                else if (j>i) FP" ");
                        if (LDOS[LDmeasure][i-1][j-1].n >= LDMINN) FP" % 7.3f ",LDOS[LDmeasure][i-1][j-1].val);
                          else FP"         ");
                    }
              }
              putc('\n', rfile);
            } 
            FP "\n  %s  Difference of LD between Shared Polymorphisms and NON-Shared Polymorphisms\n",LDstr);
            FP "     - Values are for row groups. Difference considered for every pair of groups\n");
            for (j=1; j < MaxGroupNameLength+6;j++) FP" ");
            for (i = 1; i <= numgroups; i++)
              FP "     %2u   ",i);
            putc('\n', rfile);
            for (i = 1; i <= numgroups; i++) {
              for (j=1; j < MaxGroupNameLength+7;j++) FP" ");
              for (j = 1; j <= numgroups; j++) {
           if (j == i || j == i - 1)
             FP "----------");
           else
             FP "          ");
              }
              FP "\n%2u: %s  ", i, groupnames[i - 1]);
              for (j = 1; j <= numgroups; j++) {
                if (j==i) FP"|        ");
                    else  {
                        if (j==i+1) FP"|");
                            else if (j<i) FP" ");
                                else if (j>i) FP" ");
                        if (LDS[LDmeasure][i-1][j-1].n >= LDMINN && LDO[LDmeasure][i-1][j-1].n >= LDMINN) FP" % 7.3f ",LDS[LDmeasure][i-1][j-1].val - LDO[LDmeasure][i-1][j-1].val);
                          else FP"         ");
                    }
              }
              putc('\n', rfile);
            }
            FP "\n  %s  Difference of LD between Shared Polymorphisms and \n",LDstr);
            FP "             LD between Shared and NON-Shared polymorphisms \n");
            FP "     - Values are for row groups. Difference considered for every pair of groups\n");
            for (j=1; j < MaxGroupNameLength+6;j++) FP" ");
            for (i = 1; i <= numgroups; i++)
              FP "     %2u   ",i);
            putc('\n', rfile);
            for (i = 1; i <= numgroups; i++) {
              for (j=1; j < MaxGroupNameLength+7;j++) FP" ");
              for (j = 1; j <= numgroups; j++) {
           if (j == i || j == i - 1)
             FP "----------");
           else
             FP "          ");
              }
              FP "\n%2u: %s  ", i, groupnames[i - 1]);
              for (j = 1; j <= numgroups; j++) {
                if (j==i) FP"|        ");
                    else  {
                        if (j==i+1) FP"|");
                            else if (j<i) FP" ");
                                else if (j>i) FP" ");
                        if (LDS[LDmeasure][i-1][j-1].n >= LDMINN && LDOS[LDmeasure][i-1][j-1].n >= LDMINN) FP" % 7.3f ",LDS_less_OS[LDmeasure][i-1][j-1].val);
                          else FP"         ");
                    }
              }
              putc('\n', rfile);
            }
    }
}  /*LD_possibly_imported_stuff*/


void print_LD_matrix(int groupi)
{
  unsigned int pcount, lcount, i;
  char linestr[MaxMatrixLineLength], temps[MaxMatrixLineLength];
  unsigned int linecount, dataline;
  linetype nowline;
  unsigned int FORLIM;
  boolean  LDok;
  float LDval[LDDP+1];
  int j;
  int sitenums[MaxSitesforRec];
  char  ch;
  struct LDaccumulate LDmeancalc;

doLDtest = _true;
FPM "%s\n%s\n\n",dashline,starline);

FPM"\n\nGROUP : %10s \n\n\n",groupnames[groupi]);
FPM"Matrix of LD Tests Between All Pairs of Sites \n");
FPM"------ -- -- ----- ------- --- ----- -- ----- \n");
FPM"  Fisher's Exact Test  Above the Diagonal \n");
FPM"  Chi Square Test  Below the Diagonal \n");
FPM"  Symbol Representation \n");
FPM"   '-' no test|'0' p>0.1|'1' p<0.05|'2' p<0.01|'3' p<0.005|'4' p<0.001|'5' p<0.0001|'6' p<0.00001|'7' p<0.000001|'8' p<0.0000001 \n");

prep_rec_analysis(groupi,1,_false);
j = 0;
i = 1;
while (j < gcount){
  Findnowsit(i);
  if (nowsite.seqn == siteseqnums[j]){
      sitenums[j] = nowsite.sitn;
      j++;
  }
  i++;
} 
if (gcount >= MaxSitesforRec) {
lcount = MaxSitesforRec;
FPM
   "too many informative sites ( > %d)------ table truncated\n",lcount);
} else  lcount = gcount;
for (linecount = 0; linecount <= 2; linecount++) {
strcpy(linestr, "rarecount ");
for (i = 0; i < lcount; i++) sprintf(linestr + strlen(linestr), "%c", rareclass[i][linecount]);
FPM "%s\n", linestr);
}
FORLIM = numseq + lcount + 6;
for (linecount = 1; linecount <= FORLIM; linecount++) {
if (linecount <= 6)
  nowline = PSN;
if (linecount <= numseq + 6 && linecount > 6)
  nowline = DAT;
if (linecount > numseq + 6)
  nowline = POL;

switch (nowline) 
    {
    case PSN:
      strcpy(linestr, "position  ");
      for (i = 0; i < lcount; i++) {
    sprintf(temps, "%6u", siteseqnums[i]);
    sprintf(linestr + strlen(linestr), "%c", temps[linecount - 1]);
      }
      break;

    case DAT:
      strcpy(linestr, names[linecount + grouplimitlow - 8]);
      for (i = 0; i < lcount; i++) {
    dataline = linecount + grouplimitlow - 7;
    ch = popchar(dataline, siteseqnums[i]);
    switch (toupper(ch)) {

    case 'A':
     strcat(linestr, "A");
     break;

    case 'C':
     strcat(linestr, "C");
     break;

    case 'G':
     strcat(linestr, "G");
     break;

    case 'T':
     strcat(linestr, "T");
     break;

    case 'N':
     strcat(linestr, "N");
     break;

    case '-':
     strcat(linestr, "D");
     break;

    case '*':
     strcat(linestr, "D");
     break;
    }
      }
      break;

    case POL:
      pcount = linecount - numseq - 6;
      sprintf(linestr, "%6u", siteseqnums[pcount - 1]);
      for (i = 1; i <= lcount + 4; i++) strcat(linestr, " ");
      linestr[pcount + 9] = '*';
      for (i = 1; i <= lcount; i++) 
          if (pcount != i)
              {
              Findnowsit(sitenums[pcount-1]);
              Findnowsit1(sitenums[i-1]);
              if ((i!=pcount) && nowsitefit(nowsite) && nowsitefit(nowsite1))
                 LDok = GetLD(groupi,&LDval[0]);
              else LDok = _false;
              if (LDok)
                 {
                 if (i>pcount) linestr[9+i] = fetchar;
                 if (i < pcount) linestr[9+i] = chisquarechar; 
                 }
              else linestr[9+i] = '-';
              }
    }

FPM "%s\n", linestr);
}

doLDtest = _false;
FPM"\n\nMatrices of Linkage Disequilibrium Values Between All Pairs of Sites \n");
FPM"-------- -- ------- -------------- ------ ------- --- ----- -- ----- \n");
for (LDmeasure = LDR;LDmeasure <= LDDP; LDmeasure++) if (LDdotypes[LDmeasure]){ 
      if (LDmeasure==LDR)  strcpy(LDstr," (r) ");
      if (LDmeasure==LDRS) strcpy(LDstr,"(r^2)");
      if (LDmeasure==LDD)  strcpy(LDstr," (D) ");
      if (LDmeasure==LDDP) strcpy(LDstr," (D')");
      if (LDmeasure==LDABS)  strcpy(LDstr,"(|D|)");
      if (LDmeasure==LDPABS)  strcpy(LDstr,"(|D'|)");
      FPM"\nGroup : %10s    LD MEASURE %s \n",groupnames[groupi],LDstr);
      FPM"-------------------     -- ------- -----\n");
      if (LDmeasure != LDRS) FPM"    -positive values above the diagonal,  negative values below \n");
      FPM"    - values shown are 10 times actual value, rounded to nearest integer\n");
      FPM"    -  values with absolute value >0.85 (including values near 1), are represented with '9' \n");
      FPM"    -  LD not caculated for indel polymorphisms \n");
      LDmeancalc.val = 0.0;
      LDmeancalc.n = 0;
      prep_rec_analysis(groupi,1,_false);
      j = 0;
      i = 1;
      while (j < gcount){
          Findnowsit(i);
          if (nowsite.seqn == siteseqnums[j]){
              sitenums[j] = nowsite.sitn;
              j++;
          }
          i++;
      } 
      if (gcount >= MaxSitesforRec) {
        lcount = MaxSitesforRec;
        FPM
           "too many informative sites ( > %d)------ table truncated\n",lcount);
      } else  lcount = gcount;
      for (linecount = 0; linecount <= 2; linecount++) {
        strcpy(linestr, "rarecount ");
        for (i = 0; i < lcount; i++) sprintf(linestr + strlen(linestr), "%c", rareclass[i][linecount]);
        FPM "%s\n", linestr);
      }
      FORLIM = numseq + lcount + 6;
      for (linecount = 1; linecount <= FORLIM; linecount++) {
        if (linecount <= 6)
          nowline = PSN;
        if (linecount <= numseq + 6 && linecount > 6)
          nowline = DAT;
        if (linecount > numseq + 6)
          nowline = POL;

        switch (nowline) {

        case PSN:
          strcpy(linestr, "position  ");
          for (i = 0; i < lcount; i++) {
       sprintf(temps, "%6u", siteseqnums[i]);
       sprintf(linestr + strlen(linestr), "%c", temps[linecount - 1]);
          }
          break;

        case DAT:
          strcpy(linestr, names[linecount + grouplimitlow - 8]);
          for (i = 0; i < lcount; i++) {
       dataline = linecount + grouplimitlow - 7;
       ch = popchar(dataline, siteseqnums[i]);
       switch (toupper(ch)) {

       case 'A':
         strcat(linestr, "A");
         break;

       case 'C':
         strcat(linestr, "C");
         break;

       case 'G':
         strcat(linestr, "G");
         break;

       case 'T':
         strcat(linestr, "T");
         break;

       case 'N':
         strcat(linestr, "N");
         break;

       case '-':
         strcat(linestr, "D");
         break;

       case '*':
         strcat(linestr, "D");
         break;
       }
          }
          break;

        case POL:
          pcount = linecount - numseq - 6;
          sprintf(linestr, "%6u", siteseqnums[pcount - 1]);
          for (i = 1; i <= lcount + 4; i++) strcat(linestr, " ");
          linestr[pcount + 9] = '*';
          for (i = 1; i <= lcount; i++) {
             Findnowsit(sitenums[pcount-1]);
                Findnowsit1(sitenums[i-1]);
             if ((i!=pcount) && nowsitefit(nowsite) && nowsitefit(nowsite1))
                 LDok = GetLD(groupi,&LDval[0]);
             else LDok = _false;
             if (LDok){
                 if (i>pcount) {
                    LDmeancalc.val += LDval[LDmeasure];
                    LDmeancalc.n++;
              /*      FPM"%5d    %5d    %5d    %.4f    %.4f \n",nowsite.seqn,nowsite1.seqn,LDmeancalc.n,LDval[LDmeasure],LDmeancalc.val); */
                 }
                 if (LDval[LDmeasure] < 0.0 && i<pcount){
                    LDval[LDmeasure] = fabs (LDval[LDmeasure]);
                    j = round(LDval[LDmeasure] * LDVALINTS);
                    if (j < 0) j = 0;
                    if (j > 9) j = 9;
                    linestr[9+i] = LDvalcode[j];
                 }
                 if (LDval[LDmeasure] >= 0.0 && i>pcount){
                    j = round(LDval[LDmeasure] * LDVALINTS);
                    if (j < 0) j = 0;
                    if (j > 9) j = 9;
                    linestr[9+i] = LDvalcode[j];
                 }
             }
          }
        }
        FPM "%s\n", linestr);
      }
    if (LDmeancalc.n > 0)
        FPM"\n  Mean overall Linkage Disequilibrium in Group : %s      %8.5f\n",groupnames[groupi],LDmeancalc.val/LDmeancalc.n);

    FPM"\n\n");
}
}  /*print_LD_matrix*/



/* print_regionLD prints a matrix of average LD values between regions of the sequence
the regions are defined in a file

  if just one group is being analyzed, then this routine can also test the significance of the LD patterns among
  and within regions, by scrambling the locations of polymorphic sites
  this is done by regionLDscramble 
  */

#define MAXSITESFORLDTEST  1000
/* 2-tailed tests, for X simulations  each tail must have 0.025*X terms, so that the last one will
be an estimate of the 95% significance level
must have 0.005*X terms so that the 99% significance level will be estimated */
#define MAXLDTAIL  25 /* use 5  to get 200 simulations, 10 for 400, 20 for 800, 25 for 1000, 40 for 1600 */
#define LDSIMS   MAXLDTAIL * 40
#define LDSIMS_BUF_FACTOR   1.2
#define LDMINCOUNT   10
/* random integer between 0 and x -1*/
#define randint(x)  (rand() % (x))

typedef struct  LDtest
    {
    float vals[MAXLDTAIL];
    int  n;
    } LDtest;

LDtest hiLDtest[LDDP+1][MaxregionLD][MaxregionLD], loLDtest[LDDP+1][MaxregionLD][MaxregionLD];
LDtest hiLDtest_mean[LDDP+1],loLDtest_mean[LDDP+1];
LDtest hiLDtest_var[LDDP+1],loLDtest_var[LDDP+1];
struct LDaccumulate regionLDmat[LDDP+1][MaxregionLD][MaxregionLD];
struct LDaccumulate mean_betweens[LDDP+1],sim_mean_betweens[LDDP+1];        
struct LDaccumulate var_betweens[LDDP+1],sim_var_betweens[LDDP+1];        


void regionLDscramble(int groupi){
/* 2 types of scrambling - 
within each region, scramble the base pair orders for each site.
Then between regions,  maintain the haplotypes within regions, but scramble them among regions 
For each simulation:
    scramble all the rows, for each site - then measure the within region values - then put it all back
    then scramble between regions (within each region, scrambling is among haplotypes, but haplotypes stay constant)- measure,
At the end of all simulations,  put it all back
*/

site_rec *site_list[MAXSITESFORLDTEST];  
/*site_rec is a pointer to a dynamic array of pointers site_rec **site_list;  */
unsigned int  o_seqn[MAXSITESFORLDTEST]; /* original positions */
static char o_p[MAXSITESFORLDTEST][MaxS];   /*original base values*/
int i,j,g,h,k,s;
unsigned int  tscount;
unsigned int  tcount1,tcount2;
/*struct LDaccumulate LDsimmean[LDDP+1][MaxregionLD][MaxregionLD],LDsimvar[LDDP+1][MaxregionLD][MaxregionLD]; */
static float LDval[LDDP+1];
boolean LDok;
static unsigned int  basecount[(long)X - (long)A + 1];
basetype base;
char chi,chtemp;
unsigned short  ispoly;
int numsims;
int itemp,shufflelist[MaxS];

/* get the list */
/* tried having site_list be a dynamic array of pointers - include a little extra, fraction 1.1, in case for some reason the reported numbers
of polymorphic sites by polysite and polydist are not the same as found in regionLDscramble 
it worked fine, but o_p and o_seqn have to be the same size - go back to a regular array

if (exclude_singletons) site_list = calloc((int)(( polysite[groupi]-polydist[groupi][0])*1.1),sizeof(tsr));
else site_list = calloc((int)(polysite[groupi]*1.1),sizeof(tsr)); 
*/
/* record pointers to the sites that can be scrambled */
/* find the polymorphic sites for the group */
for (tcount1 = 0,j=0; tcount1 < scount && j < MAXSITESFORLDTEST; tcount1++){
    Findnowsit(tcount1 + 1);
    if (nowsitefit(nowsite)) {
        for (base = A; (long)base <= (long)X; base = (basetype)((long)base + 1))
                basecount[(long)base - (long)A] = 0;
        for (i = grouplimits[groupi][0] - 1; i < grouplimits[groupi][1]; i++) {
            if (nowsite.p[i] == samechar)   chi = consensus[nowsite.sitn-1];
                else   chi = nowsite.p[i];
            switch (chi) {
                case 'A':basecount[0]++;break;
                case 'C':basecount[(long)C - (long)A]++;break;
                case 'G':basecount[(long)G - (long)A]++;break;
                case 'T':basecount[(long)T - (long)A]++;break;
                case '*':basecount[(long)D - (long)A]++;break;
                case '-':basecount[(long)D - (long)A]++;break;
                case 'N':basecount[(long)X - (long)A]++;break;
                }
          }
        ispoly = 0;
        for (base = A;(long)base <= (long)T; base = (basetype)((long)base + 1)){
            if (basecount[(long)base - (long)A] > exclude_singletons /* _false (= 0) when singletons are included, _true=1 if excluded */) ispoly++;
        }
        if ((basecount[(long)D - (long)A] > exclude_singletons /* _false (= 0) when singletons are included, _true=1 if excluded */)&& nowsite.s[EXN] && nowsite.s[INT]) ispoly++;
        if (ispoly>1){
            site_list[j] = nowsite_ptr;
            o_seqn[j] = nowsite.seqn;
            strncpy(o_p[j],nowsite.p,nums);
            j++;
        }
    }
}
tscount = j;
/* initialize measurement variables */
for (LDmeasure = LDR;LDmeasure <= LDDP; LDmeasure++) if (LDdotypes[LDmeasure]){
    for (k=0;k<MAXLDTAIL;k++){
        hiLDtest_mean[LDmeasure].vals[k] = -100.0;
        loLDtest_mean[LDmeasure].vals[k] = 100.0;
        hiLDtest_var[LDmeasure].vals[k] = -10000.0;
        loLDtest_var[LDmeasure].vals[k] = 10000.0;
    }
    for (i=0;i< numregionLD;i++) for (j=0;j< numregionLD;j++)  {
        /*LDsimmean[LDmeasure][i][j].val = 0.0;
        LDsimvar[LDmeasure][i][j].val = 0.0;
        LDsimmean[LDmeasure][i][j].n = 0; */
        for (k=0;k<MAXLDTAIL;k++){
            hiLDtest[LDmeasure][i][j].vals[k] = -100.0;
            loLDtest[LDmeasure][i][j].vals[k] = 100.0;
        }
        hiLDtest[LDmeasure][i][j].n = 0;
        loLDtest[LDmeasure][i][j].n = 0;
    }
}
/* in general want to do LDsims simulations, but some cells of matrix get less than that because
of gaps in the data, which cause some simulations to not return values for some regions of 
pairs of regions that have low numbers of sequences and low polymorphism and some indels
For this region do extra simulations (by LDsims_buf_factor) and in each cell just count the first
LDsims that worked */
/* debug by writing stuff to a file */

/*if ((debugfile = fopen("LDvaltable.out", "w")) == NULL){
        printf("\nError opening text file for writing \n"); exit(0);} */
numsims = LDSIMS * LDSIMS_BUF_FACTOR;
if (screenupdate == _true){
    printf("\nGroup :  %s   Simulations for LD test by regions\n",groupnames[groupi]);
    printf("Simulating Within Regions.\n");
    printf("   Simulation number (out of %d) : \n",numsims);
}
for (s=0;s< numsims;s++){
    if (screenupdate == _true){
        printf(" %2d",s+1);
        if ((s+1) % 20 == 0) printf("\n");
    }
/* scramble the base values among sequences, within each polymorphic site */
    for (i=0;i< tscount;i++){
        for (j = grouplimits[groupi][0] - 1; j < grouplimits[groupi][1]; j++) {
          chtemp = site_list[i]->p[j];
          k = (grouplimits[groupi][0] - 1)+randint(groupsize[groupi]);
          site_list[i]->p[j] = site_list[i]->p[k];
          site_list[i]->p[k] = chtemp;
          }
    }
/* initialize the mean LD values for the simulations */
    for (i=0;i< numregionLD;i++) {
        for (LDmeasure = LDR;LDmeasure <= LDDP; LDmeasure++) if (LDdotypes[LDmeasure]){
            regionLDmat[LDmeasure][i][i].val=0.0;
            regionLDmat[LDmeasure][i][i].n=0;
        }
    }
/* measure mean LD within regions */
    for (tcount1 = 0,i=0; tcount1 < tscount-1; tcount1++) {
        nowsite  = *site_list[tcount1];
         while ((regionLD[i] < nowsite.seqn) && (i < numregionLD)) i++;
        for (tcount2 = tcount1+1,j=i; tcount2 < tscount; tcount2++) {
          nowsite1 = *site_list[tcount2];
          while ((regionLD[j] < nowsite1.seqn) && (j < numregionLD)) j++;
          if (i==j) {
              if (nowsitefit(nowsite) && nowsitefit(nowsite1))
                  LDok = GetLD(groupi,&LDval[0]);
              else LDok = _false;
              if (LDok){
                  for (LDmeasure = LDR;LDmeasure <= LDDP; LDmeasure++) if (LDdotypes[LDmeasure]){
                      regionLDmat[LDmeasure][i][j].val += LDval[LDmeasure];
                      regionLDmat[LDmeasure][i][j].n++;
                  }
              }
          }
        }
    }
    for (i=0;i< numregionLD;i++){
        for (LDmeasure = LDR;LDmeasure <= LDDP; LDmeasure++) if (LDdotypes[LDmeasure]){
            if ((regionLDmat[LDmeasure][i][i].n >= LDMINCOUNT)&&(hiLDtest[LDmeasure][i][i].n < LDSIMS)) {
                regionLDmat[LDmeasure][i][i].val  /=  (float) regionLDmat[LDmeasure][i][i].n;
                hiLDtest[LDmeasure][i][i].n++;
                loLDtest[LDmeasure][i][i].n++;
            /*    LDsimmean[LDmeasure][i][i].n++;
                LDsimmean[LDmeasure][i][i].val += regionLDmat[LDmeasure][i][i].val;
                LDsimvar[LDmeasure][i][i].val += regionLDmat[LDmeasure][i][i].val * regionLDmat[LDmeasure][i][i].val;*/
                g = 0;
                while ((regionLDmat[LDmeasure][i][i].val >= hiLDtest[LDmeasure][i][i].vals[g]) && (g< MAXLDTAIL)) g++;
                g--;
                if ((g >= 0) && (g<= MAXLDTAIL-1)){
                    for(h=0;h<g; h++) hiLDtest[LDmeasure][i][i].vals[h] = hiLDtest[LDmeasure][i][i].vals[h+1];
                    hiLDtest[LDmeasure][i][i].vals[g] = regionLDmat[LDmeasure][i][i].val;
                }
                g = 0;
                while ((regionLDmat[LDmeasure][i][i].val <= loLDtest[LDmeasure][i][i].vals[g]) && (g< MAXLDTAIL)) g++;
                g--;
                if ((g >= 0) && (g<= MAXLDTAIL-1)){
                    for(h=0;h<g; h++) loLDtest[LDmeasure][i][i].vals[h] = loLDtest[LDmeasure][i][i].vals[h+1];
                    loLDtest[LDmeasure][i][i].vals[g] = regionLDmat[LDmeasure][i][i].val;
                }

            } 
        }
    }
}
/* now restore the base orders within sites  */
for (tcount1 = 0; tcount1 < tscount; tcount1++) {
    strncpy(site_list[tcount1]->p,o_p[tcount1],nums);
}
/* debug initialize the mean LD values for the simulations  
for (i=0;i< numregionLD;i++){
        for (LDmeasure = LDR;LDmeasure <= LDDP; LDmeasure++) if (LDdotypes[LDmeasure]){
            regionLDmat[LDmeasure][i][i].val=0.0;
            regionLDmat[LDmeasure][i][i].n=0;
            hiLDtest[LDmeasure][i][i].n=0;
        }
    }
    */
for (LDmeasure = LDR;LDmeasure <= LDDP; LDmeasure++) if (LDdotypes[LDmeasure]){
        sim_mean_betweens[LDmeasure].val = 0.0;
        sim_mean_betweens[LDmeasure].n = 0;
        sim_var_betweens[LDmeasure].val = 0.0;
        sim_var_betweens[LDmeasure].n = 0;
}
if (screenupdate == _true){
    printf("Simulating Between Regions.\n");
    printf("   Simulation number (out of %d) : \n",numsims);
}    
for (j = grouplimits[groupi][0] - 1,i=0; j < grouplimits[groupi][1]; j++,i++) shufflelist[i] = j;
for (s=0;s< numsims;s++){
    if (screenupdate == _true){
        printf(" %2d",s+1);
        if ((s+1) % 20 == 0) printf("\n");
    }
    for (j = 0; j < groupsize[groupi]; j++) {
      k = randint(groupsize[groupi]);
      itemp = shufflelist[j];
      shufflelist[j] = shufflelist[k];
      shufflelist[k] = itemp;
      }
    for (tcount1=0,i=0;tcount1< tscount;tcount1++){
        if ((regionLD[i] < site_list[tcount1]->seqn) && (i < numregionLD)) {
            i++;
            for (j = 0; j < groupsize[groupi]; j++) {
              k = randint(groupsize[groupi]);
              itemp = shufflelist[j];
              shufflelist[j] = shufflelist[k];
              shufflelist[k] = itemp;
              }
        for (j = grouplimits[groupi][0] - 1,g=0; j < grouplimits[groupi][1]; j++,g++) {
          chtemp = site_list[tcount1]->p[j];
          k = shufflelist[g];
          site_list[tcount1]->p[j] = site_list[tcount1]->p[k];
          site_list[tcount1]->p[k] = chtemp;
          }
        }
    } 
    
/* initialize the mean LD values for the simulations */
    for (LDmeasure = LDR;LDmeasure <= LDDP; LDmeasure++) if (LDdotypes[LDmeasure]){
        mean_betweens[LDmeasure].val = 0.0;
        mean_betweens[LDmeasure].n = 0.0;
        var_betweens[LDmeasure].val = 0.0;
        var_betweens[LDmeasure].n = 0.0;
        for (i=0;i< numregionLD-1;i++) for(j=i+1;j< numregionLD;j++){
            regionLDmat[LDmeasure][i][j].val=0.0;
            regionLDmat[LDmeasure][i][j].n=0;
        }
    }
/* measure mean LD between regions */
    for (tcount1 = 0,i=0; tcount1 < tscount-1; tcount1++) {
        nowsite  = *site_list[tcount1];
         while ((regionLD[i] < nowsite.seqn) && (i < numregionLD)) i++;
        for (tcount2 = tcount1+1,j=i; tcount2 < tscount; tcount2++) {
          nowsite1 = *site_list[tcount2];
          while ((regionLD[j] < nowsite1.seqn) && (j < numregionLD)) j++;
          if (i<=j) {
              if (nowsitefit(nowsite) && nowsitefit(nowsite1))
                  LDok = GetLD(groupi,&LDval[0]);
              else LDok = _false;
              if (LDok){
                  for (LDmeasure = LDR;LDmeasure <= LDDP; LDmeasure++) if (LDdotypes[LDmeasure]){
                      regionLDmat[LDmeasure][i][j].val += LDval[LDmeasure];
                      regionLDmat[LDmeasure][i][j].n++;
                  }
              }
          }
        }
    }
    for (i=0;i< numregionLD-1;i++) for (j=i+1;j< numregionLD;j++)  {
        for (LDmeasure = LDR;LDmeasure <= LDDP; LDmeasure++) if (LDdotypes[LDmeasure]){
            if ((regionLDmat[LDmeasure][i][j].n >= LDMINCOUNT)&&(hiLDtest[LDmeasure][i][j].n < LDSIMS)) {
                regionLDmat[LDmeasure][i][j].val  /=  (float) regionLDmat[LDmeasure][i][j].n;
                mean_betweens[LDmeasure].val += regionLDmat[LDmeasure][i][j].val;
                mean_betweens[LDmeasure].n++;
                var_betweens[LDmeasure].val += SQR(regionLDmat[LDmeasure][i][j].val);
                var_betweens[LDmeasure].n++;
                hiLDtest[LDmeasure][i][j].n++;
                loLDtest[LDmeasure][i][j].n++;
            /*    LDsimmean[LDmeasure][i][j].n++;
                LDsimmean[LDmeasure][i][j].val += regionLDmat[LDmeasure][i][j].val;
                LDsimvar[LDmeasure][i][j].val += regionLDmat[LDmeasure][i][j].val * regionLDmat[LDmeasure][i][j].val; */

                g = 0;
                while ((regionLDmat[LDmeasure][i][j].val >= hiLDtest[LDmeasure][i][j].vals[g]) && (g< MAXLDTAIL)) g++;
                g--;
                if ((g >= 0) && (g<= MAXLDTAIL-1)){
                    for(h=0;h<g; h++) hiLDtest[LDmeasure][i][j].vals[h] = hiLDtest[LDmeasure][i][j].vals[h+1];
                    hiLDtest[LDmeasure][i][j].vals[g] = regionLDmat[LDmeasure][i][j].val;
                }
                g = 0;
                while ((regionLDmat[LDmeasure][i][j].val <= loLDtest[LDmeasure][i][j].vals[g]) && (g< MAXLDTAIL)) g++;
                g--;
                if ((g >= 0) && (g<= MAXLDTAIL-1)){
                    for(h=0;h<g; h++) loLDtest[LDmeasure][i][j].vals[h] = loLDtest[LDmeasure][i][j].vals[h+1];
                    loLDtest[LDmeasure][i][j].vals[g] = regionLDmat[LDmeasure][i][j].val;
                }

            } 
        }
    }
    for (LDmeasure = LDR;LDmeasure <= LDDP; LDmeasure++) if (LDdotypes[LDmeasure]){
        if (mean_betweens[LDmeasure].n) {
            if (var_betweens[LDmeasure].n > 1) var_betweens[LDmeasure].val = (var_betweens[LDmeasure].val- SQR(mean_betweens[LDmeasure].val)/mean_betweens[LDmeasure].n)/((float) var_betweens[LDmeasure].n-1);
            mean_betweens[LDmeasure].val /= (float) mean_betweens[LDmeasure].n;
            sim_mean_betweens[LDmeasure].val += mean_betweens[LDmeasure].val;
            sim_mean_betweens[LDmeasure].n++;
            sim_var_betweens[LDmeasure].val += var_betweens[LDmeasure].val;
            sim_var_betweens[LDmeasure].n++;
            hiLDtest_mean[LDmeasure].n++;
            loLDtest_mean[LDmeasure].n++;
            hiLDtest_var[LDmeasure].n++;
            loLDtest_var[LDmeasure].n++;
            g = 0;
            while ((mean_betweens[LDmeasure].val >= hiLDtest_mean[LDmeasure].vals[g]) && (g< MAXLDTAIL)) g++;
            g--;
            if ((g >= 0) && (g<= MAXLDTAIL-1)){
                for(h=0;h<g; h++) hiLDtest_mean[LDmeasure].vals[h] = hiLDtest_mean[LDmeasure].vals[h+1];
                hiLDtest_mean[LDmeasure].vals[g] = mean_betweens[LDmeasure].val;
            }
            g = 0;
            while ((mean_betweens[LDmeasure].val <= loLDtest_mean[LDmeasure].vals[g]) && (g< MAXLDTAIL)) g++;
            g--;
            if ((g >= 0) && (g<= MAXLDTAIL-1)){
                for(h=0;h<g; h++) loLDtest_mean[LDmeasure].vals[h] = loLDtest_mean[LDmeasure].vals[h+1];
                loLDtest_mean[LDmeasure].vals[g] = mean_betweens[LDmeasure].val;
            }
            g = 0;
            while ((var_betweens[LDmeasure].val >= hiLDtest_var[LDmeasure].vals[g]) && (g< MAXLDTAIL)) g++;
            g--;
            if ((g >= 0) && (g<= MAXLDTAIL-1)){
                for(h=0;h<g; h++) hiLDtest_var[LDmeasure].vals[h] = hiLDtest_var[LDmeasure].vals[h+1];
                hiLDtest_var[LDmeasure].vals[g] = var_betweens[LDmeasure].val;
            }
            g = 0;
            while ((var_betweens[LDmeasure].val <= loLDtest_var[LDmeasure].vals[g]) && (g< MAXLDTAIL)) g++;
            g--;
            if ((g >= 0) && (g<= MAXLDTAIL-1)){
                for(h=0;h<g; h++) loLDtest_var[LDmeasure].vals[h] = loLDtest_var[LDmeasure].vals[h+1];
                loLDtest_var[LDmeasure].vals[g] = var_betweens[LDmeasure].val;
            }
        }
    }
        
    /* debug *//* fprintf(debugfile,"\n"); */
    }
/*
             Sum(x)^2
  Sum(x^2) - --------
                n
   -------------------
          n-1
          */
/* useful stuff for debugging 
for (i=0;i< numregionLD;i++) for (j=i;j< numregionLD;j++) {
    for (LDmeasure = LDR;LDmeasure <= LDDP; LDmeasure++) if (LDdotypes[LDmeasure]){
        if (LDsimmean[LDmeasure][i][j].n > 0) {
            LDsimvar[LDmeasure][i][j].val = sqrt((LDsimvar[LDmeasure][i][j].val - LDsimmean[LDmeasure][i][j].val * LDsimmean[LDmeasure][i][j].val/LDsimmean[LDmeasure][i][j].n)/(LDsimmean[LDmeasure][i][j].n - 1));
            LDsimmean[LDmeasure][i][j].val /= (float) LDsimmean[LDmeasure][i][j].n;
        }

    }
} */

/* now restore the numbers */
for (tcount1 = 0; tcount1 < tscount; tcount1++) {
    strncpy(site_list[tcount1]->p,o_p[tcount1],nums);
}
/*free(site_list);  */
} /* regionLDscramble */


void print_regionLD(int groupi){
int i,j,k,cut025,cut005;
unsigned int  tcount1,tcount2;
char LDtestchar[LDDP+1][MaxregionLD][MaxregionLD];
float LDval[LDDP+1];
boolean LDok;
struct LDaccumulate LDmeancalc[LDDP+1];
int sigcounts[LDDP+1][2][4];
int comparisons_within,comparisons_between;
static int print_header = 0;

if (doLDregiontest) regionLDscramble(groupi);
for (LDmeasure = LDR;LDmeasure <= LDDP; LDmeasure++) if (LDdotypes[LDmeasure]){ 
    LDmeancalc[LDmeasure].val = 0.0;
    LDmeancalc[LDmeasure].n = 0;
    mean_betweens[LDmeasure].val = 0.0;
    mean_betweens[LDmeasure].n = 0.0;
    var_betweens[LDmeasure].val = 0.0;
    var_betweens[LDmeasure].n = 0.0;
    for (i=0;i<4;i++) for (j=0;j<2;j++) sigcounts[LDmeasure][j][i] = 0;
    for (i=0;i< numregionLD;i++) for (j=0;j< numregionLD;j++)  {
        regionLDmat[LDmeasure][i][j].val=0.0;
        regionLDmat[LDmeasure][i][j].n=0;
    }
}

nowsite1_ptr = nowsite_ptr;
/*for (i=0;i<4;i++) meanx[i] = 0.0; */
for (tcount1 = 0; tcount1 < scount-1; tcount1++) for (tcount2 = tcount1+1; tcount2 < scount; tcount2++) {
      Findnowsit(tcount1+1);
      Findnowsit1(tcount2+1);
      if (nowsitefit(nowsite) && nowsitefit(nowsite1))
            LDok = GetLD(groupi,&LDval[0]);
      else LDok = _false;
      if (LDok){
          i = 0;
          while ((regionLD[i] < nowsite.seqn) && (i < numregionLD)) i++;
          j = 0;
          while ((regionLD[j] < nowsite1.seqn) && (j < numregionLD)) j++;
          if (i> j) {
              k = i;
              i = j;
              j = k;
          }
          for (LDmeasure = LDR;LDmeasure <= LDDP; LDmeasure++) if (LDdotypes[LDmeasure]){ 
              LDmeancalc[LDmeasure].val += LDval[LDmeasure];
              LDmeancalc[LDmeasure].n++;
              regionLDmat[LDmeasure][i][j].val += LDval[LDmeasure];
              regionLDmat[LDmeasure][i][j].n++;
          }
      }
}
for (i=0;i< numregionLD;i++) for (j=i;j< numregionLD;j++)  {
    for (LDmeasure = LDR;LDmeasure <= LDDP; LDmeasure++) if (LDdotypes[LDmeasure]){ 
        if (regionLDmat[LDmeasure][i][j].n >= LDMINCOUNT){
            regionLDmat[LDmeasure][i][j].val  /=  (float) regionLDmat[LDmeasure][i][j].n;
            if (j>i) {
                mean_betweens[LDmeasure].val += regionLDmat[LDmeasure][i][j].val;
                mean_betweens[LDmeasure].n++;
                var_betweens[LDmeasure].val += SQR(regionLDmat[LDmeasure][i][j].val);
                var_betweens[LDmeasure].n++;
            }
        }
    }
}
if (doLDregiontest){
    cut025 = 0;
    cut005 = MAXLDTAIL - (int) (0.005 * LDSIMS);
    if (cut005 >= MAXLDTAIL) cut005 = MAXLDTAIL-1;
    for (LDmeasure = LDR;LDmeasure <= LDDP; LDmeasure++) if (LDdotypes[LDmeasure]){
        if (mean_betweens[LDmeasure].n) {
            if (var_betweens[LDmeasure].n > 1) var_betweens[LDmeasure].val = (var_betweens[LDmeasure].val- SQR(mean_betweens[LDmeasure].val)/var_betweens[LDmeasure].n)/((float) var_betweens[LDmeasure].n-1);
            mean_betweens[LDmeasure].val /= (float) mean_betweens[LDmeasure].n;
        }
    }
    for (i=0;i< numregionLD;i++) for (j=i;j< numregionLD;j++)
        for (LDmeasure = LDR;LDmeasure <= LDDP; LDmeasure++) if (LDdotypes[LDmeasure]){ 
            if (regionLDmat[LDmeasure][i][j].n >= LDMINCOUNT){
    /*            assert(hiLDtest[LDmeasure][i][j].n == LDSIMS); */
                if (hiLDtest[LDmeasure][i][j].n < LDSIMS){
                    LDtestchar[LDmeasure][i][j] = 'x';
                }
                else {
                    k = 0;
                    LDtestchar[LDmeasure][i][j] = ' ';
                    while ((regionLDmat[LDmeasure][i][j].val > hiLDtest[LDmeasure][i][j].vals[k]) && (k< MAXLDTAIL)) k++;
                    k--;
                    if ((k >= cut025) && (k< cut005 )){
                        LDtestchar[LDmeasure][i][j] = '*';
                        if (i==j) sigcounts[LDmeasure][0][0]++; else sigcounts[LDmeasure][1][0]++;
                    }
                    if ((k >= cut005) && (k< MAXLDTAIL )){
                        LDtestchar[LDmeasure][i][j] = '#';
                        if (i==j) sigcounts[LDmeasure][0][1]++; else sigcounts[LDmeasure][1][1]++;
                    }
                    k = 0;
                    while ((regionLDmat[LDmeasure][i][j].val < loLDtest[LDmeasure][i][j].vals[k]) && (k< MAXLDTAIL)) k++;
                    k--;
                    if ((k >= cut025) && (k< cut005 )){
                        LDtestchar[LDmeasure][i][j] = '$';
                        if (i==j) sigcounts[LDmeasure][0][2]++; else sigcounts[LDmeasure][1][2]++;
                    }
                    if ((k >= cut005) && (k< MAXLDTAIL )){
                        LDtestchar[LDmeasure][i][j] = '&';
                        if (i==j) sigcounts[LDmeasure][0][3]++; else sigcounts[LDmeasure][1][3]++;
                    }
                }
            } else LDtestchar[LDmeasure][i][j] = ' ';
        }
} else {
    for (i=0;i< numregionLD;i++) for (j=i;j< numregionLD;j++) 
        for (LDmeasure = LDR;LDmeasure <= LDDP; LDmeasure++) if (LDdotypes[LDmeasure]){ 
            LDtestchar[LDmeasure][i][j] = ' ';
        }
}
if (!print_header){
    FP"  Gene regions given in file :  %s \n",regionLDfile_NAME);
    FP"    Last base position for each region is LastBase#\n");
    FP"    Mean LD value between or within regions is given above, or on the diagonal\n");
    FP"      - means given only for comparisons with > %d pairs of polymorphic sites \n",LDMINCOUNT);
    FP"      - 'na' means not enough pairs of polymorphic sites between the regions \n");
    FP"    # pairs of sites within regions is given after LastBase#, in each row \n");
    FP"    # pairs of sites between regions is given below the diagonal \n");
    FP"    Indel variation is not included in these measurements \n");
    FP"    Only polymorphic sites with 4 or more sequences with base values, are used\n");
    if (doLDregiontest){
        FP"    Two-tailed tests:\n");
        FP"     hi values  '*' p<=0.025 '#' p<=0.005  lo values: '$' p<=0.025 '&' p<=0.005 \n");
        FP"     'x' means  not enough simulations returned calcuable values of the LD measure \n");\
    }
    print_header = 1;
}

for (LDmeasure = LDR;LDmeasure <= LDDP; LDmeasure++) if (LDdotypes[LDmeasure]){ 
    if (LDmeasure==LDR)  strcpy(LDstr," (r) ");
    if (LDmeasure==LDRS) strcpy(LDstr,"(r^2)");
    if (LDmeasure==LDD)  strcpy(LDstr," (D) ");
    if (LDmeasure==LDDP) strcpy(LDstr," (D')");
    if (LDmeasure==LDABS)  strcpy(LDstr,"(|D|)");
    if (LDmeasure==LDPABS)  strcpy(LDstr,"(|D'|)");
    comparisons_between = 0;
    comparisons_within = 0;
    FP"\nGroup : %10s    LINKAGE DISEQUILIBRIUM %s  MEASURE \n",groupnames[groupi],LDstr);
    FP"-------------------     ------- -------------- -----  -------\n");
    FP"Region LastBase#  ");
    for (i = 1; i <= numregionLD; i++) FP "     %2u   ",i);
    putc('\n', rfile);
    for (i = 1; i <= numregionLD; i++) {
      for (j=1; j < 19;j++) FP" ");
      for (j = 1; j <= numregionLD; j++) {
           if (j == i || j == i - 1)
             FP "----------");
           else
             FP "          ");
              }
       FP "\n%2u: %6u %5u ",i, regionLD[i - 1],regionLDmat[LDmeasure][i-1][i-1].n);
           for (j = 1; j <= numregionLD; j++) {
                  if (j==i){
                      if (regionLDmat[LDmeasure][i-1][j-1].n >= LDMINCOUNT) {
                          FP"| % 6.4f%c|",regionLDmat[LDmeasure][i-1][j-1].val,LDtestchar[LDmeasure][i-1][j-1]);
                          if (LDtestchar[LDmeasure][i-1][j-1] != 'x') comparisons_within++;
                      }
                      else FP"|   na    |");
                  }
                  if (j> i) {
                      if (regionLDmat[LDmeasure][i-1][j-1].n >= LDMINCOUNT) {
                          FP" % 6.4f%c ",regionLDmat[LDmeasure][i-1][j-1].val,LDtestchar[LDmeasure][i-1][j-1]);
                          if (LDtestchar[LDmeasure][i-1][j-1] != 'x') comparisons_between++;
                      }
                      else FP"   na     ");
                  }
                  if (j< i) FP"  %6u  ",regionLDmat[LDmeasure][j-1][i-1].n);
                    
              }
              putc('\n', rfile);
            }
    FP"\n");
    if (LDmeancalc[LDmeasure].n > 0)
        FP"  Mean overall Linkage Diseqiulibrium %s in Group: %s  %8.5f\n",LDstr,groupnames[groupi],LDmeancalc[LDmeasure].val/LDmeancalc[LDmeasure].n);
    if (doLDregiontest == _true){
        FP"   Number of testable comparisons.  Within regions: %3d   Between regions: %3d \n",comparisons_within,comparisons_between);
        FP"   Counts of Significant LD Values (two-tailed tests) \n");
        FP"    - Within  Regions: Hi p< 0.025: %2d  Hi p<0.005: %2d   Low p<0.025: %2d   Low p<0.005: %2d\n",sigcounts[LDmeasure][0][0],sigcounts[LDmeasure][0][1],sigcounts[LDmeasure][0][2],sigcounts[LDmeasure][0][3]);
        FP"    - Between Regions: Hi p< 0.025: %2d  Hi p<0.005: %2d   Low p<0.025: %2d   Low p<0.005: %2d\n",sigcounts[LDmeasure][1][0],sigcounts[LDmeasure][1][1],sigcounts[LDmeasure][1][2],sigcounts[LDmeasure][1][3]);
        if (comparisons_within+comparisons_between > 0) {
            FP"   Prop. of Significant Comparisons Within Regions.  ");
            FP"     Hi :  %7.5f    Lo : %7.5f \n",(float)(sigcounts[LDmeasure][0][0]+sigcounts[LDmeasure][0][1])/(float)(comparisons_within),(float)(sigcounts[LDmeasure][0][2]+sigcounts[LDmeasure][0][3])/(float)(comparisons_within));
            FP"   Prop. of Significant Comparisons Between Regions. ");
            FP"     Hi :  %7.5f    Lo : %7.5f \n",(float)(sigcounts[LDmeasure][1][0]+sigcounts[LDmeasure][1][1])/(float)(comparisons_between),(float)(sigcounts[LDmeasure][1][2]+sigcounts[LDmeasure][1][3])/(float)(comparisons_between));
        } else FP"    -     \n");
        if ((numregionLD >2) && (mean_betweens[LDmeasure].n > 1)){
            FP"  Tests of Mean LD Between Regions \n");
            FP"     Mean Observed LD Between Regions : % 7.4f ",mean_betweens[LDmeasure].val);
            if (sim_mean_betweens[LDmeasure].n) FP"  Mean Simulated value : %7.4f \n",(sim_mean_betweens[LDmeasure].val /(float) sim_mean_betweens[LDmeasure].n));
            else FP"\n");
            FP"     Significance levels: Hi p<0.025: % 7.4f  Hi p<0.005: % 7.4f  Low p<0.025: % 7.4f  Low p<0.005: % 7.4f\n",hiLDtest_mean[LDmeasure].vals[cut025],hiLDtest_mean[LDmeasure].vals[cut005],loLDtest_mean[LDmeasure].vals[cut025],loLDtest_mean[LDmeasure].vals[cut005]);
            if (mean_betweens[LDmeasure].val >hiLDtest_mean[LDmeasure].vals[cut025]) {
                if (mean_betweens[LDmeasure].val >hiLDtest_mean[LDmeasure].vals[cut005]) FP"      Observed Value is Significantly High, p< 0.005 \n");
                else FP"      Observed Value is Significantly High, p< 0.025 \n");
            }
            if (mean_betweens[LDmeasure].val < loLDtest_mean[LDmeasure].vals[cut025]){
                if (mean_betweens[LDmeasure].val <loLDtest_mean[LDmeasure].vals[cut005])FP"      Observed Value is Significantly Low, p< 0.005 \n");
                else FP"      Observed Value is Significantly Low, p< 0.025 \n");
            }
            FP"  Tests of Variance Among LD Between Regions \n");
            FP"     Variance Observed Between Regions : %10.8f ",var_betweens[LDmeasure].val);
            if (sim_var_betweens[LDmeasure].n) FP"  Mean Simulated value : %10.8f \n",(sim_var_betweens[LDmeasure].val /(float) sim_var_betweens[LDmeasure].n));
            else FP"\n");
            FP"     Significance levels: Hi p<0.025: %10.8f  Hi p<0.005: %10.8f  Low p<0.025: %10.8f  Low p<0.005: %10.8f\n",hiLDtest_var[LDmeasure].vals[cut025],hiLDtest_var[LDmeasure].vals[cut005],loLDtest_var[LDmeasure].vals[cut025],loLDtest_var[LDmeasure].vals[cut005]);
            if (var_betweens[LDmeasure].val >hiLDtest_var[LDmeasure].vals[cut025]) {
                if (var_betweens[LDmeasure].val >hiLDtest_var[LDmeasure].vals[cut005]) FP"      Observed Value is Significantly High, p< 0.005 \n");
                else FP"      Observed Value is Significantly High, p< 0.025 \n");
            }
            if (var_betweens[LDmeasure].val < loLDtest_var[LDmeasure].vals[cut025]){
                if (var_betweens[LDmeasure].val <loLDtest_var[LDmeasure].vals[cut005])FP"      Observed Value is Significantly Low, p< 0.005 \n");
                else FP"      Observed Value is Significantly Low, p< 0.025 \n");
            }

        }    
    }
    FP"\n\n");
}
}/* print_regionLD; */


/* program
generate a distribution of random LD values
for each group
scramble the sequences
for withins  record the 5% cutoff for a range of #'s of pairs of sample sizes
same for betweens

Then any particular mean LD value can be assessed for significance

after everything else is done, the list of sites could be scrambled withou

  how to scramble the list of sites?

record the locations of each record thoughout the entire list (i.e. the addresses)
record the actual list of seqn numbers  throughout the entire list

  for each randomization
    do a bunch of swaps between pairs of sites
        pick 2 random positions,  swap their seqn #'s
        repeat many times
    measure  mean of LD on each region, and between each pair of regions - just as with unscrambled data

  run 100 times, record top 5 values and bottom 5 values


Make that this is only run when one group is being analyzed in the entire run, 
    so that all the sites in the list are in that group
Also make sure that this is not run when D is that statistic, as it too often does not return enough comparisons
to measure.
*/

/*for (LDmeasure = LDR;LDmeasure <= LDDP; LDmeasure++) if (LDdotypes[LDmeasure]){ */