/***HKA**  Computer Program
copyright 2010  by Jody Hey
*/
#include "hkaprep.h"

/* HERE ARE ALL GlOBAL VARIABLES */
/* EXTERN USED WITH MOST OF THESE IN OTHER FILES */

double sites[2][MaxLoci] = {0};
  /* # polymorphic sites in species x at locus m is in sites[x][m]*/

double	between[MaxLoci] = {0};
  /* number of differences between the two species at a randomly
     selected line or for the average pairwise difference */

/* these matrices are just like the above except they hold actual
   data through multiple runs using different trees */
double  realsites[2][MaxLoci] = {0};
double	realbetween[MaxLoci] = {0};

extern float paramconflimit[PFMax][LimitMax];
   /* contains 95% confidence limits of estimated parameters.
      positions 0-lowup are for low values, highdown-LimitMAx for high values */
extern int lowup, highdown;
   /* used in HKADIST for splitting paramconflimit into two parts one for
    upper and one for lower */

float paramstat[PFMax][2] = {0.0};
   /* contains mean and variance from simulations of estimated parameters
      1st place for the mean second for the variance*/

int bps[MaxLoci][3];
    /* a vector of sequence lengths, bps[i][j] has the length of
    locus i for species j (j<=1), and the length of the region
    compared between species if j = 2. */

double X[PFMax] = {0.0};
  /* vector of parameter estimates */
  /* the first numloci values contain the estimates of � (4Nu) for species
     1 and locus k ( 0<=k<=numloci-1), then comes an estimate of T and last
     an estimate of f. There are a total of numloci + 2 values. */

double expsites[2][MaxLoci];
 /* expected values corresponding to sites */

double varsites[2][MaxLoci];
 /* has the variances within species  */

double expdiverg[MaxLoci];
double vardiverg[MaxLoci];
 /* expectation and variatiance of divergence of a random line between species */

double rparam[PFMax]; /* holds parameters estimated from  real data */
  /* values should be > 0.0  up to index numPF - 1, after which = 0.0 */

double fact[2*MaxSorL+1]; /* contains factorials */

double pair[MaxSorL + 1]; /* values >= 0.0 */

double apair[2][MaxSorL+1];
   /* coalescent parameters for species */

float lc[32*SETUNIT+1],lc2[32*SETUNIT+1];
 /* lc for length constants. an array of multipliers for polymorphic
 sites. element i = �1/j  for j := 1 to i-1. so nothing in elements 0 and 1*/
 /*lc2 is the same but the sum of squared inverses */

SET	speciessets[2][MaxLoci];
struct BSET speciessetsb[2][MaxLoci];
  /* element [i][j] contains the set of linenumbers that make up the sample
     from species i and locus j, initialized in  START */
struct BSET emptysetb = {0};

float	scores[MaxRuns] = {0};
	/* the final deviation scores from the simulations, must be sorted */

double numPF;
       /* numPF is the number of parameters and functions */
int tspot, fspot;
  /*the positions in the array X of T and F. T goes in position numloci
  i.e. after the theta parameters. f goes next in position numloci + 1*/

int	   samplesizes[2][MaxLoci];

int  		numloci, numspecies;

unsigned    nruns;

double      actual, actprob;

float lowpercent, highpercent;

int lowpoint, highpoint;

int ohfive, ohone;



float chilook[30][2] = {3.841,6.635,\
                       5.991,9.21,\
                       7.815,11.345,\
                       9.488,13.277,\
                       11.07,15.086,\
                       12.592,16.812,\
                       14.067,18.475,\
                       15.507,20.09,\
                       16.919,21.666,\
                       18.307,23.209,\
                       19.675,24.725,\
                       21.026,26.217,\
                       22.362,27.688,\
                       23.685,29.141,\
                       24.996,30.578,\
                       26.296,32.0,\
                       27.587,33.409,\
                       28.869,34.805,\
                       30.144,36.191,\
                       31.410,37.566,\
                       32.67,38.932,\
                       33.924,40.289,\
                       35.172,41.638,\
                       36.415,42.98,\
                       37.652,44.314,\
                       38.885,45.642,\
                       40.113,46.963,\
                       41.337,48.278,\
                       42.557,49.588};
int df; /* degrees of freedom */

float chromelc[2][MaxLoci];
float lcchrome[MaxLoci][2];
 /* a matrix. It contains the products of lc values and chromeadjust values*/
 /* also the transpose of it */

float chromadjust[MaxLoci];
 /* contains either 0.75 or 1.0 depending on whether the locus is X linked
 or autosomal, respectively */

int /*boolean */ doone; /* 0 if both species have more than one lineage,
           1 if species 2 only has 1 lineage for each locus */

int numdatasets, setnum;
unsigned nowrun;

/* save the largest deviation in the matrix used for calculating X^2
 call this maxcellval.  Then determine for each simulation what the largest
value is (use only the within species values */

double datamaxcellval, maxcellprop, nowmaxcellval;

float tajmtest[MaxSpecies],tajvtest[MaxSpecies];
int /*boolean*/  dotajsim,dofulisim; 
float tajdvals[MaxSpecies][MaxLoci],tajdmvals[3][MaxSpecies], tajdvvals[3][MaxSpecies]; 

float watchtajd[MaxSpecies][MaxLoci];
int numtajd[MaxSpecies][MaxLoci];


float fulimtest[MaxSpecies],fulivtest[MaxSpecies];

float fulidvals[MaxSpecies][MaxLoci],fulidmvals[3][MaxSpecies], fulidvvals[3][MaxSpecies]; 

float watchfulid[MaxSpecies][MaxLoci];
int numfulid[MaxSpecies][MaxLoci];

int tajdlocustest[MaxSpecies][MaxLoci];
int fulidlocustest[MaxSpecies][MaxLoci];



/* in case of negative T */
int  istneg;
float negt;


/* PROTOTYPES FOR FUNCTIONS IN THIS FILE*/
void Initialize(void);


/* HERE BEGIN ACTUAL FUNCTIONS */
/* MAIN AND INITIALIZATION FUNCTIONS */

void Initialize(void){
   int i,j,k;
   for (i=0;i<= 1; i++){
     for (k=0;k<= numloci-1;k++) sites[i][k] = realsites[i][k];
     }
   for (k=0;k<=numloci-1;k++)between[k] = realbetween[k];
   for (i=0;i<=PFMax-1; i++)
     for (j=0;j<=1;j++) paramstat[i][j] = 0.0;
   for (i=0;i<=PFMax-1; i++)
     for (j=0;j<=LimitMax-1;j++) paramconflimit[i][j] = 0.0;
   lc[1] = 1;
   lc[2] = 1;
   lc2[1] = 1;
   lc2[2] = 1;
   ohfive = 0;
   ohone = 0;
   if (doone) df = numloci - 1;
    else df = 2*numloci - 2;
   for (i = 3; i <= (32*SETUNIT); i ++) lc[i] = lc[i-1] + 1/(float)(i-1);
   for (i = 3; i <= (32*SETUNIT); i ++)\
           lc2[i] = lc2[i-1] + 1/fsqr ((float)(i-1));
   for (i = 0; i <= 1; i ++)
    for (j =0; j <= numloci - 1; j++){
      chromelc[i][j] = lc[samplesizes[i][j]] * chromadjust[j];
      lcchrome[j][i] = chromelc[i][j];
      }
   if (doone) numPF = numloci + 1;
    else numPF = numloci + 2;
   tspot = numloci;
   fspot = numloci + 1;
   filllimits();
   }

main(int argc, char *argv[]){

#ifdef  __MWERKS__
  argc = ccommand(&argv); 
  SIOUXSettings.autocloseonquit = _true;
  SIOUXSettings.asktosaveonclose = _false;
#endif
 	 

  Seeduni();
  Start(argc,argv);
  Initialize();
  if (calcparam() >= maxtry){
      printf("Error, could not estimate parameters\n"); shut(); exit(0);}
  if (X[tspot] <=0.0) {
		istneg = 1;
		negt = (float) X[tspot];
		X[tspot] = 0.0;
	} else istneg = 0;
  doexp();
  actual = calcstat0();
  datamaxcellval = nowmaxcellval;
  report();
  move(); /* move estimate parameters to other vectors */
  if (nruns > 0){
      dosimb();
	  Shell(); /*sort the results of the simulations*/
	  dist();
  }
  printstats();
  shut();
}  /*end main*/


