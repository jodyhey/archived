/* ALL FUNCTIONS FOR PLACING ACTUAL VALUES WITHIN SIMULATIONS */
#include "hkaprep.h"

/* Variables defined here */

float paramconflimit[PFMax][LimitMax];
int lowup, highdown;

/* ACTUAL FUNCTIONS */


void Shell(void){
  double aln = 1.442695022, tiny = 1.0e-5, t;
  int nn,m,lognb2,i,j,k,l;
  lognb2 = (int) floor(log(nruns)*aln + tiny);
  m = nruns;
  for (nn=1; nn<= lognb2; nn++){
      m = m /2;
      k = nruns - m;
      for (j = 0; j <= k-1; j++){
          i = j;
          reloop:
          l = i+m;
          if (scores[l]< scores[i]){
             t = scores[i];
             scores[i] = scores[l];
             scores[l] = (float) t;
             i = i - m;
             if (i>= 0) goto reloop;
             }
          }
      }
  } /*  shell */

void findactual(void){
  int i=0;
  for (i=0;((actual>scores[i])&&(i<=nruns-1));i++);
  if (i) actprob = 100*((nruns - i)/(float) nruns);
     else actprob = 0.0;
  }

double calcstat0(void){
 /* return the deviation statistic, just like HKA */
 int i,k;
 double temp1;
 double temp= 0.0;

 nowmaxcellval=0.0;
 for (i=0;i<= numspecies - 1; i++)
   for (k=0;k<= numloci-1;k++)
       if (samplesizes[i][k] > 1){
        if (varsites[i][k]){
            temp1 = fsqr(sites[i][k] - expsites[i][k])/varsites[i][k];
            if (temp1 > nowmaxcellval) nowmaxcellval = temp1;
            }
          else temp1 = 0.0;
        temp +=temp1;
        }
 for (k=0;k<=numloci-1;k++){
  if (vardiverg[k]) temp1 = ( fsqr(between[k] - expdiverg[k]) / vardiverg[k]);
    else temp1 = 0.0;
     temp += temp1;
     }
 return(temp);
 } /*calcstat0*/

void findlimits(void){
 int i,j,k;
 for (i=0;i <= numPF -1; i++){
     j = 0;
     while ( ( X[i] >= paramconflimit[i][j]) && (j<= lowpoint)) j++;
     if (j <= lowpoint){
         k = j;
         for(j=lowpoint;j > k; j--) paramconflimit[i][j] = paramconflimit[i][j-1];
         paramconflimit[i][k] = (float) X[i];
         }
     j = LimitMax - 1;
     while ( (X[i] <= paramconflimit[i][j]) && (j>= highpoint)) j--;
      if (j >= highpoint){
         k=j;
         for(j=highpoint; j < k; j++) paramconflimit[i][j] = paramconflimit[i][j+1];
         paramconflimit[i][k] = (float) X[i];
         }
     paramstat[i][0] += (float) X[i];
     paramstat[i][1] += (float) fsqr(X[i]);
     }
} /* findlimits */


void signifpercents(float nowx2){
 if  (nowx2 > chilook[df-1][0]) ohfive++;
 if  (nowx2 > chilook[df-1][1]) ohone++;
 }


void filllimits(void){
 int i,j;
 if (nruns >0 ){
 lowup = (LimitMax - 2) / 2;
 highdown = lowup + 1;
 lowpoint = (int) floor(nruns * 0.025) - 1;
 if (lowpoint > lowup) lowpoint = lowup;
 if (lowpoint <= 0) lowpoint = 0;
 lowpercent = (float)((lowpoint + 1)/ (float) nruns) * 100.0;
 highpoint = (int) (LimitMax - floor(nruns - (nruns * 0.975)));
 if (highpoint >= LimitMax) highpoint = LimitMax-1;
 if (highpoint < highdown) highpoint = highdown;
 highpercent = (float) (((nruns - (LimitMax - highpoint))/(float) nruns) * 100.0);
 for (i=0; i <= numPF-1; i++){
  for (j=0; j <= lowup; j++) paramconflimit[i][j] = 1e6;
  for (j=highdown; j <= LimitMax-1; j++) paramconflimit[i][j] = (float)1e-6;
  }
  }
 }/* filllimits */

