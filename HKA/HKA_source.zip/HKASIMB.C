/* a version for large sets */
#include "hkaprep.h"

extern FILE *rfile;
/* STATIC LOCAL VARIABLES */
static struct BSET 	mut[MaxMuts];
   /* every mutation that ever happens in a simulation gets a number.
   If line y has mutation number x then the set at mut[x] includes line y*/

static int   RI, RJ , SECCALL;
static double U[17], V[97];
static double GETV;
static int  mutindex;

struct Lines {struct BSET L[MaxSorL];};
	/*Lines is an array of bsets, each set is a lineages of descendants
   the elements of the array are all from the same species */

static struct Lines s1, s2, c, nlines;//, nulllines = {0};
 /* s1 is species 1, s2 is species 2 and c is the common ancestor */

static int clocus;

static float  within[MaxSpecies][MaxLoci];
static  int  singleton[MaxSpecies][MaxLoci];

/* STATIC FUNCTION PROTOTYPES */


static int cardinality(struct BSET x);
	/* returns the number of elements in set x , requires sets96.h and */

static double  picktime(int numthings, double size);
	/* pick a random number from an exponential distribution with a
	parameter based on numthings. returns a double */

static int pickpoisson(double param);
	/* pick a random number from a poisson distribution*/

static struct Lines clsc(int species);
	/* works on array of sets,list, each set is a group of linenumbers. Each
    set contains all of the lineages that descend from one lineage at the
    point in time that is under consideration. The
    sets together make up a group attached to a node.
	the basic loop is a coalescent which is repeated until there is only 1
	set of all lines or until NNtime is reached (speciation time).
	2 sets are randomly picked from an array of sets
   for each set a random number of mutations is picked
     mutations are applied to the mut array for all lines in the set
   the two sets of lines are joined into 1 set of lines
   the two sets are deleted from the array
   The new set is tacked onto the end of the array.
   The modified cluster is returned. */

static void Makelines(void);
/* fills up  s1,s2 for any particular locus */

static void Pool(void);
static void GetSimData(void);
	/* fill up within, between */

static void LoopInitialize(void);
static void LocusInitialize(void);

float dofulid(int samplesize, int nu, int nue);
float dotajd(int samplesize, int ss, float ww);

/*debug variables  */
float meansit0 = 0.0, meansit1 = 0.0, meanwin0 = 0.0, meanwin1 = 0.0, meanb = 0.0, meanmut = 0.0;
int countco;


/* FUNCTIONS */
double uni(void){
  double  Unif;
  int  PUTV;
  Unif = U[RI]-U[RJ];
  Unif += (Unif <= 0);
  U[RI]=Unif;
  RI--;
  if (RI < 0) RI=16;
  RJ--;
  if (RJ < 0) RJ = 16;
  if (SECCALL){
      PUTV = floor(97.0 * GETV) ;
      if (PUTV > 96) PUTV = 96;
      if (PUTV < 0) PUTV = 0;
      GETV = V[PUTV];
      V[PUTV] = Unif;
      if (GETV < 1.0)  return(GETV);
       else return (0.5);
      }
    else return(Unif);
}

void Seeduni(void){
  int K, Ll;
  int  IC, ID, seed1, seed2;
  double     T;
  srand((unsigned) time(NULL));
/*  seed1 =  random(20000);
  seed2 =  random(20000);*/
  seed1 = 1234;
  seed2 = 5678;
  IC=1973;
  RI=16;
  RJ=5;
  for (K=0;K<=16;K++)
        {
        U[K]=0.0;
        T=0.5;
        for (Ll=1;Ll<= 24;Ll++)
                {
                ID = seed1-IC;
                if ( ID < 0 ) ID += 32707;
                U[K]= U[K] + (ID % 2) * T;
                seed1=seed2;
                seed2=IC;
                IC=ID;
                T=0.5*T;
                }
        }
SECCALL = 0;
for (K = 0;K <= 96;K++)  V[0] = uni();
GETV = uni();
for (K = 0;K <= 96;K++)  V[K] = uni();
SECCALL = 1;
}


/*
int cardinality(struct BSET x){
	int count = 0,j;
    forallb(j,x) ++count;
    return (count);
    }
*/
int cardinality(struct BSET x){
	int count = 0,j;
  for (j=0;j<= (SETUNIT-1);j++)
	while (x.p[j] != emptyset) {
		x.p[j] ^= (x.p[j] & -x.p[j]); ++count;
		}
	return(count);
	}

double  picktime(int numthings, double size){
	double prob, temp;
	prob = (numthings*(numthings - 1)/ 2.0)/size;
    temp = log(uni());
	return(temp/(-prob));
	}

int pickpoisson(double param){
	double randnum, raised;
	int   i;
	raised = exp(-param);
	randnum =  uni();
	for (i=0; randnum > raised; i++){
        randnum *= uni();
        }
	return (i);
	}

struct Lines clsc(int species){
  int numsets,  muts, pick, i,j;
  struct BSET set1, set2;
  double  nowtime,endtime, time, popsize, mutrate;
  mutrate = rparam[clocus]*bps[clocus][species]/2.0;
  if (species == 1) {
     popsize = rparam[fspot]*chromadjust[clocus];
     nowtime = 0.0;
     endtime = rparam[tspot];
     for (i = 0; notemptyb(s2.L[i]);i++);
     numsets = i;
     nlines = s2;
     }
  if (species == 0) {
     popsize = chromadjust[clocus];
     nowtime = 0.0;
     endtime = rparam[tspot];
     for (i = 0; notemptyb(s1.L[i]);i++);
     numsets = i;
     nlines = s1;
     }
  if (species == 2) {
     popsize = chromadjust[clocus]*(1.0 + rparam[fspot])/2.0;
     nowtime = rparam[tspot];
     endtime = 1e20; /* something very large */
     for (i = 0; notemptyb(c.L[i]);i++);
     numsets = i;
     nlines = c;
     }
  while (nowtime < endtime){
      if ((numsets == 1) && (species == 2)) break;
      if (numsets >= 2) {
        time = picktime(numsets,popsize);
        if (nowtime + time >= endtime) time = endtime - nowtime;
           }
        else {
          time = endtime - nowtime;
          mutrate = rparam[clocus]*bps[clocus][2]/2.0;
          }
      nowtime += time;
      for (i = 0; i <= numsets - 1; i++){
         muts = pickpoisson(time*mutrate);
		 if (muts){
			 for (j=(mutindex + 1); j <= (mutindex + muts);j++){
					mut[j] = nlines.L[i];
				/*	assert(((float) mut[j].p[0]+ (float) mut[j].p[1]) > 0.99);  */
			 }
			     

				mutindex += muts;
		    }
         }
       if ((nowtime < endtime) && (numsets > 1)) {
	     pick = (int) floor(uni()*numsets);
		 assert(pick >= 0);
		 assert(pick < numsets);
	     set1 = nlines.L[pick];
         for (i=pick; i < numsets - 1; i++) nlines.L[i] = nlines.L[i+1];
		 nlines.L[numsets-1] = emptysetb; 
         numsets--;
	     pick = (int) floor(uni()*numsets);
		 assert(pick >= 0);
		 assert(pick < numsets);
	     set2 = nlines.L[pick];
         for (i=pick; i < numsets - 1; i++) nlines.L[i] = nlines.L[i+1];
		 nlines.L[numsets-1] = emptysetb; 
	     unionb(set1,set2,nlines.L[numsets - 1]);
		 assert(emptyb(emptysetb));
		 countco--;
         }
      }
    return(nlines);
    } /* end clsc */

void Makelines() {
     int j;
     struct BSET tempset1,tempset2;
     tempset1 = speciessetsb[0][clocus];
     for (j=0;j <= samplesizes[0][clocus]-1; j++){
      getlowb(tempset1,tempset2);
      s1.L[j] = tempset2;
      setdiffb(tempset1,tempset2,tempset1);
		     }
     for (j = samplesizes[0][clocus]; j <= MaxSorL - 1; j++)
       s1.L[j] = emptysetb;
     tempset1 = speciessetsb[1][clocus];
     for (j=0;j <= samplesizes[1][clocus]-1; j++){
		  getlowb(tempset1,tempset2);
		  s2.L[j] = tempset2;
		  setdiffb(tempset1,tempset2,tempset1);
	     }
     for (j = samplesizes[1][clocus]; j <= MaxSorL - 1; j++)
       s2.L[j] = emptysetb;
     }  /*makelines*/


void Pool(void) {
  int i,j;
  for (i = 0; i <= MaxSorL - 1; i++) c.L[i] = emptysetb;
  for (i=0; notemptyb(s1.L[i]); i++)  c.L[i] = s1.L[i];
  for (j=0; notemptyb(s2.L[j]); j++, i++) c.L[i] = s2.L[j];
  } /*end pool  */


float dofulid(int samplesize, int nu, int nue){
static float a1,a2,a,b,c,v,u, fl;
int n,i;
 n = samplesize;
 a1 = lc[n];
 a2 = 1.0;
 for (i = 2; i <= n - 1; i++) a2 += 1.0/fsqr((float)(i));
 a = a1;
 b = a2;
 c = 2 * (n * a - 2 * (n - 1)) / ((n - 1) * (n - 2));
 v = 1 + a * a / (b + a * a) * (c - (float) (n + 1) / (float) (n - 1));
 u = a - 1.0 - v;
 if (u * nu + v * nu * nu <= 0.0) fl = -100.0; /*undefined */
 else fl = (nu - a * nue) / sqrt(u * nu + v * nu * nu);
 return(fl);
} /*dofulid */


float dotajd(int samplesize, int ss, float ww){
static float khat, sf, e1, e2, a1, c1,b2, b1, c2, a2, D, nf;
static int n, i, s;
  n = samplesize;
  nf = (float) n;
  a1 = lc[n];
  a2 = 1.0;
  for (i = 2; i <= n - 1; i++) a2 += 1.0/fsqr((float)(i));
  b1 = (nf +1.0)/(3.0*(nf -1.0));
  b2 = 2.0*(nf*nf+nf+3.0)/(9.0*nf*(nf-1.0));
  c1 = b1- 1/a1;
  c2 = b2 - (nf+2.0)/(a1*nf)+a2/(a1*a1);
  e1 = c1/a1;
  e2 = c2/(a1*a1+a2);
  khat = ww;
  s = ss;
  sf = (float) ss;
  if (sf > 0.0) D = (khat - (sf/a1))/sqrt(e1*sf+e2*sf*(sf-1));
         else D = 0.0;
  if (fabs(D) > 10.0) {
			 D = Dfault;
		 }
  return(D);
  }/* dotajd */

void GetSimData(void){
 /*f0 and f1 are sets containing the first line of each species sample */
     int num1;
     struct BSET f1,f0,tempset1,tempset2;
     int i,j;
     
     getlowb(speciessetsb[0][clocus],f0);
     getlowb(speciessetsb[1][clocus],f1);
     for (i=0;i<=mutindex; i++) {
       for (j=0;j <= numspecies - 1; j++) {
         intersectb(mut[i],speciessetsb[j][clocus],tempset1);
	       num1 = cardinality(tempset1);
		   if (num1 && (samplesizes[j][clocus] - num1)){
			   sites[j][clocus]++;
			   if (dotajsim) within[j][clocus] +=  num1*(samplesizes[j][clocus] - num1)\
                 / ((samplesizes[j][clocus] * (samplesizes[j][clocus]-1))/2.0);
			   if (dofulisim) singleton[j][clocus] += (num1==1);

		   }
	       }
       intersectb(mut[i],f0,tempset1);
       intersectb(mut[i],f1,tempset2);
       unionb(tempset1,tempset2,tempset1);
       if (cardinality(tempset1) == 1)
             between[clocus]++;
       }
	 if (clocus==0){
		 meansit0 += sites[0][0];
		 meansit1 += sites[1][0];
		 meanwin0 += within[0][0];
		 meanwin1 += within[1][0];
		 meanb += between[0];
		 meanmut += mutindex;
	 }
     }  /*getsimdata */

void LoopInitialize(void){
     int i,j;
     for (i=0;i<=numspecies - 1;i++)
		 for (j=0;j <= numloci - 1;j++) {
			 sites[i][j] = 0;
			 within[i][j] = 0.0;
			 singleton[i][j] = 0;
		 }
     for (j=0;j <= numloci - 1; j++) between[j] = 0;
     }

void LocusInitialize(void){
     int j;
     Makelines();
     for (j=0;j<=MaxMuts-1;j++) mut[j] = emptysetb;
     mutindex = -1;
     }

void dosimb(void){
/* unsigned nowrun;*/
 int k;
 int i,j;
 static float temptaj,tajsum, tajmsim[MaxSpecies],tajsumsq,tajvsim[MaxSpecies];
 static float tempfuli,fulisum, fulimsim[MaxSpecies],fulisumsq,fulivsim[MaxSpecies];
 boolean  runok;


 for (nowrun=0; nowrun <= nruns-1; nowrun++) {    /* major simulation loop */
	LoopInitialize();
  printf("%4d\n",nowrun + 1);
 	for (clocus = 0; clocus <= numloci-1; clocus++) {
		/* simulate each locus */
		LocusInitialize();
		countco = samplesizes[0][clocus]+samplesizes[1][clocus];
		s1 = clsc(0);
        s2 = clsc(1);  /*do clsc on each group*/
		Pool(); /*combine whats left of the two groups into one*/
        clsc(2); /* do clsc for time before node*/
		assert(countco==1);
/*    gotoxy(1,15+clocus);
    printf("run : %4d  locus: %1d  mutations: %3d",nowrun + 1,clocus,mutindex + 1);*/
		GetSimData();
		}
  if (calcparam() >= maxtry){
	runok = _false;
    printf("poor fitting in run : %3d \n", nowrun + 1);
    for(k = 0; k<= numPF;k++)
          printf("X[%d]:%6.2lf ",k,X[k]);
    printf("score:  %7.4lf \n",scores[nowrun]);
    FP"\n Could not fit in run %d ",nowrun);
	/*
    FP"\n variable sites species 1 : %5.1f  %5.1f  %5.1f",sites[0][0],sites[0][1],sites[0][2]);
    FP"\n variable sites species 2 : %5.1f  %5.1f  %5.1f",sites[1][0],sites[1][1],sites[1][2]);
    FP"\n variable sites between species : %5.1f  %5.1f  %5.1f \n\n",between[0],between[1],between[2]);
	 */
    nowrun--;
    }
  else {
	runok = _true;
    doexp();
    scores[nowrun] = calcstat0();
    if (datamaxcellval > nowmaxcellval) maxcellprop++;
    signifpercents(scores[nowrun]);
    findlimits();
 /*   docomps(); */
/*    gotoxy(1,20);
    printf(" score : %8.3lf",scores[nowrun]); */
    }
   
  if (runok){
	     if (dotajsim){
				for (i= 0; i<= numspecies-1; i++){
					tajsum = 0.0;
					tajsumsq = 0.0;
					for (j=0,k=0;j<= numloci-1;j++){
						if ((samplesizes[i][j] > 3)&&(sites[i][j] > 0)){
							temptaj = dotajd(samplesizes[i][j],sites[i][j],within[i][j]);
							watchtajd[i][j] += temptaj;
							numtajd[i][j]++;
							if ((tajdvals[i][j] < Dfault_check)&& (temptaj < tajdvals[i][j])) tajdlocustest[i][j]++;
							k++;
							tajsum += temptaj;
							tajsumsq += fsqr(temptaj);
						}
					}  
					if (k>0){
						tajmsim[i] = tajsum/ (float) k;
						if (k>1) tajvsim[i] = (tajsumsq - fsqr(tajsum)/(float) k)/ (float) (k-1);
						  else tajvsim[i] = -1.0;
					}
				}
				for (i= 0; i<= numspecies-1; i++){
					tajdmvals[0][i] += tajmsim[i];
					tajdvvals[0][i] += tajvsim[i];
					if (tajmsim[i] < (tajmtest[i])) tajdmvals[1][i]++;
					if (tajmsim[i] > (tajmtest[i])) tajdmvals[2][i]++;
					if (tajvsim[i]>0){
						if (tajvsim[i] > tajvtest[i]) tajdvvals[2][i]++;
							else tajdvvals[1][i]++;
					}
				}
			}

		   if (dofulisim){
				for (i= 0; i<= numspecies-1; i++){
					fulisum = 0.0;
					fulisumsq = 0.0;
					for (j=0,k=0;j<= numloci-1;j++){
						if ((samplesizes[i][j] > 3)&&(sites[i][j] > 0)){
							tempfuli = dofulid(samplesizes[i][j],sites[i][j],singleton[i][j]);
							if (tempfuli > -10.0){
								watchfulid[i][j] += tempfuli;
								numfulid[i][j]++;
								if ((fulidvals[i][j] < Dfault_check)&& (tempfuli < fulidvals[i][j])) fulidlocustest[i][j]++;
								k++;
							}
						}
						if (tempfuli > -10.0){
							fulisum += tempfuli;
							fulisumsq += fsqr(tempfuli);
						}
					}  
					if (k>0){
						fulimsim[i] = fulisum/ (float) k;
						if (k>1) fulivsim[i] = (fulisumsq - fsqr(fulisum)/(float) k)/ (float) (k-1);
						  else fulivsim[i] = -1.0;
					}
				}
				for (i= 0; i<= numspecies-1; i++){
					fulidmvals[0][i] += fulimsim[i];
					fulidvvals[0][i] += fulivsim[i];
					if (fulimsim[i] < (fulimtest[i])) fulidmvals[1][i]++;
					if (fulimsim[i] > (fulimtest[i])) fulidmvals[2][i]++;
					if (fulivsim[i]>0){
						if (fulivsim[i] > fulivtest[i]) fulidvvals[2][i]++;
							else fulidvvals[1][i]++;
					}
				}
			}
	}
  }
 } /* dosim */


