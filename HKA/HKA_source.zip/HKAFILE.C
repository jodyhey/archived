#include "hkaprep.h"


/* STATIC LOCAL VARIABLES */
static char slabel[2][namelength + 1]; /* array of species names */
static char llabel[MaxLoci][namelength + 1]; /* array of locus names */
   /* first index changes names, second index is within names */

static char plabel[PFMax][45]; /*array of parameter names */
static char message[81],treestr[101], *commentptr;
static int /*boolean */ Ip,Rp,Mp,Sp,Tp,Fp;
char  dname[40], rname[40];
char  comment[101];
char  extracomments[10][101];
char templine[301];
int num_extracomments;
char command_line[200];

FILE		*dfile, *rfile;  /*data and results files*/

/* EXTERN FUNCTION PROTOTYPES */

extern int findnode(int species1, int species2);


/* STATIC LOCAL FUNCTION PROTOTYPES */

static int getsnum(char *slabelpt);
static int getlnum(char *slabelpt);
static int getspeciesid(void);
static int getlocusid(void);
static char *read_name(void);
static void strdelete(char *s,int pos,int len);

static char *strpos(char *str1, char *str2);
	/* find the position where the shorter of str2 and str1 occurs in the
	other and return the pointer to the location within the longer string*/

static char *dec2any(unsigned int number);
	/* convert integer to string. returns a pointer to the string*/

static void fillmulti(void);
static void fillplabel(void);
static double gammafunc(double x);
static double chicalc(double value);




/*  FUNCTIONS */

/* Delete the substring of length "len" at index "pos" from "s".
   Delete less if out-of-range. */
void strdelete(char *s,int pos,int len)
{
    int slen;

    if (--pos < 0)
        return;
    slen = strlen(s) - pos;
    if (slen <= 0)
        return;
    s += pos;
    if (slen <= len) {
        *s = 0;
        return;
    }
    while ((*s = s[len])) s++;
}
double gammafunc(double x){
 /* calculates gamma function, only if x is an integer or integer + 0.5 */
  #define sqrtpi  1.77245385
  double temp, prod=1.0;
  temp = x;
  while (temp > 1.0) {
      temp--;
      prod *= temp;
      }
  if (temp <= 0.5) prod *= sqrtpi;
  return (prod);
  }

double chicalc(double value){
/*calculates the probability associated with a a particular value
from a chi square distribution having df degrees of freedom */
 long double temp, prod, sum = 0.0;
 int i,j;
 for (i=1; i <= 100; i++){
   prod = 1.0;
   temp = pow(value,i);
   for (j=1; j <= i; j++) prod *= (df + 2.0*j);
   sum += temp/prod;
   }
 temp = pow(value/2.0,df/2.0)*exp(-value/2.0)/gammafunc((df+2)/2.0);
 return(1.0 - temp*(1+sum));
 }



char *read_name(void){
 /* reads in a string up to namelength characters.
  * stops if there is a whitespace
  * stops if end of line character
  * stops if there is a '\t' space
  * stops if longer than namelength
  */
static  char temps[namelength+1],tchar;
static int i, done;
 done = 0;
 do{
    tchar = getc(dfile);
    } while ((tchar == ' ')||(tchar == '\n')||(tchar == '\t'));
 temps[0] = tchar;
 i = 1;
 do{
   tchar = getc(dfile);
   if ((tchar != ' ')&&(tchar != '\n')&&(tchar != '\t')) {
      temps[i] = tchar;
      i++;
      }
    else done = 1;
   }while ((i<namelength)&&(! done));

 temps[i] = '\0';
 return(temps);
 }

int getsnum(char *slabelpt){
static  int  i;
  i=0;
  while ((strcmp(slabelpt,slabel[i])) && (i <= numspecies - 1) ) i++;
  if (i > numspecies - 1) return(-1);
     else return(i);
  }

int getlnum(char *llabelpt){
static  int  i;
   i = 0;
  while ((strcmp(llabelpt,llabel[i])) && (i <= numloci - 1) ) i++;
  if (i > numloci - 1) return(-1);
     else return(i);
  }

int getspeciesid(void){
static    char labelhold[namelength+1];
static    int speciesid;
    strcpy(labelhold,read_name());
    if (isdigit(labelhold[0]))
     speciesid = ((labelhold[0] - '0') <= numspecies - 1) ? labelhold[0] - '0': -1;
    else speciesid = getsnum(labelhold);
    if (speciesid == -1){
         printf("Error get species ID in getspeciesid\n");
         exit(0);
         }
    return(speciesid);
    }

int getlocusid(void){
static    char labelhold[namelength+1];
static    int locusid;
    strcpy(labelhold,read_name());
 /*   if (isdigit(labelhold[0]))
     locusid = ((labelhold[0] - '0') <= numloci - 1) ? labelhold[0] - '0': -1;
    else */ locusid = getlnum(labelhold);
    if (locusid == -1){
         printf("Error get locus ID in getlocusid\n");
         exit(0);
         }
    return(locusid);
    }

void fillplabel(void){
    int i;
    for (i=0;i<=numloci -1;i++){
		sprintf(plabel[i],"Theta(4Nu) for species 1, locus:%10s",&llabel[i]);
		plabel[i][44] = '\0';
	}
    sprintf(plabel[numloci + 1],"Population Scalar 'f' for species 2       ");
	plabel[numloci+1][44] = '\0';
    sprintf(plabel[numloci],"Speciation time parameter 'T'             ");
	plabel[numloci][44] = '\0';
   }

char *strpos(char *str1, char *str2){
   /* finds the position of one string within another */
	char *tempstr, *ip, *jp;
	/* first make sure that the short string is at str2 */
	if (strlen(str1) < strlen(str2)) {
		tempstr = str1;
		str1 = str2;
		str2 = tempstr;
		}
	jp = str2;
	for (ip = str1;*ip != '\x0';ip++)
	   if (*str2 == *ip) {
			tempstr = ip;
			for (jp=str2;*jp==*tempstr && *jp != '\x0'; jp++,tempstr++);
			if (*jp == '\x0') return (ip);
			}
	return(NULL);
   }

char *dec2any(unsigned int number) {
   static char buffer[32];      /* allow for up to 32-bit integers */
   char *bufptr = buffer + 31;  /* point to end of buffer */
   int digit;
   *bufptr-- = '\0';
   do {
	  digit = number % 10;
	  number /= 10;
	  *bufptr-- = (digit < 10) ? (digit + '0') : (digit + 'A' - 10); }
   while (number);
   return(++bufptr);
	}


static void getparams(int argc, char *argv[])
{
  char pstr[256];
  char ch;
  unsigned int  i;

  Ip = _false;
  Rp = _false;
  Mp = _false;
  Sp = _false;
  Tp = _false;
  Fp = _false;
  
  for (i = 1; i < argc; i++) {
	if (i==1) strcpy(command_line,argv[i]);
	else {
		strcat(command_line," ");
		strcat(command_line,argv[i]);
	}
    strcpy(pstr, argv[i]);
    ch = pstr[0];
    if (ch == '-' || ch == '/' || ch == '\\'){
     ch = pstr[1];
     strdelete(pstr,1,2);
    } else {
      ch = pstr[0];
      strdelete(pstr,1,1);
    }
    switch (toupper(ch)) {

    case 'I':
	case 'D':
      sprintf(dname, "%s", pstr);
      Ip = _true;
      break;

    case 'R':
      sprintf(rname, "%s", pstr);
      Rp = _true;
      break;

    case 'M':
      sprintf(message, "%s", pstr);
      Mp = _true;
      break;

    case 'S':
	  nruns = atoi(&pstr[0]);
      Sp = _true;
      break;

    case 'T':
      Tp = _true;
	  dotajsim = _true;
      break;
    case 'F':
      Fp = _true;
	  dofulisim = _true;
      break;
    }
  }
}


void Start(int argc, char *argv[]){
/* revised input format */
/*
Line 1  - a line of text
line 2 - the number of loci = numloci
line 3 - the names of the two species 
the next numloci lines each have the following items

	locus identifier (input data filename upto 10 characters)
	inheritance scalar (1.0 for autosomal 0.75 for X linked 0.25 for extrachromosomal or Y)
	mean sequence length group1 
	mean sequence length group2 
	mean sequence length between group 
	# of sequences group1 
	# of sequences group2 
	# of polymorphic sites group1 
	# of polymorphic sites group2 
	mean pairwise divergence between groups
	Tajima D  for group 1 
	Tajima D  for group 2 
	Fu & Li D for group 1 
	Fu & Li D for group 2 
if any D value is less than -10, it is taken as a fault value and will be ignored in analyses
*/
     int i,j,k;
     int numlines;
     char holdchar;
     SET tempset;
     struct BSET tempsetb;
     time_t t;
     float  temp1,temp2,temp3;
     char *dptr, dot = '.'; /* strchr */
     char *fgetsresult, *tempchar, tempch;

     printf("**** HKA tests ******* \n");
	 getparams(argc,argv);

     /*if (!Ip) {
		printf("Name of data file ('.hka' extension is assumed if none is given): \n");
		scanf("%s",dname);
	 }
	 dptr = strchr(dname,dot);
     if (!dptr) strncat(dname,".hka",4); */

	 if (!Ip) {
		printf("Name of data file: \n");
		gets(templine);
		if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
		sscanf(templine,"%s",dname);
	 }
	 if ((dfile = fopen(dname,"r")) == NULL){
	    printf("Error opening text file for reading\n"); exit(0);}
	 if (!Rp){
		printf("type the name of the results file : \n");
		gets(templine);
		if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
		sscanf(templine,"%s",rname);
	 }
     strncat(rname,".hka",4);
     if ((rfile = fopen(rname,"w")) == NULL){
        printf("Error opening text file for writing\n"); exit(0);}
	 if (!Sp){
		printf("type the number of simulations : \n");
		gets(templine);
		if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
		sscanf(templine,"%d",&nruns);
		if (nruns > 0) Sp = _true;
	 }
	 if (!Mp){
		*message = '\0';
		printf("TYPE A MESSAGE TO HEAD THE OUTPUT FILE : \n");
		/*scanf("%s",message); */
		fgets(message, 81, stdin);
		tempchar = strchr(message, '\n');
		if (tempchar != NULL){
			*tempchar = 0; 
		}
	 }
	 if (!Tp){
		 printf("Does Input File have Tajima D values? y or n \n");
		 gets(templine);
		 if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
		 sscanf(templine,"%c",&holdchar); 
		 if (toupper(holdchar) == 'Y') dotajsim = _true;
		 else dotajsim = _false;
	 }
	 if (!Fp){
		 printf("Does Input File have Fu&Li D values? y or n \n");
		 gets(templine);
		 if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
		 sscanf(templine,"%c",&holdchar); 
		 if (toupper(holdchar) == 'Y') dofulisim = _true;
		 else dofulisim = _false;
	 }
	 

	 /* get info from input file */
     commentptr = comment;
     fgetsresult = fgets(comment,100,dfile);
	 if (comment[strlen(comment)-1] == '\n') comment[strlen(comment)-1] = '\0';
	 num_extracomments=0;
	 do{
		 do{fgetsresult = fgets(templine, 300, dfile);
		 } while (templine[0] == '\n');
		if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
		if (templine[0]=='#'){
		   strcpy(extracomments[num_extracomments],&templine[1]);
		   num_extracomments++;
		 }
	 }while (templine[0]=='#');
	 sscanf(templine, "%d",&numloci);
/*	 fscanf(dfile,"%d",&numloci);  */
     numspecies = 2;
	 doone = _false;
     /*for (i=0;i <= numspecies - 1; i++) {
		 fscanf(dfile,"%10s",slabel[i]);
	 }
	 fscanf(dfile,"\n");
	 */
	 fgets(templine, 200, dfile);
	 if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
	 sscanf(templine,"%10s %10s",slabel[0],slabel[1]);


     for (i=0;i <= numloci - 1; i++){
		 if (dotajsim && dofulisim){
			 fgets(templine,300,dfile);
			 if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
			 sscanf(templine,"%10s %f %f %f %f %d %d %lf %lf %lf %f %f %f %f",
			 llabel[i],&chromadjust[i],&temp1,&temp2,&temp3,&samplesizes[0][i],&samplesizes[1][i],&realsites[0][i],
			 &realsites[1][i],&realbetween[i],&tajdvals[0][i],&tajdvals[1][i],&fulidvals[0][i],&fulidvals[1][i]);
		 }
		 if (dotajsim && !dofulisim){
			 fgets(templine,300,dfile);
			 if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
			 sscanf(templine,"%10s %f %f %f %f %d %d %lf %lf %lf %f %f",
			 llabel[i],&chromadjust[i],&temp1,&temp2,&temp3,&samplesizes[0][i],&samplesizes[1][i],&realsites[0][i],
			 &realsites[1][i],&realbetween[i],&tajdvals[0][i],&tajdvals[1][i]);

		 }
		 if (!dotajsim && !dofulisim){
			 fgets(templine,300,dfile);
			 if (templine[strlen(templine)-1] == '\n') templine[strlen(templine)-1] = '\0';
			 sscanf(templine,"%10s %f %f %f %f %d %d %lf %lf %lf %f %f",
			 llabel[i],&chromadjust[i],&temp1,&temp2,&temp3,&samplesizes[0][i],&samplesizes[1][i],&realsites[0][i],
			 &realsites[1][i],&realbetween[i],&tajdvals[0][i],&tajdvals[1][i]);
		 }
		 bps[i][0] = (int) temp1;
		 bps[i][1] = (int) temp2;
		 bps[i][2] = (int) temp3;
		 if (!doone) doone = (samplesizes[1][i] ==1);

/*
		 fscanf(dfile,"%10s",llabel[i]);
		 fscanf(dfile,"%f",&chromadjust[i]);
		 fscanf(dfile,"%f %f %f",&temp1,&temp2,&temp3);

		 bps[i][0] = (int) temp1;
		 bps[i][1] = (int) temp2;
		 bps[i][2] = (int) temp3;
		 fscanf(dfile,"%d",&samplesizes[0][i]);
		 fscanf(dfile,"%d",&samplesizes[1][i]);

		 if (!doone) doone = (samplesizes[1][i] ==1);
		 fscanf(dfile,"%lf",&realsites[0][i]);
		 fscanf(dfile,"%lf",&realsites[1][i]);
		 fscanf(dfile,"%lf",&realbetween[i]);
		 
		 if (dotajsim){
			fscanf(dfile,"%f",&tajdvals[0][i]);
			fscanf(dfile,"%f",&tajdvals[1][i]);

			if (tajdvals[0][i] <= -10.0) tajdvals[0][i] = Dfault;
			if (tajdvals[1][i] <= -10.0) tajdvals[1][i] = Dfault;
		 }
		 if (dofulisim){
			fscanf(dfile,"%f",&fulidvals[0][i]);
			fscanf(dfile,"%f",&fulidvals[1][i]);

			if (fulidvals[0][i] <= -10.0) fulidvals[0][i] = Dfault;
			if (fulidvals[1][i] <= -10.0) fulidvals[1][i] = Dfault;
		 } */
	 }
	 if (!Sp) {
		 dotajsim = _false;
		 dofulisim = _false;
	 }
     fillplabel();
     /* create speciessets */
     for (j=0; j <= numloci - 1; j++)
        for (i=0,numlines=0,k=0; i<= numspecies-1;i++){
           numlines += samplesizes[i][j];
               speciessetsb[i][j]=emptysetb;
                 for (;k<numlines; k++){
                   singlesetb(tempsetb,k);
                   unionb(speciessetsb[i][j],tempsetb,speciessetsb[i][j]);
                   }
           }
      if (doone) numspecies = 1;
	/* setup for tajd tests */
	  if (dotajsim){
		for (i=0;i<= numspecies -1; i++){
			temp1 = 0; temp2 = 0;
			for (j=0, k=0; j <= numloci - 1; j++)
				if ((samplesizes[i][j] > 3)&&(realsites[i][j] > 0) && (tajdvals[i][j] < Dfault_check)){
					temp1 += tajdvals[i][j];
					temp2 += fsqr(tajdvals[i][j]);
					k++;
				}
			if (k>0) {
				tajmtest[i] = temp1/(float)k;
				if (k>1) tajvtest[i] = (temp2 - fsqr(temp1)/(float) k)/ (float) (k-1);
			}
			for (j=0;j<=2;j++)tajdmvals[j][i] = 0.0;
			for (j=0;j<=2;j++)tajdvvals[j][i] = 0.0;
			for (j=0;j<=numloci-1;j++)watchtajd[i][j] = 0.0;
		    for (j=0;j<=numloci-1;j++)tajdlocustest[MaxSpecies][MaxLoci] = 0;
			for (j=0;j<=numloci-1;j++)numtajd[i][j] = 0;
		}
	  }
	/* set up for fuli tests*/
 	  if (dofulisim){
		for (i=0;i<= numspecies -1; i++){
			temp1 = 0; temp2 = 0;
			for (j=0, k=0; j <= numloci - 1; j++)
				if ((samplesizes[i][j] > 3)&&(realsites[i][j] > 0)&& (fulidvals[i][j] < Dfault_check)){
					temp1 += fulidvals[i][j];
					temp2 += fsqr(fulidvals[i][j]);
					k++;
				}
			if (k>0) {
				fulimtest[i] = temp1/(float)k;
				if (k>1) fulivtest[i] = (temp2 - fsqr(temp1)/(float) k)/ (float) (k-1);
			}
			for (j=0;j<=2;j++)fulidmvals[j][i] = 0.0;
			for (j=0;j<=2;j++)fulidvvals[j][i] = 0.0;
			for (j=0;j<=numloci-1;j++) watchfulid[i][j] = 0.0;
			for (j=0;j<=numloci-1;j++) fulidlocustest[MaxSpecies][MaxLoci] = 0;
			for (j=0;j<=numloci-1;j++) numfulid[i][j] = 0;
		}
	  }
	
  	  printf("                         Simulation #      out of %4d",nruns);
	  FP"**HKA**   -- COMPUTER PROGRAM FOR HKA TESTS --\n ");
	  
	  FP"     This program implements the method described in:\n");
	  FP"          Hudson, R. R., M. Kreitman and M. Aguad�, (1987) \n");
	  FP"          A test of neutral molecular evolution based on nucleotide data\n");
	  FP"          Genetics 116: 153-159 \n\n");
	  FP "%s\n%s\n\n",dashline,starline);
	  FP"DATA FROM FILE: %s\n",dname);
	  FP"DATA FILE TEXT LINE:\n %s \n\n",commentptr);
      if (num_extracomments > 0){
		 FP"Additional text from data file : \n");
		 for (i=0;i< num_extracomments;i++){
			 FP"  %s\n",extracomments[i]);
		 }
		 FP"\n\n");
	  }
	  FP"MESSAGE ADDED AT RUNTIME: \n %s \n\n", message);
	  FP"NUMBER OF SIMULATIONS: %4d \n",nruns);
	  FP"LOCI AND LENGTHS               species1 species2  between\n");
      for (i=0;i<=numloci-1;i++){
		  FP"                  %10s : ",llabel[i]);
		  for (j=0;j<=2; j++) FP" %5d   ",bps[i][j]);
		  FP"\n");
      }
}  /* end Start */



void report(){
  int i,k;
  double statemp;
  FP"\nOBSERVED AND EXPECTED VARIATION \n");
  FP"\nPOLYMORPHIC SITES WITHIN SPECIES \n");
  FP"Species           SampSize observed    expected     variance  deviation\n");
  FP"--------------    -------- --------    --------     --------  ---------\n");
  for (k=0;k<= numloci-1;k++){
    FP"\n*** LOCUS: %s ",llabel[k]);
    if (chromadjust[k] == 1.0) FP"  Autosomal *** \n\n");
    if (chromadjust[k] == 0.75) FP"  Sex-linked *** \n\n");
    if (chromadjust[k] == 0.25) FP"  extrachromosomal or Y-linked *** \n\n");
    for (i=0;i<= numspecies - 1;i++){
      statemp = fsqr(sites[i][k] - expsites[i][k]);
      statemp /= varsites[i][k];
      FP"  %12s      %3d    %4.0f          %6.2f      %6.2f     %7.3f\n",\
          slabel[i],samplesizes[i][k],sites[i][k],\
          expsites[i][k],varsites[i][k],statemp);
      }
     }
  FP"\n\nDIVERGENCE BETWEEN SPECIES \n");
  FP"       observed  expected   variance  deviation \n");
  FP"       --------  --------   --------  --------- \n");
  for (k=0;k<= numloci-1;k++){
      FP"\n*** LOCUS: %s ",llabel[k]);
     if (chromadjust[k] == 1.0) FP"  Autosomal *** \n\n");
     if (chromadjust[k] == 0.75) FP"  Sex-linked *** \n\n");
     if (chromadjust[k] == 0.25) FP"  extrachromosomal or Y-linked *** \n\n");
      statemp = fsqr(between[k] - expdiverg[k]);
      statemp /= vardiverg[k];
      FP"       %6.2f     %6.2f     %6.2f    %7.3f ",\
          between[k],expdiverg[k],vardiverg[k], statemp);
     }
  FP"\nSUM OF DEVIATIONS: %8.4f \n",actual);
  FP"Degrees of Freedom: %2d  Probability from chi square distribution: %7.5f \n",\
     df,chicalc(actual));
 
  }/*report*/

void printstats(void){
  int i,j;
   FP"TEST OF MAXIMUM CELL VALUE: \n");
   FP"  Maximum Cell Value: %8.4f  Proportion of runs with lower values : %7.5f \n",\
     datamaxcellval, maxcellprop/nruns);

  FP"\n\nESTIMATED PARAMETER VALUES AND SIMULATION STATISTICS\n\n");
  if (istneg){
	  FP" *** NOTE ***  Actual Estimate of T is negative : %8.5f \n",negt);
	  FP"        **** For Expectations and Simulations, T was set to 0.0 \n");
  }
  FP"Parameter                                   Estimate  %4.1f%%  -  %4.1f%%    Mean  Variance\n", lowpercent, highpercent);
  FP"-----------------------------------------   -------   ------  -------     -----  -------\n");
  if (nruns == 0)
    for (i=0; i <= numPF - 1; i++) FP"%30s %8.5f\n", plabel[i],rparam[i]);
  else
   for (i=0; i <= numPF - 1; i++)
    FP"%30s %8.5f %8.5f %8.5f %8.5f %10.7f\n",\
    plabel[i],rparam[i], paramconflimit[i][lowpoint],paramconflimit[i][highpoint],\
    paramstat[i][0]/nruns, paramstat[i][1]/nruns - fsqr(paramstat[i][0]/nruns));
  FP"\nTheta values adjusted for length \n\n");
  if (nruns == 0)
    for (i=0; i <= numloci - 1; i++) FP"%30s %8.5f\n", plabel[i],rparam[i]*bps[i][0]);
  else
   for (i=0; i <= numloci - 1; i++)
    FP"%30s %8.5f %8.5f %8.5f %8.5f %10.7f\n",\
    plabel[i],rparam[i]*bps[i][0], paramconflimit[i][lowpoint]*bps[i][0],\
    paramconflimit[i][highpoint]*bps[i][0],\
    paramstat[i][0]*bps[i][0]/nruns,\
    (paramstat[i][1]/nruns - fsqr(paramstat[i][0]/nruns))*fsqr((float) bps[i][0]));

  FP "%s\n%s\n\n",dashline,starline);
  if (dotajsim){
     for (j=0;j<=numspecies-1;j++) 
		 for (i=0;i<= numloci-1;i++)
			 if (numtajd[j][i]) watchtajd[j][i] /= (float) numtajd[j][i];
     for (i=0;i<=2;i++) 
		 for (j=0;j<=numspecies-1;j++) tajdmvals[i][j] /= (float) nruns;
     FP"\n\nTESTS OF MEANS AND VARIANCES OF TAJIMA D VALUES \n");
	 FP"  Species  Observed mean value  Simulated Mean Mean   %% lower     %% higher \n");
     for (i=0; i<= numspecies-1;i++){  
		 FP"   %2d       %8.5f               %8.5f          %8.5f       %8.5f\n",\
			 i,tajmtest[i],tajdmvals[0][i],100.0*tajdmvals[1][i]/(tajdmvals[1][i]+tajdmvals[2][i]),100.0*tajdmvals[2][i]/(tajdmvals[1][i]+tajdmvals[2][i]));
	 }
	 FP"  Species  Observed variance  Simulated Mean Variance %% lower     %% higher \n");
	 for (i=0; i<= numspecies-1;i++){  
		 FP"   %2d       %8.5f               %8.5f          %8.5f        %8.5f      \n",\
			 i,tajvtest[i],tajdvvals[0][i]/(tajdvvals[1][i]+tajdvvals[2][i]),100.0*tajdvvals[1][i]/(tajdvvals[1][i]+tajdvvals[2][i]),100.0*tajdvvals[2][i]/(tajdvvals[1][i]+tajdvvals[2][i]));
	 }
	 FP"\n\nTESTS OF INDIVIDUAL TAJIMA D VALUES \n");
	 FP"  Species  Locus   Observed Value  Simulated Mean Mean   %% lower     %% higher \n");
     for (i=0;i<= numspecies-1;i++)
		for (j=0; j<= numloci-1;j++){  
			if (tajdvals[i][j] < Dfault_check){
				FP"  %2d %10s     %8.5f       %8.5f             %8.5f       %8.5f\n",\
						i,llabel[j],tajdvals[i][j],watchtajd[i][j],100.0*tajdlocustest[i][j]/(float) numtajd[i][j],100.0*((float) numtajd[i][j] - tajdlocustest[i][j])/(float) numtajd[i][j]);
			}else FP"  %2d %10s   no observed value \n",i,llabel[j]);
	 }
  }

  if (dofulisim){
     for (j=0;j<=numspecies-1;j++) 
		 for (i=0;i<= numloci-1;i++)
			 if (numfulid[j][i]) watchfulid[j][i] /= (float) numfulid[j][i];
     for (i=0;i<=2;i++) 
		 for (j=0;j<=numspecies-1;j++) fulidmvals[i][j] /= (float) nruns;
	 FP"\n\nTESTS OF MEANS AND VARIANCES OF Fu&Li D VALUES \n");
     FP"  Species  Observed mean value  Simulated Mean Mean   %% lower     %% higher \n");
     for (i=0; i<= numspecies-1;i++){  
		 FP"   %2d       %8.5f               %8.5f          %8.5f       %8.5f\n",\
			 i,fulimtest[i],fulidmvals[0][i],100.0*fulidmvals[1][i]/(fulidmvals[1][i]+fulidmvals[2][i]),100.0*fulidmvals[2][i]/(fulidmvals[1][i]+fulidmvals[2][i]));
	 }
	 FP"  Species  Observed variance  Simulated Mean Variance %% lower     %% higher \n");
	 for (i=0; i<= numspecies-1;i++){  
		 FP"   %2d       %8.5f               %8.5f           %8.5f        %8.5f      \n",\
			 i,fulivtest[i],fulidvvals[0][i]/(fulidvvals[1][i]+fulidvvals[2][i]),100.0*fulidvvals[1][i]/(fulidvvals[1][i]+fulidvvals[2][i]),100.0*fulidvvals[2][i]/(fulidvvals[1][i]+fulidvvals[2][i]));
	 }
	 FP"\n\nTESTS OF INDIVIDUAL Fu&Li D VALUES \n");
	 FP"  Species  Locus   Observed Value  Simulated Mean Mean   %% lower     %% higher \n");
     for (i=0;i<= numspecies-1;i++)
		for (j=0; j<= numloci-1;j++){  
			if (fulidvals[i][j] < Dfault_check){
				FP"  %2d %10s     %8.5f       %8.5f             %8.5f       %8.5f\n",\
						i,llabel[j],fulidvals[i][j],watchfulid[i][j],100.0*fulidlocustest[i][j]/(float) numfulid[i][j],100.0*((float) numfulid[i][j] - fulidlocustest[i][j])/(float) numfulid[i][j]);
			}else FP"  %2d %10s   no observed value \n",i,llabel[j]);
	 }
  }
  FP "%s\n%s\n\n",dashline,starline);
} /* printstats */


void dist(void){
 /* report test results*/
 int i,j, top = 20;
 findactual();
 FP"\nSUM OF DEVIATIONS: %8.4f < %7.5f of simulated values \n",actual,actprob/100.0);
 FP"Comparison with chi-square distribution. \n");
 FP"Proportion of simulations with X^2 values greater than %5.3f (0.05) : %6.5f \n",\
     chilook[df-1][0],(float)ohfive /(float) nruns);
 FP"Proportion of simulations with X^2 values greater than %5.3f (0.01) : %6.5f \n",\
     chilook[df-1][1],(float)ohone /(float) nruns);
 /* comment out cumulative table ?? */
 FP"\nCUMULATIVE PROBABILITY DISTRIBUTION FROM SIMULATIONS\n\n");
 FP" %%        X^2 Value  Location in Cumulative Chi Square Distribution \n");
  j = floor(0.01 * nruns);
  FP" 99.0%% >= %6.3f         %4.3f  \n",scores[j],chicalc(scores[j]));
   for (i=1;i< top;i++){
       j = floor((i/(float) top) * nruns);
       FP"%5.1f%% >= %6.3f         %4.3f  \n",
                  (100*(top - i)/(float)top),scores[j],chicalc(scores[j]));
       }
  j = floor(0.99 * nruns);
    FP"  1.0%% >= %6.3f         %4.3f  \n",scores[j],chicalc(scores[j]));
   }


void shut(void){
/* close files and reset directory */
 FP"\n\n  - HKA  program by Jody Hey  updated Feb 16 2010 \n");
 fclose(rfile);
 fclose(dfile);
 }
