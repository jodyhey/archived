/* ALL FUNCTIONS FOR GETTING EXPECTATIONS AND VARIANCES */
#include "hkaprep.h"

/* STATIC FUNCTION PROTOTYPES */

static void dowithin(void);
static void dobetween(void);

/* FUNCTIONS */

void doexp(void){
    dowithin();
    dobetween();
    }

void dowithin(void){
 /* fill up the matrices expsites and varsites for # of polymorphic sites
    within species */
 int i, locus;
 for (i=0;i<= numspecies - 1; i++)
  for (locus=0; locus <= numloci - 1; locus++)
    if (i){expsites[i][locus] = chromadjust[locus] * \
                bps[locus][i]*X[locus]*lc[samplesizes[i][locus]]* X[fspot];
          varsites[i][locus] = expsites[i][locus] + \
                fsqr(bps[locus][i]*X[locus]*X[fspot]*chromadjust[locus])*\
                   lc2[samplesizes[i][locus]];
                }
     else {expsites[i][locus] = chromadjust[locus]* \
                  bps[locus][i]*X[locus]*lc[samplesizes[i][locus]];
           varsites[i][locus] = expsites[i][locus] + \
                   fsqr(bps[locus][i]*X[locus]*chromadjust[locus])\
                    *lc2[samplesizes[i][locus]];
                }
   } /* dowithin */

void dobetween(void){
 /* fill up expdiverg and vardiverg */
 int locus;
 for (locus=0; locus <= numloci-1; locus++)
  if (doone){
   expdiverg[locus] = bps[locus][2]*X[locus]*(X[tspot] + \
                      1.0*chromadjust[locus]);
   vardiverg[locus] = expdiverg[locus] +\
           fsqr(bps[locus][2]*X[locus]*chromadjust[locus]);
  }
  else{
   expdiverg[locus] = bps[locus][2]*X[locus]*(X[tspot] + \
          chromadjust[locus]* (1 + X[fspot])/2.0);
   vardiverg[locus] = expdiverg[locus] +\
       fsqr(bps[locus][2]*X[locus]*chromadjust[locus]*(1 + X[fspot])/2.0);
   }
 }
