/* ALL FUNCTIONS RELATING TO PARAMETER ESTIMATION FOR POLYMORPHIC SITES*/
#include "hkaprep.h"

/* STATIC VARIABLES LOCAL TO THIS FILE` */

static double betastart[PFMax], beta[PFMax], alpha[PFMax][PFMax];
static int INDX[PFMax];

/* STATIC FUNCTION PROTOTYPES */

static void fillbeta(void);
static void fillalpha(void);
static void fillbetastart(void);
static void fillguess(int source);
static void ludcmp(void);
static void lubksb(void);

/* ACTUAL FUNCTIONS */

void fillguess(int source){
       /* puts 1's or random numbers of parameters from actual data into X */
       int i;
       switch (source){
        case 0: for (i=0; i <= numPF - 1; i++) X[i] = 1; break;
        case 1: for (i=0; i <= numPF - 1; i++) X[i] = rparam[i];break;
        default:
                 for (i=0; i <= numPF - 1; i++) X[i] = \
                            ( (float) (uni()*2000.0 + 1.0)) / 1000.0;
        }
       }

void fillalpha(void){
   /* do the calculations that fill up the vector alpha.  */
   /* alpha contains the value of the derivatives of the SW, SB and LA
      equations w/ respect to all of the parameters. There are as many
      eauations as parameters so the matrix is square. The rows represent
      the equations, and for a particular row ( i.e. equation). the values
      in the different columns are the current value of the derivative of the
      equation taken w/ respect to the parameter associated w/ that column.
      The rows go in the same order as the ordering of the equations in beta.
      The order of the parameters across the columns proceeds the same as
      their ordering in X */

 int i,j, locus,eq;
 double temp = 0.0, tempc = 0.0;
 for (i=0;i<=numPF - 1; i++)
  for (j=0;j<=numPF-1;j++) alpha[i][j]=0.0;
 if (doone){
  for (locus = 0; locus <= numloci - 1; locus++){
   temp += bps[locus][2]* X[locus];
   alpha[0][locus] = bps[locus][0]*lc[samplesizes[0][locus]]*\
                    chromadjust[locus];
   alpha[1][locus] = (X[tspot] + chromadjust[locus]) * bps[locus][2]; 
   }
  for (locus=0;locus <=numloci-2;locus++)
     alpha[locus + 2][locus] = bps[locus][2]*X[tspot] + \
        chromadjust[locus]*(bps[locus][2] +
      + lc[samplesizes[0][locus]]*bps[locus][0]); 
  alpha[1][tspot] = temp;
  for (eq = 2; eq <=numPF - 1;eq++)
    alpha[eq][tspot] = bps[eq - 2][2] * X[eq-2];
  }
 else{
  for (locus = 0; locus <= numloci - 1; locus++){
   temp += bps[locus][2]* X[locus];
   tempc += chromadjust[locus]*bps[locus][2]* X[locus];
   alpha[0][locus] = bps[locus][0] * lc[samplesizes[0][locus]]*\
                   chromadjust[locus];
   alpha[1][locus] = bps[locus][1] * lc[samplesizes[1][locus]] * X[fspot]*\
                   chromadjust[locus];
   alpha[1][fspot] += bps[locus][1]*X[locus]*lc[samplesizes[1][locus]]*\
                    chromadjust[locus];
  /*alpha[2] refers to the SB equation */
    alpha[2][locus] = bps[locus][2]*\
            (X[tspot] + chromadjust[locus]*(1 + X[fspot])/2.0);
   }
  /* now get derivatives for LA equations w/ respect to the parameters */
  for (locus = 0; locus <= numloci - 2; locus++)
    alpha[locus + 3][locus] = \
      bps[locus][2]*X[tspot] +\
      chromadjust[locus]*(bps[locus][2]*(1 + X[fspot])/2.0 \
      + lc[samplesizes[0][locus]]*bps[locus][0] \
      + lc[samplesizes[1][locus]]*bps[locus][1]*X[fspot]);

  alpha[2][tspot] = temp;
  alpha[2][fspot] = tempc / 2.0;

  for (eq = 3; eq <=numPF - 1;eq++){
    alpha[eq][tspot] = bps[eq - 3][2] * X[eq-3];
    alpha[eq][fspot] = X[eq-3]*chromadjust[eq-3]*\
      (bps[eq-3][2]/2.0 + bps[eq-3][1]* lc[samplesizes[1][eq-3]]);
   }
  }
 }


void fillbeta(void){
 /* do the calculations for SW SB and LA equations and fill up vector beta*/
 /* first the 2 SW equations,
    then the SB equation,
    then the L-1 LA equations */
 /* beta contains the difference between the right hand values that come
    from the data and are in betastart and the current best estimate of
    those values using the current extimate of the parameters that have
    been placed in X.*/
 int i,locus;
 double temp[PFMax],tempt= 0.0, tempp= 0.0;
 for (i=0;i <= numPF - 1; i++) temp[i] = 0.0;
 if (doone){
  for (locus = 0;locus <= numloci - 1;locus++){
      temp[0] += bps[locus][0]* X[locus] * \
               lc[samplesizes[0][locus]]* chromadjust[locus];
      tempt +=  bps[locus][2]* X[locus];
      tempp +=  bps[locus][2]* X[locus]*chromadjust[locus];
       }
  temp[1] = X[tspot]*tempt + tempp;
  for (i = 2, locus = 0;locus <= numloci - 2;locus++, i++)
   temp[i] = X[locus]* (bps[locus][2]*X[tspot] +\
            chromadjust[locus]*(bps[locus][2]+\
               lc[samplesizes[0][locus]]*bps[locus][0]));
  }
 else{
 for (locus = 0;locus <= numloci - 1;locus++){
      temp[0] += bps[locus][0]* X[locus] * \
             lc[samplesizes[0][locus]]*chromadjust[locus];
      temp[1] += bps[locus][1]* X[locus] *\
             lc[samplesizes[1][locus]]*chromadjust[locus];
      tempt += bps[locus][2]* X[locus];
      tempp +=  bps[locus][2]* X[locus]*chromadjust[locus];
       }
  temp[1] *= X[fspot];
  temp[2] = (X[tspot]*tempt + tempp*(1 + X[fspot])/2.0);
  for (i = 3, locus = 0;locus <= numloci - 2;locus++, i++)
   temp[i] = X[locus]*\
     (bps[locus][2]*X[tspot] + \
      chromadjust[locus]*(bps[locus][2]*(1 + X[fspot])/2.0 +\
       lc[samplesizes[0][locus]]*bps[locus][0] +\
       lc[samplesizes[1][locus]]*X[fspot]* bps[locus][1]));
  }
 for (i = 0; i <= numPF - 1;i++) beta[i] = betastart[i] - temp[i];
 } /*fillbeta*/

void fillbetastart(void){
  /* just call this once per loop. Put the appropriate sums from
     data matrices within and between into the vector betastart */
 /* first the 2 SW equations,
    then the SB equation,
    then the L-1 LA equations */
  int i,locus;
  for (i=0;i <= numloci + 2; i++) betastart[i] = 0.0;
  if (doone){
   for (locus = 0;locus <= numloci - 1;locus++){
      betastart[0] += sites[0][locus];
      betastart[1] += between[locus];
      }
   for (i = 2, locus = 0;locus <= numloci - 2;locus++, i++)
    betastart[i] = sites[0][locus] +  between[locus];
    }
  else {
     for (locus = 0;locus <= numloci - 1;locus++){
      betastart[0] += sites[0][locus];
      betastart[1] += sites[1][locus];
      betastart[2] += between[locus];
      }
   for (i = 3, locus = 0;locus <= numloci - 2;locus++, i++)
    betastart[i] = sites[0][locus] + sites[1][locus] + between[locus];
    }
  } /* fillbetastart */

void ludcmp(void){
 /* does LU decomposition as described on page 35 of numerical recipes.
    the value D = +/- 1 is sometime useful as descirbed on page 35 */
 /* makes use of a matrix INDX that gets used later, so INDX is global */
 int D = 1, i,j,k;
 double AAMAX, SUM, DUM;
 int IMAX;
 double VV[PFMax];
 double tiny = 1e-30;
 for (i=0; i <= numPF - 1;i++) {
     AAMAX = 0;
     for (j=0; j <= numPF - 1; j++){
         if (fabs(alpha[i][j]) > AAMAX) AAMAX = fabs(alpha[i][j]);
         }
     VV[i] = 1/AAMAX;
     }
 for (j=0; j <= numPF - 1; j++){
   for (i=0; i <= j-1; i++){
       SUM = alpha[i][j];
       for (k=0; k <= i-1; k++) SUM -= (alpha[i][k] * alpha[k][j]);
       alpha[i][j] = SUM;
       }
   AAMAX = 0;
   for (i=j; i <= numPF - 1; i++){
      SUM = alpha[i][j];
      for (k=0; k <= j-1; k++) SUM -= (alpha[i][k] * alpha[k][j]);
      alpha[i][j] = SUM;
      DUM = VV[i]* fabs(SUM);
      if (DUM >= AAMAX) {
         IMAX = i;
         AAMAX = DUM;
         }
      }
   if (j != IMAX){
     for (k=0; k <= numPF - 1; k++){
        DUM = alpha[IMAX][k];
        alpha[IMAX][k] = alpha[j][k];
        alpha[j][k] = DUM;
        }
     D = -D;
     VV[IMAX] = VV[j];
     }
   INDX[j] = IMAX;
   if (alpha[j][j] == 0) alpha[j][j] = tiny;
   if (j != (numPF - 1)){
      DUM = 1/alpha[j][j];
      for (i=j+1; i <= numPF - 1; i++) alpha[i][j] *= DUM;
      }
   }
 } /* ludcmp */

void lubksb(void){
  /* continues LU decomposition as described on page 35 of numerical recipes.
    returns +/- 1 as descirbed on page 35 */
  /* makes use of a matrix INDX that gets used later, so INDX
     is static to this file*/
  int ii=0, i,j,LL;
  double  SUM;
  for (i=0; i <= numPF-1; i++){
      LL = INDX[i];
      SUM = beta[LL];
      beta[LL] = beta[i];
      if (LL != 0) for (j=ii; j <= i-1; j++) SUM -= alpha[i][j] * beta[j];
        else if (SUM != 0) ii=i;
      beta[i] = SUM;
      }
  for (i=numPF-1; i>=0; i--){
      SUM = beta[i];
      if (i<numPF-1) for (j=i+1;j<=numPF-1;j++) SUM -=alpha[i][j] * beta[j];
      beta[i] = SUM/alpha[i][i];
      }
  } /*lubksb*/

int calcparam(void){
  /* a variation on MNEWT from numerical recipes page 272 */
  /* starting guess is all ones when actual data is used. For the simulations
     the estimated parameters from the actual data are used as the starting
     guess. Do ntrial recurssions, if it does not fit, then try again with
     random numbers as starting guess */
  #define ntrial 15
  int i,j, DataOrSimTry;
  int negp;
  double errf, errx, tolx = 1e-6, tolf = 1e-6;

  fillbetastart();
  DataOrSimTry = (X[0] > 0.0);

  do {
     fillguess(DataOrSimTry);
     if (DataOrSimTry) DataOrSimTry++;
                       else DataOrSimTry += 2;
     for (i=0; i <= ntrial - 1; i++){
         fillalpha();
         fillbeta();
         errf = 0;
         for (j= 0, errf = 0; j <= numPF-1; j++) errf += fabs(beta[j]);
         if (errf <= tolf) break;
         ludcmp();
         lubksb();
         for (j= 0, errx = 0; j <= numPF-1; j++){
             X[j] += beta[j];
             errx += fabs(beta[j]);
             }
         if (errx <= tolx) break;
         }
     if (DataOrSimTry > maxtry) break;
     } while ((errf > tolf) && (errx > tolx));
   j=0;
   negp=0;
   while ((j< tspot) && (X[j] >= 0.0)){
	   if (X[j] >= 0.0) j++; 
   }
   if (j<tspot) negp = 1;
   if ((numPF > tspot)&&(X[fspot] < 0.0)) negp = 1;
   if (negp) DataOrSimTry = maxtry+1;
   return(DataOrSimTry - 1);
  } /* calcparam */

void move(void){
 /* move current parameters into permament param vectors*/
 int i;
 for (i=0; i<= PFMax - 1;i++) rparam[i] = X[i];
 if (doone) rparam[fspot] = 1.0;
 }

