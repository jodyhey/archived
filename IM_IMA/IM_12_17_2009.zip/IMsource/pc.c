/* IM  by Jody Hey and Rasmus Nielsen  2004-2009 */
/*last updates 12_17_09 */



/* pc.c functions for exponential size change */

#undef GLOBVARS
#include "im.h" 


/* random time for migration with exponential population size change */
__forceinline double rm(double q, double qa, double m, double t, double f, double pret, int n)
	{
	double r, z,lz, t1,t2, t3,t4;
//return 2* exp(-n*(n-1)*time/q) /q;
    if (n<1)
        return TIMEMAX;
	z = f*qa/q;
    lz = log(z);
    myassert(z>0);
    r = uniform();
	t1 = pow(z,pret/t);
	t2 = m * n * t*(t1 - z) / lz;
	t3 = 1 - exp(t2);
    if (r > t3)
        {
		t4 = TIMEMAX;
        return t4;
        }
    else
        {
        t2 = log(t1 - log(1-r) * lz / (m * n * t));
        t3 = (t * t2/lz) - pret;
    	myassert(t3>=0);
        return t3;
        }
    } /* rc */

/* random time from a coalescent with exponential population size change */
__forceinline double rc(double q, double qa, double t, double f, double pret, int pairs)
	{
	double r, z,lz, t1,t2, t3,t4,t5;
	z = f*qa/q;
    lz = log(z);
    myassert(z>0);
    if (pairs < 1)
        return TIMEMAX;
	r = uniform();
	t1 = pow(z,pret/t);
	t5 = q * lz;
	t2 = pairs * 2 * t * ((1/z) - (1/t1))/(t5);
	t3 = 1 - exp(t2);
    if (r > t3)
        {
    	t4 = TIMEMAX;
        return t4;
        }
    else
        {
        t2 = pairs * 2 * t / (pairs * 2 * t + t1 * q * log(1-r) * lz);
        t3 = t * log(t2)/lz;
    	myassert(t3>=0);
        return t3;
        }
    } /* rc */

/* probability of a particular pair coalescing */
__forceinline double pcexp(double q, double qa, double t, double f, double time, double pret, int n)
	{
	double z, t1,t2, t3,t4;
//return 2* exp(-n*(n-1)*time/q) /q;
	z = f*qa/q;
    myassert(z>0);
    if (fabs(z-1) < 1e-15)
    	return 2* exp(-n*(n-1)*time/q)/q;
	t1 = pow(z,(time+pret)/t);
	t4 = q*log(z) * t1;
	t2 = n*(n-1)*t* (pow(z,time/t)-1)/(t4);
	t2 = exp(-t2);
	if (t2 != 0)
		t3 = 2*t2/(q * t1);
	else
		t3 = 0;
	myassert(t3>=0);
    return t3;
    } /*pcexp */

/* probability of no pairs coalescing in the interval */
__forceinline double pncexp(double q, double qa, double t, double f, double time, double pret, int n)
	{
	double z, t1,t2, t3,t4;
//return  exp(-n*(n-1)*time/q);
	z = f*qa/q;
    myassert(z>0);
    if (fabs(z-1) < 1e-15)
		return exp(-n*(n-1)*time/q);
	t4 = q*log(z);
	t1 = pow(z,-(pret+time)/t);
    t2 = n*(n-1)*t*t1 * (pow(z,time/t)-1)/(t4);
	t3 = exp(-t2);
	myassert(t3>=0);
	return t3;
	} /* pncexp */
	

/* probability of a particular migrant */
__forceinline double pmexp(double q, double qa, double m, double t, double f, double time, double pret, int n)
	{
	double z,t1, t2, t3;
    /* z=1 */
//return m* /* n* */exp(-m*n*time);
    z = f*qa/q;
    myassert(z>0);
    if (fabs(z-1) < 1e-15)
		return m* /* n* */ exp(-m*n*time);
	t3 = pow(z, pret/t)/log(z);
	if (time==0)
		{
		t2 = m*n*pow(z,pret/t);
		}
	else
		{
		t1 = m*n*t*(pow(z, time/t)-1)*t3;
		t2 = m * pow(z, (pret+time)/t)*exp(-t1);
		}
    
	myassert(t2 >=0);
	myassert(t2 < 1e200);
	return t2/n;
    } /*pmexp */

/* probability of no migration yet */
__forceinline double pnmexp(double q, double qa, double m, double t, double f, double time, double pret, int n)
	{
		double z,t1, t2, t3;
//return exp(-m*n*time);
    z = f*qa/q;
    myassert(z>0);
    if (fabs(z-1) < 1e-15)
		return exp(-m*n*time);
    if (m==0)
        return 1;
	t3 = pow(z, pret/t)/log(z);
	t1 = m*n*t*(pow(z, time/t)-1)*t3;
	t2 = exp(-t1);
    myassert(t2 >=0 && t2 <=1);
    return t2;
    }/*pnmexp */



/* version of simroot that works for the exponential size change model*/
int simrootg(int ci, int li, double m1, double m2, int edge, int downedge, int curpopedge,int edgemignum)
	{
	int i, ai, stop, rootmignum, curpoproot;
	double  t, oldt, rm1, rm2, rc1, rc2;
	struct edge *tree = L[ci][li]->tree;
	double qt1 = (Q[ci]->q1*Q[ci]->h[li]);
	double qt2 = (Q[ci]->q2*Q[ci]->h[li]);
	double qtA = (Q[ci]->qA*Q[ci]->h[li]);


    oldt = t = L[ci][li]->roottime;
	rootmignum = 0;
	curpoproot = tree[L[ci][li]->root].pop;
	while (tree[L[ci][li]->root].mig[rootmignum] > -0.5 && tree[L[ci][li]->root].mig[rootmignum] < t) 
		{
		rootmignum++;
		curpoproot = 1 - curpoproot;
		}
	stop = 0;
	do
		{
		if (t < Q[ci]->t)
			{
			if (curpopedge == curpoproot)
				{
        		if (curpopedge == 0)
                    {
                    rm1 = rm(qt2,qtA,m1,Q[ci]->t,(1-Q[ci]->s),t,2);
                    rc1 = rc(qt1,qtA,Q[ci]->t,Q[ci]->s,t,1);
					myassert(rm1>0 && rc1 > 0);
                    t = t +  MIN(rm1,rc1);
                    }
				else
                    {
                    rm2 = rm(qt1,qtA,m2,Q[ci]->t,Q[ci]->s,t,2);
                    rc2 = rc(qt2,qtA,Q[ci]->t,(1-Q[ci]->s),t,1); 
					myassert(rm2>0 && rc2 > 0);
                    t = t +  MIN(rm2,rc2);
                    }
				}
            else 
                {
                rm1 = rm(qt2,qtA,m1,Q[ci]->t,(1-Q[ci]->s),t,1);
                rm2 = rm(qt1,qtA,m2,Q[ci]->t,Q[ci]->s,t,1);
				myassert(rm1>0 && rm2 > 0);
                t = t + MIN(rm1,rm2); 
                }
			if (t >= Q[ci]->t)
				t = Q[ci]->t;
			}
        if (t >= Q[ci]->t || ((curpoproot == curpopedge) && 
            (  ((curpoproot == 0) && (rc1 < rm1) )
            || ((curpoproot == 1) && (rc2 < rm2) ) ) ) )
			{
			if (t >= Q[ci]->t)
				t = t + expo(2.0/(qtA));
			// this can cause roottime to equal TIMEMAX under some circumstances  - awkward 
			L[ci][li]->roottime = tree[L[ci][li]->root].time = tree[edge].time = t; // just make it an error check in domcmc() if t > TIMEMAX
			tree[L[ci][li]->root].down = tree[edge].down = downedge;
			tree[downedge].time = TIMEMAX;
			tree[downedge].down = -1;
			for (ai = 0; ai< L[ci][li]->numsmm;ai++)
				tree[downedge].dlikeA[ai] = 0;
			tree[downedge].up[0] = edge;
			tree[downedge].up[1] = L[ci][li]->root;
			tree[downedge].pop = curpopedge;
			tree[downedge].mig[0] = -1;
			tree[L[ci][li]->root].mig[rootmignum] = -1;
			tree[edge].mig[edgemignum] = -1;
			stop = 1;
			}
		else
			{
			/*printf("mig and t: %f, %i %i %i\n",t,curpoproot,curpopedge,L[ci][li]->root);*/
    		if (((curpoproot == curpopedge) && bitran() /*uniform() < 0.5 */) || 
                   ((curpoproot == 0 && curpopedge == 1) && (rm1 < rm2) )
                || ((curpoproot == 1 && curpopedge == 0) && (rm2 < rm1) ) )
				{
				curpoproot = 1 - curpoproot;
				checkmig(rootmignum,&(tree[L[ci][li]->root].mig), &(tree[L[ci][li]->root].cmm));
				tree[L[ci][li]->root].mig[rootmignum] = t;
				rootmignum++;
				}
			else
				{
				curpopedge = 1 - curpopedge;
				checkmig(edgemignum,&(tree[edge].mig), &(tree[edge].cmm));
				tree[edge].mig[edgemignum] = t;
				edgemignum++;
				}
			}
		} while(stop == 0);
	i = L[ci][li]->root;
	L[ci][li]->root = downedge;
	return i;
    } /* simrootg */

/* version of makecoal that works for the exponential size change model (-r0) */
void makecoalg(int ci, int li, double m1, double m2, int edge, int downedge, int sisedge, int *newsisedge)

	{
	int curpop, i,j, ai,num, nextnode, stop, dow;
	double curt, time, rm1, rm2, rc1, rc2;
	struct edge *tree = L[ci][li]->tree;
	double qt1 = (Q[ci]->q1*Q[ci]->h[li]);
	double qt2 = (Q[ci]->q2*Q[ci]->h[li]);
	double qtA = (Q[ci]->qA*Q[ci]->h[li]);

	if (tree[edge].up[0] == -1)
		curt = 0;
	else
		{
		curt = tree[tree[edge].up[0]].time;
		}
	i = 0;
	while (tree[sisedge].mig[i] > -0.5 ) 
		i++;
	j = -1;
	do {
		j++;
		checkmig(i,&(tree[sisedge].mig), &(tree[sisedge].cmm));
		tree[sisedge].mig[i] = tree[downedge].mig[j];
		i++;
		} while (tree[downedge].mig[j] > -0.5 ); 
	tree[sisedge].time = tree[downedge].time;
	tree[edge].time = curt;
	tree[edge].mig[0] = - 1;
	tree[downedge].time = 0;/*huh?*/
	dow = tree[sisedge].down = tree[downedge].down;
	if (dow != -1)
		{
		if (tree[dow].up[0] == downedge)
			tree[dow].up[0] = sisedge;
		else tree[dow].up[1] = sisedge;
		}
	else
		{ 
		L[ci][li]->root = sisedge;
		tree[sisedge].time = TIMEMAX;
		for (ai = 0; ai< L[ci][li]->numsmm;ai++)
	        tree[sisedge].dlikeA[ai] = 0;
		}
	stop = 0;
	i = 0;
	curpop = tree[edge].pop;
	do
		{
		time = curt;
		do
			{
			num = 0;
			curt = time;
			time = gettime(ci,li,&nextnode, time, &num, curpop, Q[ci]->t);
			if (curt < Q[ci]->t)
				{
				if (curpop == 0)
                    {
                    if ( (m1 + num) >0) 
                        {
                        rm1=rm(qt2,qtA,m1,Q[ci]->t,(1-Q[ci]->s),curt,1);
                        rc1=rc(qt1,qtA,Q[ci]->t,Q[ci]->s,curt,num); 
						rm2=rc2=0;
                        curt = curt + MIN(rm1,rc1);
                        }
                    else curt = TIMEMAX;/*very large number*/
                    }
				else
                    {
                    if ( (m2 +num) > 0)
                        {
                        rm2=rm(qt1,qtA,m2,Q[ci]->t,Q[ci]->s,curt,1);
                        rc2=rc(qt2,qtA,Q[ci]->t,(1-Q[ci]->s),curt,num);
						rm1=rc1=0;
                        curt = curt + MIN(rm2,rc2);
                        }
                    else curt = TIMEMAX;/*very large number*/
                    }
				if (curt > Q[ci]->t && Q[ci]->t < time)
					{
					num = 0;
					time = gettime(ci, li, &nextnode, Q[ci]->t, &num, curpop, Q[ci]->t);
					curt = Q[ci]->t + expo(num * 2.0/(qtA));
					}
				}
			else 
               curt = curt + expo(num * 2.0/(qtA));
			}while (curt > time && time < L[ci][li]->roottime);
		if (curt >= L[ci][li]->roottime)
			{
			*newsisedge = simrootg(ci,li,m1,m2,edge, downedge, curpop, i);
			stop = 1;
			}
		else 
            {
            if (curt < Q[ci]->t && 
                 ( (curpop == 0 && (rm1 < rc1 ) )
                || (curpop == 1 && (rm2 < rc2 ) ) ) )
                {
				myassert( (curpop==0 && rm1 < Q[ci]->t) || (curpop==1 && rm2 < Q[ci]->t));
                curpop = 1-curpop;
				checkmig(i,&(tree[edge].mig), &(tree[edge].cmm));
                tree[edge].mig[i] = curt;
                i++;
                }
		    else
			    {
			    tree[edge].mig[i] = -1;
			    *newsisedge = updateedge(ci, li, curt, edge, downedge, num, curpop, sisedge);
				stop = 1;
			    }
            }
		} while (stop == 0);
    } /* makecoalg */
