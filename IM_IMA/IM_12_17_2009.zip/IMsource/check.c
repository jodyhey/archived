/* IM  by Jody Hey and Rasmus Nielsen  2004-2009 */
/*last updates 12_17_09 */


/* check.c */

#undef GLOBVARS
#include "im.h"

/* info for aread and awrite - reciprocal functions for printing and scanning values 
*name is a string, usually with the name
*a  the address at the beginning
iu is the number of values  1, if just one,  >1 if an 
/*atype = 0 for integer
1  for long
2  for float
3  for double
4  for character
5  for unsigned long
*/

/* change this string whenever the dck format changes */ 
char dckversionstring[50] = "DCK FORMAT VERSION 1.03 date 3/5/2007";
// change this - get rid of 07 typo
// 8/29/07  was not mallocing scalefactors when loading checkpointfile,  
// I don't think need to save scalefactors in the checkpointfile, as they get recalculated by makefrac 
				


void awrite(char *name, int atype, int iu, void *a)

	{
	int *ip;
	long *lip;
	float *fp;
	double *dp;
	char *cp;
	unsigned long *ulp;
	int i;
	
	fprintf(dckfile,"%s %d %d ",name,atype,iu);
	switch (atype)
		{
		case 0 : for (i = 0, ip=a; i<iu; i++) fprintf(dckfile,"%d ",*(ip + i)); break;
		case 1 : for (i = 0, lip=a; i<iu;i++) fprintf(dckfile,"%ld ",*(lip + i)); break;
		case 2 : for (i = 0, fp=a; i<iu; i++) fprintf(dckfile,"%g ",*(fp + i)); break;
		case 3 : for (i = 0, dp=a; i<iu; i++) fprintf(dckfile,"%lg ",*(dp + i)); break;
		case 4 : for (i = 0, cp=a; i<iu; i++) fprintf(dckfile,"%c",*(cp + i)); 
				if (*(cp+i) != '\0')
					fprintf(dckfile,"%c",'\0'); 
				break;
		case 5 : for (i = 0, ulp=a; i<iu;i++) fprintf(dckfile,"%lu ",*(ulp + i)); break;
		}
	fprintf(dckfile,"\n");
	} /* arraywrite */
	
void aread(char *name, int atype, int iucheck, void *a)
	{
	int *ip;
	long *lip;
	float *fp;
	double *dp;
	char *cp;
	unsigned long *ulp;
	int typecheck,i, iu;
	char namecheck[100];
	char dckversioncheck[50], *tc;

	fscanf(dckfile,"%s %d %d ",namecheck,&typecheck,&iu);
	if (strcmp(name,namecheck) != 0)
		{
		printf("variable names do not match: %s  <> %s \n",name,namecheck);
		err(-1,-1,43);
		}
	if (typecheck != atype)
		{
		printf("variable types do not match: %d  <> %d \n",atype,typecheck);
		err(-1,-1,44);
		}
	if (strcmp(name,"dck_version_string") == 0)
		{
		strcpy(dckversioncheck,dckversionstring);
		tc = a;
		}
	switch (atype)
		{
		case 0 : for (i = 0, ip=a; i<iu; i++, ip++) fscanf(dckfile,"%d ",ip); break;
		case 1 : for (i = 0,lip=a; i<iu; i++,lip++) fscanf(dckfile,"%ld ",lip); break;
		case 2 : for (i = 0, fp=a; i<iu; i++, fp++) fscanf(dckfile,"%g ",fp);break;
		case 3 : for (i = 0, dp=a; i<iu; i++, dp++) fscanf(dckfile,"%lg ",dp);	break;
		case 4 : for (i = 0, cp=a; i<iu; i++, cp++) fscanf(dckfile,"%c",cp);*cp = '\0';	
					if (strcmp(name,"dck_version_string")==0)
						if (strcmp(tc,dckversioncheck) != 0)
							{
							printf("dck file versions do not match: file version: %s  expecting version: %s\n",tc,dckversioncheck);
							err(-1,-1,45);
							}
					break;
		case 5 : for (i = 0,ulp=a; i<iu; i++,ulp++) fscanf(dckfile,"%lu ",ulp); break;
		}
	} /* arrayread */

#define aa   awrite
/* the order of things written to the dck file is nearly arbitrary.  file can be large */


void writedck(void)  // same as readdck but without the malloc statements
	{
	int i,j, ci, li;
	printf("WRITING CHECKPOINT FILE . . . . . \n");
    remove(olddckfilename);
    rename(dckfilename, olddckfilename);
	if ((dckfile = fopen(dckfilename,"w")) == NULL)
		{
		printf("Error opening check file for writing\n"); 
		err(-1,-1,9);
		}
		aa("dck_version_string",4,strlen(dckversionstring),&(dckversionstring[0]));

	aa("fpstr",4,strlen(fpstr),&fpstr[0]);
	aa("infilename",4,strlen(infilename),&infilename[0]);
	aa("checkmode",0,1,&checkmode);
	aa("checkinmode",0,1,&checkinmode);
	aa("checktimer",1,1,&checktimer);
	aa("outfilename",4,strlen(outfilename),&outfilename[0]);
	aa("oldoutfilename",4,strlen(oldoutfilename),&oldoutfilename[0]);
	aa("surfilename",4,strlen(surfilename),&surfilename[0]);
	aa("dckfilename",4,strlen(dckfilename),&dckfilename[0]);
	aa("numchains",0,1,&numchains);
	aa("nloci",0,1,&nloci);
	
	for (ci = 0; ci< numchains;ci++)
		{
		aa("Q",3,sizeof(struct parameters)/sizeof(double),Q[ci]);
		}
	aa("Qwin",3,sizeof(struct parameters)/sizeof(double),&Qwin);
	aa("Qmax",3,sizeof(struct parameters)/sizeof(double),&Qmax);
	aa("Qmin",3,sizeof(struct parameters)/sizeof(double),&Qmin);
	aa("Qaccp",3,sizeof(struct parameters)/sizeof(double),&Qaccp);
	aa("Qupdatetries",3,sizeof(struct parameters)/sizeof(double),&Qupdatetries);
	aa("Qaccp0",3,sizeof(struct parameters)/sizeof(double),&Qaccp0);
	aa("Qold",3,sizeof(struct parameters)/sizeof(double),&Qold);
	for (i = 0; i< gridsize;i++)
		{
		aa("Qgrid",3,sizeof(struct parameters)/sizeof(double),&Qgrid[i]);
		}
	for (i = 0; i< gridsize;i++)
		{
		aa("Qvec",3,sizeof(struct parameters)/sizeof(double),&Qvec[i]);
		}
	for (i = 0; i< TRENDDIM;i++)
		{
		aa("Qtrend",3,sizeof(struct parameters)/sizeof(double),&Qtrend[i]);
		}
	aa("beforegrid",3,sizeof(struct parameters)/sizeof(double),&beforegrid);
	aa("aftergrid",3,sizeof(struct parameters)/sizeof(double),&aftergrid);
		aa("seed_for_ran1",1,1,&seed_for_ran1);
	aa("step",1,1,&step);
	aa("burnsteps",1,1,&burnsteps);
	aa("recordstep",1,1,&recordstep);
	aa("burnduration,",1,1,&burnduration);
	aa("chainduration,",1,1,&chainduration);
	aa("checkduration",1,1,&checkduration);
	aa("bdurationmode,",0,1,&bdurationmode);
	aa("cdurationmode,",0,1,&cdurationmode);
	aa("checkmode",0,1,&checkmode);
	aa("printoptions[SMOOTHDIST+1]",0,SMOOTHDIST+1,&printoptions[0]);
	aa("progopts[WIDELOGSCALE+1]",0,WIDELOGSCALE+1,&progopts[0]);
	aa("recordint",0,1,&recordint);
	aa("gupdateint",0,1,&gupdateint);
	aa("heatmode",0,1,&heatmode);
	aa("swaptries",0,1,&swaptries);
	for (ci = 0; ci< numchains;ci++)
		aa("swapcount",5,numchains,&(swapcount[ci][0]));
	aa("fpstri",0,1,&fpstri);
	aa("basics",0,1,&basics);
	aa("nloci",0,1,&nloci);
	aa("numparams",0,1,&numparams);
	aa("firstuparam",0,1,&firstuparam);
	aa("lastuparam",0,1,&lastuparam);
	aa("nurates",0,1,&nurates);
	aa("printint",0,1,&printint);
	aa("largestsamp",0,1,&largestsamp);
	aa("mostsmm",0,1,&mostsmm);
	aa("surfsetvals",0,1,&surfsetvals);
	aa("surfsetvals",0,1,&surfsetvals);
	aa("swap01",0,1,&swap01);
	aa("swap01d",0,1,&swap01d);
	aa("swap12",0,1,&swap12);
	aa("swap12d",0,1,&swap12d);
	aa("chaintimeintervals",0,1,&chaintimeintervals);
	aa("surfilecount",0,1,&surfilecount);
	aa("adaptcheck",0,1,&adaptcheck);
	aa("starttime",1,1,&starttime);
	aa("endtime",1,1,&endtime);
	aa("totaltime",1,1,&totaltime);
	aa("burntime",1,1,&burntime);
	aa("chainstarttime",1,1,&chainstarttime);
	aa("timer",1,1,&timer);
	aa("lasttime",1,1,&lasttime);
	aa("generationtime",3,1,&generationtime);
	aa("hval1",3,1,&hval1);
	aa("hval2",3,1,&hval2);
	aa("hilike",3,1,&hilike);
	aa("hiprob",3,1,&hiprob);
	aa("surfilenumstr",4,strlen(surfilenumstr),&surfilenumstr[0]);
	aa("beta",3,numchains,&beta[0]);
	aa("hilocuslike",3,nloci,&hilocuslike[0]);
	aa("hilocusprob",3,nloci,&hilocusprob[0]);
	aa("uperyear",3,nloci + mostsmm,&uperyear[0]);
	aa("uscaleml",3,nloci + mostsmm,&uscaleml[0]);
	aa("lptrend",3,TRENDDIM,&lptrend[0]);
	aa("holdsisdlikeA",3,mostsmm,&holdsisdlikeA[0]);
	aa("tmrcagrid",3,gridsize,&tmrcagrid[0]);
	aa("kappawindowsize",3,nloci,&kappawindowsize[0]);
	aa("kappamax",3,nloci,&kappamax[0]);
	aa("holddownA",0,mostsmm,&holddownA[0]);
	aa("ntest",0,3,&ntest[0]);
	aa("mtest",0,nloci,&mtest[0]);
	aa("nmtest",0,nloci,&nmtest[0]);
	aa("swaporder",0,numchains,&swaporder[0]);
	aa("gaccp",0,nloci,&gaccp[0]);
	aa("topolaccp",0,nloci,&topolaccp[0]);
	aa("locusulookup",0,nloci,&locusulookup[0]);
	aa("checkstep",0,AUTOCTERMS,&checkstep[0]);
	aa("gupdatetries",1,nloci,&gupdatetries[0]);
	aa("ulow[]",3,nloci + mostsmm,&ulow[0]);
	aa("uhi[]",3,nloci+mostsmm,&uhi[0]);
	for (i=0;i<numparams ;i++)
	 aa("correlations[][]",3,numparams,&(correlations[i][0]));
	for (i=0;i<nloci + mostsmm;i++)
	 aa("urrlow[][]",3,nloci + mostsmm,&(urrlow[i][0]));
	for (i=0;i< nloci + mostsmm ;i++)
	 aa("urrhi[][]",3,nloci + mostsmm,&(urrhi[i][0]));
	for (i=0;i<numchains ;i++)
	 aa("kappa[][]",3,nloci,&(kappa[i][0]));
	for (i=0;i<nloci;i++)
	 aa("tmrcadist[][gridsize]",3,gridsize,&(tmrcadist[i][0]));
	aa("tmrcaafter[]",3,nloci,&(tmrcaafter[0]));
	for (i=0;i<nloci ;i++)
	 aa("Aupdateratecount[][]",3,mostsmm,&(Aupdateratecount[i][0]));
	for (i=0;i<nloci ;i++)
	 aa("Aupdatetries[][]",3,mostsmm,&(Aupdatetries[i][0]));
	for (i=0;i<2 ;i++)
	 aa("snadist[2][gridsize]",3,gridsize,&(snadist[i][0]));
	aa("snagrid[gridsize]",3,gridsize,&(snagrid[0]));
	for (i=0;i<nloci;i++)
	  for (j=0;j<2;j++)
		aa("meventvec[][2][gridsize+1]",3,gridsize,&(meventvec[i][j][0]));
	for (i=0;i<nloci;i++)
	  for (j=0;j<2;j++)
		aa("mtimevec[][2][gridsize+1]",3,gridsize,&(mtimevec[i][j][0]));
	for (i=0;i<2;i++)
	  for (j=0;j<nloci;j++)
		aa("mcomp[2][][]",0,nloci,&(mcomp[i][j][0]));
	for (i=0;i<nurates;i++)
		aa("ucomp[][]",0,nurates,&(ucomp[i][0]));
	aa("popnames[0]",4,strlen(popnames[0]),&(popnames[0][0]));
	aa("popnames[1]",4,strlen(popnames[1]),&(popnames[1][0]));
	aa("nextstepsave",0,AUTOCTERMS,&nextstepsave[0]);
	aa("nextstepcalc",0,AUTOCTERMS,&nextstepcalc[0]);
	aa("nextpossave",0,AUTOCTERMS,&nextpossave[0]);
	aa("nextposcalc",0,AUTOCTERMS,&nextposcalc[0]);
	aa("maxpos",0,AUTOCTERMS,&maxpos[0]);
	aa("holdswap",0,1,&holdswap);
	aa("sw01",0,1,&sw01);
	aa("sw01d",0,1,&sw01d);
	aa("sw12",0,1,&sw12);
	aa("sw12d",0,1,&sw12d);
	aa("trendspot",0,1,&trendspot);
	aa("recordtrendinc",0,1,&recordtrendinc);
	aa("recordinc",0,1,&recordinc);
	aa("movespot",0,1,&movespot);
	aa("runinterval",0,1,&runinterval);
	aa("checkinterval",0,1,&checkinterval);
	aa("pmax",0,1,&pmax);
	aa("z_rndu",0,1,&z_rndu);
	aa("x_rndu",0,1,&x_rndu);
	aa("y_rndu",0,1,&y_rndu);

	for (i=0;i<nloci;i++)
		{
		aa("tmrca_s",3,1,&(tmrca[i].s));
		aa("tmrca_s2",3,1,&(tmrca[i].s2));
		aa("tmrca_n",0,1,&(tmrca[i].n));
		}
	for (i=0;i<AUTOCTERMS;i++)
		for (j=0;j<BASICPARAMS+2;j++)
		{
		aa("autoc_s",3,1,&(autoc[i][j].s));
		aa("autoc_s2",3,1,&(autoc[i][j].s2));
		aa("autoc_n",0,1,&(autoc[i][j].n));
		}
	for (i=0;i<AUTOCTERMS;i++)
		{
		aa("auto_lp_s",3,1,&(autoc_lp[i].s));
		aa("auto_lp_s2",3,1,&(autoc_lp[i].s2));
		aa("auto_lp_n",0,1,&(autoc_lp[i].n));
		}
	for (i=0;i<BASICPARAMS+2;i++)
		{
		aa("variance_s",3,1,&(variance[i].s));
		aa("variance_s2",3,1,&(variance[i].s2));
		aa("variance_n",0,1,&(variance[i].n));
		}
	aa("variance_lp_s",3,1,&(variance_lp.s));
	aa("variance_lp_s2",3,1,&(variance_lp.s2));
	aa("variance_lp_n",0,1,&(variance_lp.n));
    for (i=0;i<numparams-1;i++)
     for (j=i+1;j<=numparams-1;j++)
        {
		aa("c_n",0,1,&(c[i][j].n));
		aa("c_s",3,5,&(c[i][j].si));
        }
	for (i=0;i<numparams;i++)
		{
		aa("paraminfo[i].listpos",0,6,&(paraminfo[i].listpos));
		aa("paraminfo[i].str",4,strlen(paraminfo[i].str),&(paraminfo[i].str[0]));
		}

    for (ci=0;ci< numchains;ci++)
        for (li=0;li<nloci;li++)
			{
			aa("name",4,strlen(L[ci][li]->name),&(L[ci][li]->name[0]));
			aa("numgenes",0,1,&(L[ci][li]->numgenes));
			aa("numpop1",0,1,&(L[ci][li]->numpop1));
			aa("numpop2",0,1,&(L[ci][li]->numpop2));
			aa("model",0,1,&(L[ci][li]->model));
			aa("numsmm",0,1,&(L[ci][li]->numsmm));
			aa("numlines",0,1,&(L[ci][li]->numlines));
			aa("numsites",0,1,&(L[ci][li]->numsites));
			aa("pop1sites",0,1,&(L[ci][li]->pop1sites));
			aa("pop2sites",0,1,&(L[ci][li]->pop2sites));
			aa("numbases",0,1,&(L[ci][li]->numbases));
			aa("root",0,1,&(L[ci][li]->root));
			if (L[ci][li]->model == STEPWISE || L[ci][li]->model == JOINT_IS_SW)
				{
				aa("maxA[]",0,mostsmm,&(L[ci][li]->maxA[0]));
				aa("minA[]",0,mostsmm,&(L[ci][li]->minA[0]));
				}
			aa("ecount",0,1,&(L[ci][li]->ecount));
			aa("totsites",0,1,&(L[ci][li]->totsites));
			aa("roottime",3,1,&(L[ci][li]->roottime));
			aa("length",3,1,&(L[ci][li]->length));
			aa("oldlike",3,1,&(L[ci][li]->oldlike));
			if (L[ci][li]->model == STEPWISE || L[ci][li]->model == JOINT_IS_SW)
				aa("oldlike_a[]",3,mostsmm,&(L[ci][li]->oldlike_a[0]));
			aa("oldprob",3,1,&(L[ci][li]->oldprob));
			aa("pi[4]",3,4,&(L[ci][li]->pi[0]));
			for (i=0;i< L[ci][li]->numlines;i++)
				{
				aa("up[2]",0,2,&(L[ci][li]->tree[i].up[0]));
				aa("down",0,1,&(L[ci][li]->tree[i].down));
				aa("mut",0,1,&(L[ci][li]->tree[i].mut));
				aa("pop",0,1,&(L[ci][li]->tree[i].pop));
				if (L[ci][li]->model == STEPWISE || L[ci][li]->model == JOINT_IS_SW)
					{
					aa("A[]",0,mostsmm,&(L[ci][li]->tree[i].A[0]));
					aa("dlikeA[]",3,mostsmm,&(L[ci][li]->tree[i].dlikeA[0]));
					}
				aa("time",3,1,&(L[ci][li]->tree[i].time));
				aa("cmm",0,1,&(L[ci][li]->tree[i].cmm));
				j = 0;
				while (L[ci][li]->tree[i].mig[j] > 0) j++;
				aa("mig[]",3,j+1,L[ci][li]->tree[i].mig);
				if (L[ci][li]->model == HKY && i >= L[ci][li]->numgenes)
					{
					/* don't think need to save scalefactors, as they get recalculated by makefrac 
					aa("L[ci][li]->tree[i].scalefactor[0]",3,L[ci][li]->numsites,&(L[ci][li]->tree[i].scalefactor[0]));
					aa("L[ci][li]->tree[i].oldscalefactor[0]",3,L[ci][li]->numsites,&(L[ci][li]->tree[i].oldscalefactor[0]));  */
					for (j=0; j<L[ci][li]->numsites; j++)
						{
						aa("L[ci][li]->tree[i].frac[j]",3,4,&(L[ci][li]->tree[i].frac[j][0]));
						aa("L[ci][li]->tree[i].newfrac[j]",3,4,&(L[ci][li]->tree[i].newfrac[j][0]));
						}
  					}
				}
				if (L[ci][li]->model == HKY || L[ci][li]->model == INFINITESITES || L[ci][li]->model == JOINT_IS_SW)
					{
					for (i=0; i<L[ci][li]->numgenes; i++)
						{
						aa("L[ci][li]->seq[i]",0,L[ci][li]->numsites,&(L[ci][li]->seq[i][0]));
						}
					}
				if (L[ci][li]->model == HKY)
					{
					aa("L[ci][li]->mult",0,L[ci][li]->numsites,&(L[ci][li]->mult[0]));
					}
				if (L[ci][li]->model == INFINITESITES)
					{
					aa("L[ci][li]->badsite",0,L[ci][li]->numbases,&(L[ci][li]->badsite[0]));
					}
			//geteventinfo(ci, li, &L[ci][li]->ecount, &L[ci][li]->elist);
			// should be no reason do to this here - newgeteventinfo(ci, li, &L[ci][li]->ecount, &L[ci][li]->elist, &L[ci][li]->eindex);
			}
	aa("countuprior",0,1,&countuprior);
	aa("uprior_failedupdate[]",0,nloci+mostsmm,&uprior_failedupdate[0]);
	aa("iseed",5,1,iseed);
	fclose(dckfile);
	printf("DONE.\n");
	} /*writedck() */

#undef aa

#define aa  aread
/*readdck() is very similar to writedck(), except it includes some mallocs() and a small number of initializations at the end*/
/* avoid using defined constants as much as possible so that checkfile format does not depend on compilation */
void readdck(void)
	{
	int i,j,ci,li;
	struct locus  **tempL;

	if ((dckfile = fopen(dckfilename,"r")) == NULL)
		{
		printf("Error opening check file for reading\n"); 
		err(-1,-1,10);
		}
	aa("dck_version_string",4,strlen(dckversionstring),&(dckversionstring[0]));
	aa("fpstr",4,strlen(fpstr),&fpstr[0]);
	aa("infilename",4,strlen(infilename),&infilename[0]);
	aa("checkmode",0,1,&checkmode);
	aa("checkinmode",0,1,&checkinmode);
	aa("checktimer",1,1,&checktimer);
	aa("outfilename",4,strlen(outfilename),&outfilename[0]);
	aa("oldoutfilename",4,strlen(oldoutfilename),&oldoutfilename[0]);
	aa("surfilename",4,strlen(surfilename),&surfilename[0]);
	aa("dckfilename",4,strlen(dckfilename),&dckfilename[0]);
	aa("numchains",0,1,&numchains);
	aa("nloci",0,1,&nloci);
	
	for (ci = 0; ci< numchains;ci++)
		{
        Q[ci] = malloc(sizeof(struct parameters));
		aa("Q",3,sizeof(struct parameters)/sizeof(double),Q[ci]);
		}
	aa("Qwin",3,sizeof(struct parameters)/sizeof(double),&Qwin);
	aa("Qmax",3,sizeof(struct parameters)/sizeof(double),&Qmax);
	aa("Qmin",3,sizeof(struct parameters)/sizeof(double),&Qmin);
	aa("Qaccp",3,sizeof(struct parameters)/sizeof(double),&Qaccp);
	aa("Qupdatetries",3,sizeof(struct parameters)/sizeof(double),&Qupdatetries);
	aa("Qaccp0",3,sizeof(struct parameters)/sizeof(double),&Qaccp0);
	aa("Qold",3,sizeof(struct parameters)/sizeof(double),&Qold);
	for (i = 0; i< gridsize;i++)
		{
		aa("Qgrid",3,sizeof(struct parameters)/sizeof(double),&Qgrid[i]);
		}
	for (i = 0; i< gridsize;i++)
		{
		aa("Qvec",3,sizeof(struct parameters)/sizeof(double),&Qvec[i]);
		}
	for (i = 0; i< TRENDDIM;i++)
		{
		aa("Qtrend",3,sizeof(struct parameters)/sizeof(double),&Qtrend[i]);
		}
	aa("beforegrid",3,sizeof(struct parameters)/sizeof(double),&beforegrid);
	aa("aftergrid",3,sizeof(struct parameters)/sizeof(double),&aftergrid);
		aa("seed_for_ran1",1,1,&seed_for_ran1);
	aa("step",1,1,&step);
	aa("burnsteps",1,1,&burnsteps);
	aa("recordstep",1,1,&recordstep);
	aa("burnduration,",1,1,&burnduration);
	aa("chainduration,",1,1,&chainduration);
	aa("checkduration",1,1,&checkduration);
	aa("bdurationmode,",0,1,&bdurationmode);
	aa("cdurationmode,",0,1,&cdurationmode);
	aa("checkmode",0,1,&checkmode);
	aa("printoptions[SMOOTHDIST+1]",0,SMOOTHDIST+1,&printoptions[0]);
	aa("progopts[WIDELOGSCALE+1]",0,WIDELOGSCALE+1,&progopts[0]);
	aa("recordint",0,1,&recordint);
	aa("gupdateint",0,1,&gupdateint);
	aa("heatmode",0,1,&heatmode);
	aa("swaptries",0,1,&swaptries);
	for (ci = 0; ci< numchains;ci++)
		aa("swapcount",5,numchains,&(swapcount[ci][0]));
	aa("fpstri",0,1,&fpstri);
	aa("basics",0,1,&basics);
	aa("nloci",0,1,&nloci);
	aa("numparams",0,1,&numparams);
	aa("firstuparam",0,1,&firstuparam);
	aa("lastuparam",0,1,&lastuparam);
	aa("nurates",0,1,&nurates);
	aa("printint",0,1,&printint);
	aa("largestsamp",0,1,&largestsamp);
	numlist = malloc(largestsamp* sizeof(int));
	mc = malloc(2*largestsamp * sizeof(int));
	aa("mostsmm",0,1,&mostsmm);
	aa("surfsetvals",0,1,&surfsetvals);
	aa("surfsetvals",0,1,&surfsetvals);
	aa("swap01",0,1,&swap01);
	aa("swap01d",0,1,&swap01d);
	aa("swap12",0,1,&swap12);
	aa("swap12d",0,1,&swap12d);
	aa("chaintimeintervals",0,1,&chaintimeintervals);
	aa("surfilecount",0,1,&surfilecount);
	aa("adaptcheck",0,1,&adaptcheck);
	aa("starttime",1,1,&starttime);
	aa("endtime",1,1,&endtime);
	aa("totaltime",1,1,&totaltime);
	aa("burntime",1,1,&burntime);
	aa("chainstarttime",1,1,&chainstarttime);
	aa("timer",1,1,&timer);
	aa("lasttime",1,1,&lasttime);
	aa("generationtime",3,1,&generationtime);
	aa("hval1",3,1,&hval1);
	aa("hval2",3,1,&hval2);
	aa("hilike",3,1,&hilike);
	aa("hiprob",3,1,&hiprob);
	aa("surfilenumstr",4,strlen(surfilenumstr),&surfilenumstr[0]);
	aa("beta",3,numchains,&beta[0]);
	aa("hilocuslike",3,nloci,&hilocuslike[0]);
	aa("hilocusprob",3,nloci,&hilocusprob[0]);
	aa("uperyear",3,nloci + mostsmm,&uperyear[0]);
	aa("uscaleml",3,nloci + mostsmm,&uscaleml[0]);
	aa("lptrend",3,TRENDDIM,&lptrend[0]);
	aa("holdsisdlikeA",3,mostsmm,&holdsisdlikeA[0]);
	aa("tmrcagrid",3,gridsize,&tmrcagrid[0]);
	aa("kappawindowsize",3,nloci,&kappawindowsize[0]);
	aa("kappamax",3,nloci,&kappamax[0]);
	aa("holddownA",0,mostsmm,&holddownA[0]);
	aa("ntest",0,3,&ntest[0]);
	aa("mtest",0,nloci,&mtest[0]);
	aa("nmtest",0,nloci,&nmtest[0]);
	aa("swaporder",0,numchains,&swaporder[0]);
	aa("gaccp",0,nloci,&gaccp[0]);
	aa("topolaccp",0,nloci,&topolaccp[0]);
	aa("locusulookup",0,nloci,&locusulookup[0]);
	aa("checkstep",0,AUTOCTERMS,&checkstep[0]);
	aa("gupdatetries",1,nloci,&gupdatetries[0]);
	aa("ulow[]",3,nloci + mostsmm,&ulow[0]);
	aa("uhi[]",3,nloci+mostsmm,&uhi[0]);
	for (i=0;i<numparams ;i++)
	 aa("correlations[][]",3,numparams,&(correlations[i][0]));
	for (i=0;i<nloci + mostsmm;i++)
	 aa("urrlow[][]",3,nloci + mostsmm,&(urrlow[i][0]));
	for (i=0;i< nloci + mostsmm ;i++)
	 aa("urrhi[][]",3,nloci + mostsmm,&(urrhi[i][0]));
	for (i=0;i<numchains ;i++)
	 aa("kappa[][]",3,nloci,&(kappa[i][0]));
	for (i=0;i<nloci;i++)
	 aa("tmrcadist[][gridsize]",3,gridsize,&(tmrcadist[i][0]));
	aa("tmrcaafter[]",3,nloci,&(tmrcaafter[0]));
	for (i=0;i<nloci ;i++)
	 aa("Aupdateratecount[][]",3,mostsmm,&(Aupdateratecount[i][0]));
	for (i=0;i<nloci ;i++)
	 aa("Aupdatetries[][]",3,mostsmm,&(Aupdatetries[i][0]));
	for (i=0;i<2 ;i++)
	 aa("snadist[2][gridsize]",3,gridsize,&(snadist[i][0]));
	aa("snagrid[gridsize]",3,gridsize,&(snagrid[0]));
	for (i=0;i<nloci;i++)
	  for (j=0;j<2;j++)
		aa("meventvec[][2][gridsize+1]",3,gridsize,&(meventvec[i][j][0]));
	for (i=0;i<nloci;i++)
	  for (j=0;j<2;j++)
		aa("mtimevec[][2][gridsize+1]",3,gridsize,&(mtimevec[i][j][0]));
	for (i=0;i<2;i++)
	  for (j=0;j<nloci;j++)
		aa("mcomp[2][][]",0,nloci,&(mcomp[i][j][0]));
	for (i=0;i<nurates;i++)
		aa("ucomp[][]",0,nurates,&(ucomp[i][0]));
	aa("popnames[0]",4,strlen(popnames[0]),&(popnames[0][0]));
	aa("popnames[1]",4,strlen(popnames[1]),&(popnames[1][0]));
	aa("nextstepsave",0,AUTOCTERMS,&nextstepsave[0]);
	aa("nextstepcalc",0,AUTOCTERMS,&nextstepcalc[0]);
	aa("nextpossave",0,AUTOCTERMS,&nextpossave[0]);
	aa("nextposcalc",0,AUTOCTERMS,&nextposcalc[0]);
	aa("maxpos",0,AUTOCTERMS,&maxpos[0]);
	aa("holdswap",0,1,&holdswap);
	aa("sw01",0,1,&sw01);
	aa("sw01d",0,1,&sw01d);
	aa("sw12",0,1,&sw12);
	aa("sw12d",0,1,&sw12d);
	aa("trendspot",0,1,&trendspot);
	aa("recordtrendinc",0,1,&recordtrendinc);
	aa("recordinc",0,1,&recordinc);
	aa("movespot",0,1,&movespot);
	aa("runinterval",0,1,&runinterval);
	aa("checkinterval",0,1,&checkinterval);
	aa("pmax",0,1,&pmax);
	aa("z_rndu",0,1,&z_rndu);
	aa("x_rndu",0,1,&x_rndu);
	aa("y_rndu",0,1,&y_rndu);

	for (i=0;i<nloci;i++)
		{
		aa("tmrca_s",3,1,&(tmrca[i].s));
		aa("tmrca_s2",3,1,&(tmrca[i].s2));
		aa("tmrca_n",0,1,&(tmrca[i].n));
		}
	for (i=0;i<AUTOCTERMS;i++)
		for (j=0;j<BASICPARAMS+2;j++)
		{
		aa("autoc_s",3,1,&(autoc[i][j].s));
		aa("autoc_s2",3,1,&(autoc[i][j].s2));
		aa("autoc_n",0,1,&(autoc[i][j].n));
		}
	for (i=0;i<AUTOCTERMS;i++)
		{
		aa("auto_lp_s",3,1,&(autoc_lp[i].s));
		aa("auto_lp_s2",3,1,&(autoc_lp[i].s2));
		aa("auto_lp_n",0,1,&(autoc_lp[i].n));
		}
	for (i=0;i<BASICPARAMS+2;i++)
		{
		aa("variance_s",3,1,&(variance[i].s));
		aa("variance_s2",3,1,&(variance[i].s2));
		aa("variance_n",0,1,&(variance[i].n));
		}
	aa("variance_lp_s",3,1,&(variance_lp.s));
	aa("variance_lp_s2",3,1,&(variance_lp.s2));
	aa("variance_lp_n",0,1,&(variance_lp.n));
    for (i=0;i<numparams-1;i++)
     for (j=i+1;j<=numparams-1;j++)
        {
		aa("c_n",0,1,&(c[i][j].n));
		aa("c_s",3,5,&(c[i][j].si));
        }
	paraminfo = malloc(numparams*sizeof(*paraminfo));
	for (i=0;i<numparams;i++)
		{
		aa("paraminfo[i].listpos",0,6,&(paraminfo[i].listpos));
		aa("paraminfo[i].str",4,strlen(paraminfo[i].str),&(paraminfo[i].str[0]));
		}

	tempL = malloc(numchains * sizeof(struct locus *));
    for (ci=0;ci< numchains;ci++)
        tempL[ci] = malloc(nloci*sizeof(struct locus));  
    L = malloc(numchains * sizeof(struct locus *));
    for (ci=0;ci< numchains;ci++)
        L[ci] = malloc(nloci * sizeof(struct locus *));
    for (ci=0;ci< numchains;ci++)
        for (li=0;li<nloci;li++)
			{
            L[ci][li] = &tempL[ci][li]; 
			aa("name",4,strlen(L[ci][li]->name),&(L[ci][li]->name[0]));
			aa("numgenes",0,1,&(L[ci][li]->numgenes));
			aa("numpop1",0,1,&(L[ci][li]->numpop1));
			aa("numpop2",0,1,&(L[ci][li]->numpop2));
			aa("model",0,1,&(L[ci][li]->model));
			aa("numsmm",0,1,&(L[ci][li]->numsmm));
			aa("numlines",0,1,&(L[ci][li]->numlines));
			aa("numsites",0,1,&(L[ci][li]->numsites));
			aa("pop1sites",0,1,&(L[ci][li]->pop1sites));
			aa("pop2sites",0,1,&(L[ci][li]->pop2sites));
			aa("numbases",0,1,&(L[ci][li]->numbases));
			aa("root",0,1,&(L[ci][li]->root));
			if (L[ci][li]->model == STEPWISE || L[ci][li]->model == JOINT_IS_SW)
				{
				aa("maxA[]",0,mostsmm,&(L[ci][li]->maxA[0]));
				aa("minA[]",0,mostsmm,&(L[ci][li]->minA[0]));
				}
			aa("ecount",0,1,&(L[ci][li]->ecount));
			aa("totsites",0,1,&(L[ci][li]->totsites));
			aa("roottime",3,1,&(L[ci][li]->roottime));
			aa("length",3,1,&(L[ci][li]->length));
			aa("oldlike",3,1,&(L[ci][li]->oldlike));
			if (L[ci][li]->model == STEPWISE || L[ci][li]->model == JOINT_IS_SW)
				aa("oldlike_a[]",3,mostsmm,&(L[ci][li]->oldlike_a[0]));
			aa("oldprob",3,1,&(L[ci][li]->oldprob));
			aa("pi[4]",3,4,&(L[ci][li]->pi[0]));
			L[ci][li]->tree = malloc(L[ci][li]->numlines*(sizeof(struct edge)));
			for (i=0;i< L[ci][li]->numlines;i++)
				{
				aa("up[2]",0,2,&(L[ci][li]->tree[i].up[0]));
				aa("down",0,1,&(L[ci][li]->tree[i].down));
				aa("mut",0,1,&(L[ci][li]->tree[i].mut));
				aa("pop",0,1,&(L[ci][li]->tree[i].pop));
				if (L[ci][li]->model == STEPWISE || L[ci][li]->model == JOINT_IS_SW)
					{
					aa("A[]",0,mostsmm,&(L[ci][li]->tree[i].A[0]));
					aa("dlikeA[]",3,mostsmm,&(L[ci][li]->tree[i].dlikeA[0]));
					}
				aa("time",3,1,&(L[ci][li]->tree[i].time));
				aa("cmm",0,1,&(L[ci][li]->tree[i].cmm));
				L[ci][li]->tree[i].mig = malloc(L[ci][li]->tree[i].cmm * sizeof(double));
				j = 0;
				while (L[ci][li]->tree[i].mig[j] > 0) j++;
				aa("mig[]",3,j+1,L[ci][li]->tree[i].mig);
				if (L[ci][li]->model == HKY && i >= L[ci][li]->numgenes)
					{
					L[ci][li]->tree[i].scalefactor=malloc((L[ci][li]->numsites)*sizeof(double));
					L[ci][li]->tree[i].oldscalefactor=malloc((L[ci][li]->numsites)*sizeof(double));
					/*  don't think need to save scalefactors, as they get recalculated by makefrac 
					aa("L[ci][li]->tree[i].scalefactor[0]",3,L[ci][li]->numsites,&(L[ci][li]->tree[i].scalefactor[0]));
					aa("L[ci][li]->tree[i].oldscalefactor[0]",3,L[ci][li]->numsites,&(L[ci][li]->tree[i].oldscalefactor[0]));  */
					L[ci][li]->tree[i].frac=malloc(L[ci][li]->numsites*(sizeof(double *)));
					L[ci][li]->tree[i].newfrac=malloc(L[ci][li]->numsites*(sizeof(double *)));
					for (j=0; j<L[ci][li]->numsites; j++)
						{
						L[ci][li]->tree[i].frac[j]=malloc(4*(sizeof(double)));
						L[ci][li]->tree[i].newfrac[j]=malloc(4*(sizeof(double)));
						aa("L[ci][li]->tree[i].frac[j]",3,4,&(L[ci][li]->tree[i].frac[j][0]));
						aa("L[ci][li]->tree[i].newfrac[j]",3,4,&(L[ci][li]->tree[i].newfrac[j][0]));
						}
  					}
				}
				if (L[ci][li]->model == HKY || L[ci][li]->model == INFINITESITES || L[ci][li]->model == JOINT_IS_SW)
					{
					L[ci][li]->seq=malloc(L[ci][li]->numgenes*(sizeof(int *))); 
					for (i=0; i<L[ci][li]->numgenes; i++)
						{
						L[ci][li]->seq[i]=malloc((L[ci][li]->numsites)*(sizeof(int)));
						aa("L[ci][li]->seq[i]",0,L[ci][li]->numsites,&(L[ci][li]->seq[i][0]));
						}
					}
				if (L[ci][li]->model == HKY)
					{
					L[ci][li]->mult = malloc((L[ci][li]->numsites)*(sizeof(int)));
					aa("L[ci][li]->mult",0,L[ci][li]->numsites,&(L[ci][li]->mult[0]));
					}
				if (L[ci][li]->model == INFINITESITES)
					{
					L[ci][li]->badsite = malloc(L[ci][li]->numbases*(sizeof(int)));
					aa("L[ci][li]->badsite",0,L[ci][li]->numbases,&(L[ci][li]->badsite[0]));
					}
			//geteventinfo(ci, li, &L[ci][li]->ecount, &L[ci][li]->elist);
			newgeteventinfo(ci, li, &L[ci][li]->ecount, &L[ci][li]->elist, &L[ci][li]->eindex);
			}
	aa("countuprior",0,1,&countuprior);
	aa("uprior_failedupdate[]",0,nloci+mostsmm,&uprior_failedupdate[0]);
	iseed = malloc(sizeof(unsigned long));
	aa("iseed",5,1,iseed);
	fclose(dckfile);

/* set some things so restart can begin properly*/ 
	
	copyedge = malloc(3*(sizeof(struct edge)));
	for (i=0;i<3;i++)
		copyedge[i].mig = malloc(ABSMAXMIG * sizeof(double));
#ifdef INCLUDESIZECHANGE
    if (!progopts[POPSIZECHANGEMODE]) 
        {
#endif
        ptreeprob = treeprobc;
#ifdef INCLUDESIZECHANGE
        }
    else
        {
        ptreeprob = treeprob;
        pc = pcexp;
        pnc = pncexp;
        pm = pmexp;
        pnm = pnmexp;
        }
#endif
	checkinmode = 1;
	burndone = 1;
	restartstep=0;
	i = 0;
	time(&restarttime);
	runinterval = 0;
	checkinterval = 0;
	time(&checklasttime);
	time(&lasttime);

	}  /* readdck() */
#undef aa


void reinitialize(void)
	{
	int ci, li, i,j,k;

	time(&chainstarttime);
    burnsteps = step-1;
	//step = 0;
	recordstep = 0;
	if (cdurationmode == TIMEINF)
		{
        time(&lasttime);
		time(&timer);
		}
    for (li=0;li<nloci;li++) 
		{
        gaccp[li] = 0;
        topolaccp[li] = 0;
        gupdatetries[li] = 0;
		}
	Qaccp = Qupdatetries = Qaccp0;
    adaptcheck = 10000;
    if (printoptions[PRINTALLVALUES])
		surfilecount = 0;
	if (numchains > 1)
		{
		for (i=0;i< numchains;i++)
			for (j=0;j< numchains;j++)
				swapcount[i][j] = 0;
		}
	for (li=0;li< nloci;li++)
        ieevent(&tmrca[li]);
	ieevent(&variance_lp);
	for (i=0;i< AUTOCTERMS;i++)
	    ieevent(&autoc_lp[i]);
	for (j=0;j< basics;j++)
		{
		ieevent(&variance[j]);
		for (i=0;i< AUTOCTERMS;i++)
	        ieevent(&autoc[i][j]);
		} 
    if (printoptions[PRINTTMRCA])
		for (li = 0; li< nloci; li++)
			{
			for (k=0;k<gridsize;k++)
				tmrcadist[li][k] = 0;;
			tmrcaafter[li] = 0;;
			}
    if (printoptions[MIGRATEDIST])
        for (li = 0; li< nloci; li++)
			for (k=0;k<gridsize;k++)
				for (i=0;i<=1;i++)
					{
					meventvec[li][i][k] = 0;
                    mtimevec[li][i][k] = 0;
                    }
	ci = 0;
    for (j = 0; j< nurates;j++)
        {
		beforegrid.u[j] = 0;
		aftergrid.u[j] = 0;
		for (k=0;k<gridsize;k++)
			Qvec[k].u[j] = 0;
		}
	if (progopts[UPDATEH])
		for (li = 0; li< nloci; li++)
			{
			beforegrid.h[li] = 0;
			aftergrid.h[li] = 0;
			for (k=0;k<gridsize;k++)
				Qvec[k].h[li] = 0;
			}
	beforegrid.q1 = beforegrid.q2 = beforegrid.qA = beforegrid.t = 0;
	aftergrid.q1 = aftergrid.q2 = aftergrid.qA = aftergrid.t = 0;
	for (k=0;k<gridsize;k++)
		Qvec[k].q1 = Qvec[k].q2  = Qvec[k].qA = Qvec[k].t = 0;
	for((progopts[LOCUSMIGRATION]) ? (i=nloci) : (i=1), li=0;li<i;li++)
        {
		beforegrid.m1[li] = beforegrid.m2[li] = 0;
		for (k=0;k<gridsize;k++)
			Qvec[k].m1[li] = Qvec[k].m2[li] = 0;
		}
    if (progopts[POPSIZECHANGEMODE])
        {
		beforegrid.s = aftergrid.s = 0;
		for (k=0;k<gridsize;k++)
			Qvec[k].s = 0;
		}
	for (i=0;i<numparams-1;i++)
		for (j=i+1;j<=numparams-1;j++)
			{
			c[i][j].n = 0;
			c[i][j].si = 0;
			c[i][j].si2 = 0;
			c[i][j].sj = 0;
			c[i][j].sj2 = 0;
			c[i][j].sij = 0;
			correlations[i][j] = 0;
			}
	if (printoptions[PRINTASCIITREND])
		{
		trendspot = 0;
		recordtrendinc = 1;
		recordinc = 0;
		movespot = TRENDDIM - 1;
		for (k=0;k<TRENDDIM;k++)
			lptrend[k] = 0; 
		for (i = 0; i< numparams; i++)
			if (paraminfo[i].inmodel)
				{
				for (j= movespot; j < TRENDDIM; j++)
					*(&Qtrend[j].q1 + paraminfo[i].listpos)  = 0;
				}
		}
	if (1 /*printoptions[DEMOGTEST] */)
		{
		mtest[0]  = nmtest[0]  = 0;
		if (progopts[LOCUSMIGRATION])
			for (i=1;i<nloci;i++)
				{
				mtest[i]  = nmtest[i]  = 0;
				}

		ntest[0] = ntest[1] = ntest[2] = 0;
		if (progopts[LOCUSMIGRATION])
			for (i=0;i<nloci-1;i++)
				for (j=i+1;j<nloci;j++)
					{
					mcomp[0][i][j] = mcomp[1][i][j] = 0;
					}
		if (nurates > 1)
			for (i=0;i<nurates-1;i++)
				for (j=i+1;j<nurates;j++)
					ucomp[i][j]  = 0;
		if (progopts[POPSIZECHANGEMODE])
			for (k=0;k<gridsize;k++)
				snadist[0][k] = snadist[1][k] = 0;
		}
	time(&checklasttime);
	checkinterval=0;
	SP"\n Burn duration reset upon restart.  Burnsteps: %ld\n", burnsteps);
	writedck();
	} /* reinitialize */
