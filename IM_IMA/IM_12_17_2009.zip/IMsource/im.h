/* IM  by Jody Hey and Rasmus Nielsen  2004-2009 */
/*last updates 12_17_09 */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <float.h>
#include <limits.h>
#include <time.h>
#include <ctype.h>
#include <assert.h>
#ifdef _DEBUG
#include <crtdbg.h>
#endif
/* if compiled under Microsoft Visual C++, then _MSC_VER  is defined */
/* to find info under MVC++ help for other compiler predefinitions search help for
'predefined macros' */
/* if compiled under Metrowerks  CodeWarrior  then __MWERKS__ is defined */
/* to find info under Metrowerks Codewarrior  search the Codewarrior Manuals 
(not the basic help)  for 'Predefined Symbols */

/*
#ifndef _MSC_VER
#undef __forceinline
#endif 
*/

#ifndef _MSC_VER
#ifndef __forceinline
#define __forceinline __attribute__((__always_inline__)) inline
#endif
#endif

/* microsft visual studio compiler stuff */
/* disable deprecate warning  C4996 */
#pragma warning( disable : 4996)

/******** DEBUG RELATED OPTIONS *************** */
/* debugging related definitions */
/*MVC++  defines _DEBUG  under debuggin, and NDEBUG  under Release version*/
/* can define these to add extra debugging routines,*/
/* to use the myassert function define USE_MYASSERT */

/* under MVC++  do not turn on speed optimzation or if you do, be sure to retain inequality checking with /Op */ 

#ifdef _DEBUG
#define USE_MYASSERT 
#define MYDEBUG
#endif

//#define USE_MYASSERT

#ifndef USE_MYASSERT
#define myassert(a)
#endif

/* 12/17/09  turned on ALTMIGRATEDIST to avoid the problem associated with recording mean times  */
#define ALTMIGRATEDIST  // for checking migration time distributions a different way.  Instead of the distribution of average times, it gets the distribution of all times
//#undef ALTMIGRATEDIST


// if going to use memory models larger than 1 Mbyte, includes this flag in MSVC++ linker
//      /LARGEADDRESSAWARE
//  Also, in order to use this must also add /3G to the Boot.ini file for Windows XP

/******** SIMPLE DEFINITIONS MACROS *************** */


/* CONSTANTS */
#define  FNSIZE    100
#define  MAXLOCI   200
#define  MAXLINKEDSMM 20
#define  NAMELENGTH 151
#define TIMEMAX 1000000.0
#define SENS 0.00000001
#define STARTMIGMAX 1000 /* max number per edge when trees are first built */
#define ABSMAXMIG  5000  /* absolute maximum # of migration events allowed */ 
#define MIGINC 20 /* number of possbile migration events to add to branch migration array at a time */
#define MAXCHAINS 200
#define DEFCHAINS  1
#define RECORDINTDEFAULT 10
#define GUPDATEDEFAULT 1


#define CHECKAUTOCWAIT 100000   /* 100000 */
#define AUTOCINT 1000
#define AUTOCNEXTARRAYLENGTH 1000  /* largest value in checkstep[], divided by AUTOCINT */
/* gridsize is the number of bins that the histograms are partioned into */

/* changing these will corrupt the checkfile format  (possible that other defined constants will as well */
#define gridsize 1000
#define TRENDDIM 500 
#define BASICPARAMS  5
#define AUTOCTERMS 12

#define PRINTINTDEFAULT 10000
#define  SWAPDIST 7



#define INCLUDESIZECHANGE
//#undef  INCLUDESIZECHANGE



/* MACROS  */
#define  MYDBL_MAX DBL_MAX/1e10
#define  MYDBL_MIN DBL_MIN/1e10
//careful with these, only for simple integers 
#define ODD(a) ( ((a) & 1) == 1 ? 1 : 0 )  
#define MIN(a,b) ((a) < (b) ? (a) : (b))
#define MAX(a,b) ((a) > (b) ? (a) : (b))
#define ROUND(a) (long) ((a)+0.5)

#define FP fprintf(outfile, 
#define SP fpstri += sprintf(&fpstr[fpstri],
#define f_close(a)  fclose(a); (a) = NULL

static int imaxarg1,imaxarg2;
#define IMAX(a,b) (imaxarg1=(a),imaxarg2=(b),(imaxarg1) > (imaxarg2) ?\
        (imaxarg1) : (imaxarg2))
static int iminarg1,iminarg2;
#define IMIN(a,b) (iminarg1=(a),iminarg2=(b),(iminarg1) < (iminarg2) ?\
        (iminarg1) : (iminarg2))

/* run options    progopts  -j*/
/*  RETURNPRIOR - likelihood() and likelihoodhky()  return 1 
	POPSIZEPRIORSETMODE - default   = 0  use command line value as a scaler  = 1 use command line value as actual upper bound, 
	UPDATEH  - treat inheritance scalar as parameters
	MUTATIONPRIORRANGE - include pior ranges on mutation rate scalrs, as included in input file
    EQUILIBRIUMMIGRATION  - fix t to a v. large value and qA to a v. small value 
    ONEPOP - set t=0 so that the model is just a single population
    COMMONTHETA - set theta1 = theta2 = thetaA
    COMMONMIGRATION - set m1=m2
    LOCUSMIGRATION  -  every locus gets its own values of m1 and m2 
    POPSIZECHANGEMODE - populations 1 and 2 can change, use extra parameter s
    WIDELOGSCALE  - set the recording and output of the log scale for mutation paramters to be very wide 
     */

enum  {RETURNPRIOR=0,POPSIZEPRIORSETMODE,UPDATEH,MUTATIONPRIORRANGE,EQUILIBRIUMMIGRATION,ONEPOP,COMMONTHETA,COMMONMIGRATION,LOCUSMIGRATION,POPSIZECHANGEMODE,WIDELOGSCALE};

/* mutation models */
/* INFINITESITES
	HKY
	STEPWISE  - one or more linked stepwise loci, no IS portion
	JOINT_IS_SW  - one IS portion and one or more STEPWISE portions
	SW_PARTOFSWM - one SMM portion of a locus with multiple STRs
	SW_PARTOFJOINT - refers to a STEPWISE portion of compound (joint) locus with one or more STRs
 */

enum {INFINITESITES,HKY,STEPWISE,JOINT_IS_SW /*,SW_PARTOFSWM,SW_PARTOFJOINT */};

/* print options   printoptions[]
   PRINTTMRCA - print a table of the TMRCA distribution 
   DEMOGHIST - print out distributions on demographic scales - requires mutation rates and generation times 
   MIGRATEDIST - print out distributions of numbers and times of migration events
   PRINTASCIITREND = print ascii trends of parameters over time 
   PRINTASCIICURVE - print ascii curves
   SMOOTHDIST - print smoothed curve w/ y axis approximating density

  old options removed
       RECORDALLCHAINS - causes Qvec to store the residence times for all of the chaings  - took up way too much RAM
	   DEMOGTEST - print out posteriors for various ratios and differences among demographic parameters   - made default
   
*/

enum  {PRINTALLVALUES=0,PRINTTMRCA,DEMOGHIST, MIGRATEDIST, PRINTASCIITREND,PRINTASCIICURVE,SMOOTHDIST};


/*  TIMESTEPS - time counted in # of steps
    TIMEINF  - run until first charcater in 'IMrun' is not 'y' */
enum  {TIMESTEPS,TIMEINF};

/* special heating models during burnin */
/* heat alt 1  all chains start at a low heating value, every interval they increase, until they are at the maximum value for that chain */
enum {HEATALT1 = 2};

/* heating modes */
enum {HLINEAR,HTWOSTEP, HADAPT,HGEOMETRIC};
/* HLINEAR means that each successive chain has an identical increment in the increase in the denominator for caluclating beta
       beta[ci] = 1.0/ (1.0 + h1*ci);
   HTWOSTEP invokes an additional increment for chains after 1
      h1 is the basic heating term as in HLINEAR
      h2 is for an additional decline in beta for successive chains after 1
        beta[ci] = 1.0/ (1.0 + h1  +  h1 * (ci-1)* h2); 
   HADAPT  invokes HTWOSTEP, but updates h1 and h2 
   HGEOMETRIC invokes a geometric decline in beta. small at first then faster.
     h2 is the bottom value of beta  0<h2<1).  
     h1 is how quickly it is approached 0<h1<1, h1=1 begets linear decline in beta 
        beta[ci] = 1 - (1 - h2) * ci * pow(h1,(numchains - 1 - ci))/(numchains-1);
 */


/*Main data structures: edge, locus, parameter */

/* an edge is a node in the genealogy
each edge gets a number.  the n sequences are numbers 0 thru n-1.  The remaining n-1 edges are numbered after that.
For edge i.
up[2] - contains the numbers of the edges to which edge i connects to  (i.e. the numbers of its descendants in the tree).
down - contains the number to which edge connects down to  (i.e. the immediate ancestor in the tree
time - contains the time at the bottom of the edge, that is 
     the time at the top of the ancestral edge (down). 
mig[] - contains the times of migration on the downward branch that occured to the lineage between the ancestor and the current time
    these times are on the same scale as time, and thus must be less than the population splitting time
pop - contains the population that the edge is in at its top, which may be different than 
    the one it is in at the bottom, depending on migration.
mut - used for labeling under INFINITESITES
A[i] - an allele state for stepwise or other allelic model at stepwise locus i.  This is the state of the node at the top.
dlikeA[i] - the likelihood of the distance between A, the allele state at the top of the node, and the allele state at the top
of the down edge */ 

struct edge
    {
	int up[2];
	int down;
	double time;
	double *mig; 
	int cmm; //current size of mig array
	int mut;
    int A[MAXLINKEDSMM];
    double dlikeA[MAXLINKEDSMM];
	int pop;
	double **frac;
    double **newfrac;
    double *scalefactor;
    double *oldscalefactor;
    };	

struct treeevent
    {
    double time;
    int pop;
    int cmt; /*event code :  coalesce =0 ; migrate=1; or process reaches divT = -1 */
    int num0;
    int num1;
    } ;

struct treevals  /* used only by treeprint() */
    {
    int nodenum;
    int up1;
    int up2;
    int down;
    double utime;
	double dtime;
    double timei;
    int migcount;
    int pop;
	int finpop;
    int mut;
    int A[MAXLINKEDSMM];
    double ldA[MAXLINKEDSMM];
	int flag;
    };

/* if running under a population size change model, then need to calculate two oldprob values,  one for growth and one for constant */
/* if running under constant,  just need the one oldprob*/
/* so use oldprob as the primary value, regardless of model and then if running under growth also use oldprobc */
struct locus 
	{
	char name[NAMELENGTH];
	int numgenes;
	int numpop1;
	int numpop2;
    int model;
	int numsmm;  /* # of SMM loci in this locus */
	int numlines;
	int numsites;
	int pop1sites;
	int pop2sites;
	int numbases;
	int root;
	double roottime;
    double length;
	double oldlike;
    double oldlike_a[MAXLINKEDSMM];
	double oldprob;
    int maxA[MAXLINKEDSMM];
    int minA[MAXLINKEDSMM];
	struct edge *tree;
    struct treeevent *elist;
	unsigned long *eindex;
    int ecount;
	int totsites;
	int **seq;
	int *mult;
	int *badsite;
	double pi[4];
	};

/*	when nloci > 1 
    the mutation parameters in Q.u[0] are each the unique products of a combination of nloci-1 values in ulinlist[]
    Thus the things that are actually updated are in ulinlist, however the update criterion depends on the Q.u values
    and the changes in the tree likelihoods. 
    Much the same applies to inheritance scalars in Q.h[]
    If progopts[UPDATEH] ==0 then Q.h[] simply holds the values read in from the data file
    If progopts[UPDATEH] ==1 then Q.h[] holds nloci parameters.  However these are in turn each the unique products of a combination 
    of nloci-1 values in glinlist[]    Thus the things that are actually updated are in ulinlist, however the update 
    criterion depends on the Q.u values and the changes in the tree likelihoods. 

    The way that values in ulinlist (and glinlist) are combined to give mutation and inheritance parameters is set in ubinlist[]
    These combinations are changed every 100,000 generations in order to equalize among combinations.  This helps to avoid bias 
    in particular mutation parameter estimates and particular inheritance scalar estimates.  The result should be a mean value
    among mutation scalar estimates that is equal to or near 1. (same for inheritance scalars). 
*/			

/*paramtypes */

enum {Q1,Q2,QA,T,S,M,U,H};

struct parameters 
	{
	double q1;
	double q2;
	double qA;
	double t;
    double s;
    double m1[MAXLOCI];
    double m2[MAXLOCI];
	double u[MAXLOCI+MAXLINKEDSMM];
	double h[MAXLOCI];
	};

struct paraminfotype
    {
    int listpos;  // the place in a struct parameters  where the parameter occurs 
    int paramtype;
    int locus;  /* -1 if applies to all loci */
    int utype; /* if a U, utype is mutation type */
	int inmodel; /* 1 if it is in the model 0 otherwise  */
	int Apos;  /* position in the array of STR allele values - in cases of loci with multiple linked STRs */
    char str[6];
    };

/* eevent contains info needed to calculate the mean and variance of the time of an event */ 
struct eevent
	{
	double s; /* sum of times */
	double s2; /* sum of squares of times*/
	int n; /* number of events */
	};

/* calccor is for calculating correlations between pairs of parameters */
struct calccor
    {
    long  n;
    double si,si2,sj,sj2,sij;
    };

/* prototypes */

/* in front.c  */

void start(int argc, char *argv[]);
void checkautoc(void);
int pickparam(int p);
void Qupdate(void);
double  swapweight(int ci, int cj);
int swapchains(void);
void record(void);
void finish(void);
int run(void);


/* in datain.c */

void readdata(void);
void fillparaminfo(void);
void setinitialQ(void);
int findsegsites(int ci, int li, int numbases, int initseg[], int *pop1seg, int *pop2seg, int MODEL);
void elimfrom(int ci, int li, int site);
int seqid(int ci, int li, int i, int j);
void sortseq(int ci, int li);
void eliminategaps(int ci, int li);
int numvar(int ci, int li);
void readseqHKY(int ci, int li);
void allocatefracs(int ci, int li);
void readseqIS(int ci, int li, int MODEL);
int startnummig(double startt, double endt, int startpop, int endpop, int prior, double m1, double m2, double times[]);

/*in makeg.c */
void makeHKY(int ci, int li, double m1, double m2, double divt);
void makeIS(int ci, int li, double m1, double m2, double divt);
void makeSW(int ci, int li, double m1, double m2, double divt);
void makeJOINT_IS_SW(int ci, int li, double m1, double m2, double divt);


/* in util.c */
#ifdef USE_MYASSERT
void myassert(int isit);
#endif
void err(int ci, int li, int i);
extern double square(double x);
void SetSeed(int seed);
extern double uniform();
extern int bitran(void);
extern double expo(double c);
void printgraph(int ci, int li);
void printgraphwithmut(int ci, int li);
char *nextnonspace(char *textline);
char *nextwhite(char *c);
void strdelete(char *s,int pos,int len);
void ieevent(struct eevent *a);
extern  void checkmig(int i, double **mig, int *nmig);
void shelltreevals(struct treevals *lptr, int length);
void treeprint(int ci, int li);
void indexx(unsigned long n, struct treeevent *arr, unsigned long *indx);
void sort(unsigned long n, struct treeevent *arr);

/* in chain.c */
void hpsort(struct treeevent *lptr,int  n);
//extern void geteventinfo(int ci,int li, int *ecount, struct treeevent **e);
void newgeteventinfo(int ci,int li, int *ec, struct treeevent **e, unsigned long **eindex);
//double treeprob(double q1, double q2, double qA, double m1, double m2, double t, double h, int *ec, struct treeevent *e, double s);    
//extern double treeprobc(double q1, double q2, double qA, double m1, double m2, double t, double h, int *ec, struct treeevent *e, double junk);
extern double treeprob(double q1, double q2, double qA, double m1, double m2, double t, double h, int *ec, struct treeevent *e, unsigned long *eindex, double s);    
extern double treeprobc(double q1, double q2, double qA, double m1, double m2, double t, double h, int *ec, struct treeevent *e, unsigned long *eindex, double junk);
extern void labeltree(int ci, int li, int edge);
double pijt(int ci, int li, double mutrate, double t, double kappa, int from, int to);
int makefrac (int node, int ci, int li, double mutrate, double kappa,   int e1, int e2, int e3, int e4);
double getstandfactor(int ci, int li, double kappa);
double likelihoodHKY(int ci, int li, double mutrate, double kappa, int e1, int e2, int e3, int e4);
void calc_sumlogk(int ci, int li, double *sumlogk);
extern double likelihoodIS(int ci, int li, double mutrate);
void storoldedges(int ci, int li, int edge, int sisedge, int downedge);
void restoreedges(int ci, int li, int edge, int sisedge, int downedge, int newsisedge);
void copyfraclike(int ci, int li);
void storescalefactors(int ci, int li);  // for HKY model
void restorescalefactors(int ci, int li);
extern double gettime(int ci, int li, int *returnnode, double oldt, int *num, int pop, double divt);
int simroot(int ci, int li, double m1, double m2, int edge, int downedge, int curpopedge,int edgemignum);
int updateedge(int ci, int li, double curt, int edge, int downedge, int num, int pop, int oldsisedge);
void makecoal(int ci, int li, double m1, double m2, int edge, int downedge, int sisedge, int *newsisedge);
int doMCMC(int ci, int li, double kappa, int MODEL, int *topolchange);
double changeq(int ci, int qswitch, double oldq, double windowsize, double maxval);
double changecommonq(int ci, double oldq, double windowsize, double maxval);
double changemsingle(int ci, int li, double oldm, double maxm, int pop);
double changemall(int ci, double oldm, double maxm, int pop);
double changecommonmall(int ci, double oldm, double maxm);
double changecommonmsingle(int ci,int li, double oldm, double maxm);
int changet(int ci, double *t, double tmax, double tmin,double twin);
int changeu(int ci, int j, int ui);
int changekappa(int ci);
int changeh(int ci, int hi);
double changes(int ci, double olds, double smax, double smin, double windowsize);


/* in stepwise.c  */
double bessi0(double x);
double bessi1(double x);
double bessi(int n, double x);
int geometric(double p);
void readseqSW(int ci, int li);
double finishSWupdateA(int ci, int li,int ai, int edge, int downedge, int sisedge, int newsisedge, double u, double *Aterm);
double updateA(int ci, int li,int ai,  double u, int *count, double uprop);
double likelihoodSW(int ci, int li,int ai, double u);
void checklikelihoodSW(int ci, int li, int ai, double u);

/* in out.c  */
void intervaloutput(int changed0, int qswapped);
void asciicurve(double *x, double *y,char *qlabel, int logscale);
void asciitrend(double *y,char *qlabel, int xlen, int ylen, int logscale, int pjump);
void printoutput(void);
void printsmoothdistoutput(void);
void isvals(void);

/* in popchange.c */
extern double pcexp(double q, double qa, double t, double f, double time, double pret,int pairs);
extern double pncexp(double q, double qa, double t, double f, double time,double pret, int n);
extern double pmexp(double q, double qa, double m, double t, double f, double time, double pret,int n);
extern double pnmexp(double q, double qa, double m, double t, double f, double time, double pret,int n);
extern double rc(double q, double qa, double t, double f, double pret, int pairs);
extern double rm(double q, double qa, double m, double t, double f, double pret, int n);
int simrootg(int ci, int li, double m1, double m2, int edge, int downedge, int curpopedge,int edgemignum);
void makecoalg(int ci, int li, double m1, double m2, int edge, int downedge, int sisedge, int *newsisedge);

/* in check.c */
void readdck(void);
void writedck(void);
void reinitialize(void);

/* extern global variables */

/* if GLOBVARS is defined then gextern is ignored. This
causes the corresponding variable declarations to be definitions.
GLOBVARS is only defined in front.c.  If GLOBVARS is not defined,
as is the case at the beginning of the other files, then gextern
gets replaced by extern and the variable declarations are simply
declarations */

#ifdef GLOBVARS
#define gextern
#else
#define gextern extern
#endif

/* *L[MAXCHAINS][MAXLOCI]; */
gextern struct locus ***L;  

/* considered setting all these parameter arrys to just be pointers, and then creating little initiallization functions
this would save a lot of memory for cases when nloci << maxloci.  The problem is that for output and a few
other cases the positions in Q  and Qvec are found by jumping a pointer to the right location.  If a 
struct parameter consists of a mix of doubles and pointers to doubles, then this won't work.  */
gextern struct parameters *Q[MAXCHAINS], Qwin, Qmax, Qmin, Qaccp, Qupdatetries, Qaccp0, Qgrid[gridsize+1], Qvec[gridsize+1],Qold, Qtrend[TRENDDIM] /*, Qobsmax, Qobsmin */;
gextern struct parameters beforegrid, aftergrid;
gextern struct paraminfotype *paraminfo;
gextern struct calccor c[5*MAXLOCI + BASICPARAMS][5*MAXLOCI + BASICPARAMS];
gextern struct edge *copyedge;
gextern struct eevent tmrca[MAXLOCI];
gextern struct eevent autoc[AUTOCTERMS][BASICPARAMS+2], autoc_lp[AUTOCTERMS];
gextern struct eevent variance[BASICPARAMS+2], variance_lp;

gextern FILE *outfile,*infile,*pvalfile;
gextern FILE *treeprintfile, *surfile, *paraminputfile, *checkdonefile;
gextern FILE *dckfile;

gextern char outfilename[FNSIZE], surfilename[FNSIZE];
gextern char oldoutfilename[FNSIZE];
gextern char surfilenumstr[8];
gextern char fpstr[5000];
gextern char popnames[2][NAMELENGTH];
gextern char dckfilename[FNSIZE],olddckfilename[FNSIZE];
gextern char infilename[FNSIZE];
gextern char textline[501];
gextern char fpstr[5000];

gextern int numchains;
gextern int numparams;
gextern int infilelines;
gextern int nloci;
gextern int fpstri;
gextern int progopts[WIDELOGSCALE+1];
gextern int holddownA[MAXLINKEDSMM]; 
gextern int nurates;
gextern int firstuparam, lastuparam;
gextern int gaccp[MAXLOCI], topolaccp[MAXLOCI];
gextern int bdurationmode,cdurationmode;
gextern int swaporder[MAXCHAINS];
gextern int burndone;
gextern int restartburn;
gextern int somestepwise;
gextern int swap01,swap01d,swap12,swap12d;
gextern int printoptions[SMOOTHDIST+1];
gextern int checkstep[AUTOCTERMS];
gextern int chaintimeintervals,surfilecount; 
gextern int fpstri;
gextern int adaptcheck;
gextern int surfsetvals;
gextern int heatmode;
gextern int *numlist;
gextern int *mc;
gextern int recordint;
gextern int gupdateint;
gextern int basics;
gextern int printint;
gextern int swaptries;
gextern int largestsamp;
gextern int mostsmm;
gextern int locusulookup[MAXLOCI];
gextern int urri[MAXLOCI+MAXLINKEDSMM][MAXLOCI+MAXLINKEDSMM];
gextern int countuprior;
gextern int uprior_failedupdate[MAXLOCI+MAXLINKEDSMM];
gextern int ntest[3]; //0 n1 > n2 1 n1 > na 2 n2 > na
gextern int mtest[MAXLOCI]; // m1[i] > m2[j]
gextern int nmtest[MAXLOCI]; // n1m1[i] > n1m2[j]
gextern int mcomp[2][MAXLOCI][MAXLOCI], ucomp[MAXLOCI+MAXLINKEDSMM][MAXLOCI+MAXLINKEDSMM]; 
gextern int burnheatinc;
gextern int checkmode,checkinmode;
gextern int nextstepsave[AUTOCTERMS], nextstepcalc[AUTOCTERMS],nextpossave[AUTOCTERMS],nextposcalc[AUTOCTERMS], maxpos[AUTOCTERMS];
gextern int holdswap, sw01,sw01d,sw12,sw12d;
gextern int runinterval;
gextern int checkinterval;
gextern int pmax;

gextern long burnduration, chainduration; 
gextern long gupdatetries[MAXLOCI];
gextern long seed_for_ran1;
gextern long checkduration; 
gextern long step;
gextern long recordstep;
gextern long burnsteps;
gextern long restartstep;
gextern unsigned long *iseed;
gextern unsigned long swapcount[MAXCHAINS][MAXCHAINS];

gextern time_t starttime, endtime, totaltime, burntime, chainstarttime, timer, lasttime;
gextern time_t restarttime;
gextern time_t checktimer, checklasttime;

gextern double kappa[MAXCHAINS][MAXLOCI],kappawindowsize[MAXLOCI],kappamax[MAXLOCI];
gextern double beta[MAXCHAINS], holdbeta[MAXCHAINS];
gextern double holdsisdlikeA[MAXLINKEDSMM]; 
gextern double Aupdateratecount[MAXLOCI][MAXLINKEDSMM], Aupdatetries[MAXLOCI][MAXLINKEDSMM];
gextern double hilike, hiprob,hilocuslike[MAXLOCI], hilocusprob[MAXLOCI];
gextern double heat;
gextern double inc;
gextern double tmrcadist[MAXLOCI][gridsize], tmrcagrid[gridsize];
gextern double tmrcaafter[MAXLOCI];
gextern double snadist[2][gridsize], snagrid[gridsize]; // snadist[0] is for s*Na snadist[1] is for (1-s)Na
gextern double correlations[4*MAXLOCI+MAXLINKEDSMM + BASICPARAMS][4*MAXLOCI+MAXLINKEDSMM + BASICPARAMS];
gextern double hval1, hval2;
gextern double meventvec[MAXLOCI][2][gridsize+1],mtimevec[MAXLOCI][2][gridsize];
gextern double autocvals[AUTOCTERMS][BASICPARAMS+2][AUTOCNEXTARRAYLENGTH], autocvals_lp[AUTOCTERMS][AUTOCNEXTARRAYLENGTH];
gextern double uperyear[MAXLOCI+MAXLINKEDSMM];
gextern double uscaleml[MAXLOCI+MAXLINKEDSMM];
gextern double generationtime;
gextern double lptrend[TRENDDIM]; 
gextern double ulow[MAXLOCI+MAXLINKEDSMM], uhi[MAXLOCI+MAXLINKEDSMM], urrlow[MAXLOCI+MAXLINKEDSMM][MAXLOCI+MAXLINKEDSMM], urrhi[MAXLOCI+MAXLINKEDSMM][MAXLOCI+MAXLINKEDSMM];

gextern double (*pc)(double, double, double, double, double, double, int);
gextern double (*pnc)(double, double, double, double, double, double, int);
gextern double (*pm)(double,double, double, double, double, double, double, int);
gextern double (*pnm)(double,double, double, double, double, double, double, int);
//gextern double (*ptreeprob)(double,double,double,double,double,double,double,int *,struct treeevent *,double); 
gextern double (*ptreeprob)(double,double,double,double,double,double,double,int *,struct treeevent *,unsigned long *,double);


/* some initialized variables that need to be started differently */
#ifdef GLOBVARS
int checkstep[AUTOCTERMS] = {1,10,50,100,500,1000,5000,10000,50000,100000,500000,1000000};
double  hilike = -1e20, hiprob = -1e20;
int adaptcheck = 1000;
int trendspot = 0, recordtrendinc = 1, recordinc = 0, movespot = TRENDDIM - 1;
int z_rndu=137, x_rndu=11, y_rndu=23;
int singlepopmode = 0;
#else
extern int checkstep[AUTOCTERMS];
extern double  hilike, hiprob;
extern int adaptcheck;
extern int trendspot, recordtrendinc, recordinc, movespot;
extern int z_rndu, x_rndu, y_rndu;
extern int singlepopmode;
#endif
