/* IM  by Jody Hey and Rasmus Nielsen  2004-2009 */
/*last updates 12_17_09 */


/* datain.c*/

#undef GLOBVARS
#include "im.h" 


void readdata(void)
	{
	/* first line is a comment*/
	/* any number of additional comments,  each line begins with '#' */
	/* names of two species,  species1 first, followed by species 2 */
	/* number of loci */
	/* for each locus */
	/* name, number of sequences in pop1, number of sequences in pop2, length of sequences , 
     H for HKY model 
     I for  infinite sites
     S  for stepwise model
	 W  for stepwise2 model
     J  for joint infinite sites and stepwise
	 M  for joint infinite sites and stepwise2
    inheritance scalar (1 or 0.75 or 0.25)
	mutation rate per year for complete locus, not per/bp 
	range of mutation rates in parentheseses 
	*/
	char ch,  *cc;
	int li,ci, i, ui, uinext;
    char c;
    int holdinfilelines;
	struct locus  **tempL;

	fgets(textline,300,infile);
	infilelines++;
	SP"\nText from input file: %s",textline);
    ch=getc(infile);
	while (ch =='#')
		{
		infilelines++;
		fgets(textline, 300, infile);
        SP"\nText from input file: %s",textline);
		ch=getc(infile);
		}
    ungetc(ch,infile);
	fscanf(infile,"%s %s \n",popnames[0],popnames[1]);
	fscanf(infile,"%d \n",&nloci);
    if (nloci < 1)
        {
        err(-1,-1,21);
        }
	infilelines+=2;
    SP"\n");
    SP"- Population Names - \n");
    SP"Population 1 : %s \n",popnames[0]);
    SP"Population 2 : %s \n",popnames[1]);
    SP"- Locus Information -\n");
    SP"Locus#\tLocusname\tsamplesize1\tsamplesize2\tModel\tInheritanceScalar\tMutationRatesPerYear\n");
    holdinfilelines = infilelines;
    f_close(infile);
    infile = NULL;

/* not sure if this is the simplest way to do this.  
The program allocoates a block of numchains * nloci  locus structures,  
then allocates a block of as many pointers to those structures and assigns the pointers.
do this because need to be able to swap the pointers without swapping the values  */

    tempL = calloc(numchains,sizeof(struct locus *));
    for (ci=0;ci< numchains;ci++)
        tempL[ci] = calloc(nloci,sizeof(struct locus));  
    L = calloc(numchains,sizeof(struct locus *));
    for (ci=0;ci< numchains;ci++)
        L[ci] = calloc(nloci,sizeof(struct locus *));
    for (ci=0;ci< numchains;ci++)
        for (li=0;li<nloci;li++)
			{
            L[ci][li] = &tempL[ci][li]; 
			L[ci][li]->numpop1 = L[ci][li]->numpop2 =  L[ci][li]->model = L[ci][li]->numsmm = L[ci][li]->numlines = L[ci][li]->numsites = L[ci][li]->pop1sites = L[ci][li]->pop2sites = L[ci][li]->numbases = L[ci][li]->root = L[ci][li]->numgenes = -1;
			L[ci][li]->ecount = L[ci][li]->totsites = -1;
			L[ci][li]->roottime = L[ci][li]->oldprob = L[ci][li]->roottime = L[ci][li]->length = L[ci][li]->oldlike = L[ci][li]->oldprob = L[ci][li]->roottime = L[ci][li]->oldprob  = -1;
			for (ui = 0; ui < MAXLINKEDSMM;ui++)
				{
				L[ci][li]->oldlike_a[ui] = -1;
				L[ci][li]->maxA[ui] = -1;
				L[ci][li]->minA[ui] = -1;
				}
			L[ci][li]->tree = NULL;
			L[ci][li]->elist = NULL;
			L[ci][li]->eindex = NULL;
			L[ci][li]->seq = NULL;
			L[ci][li]->mult = NULL;
			L[ci][li]->badsite = NULL;
			for (ui = 0;ui<4;ui++)
				L[ci][li]->pi[ui] = -1;
			}
	mostsmm  = 0;
    for (ci=0;ci< numchains;ci++)
        {
        infilelines = holdinfilelines;
        if (NULL==(infile=fopen(infilename,"r")))
            {
  	        /*Cannot find the infile */
  	        err(ci,-1,1);
            }
	    for (i=0;i< infilelines;i++)
		   //while ((c=(fgetc(infile)))!='\n' && c != '\r');
		   while ((c=(fgetc(infile)))!='\n'); // bug found by Peter Ersts - was causing portability problems
        if (numchains > 1)
            printf("Loading Chain %i \n",ci);
	    for (uinext = 0,li=0;li<nloci;li++)
		    {
            fgets(textline,300,infile);
			while  (( textline[strlen(textline)-1] == '\n')|| (textline[strlen(textline)-1] == ' ')) 
				textline[strlen(textline)-1] = '\0';
			cc = textline;
			if (ci==0)
				{
				ui = uinext;
				L[ci][li]->numsmm = 0;
				uperyear[ui] = -1;
				sscanf(cc,"%s",L[ci][li]->name);
				cc = nextnonspace(cc);
				sscanf(cc,"%d",&L[ci][li]->numpop1);
				cc = nextnonspace(cc);
				sscanf(cc,"%d",&L[ci][li]->numpop2);
				if (singlepopmode)
					{
					if (Qmax.q1 <= 0 && L[ci][li]->numpop1 > 0)
						err(-1, -1, 22);
					if (Qmax.q2 <= 0 && L[ci][li]->numpop2 > 0)
						err(-1, -1, 22);
					}
				cc = nextnonspace(cc);
				L[ci][li]->numgenes = L[ci][li]->numpop1 + L[ci][li]->numpop2;
				if (progopts[ONEPOP])
					{
					L[ci][li]->numpop1 += L[ci][li]->numpop2;
					L[ci][li]->numpop2 = 0;
					}
				L[ci][li]->numlines = 2*L[ci][li]->numgenes - 1;
				SP"%d\t%s\t%3d\t%3d",li,L[ci][li]->name,L[ci][li]->numpop1,L[ci][li]->numpop2);
				sscanf(cc,"%d",&L[ci][li]->numbases);
				cc = nextnonspace(cc);
				switch (toupper(cc[0])) 
					{
					case 'I' :L[ci][li]->model=INFINITESITES; SP"\tIS"); uinext = ui+1;  break;
					case 'H' :L[ci][li]->model=HKY; SP"\tHKY"); uinext = ui+1; break;
					case 'S' :L[ci][li]->model=STEPWISE;
								if (isdigit(cc[1]))
									{
									L[ci][li]->numsmm = atoi(&cc[1]);
									}
								else 
									L[ci][li]->numsmm = 1;
								if (L[ci][li]->numsmm > 1)
									SP"\tSW_M");
								else
									SP"\tSW");
								if (L[ci][li]->numsmm > mostsmm)
									mostsmm = L[ci][li]->numsmm;
								uinext = ui + L[ci][li]->numsmm;
								break;
					case 'J' :L[ci][li]->model=JOINT_IS_SW;
								if (isdigit(cc[1]))
									{
									L[ci][li]->numsmm = atoi(&cc[1]);
									}
								else 
									L[ci][li]->numsmm = 1;
								if (L[ci][li]->numsmm > 1)
									SP"\tIS+SW_M");
								else
									SP"\tIS+SW");
								if (L[ci][li]->numsmm > mostsmm)
									mostsmm = L[ci][li]->numsmm;
								uinext = ui + L[ci][li]->numsmm + 1;
								break;
					default: L[ci][li]->model=INFINITESITES;SP"\tIS");
					}
				cc = nextnonspace(cc);
				if (cc)
					{
					sscanf(cc,"%lf",&Q[ci]->h[li]);
					SP"\t%lf",Q[ci]->h[li]);
					cc = nextnonspace(cc);
					while (cc)
						{
						sscanf(cc,"%lf",&uperyear[ui]);
						SP"\t%lg",uperyear[ui]);
						cc = nextnonspace(cc);
						if (cc &&  cc[0] == '(') /* look for a mutation rate range in parentheses e.g. (0.03,0.05)  */
							{
							cc++;
							sscanf(cc,"%lf",&ulow[ui]);
							while (cc[0] != ',') cc++;
							cc++;
							sscanf(cc,"%lf",&uhi[ui]);
							while (cc[0] != ')') cc++;
							while (!isdigit(cc[0]) && cc[0] != '\0') cc++;
							if (cc[0] == '\0') 
								cc = NULL;
							if (ulow[ui]> uhi[ui] || ulow[ui]> uperyear[ui] || uhi[ui] < uperyear[ui])
								err(ci,li,79);
							SP"\t(%lg - %lg)",ulow[ui],uhi[ui]);
							countuprior++;
							}
						ui++;
						}
					}
				else 
					{
					Q[ci]->h[li] = 1;
					SP"\t%lf",Q[ci]->h[li]);
					}
				SP"\n");
                }
			else
				{
				L[ci][li]->model = L[0][li]->model;
				L[ci][li]->numsmm = L[0][li]->numsmm;
				strcpy(L[ci][li]->name,L[0][li]->name);
				L[ci][li]->numpop1 = L[0][li]->numpop1;
				L[ci][li]->numpop2 = L[0][li]->numpop2;
				L[ci][li]->numbases = L[0][li]->numbases;
				L[ci][li]->numgenes = L[0][li]->numgenes;
				L[ci][li]->numlines = L[0][li]->numlines;
				Q[ci]->h[li] = Q[0]->h[li];
				}
		    infilelines++;
            L[ci][li]->tree = calloc(L[ci][li]->numlines,(sizeof(struct edge)));
			for (i = 0; i < L[ci][li]->numlines; i++)
				{
				L[ci][li]->tree[i].mig = malloc(MIGINC * sizeof(double));
				L[ci][li]->tree[i].mig[0] = -1;
				L[ci][li]->tree[i].cmm = MIGINC;
				L[ci][li]->tree[i].up[0] = L[ci][li]->tree[i].up[0] = L[ci][li]->tree[i].down = -1;
				L[ci][li]->tree[i].time = 0;
				L[ci][li]->tree[i].mut = -1;
				for (ui = 0;ui < MAXLINKEDSMM;ui++)
					{
					L[ci][li]->tree[i].A[ui] = -1;
					L[ci][li]->tree[i].dlikeA[ui] = -1;
					}
				L[ci][li]->tree[i].pop = -1;
				L[ci][li]->tree[i].frac = NULL;
				L[ci][li]->tree[i].newfrac = NULL;
				L[ci][li]->tree[i].scalefactor = NULL;
				L[ci][li]->tree[i].oldscalefactor = NULL;
				}

            switch(L[ci][li]->model) 
                {
                case INFINITESITES:readseqIS(ci,li, INFINITESITES);break;
                case HKY: readseqHKY(ci,li); break;
                case STEPWISE: readseqSW(ci,li);break;
                case JOINT_IS_SW: readseqIS(ci,li,JOINT_IS_SW);break;
		        }
			}
		if(ci==0 && progopts[MUTATIONPRIORRANGE])
			{
			SP" Use prior ranges on mutation rates specified in input file \n");
			if (countuprior <= 1)
				{
				SP" Less than 2 prior ranges given in input file,  mutation rate priors not used \n");
				progopts[MUTATIONPRIORRANGE] = 0;
				}
			}
        f_close(infile);
        infile = NULL;
        }
	} /* readdata */


/* parameter values and things related to them, or recorded from them, often occur in structures of type 'parameters'. 
These can be somewhat sparcely filled and it can be confusing to find them, depending on the data set and the 
run options.  paraminfo will contains the locations of parameters in these structures, as well as other information
regarding the parameters 
Migration m1 parameters begin at position 5 and go to  4 + Maxloci
migration m2 parameters begin at position 5+ Maxloci and go to 4+2*Maxloci

mutation rates begin at position 5 + 2*Maxloci

inheritance parameters begin at position 5+3*Maxloci + MAXLINKEDSMM and go to position 4+4*MAXLOCI + MAXLINKEDSMM;
This hinges on knowing the correct locations in these structures
q1,q2,qA, t, s    positions 0-5
migration terms = positions 5 and 6 if LOCUSMIGRATION is false
otherwise positions 5 thru 5+ 2*nloci */

void fillparaminfo(void)
    {
    int i, li, pi, ui;

    if (!progopts[POPSIZECHANGEMODE])
        numparams = 4;
    else 
        numparams = 5;
    nurates = 0;
    if (progopts[LOCUSMIGRATION]) 
        numparams += 2*nloci;
    else
        numparams += 2;
    firstuparam = numparams;
    if (nloci > 1  || L[0][0]->numsmm >= 1) 
        {
        for (li=0;li<nloci;li++)
			{
            if (L[0][li]->model == JOINT_IS_SW)
                numparams += 1 + L[0][li]->numsmm;
			if (L[0][li]->model == STEPWISE)
                numparams += L[0][li]->numsmm;
            if (L[0][li]->model == INFINITESITES || L[0][li]->model ==HKY)
                numparams +=1; 
			}
        }
	lastuparam = numparams-1;
    if (progopts[UPDATEH]) numparams += nloci;
    paraminfo = malloc(numparams*sizeof(*paraminfo));
	/* initialize all of them to null values */
	paraminfo[0].listpos = paraminfo[0].paramtype = paraminfo[0].locus=paraminfo[0].utype=paraminfo[0].inmodel=paraminfo[0].Apos = -1;
	strcpy(paraminfo[0].str,"");
	for (pi = 1; pi < numparams; pi++)
		paraminfo[pi] = paraminfo[0];

	for (pi = 0; pi < numparams; pi++)
		paraminfo[pi].inmodel = 0;
    paraminfo[0].listpos = 0;
    paraminfo[0].paramtype = Q1;
    strcpy(paraminfo[0].str,"q1  ");
	paraminfo[0].inmodel = 1;
    paraminfo[1].listpos = 1;
    paraminfo[1].paramtype = Q2;
    strcpy(paraminfo[1].str,"q2  ");
	paraminfo[1].inmodel = 1;
    paraminfo[2].listpos = 2;
    paraminfo[2].paramtype = QA;
    strcpy(paraminfo[2].str,"qA  ");
	paraminfo[2].inmodel = 1;
    paraminfo[3].listpos = 3;
    paraminfo[3].paramtype = T;
    strcpy(paraminfo[3].str,"t   ");
	paraminfo[3].inmodel = 1;
	if (progopts[EQUILIBRIUMMIGRATION])
        {
        paraminfo[2].inmodel = paraminfo[3].inmodel = 0;
        }
	if (progopts[COMMONTHETA])
        {
        paraminfo[1].inmodel = paraminfo[2].inmodel = 0;
		}
	if (progopts[ONEPOP])
        {
        paraminfo[0].inmodel = paraminfo[1].inmodel = paraminfo[3].inmodel = 0;
		paraminfo[2].inmodel = 1;
		}
    pi=4;
    if (progopts[POPSIZECHANGEMODE])
        {
        paraminfo[pi].listpos = 4;
        paraminfo[pi].paramtype = S;
        strcpy(paraminfo[pi].str,"s   ");
		paraminfo[pi].inmodel = 1;
        pi++;
        }
    if (progopts[LOCUSMIGRATION]==0) 
        {
        paraminfo[pi].listpos = 5;
        paraminfo[pi].paramtype = M;
        paraminfo[pi].locus = -1;
        strcpy(paraminfo[pi].str,"m1  ");
		paraminfo[pi].inmodel = 1;
        pi++;
        paraminfo[pi].listpos = 5+MAXLOCI;
        paraminfo[pi].paramtype = M;
        paraminfo[pi].locus = -1;
        strcpy(paraminfo[pi].str,"m2  ");
		if (progopts[COMMONMIGRATION])
			paraminfo[pi].inmodel = 0;
		else
			paraminfo[pi].inmodel = 1;
        pi++;
        }
    else
        {
        for (li=0;li<nloci;li++, pi++)
            {
            paraminfo[pi].listpos = 5+li;
            paraminfo[pi].paramtype = M;
            paraminfo[pi].locus = li;
            sprintf(paraminfo[pi].str,"%dm1",li);
            while (strlen(paraminfo[pi].str)<4) strcat(paraminfo[pi].str," ");
			paraminfo[pi].inmodel = 1;
            }
        for (li=0;li<nloci;li++, pi++)
            {
            paraminfo[pi].listpos = 5+MAXLOCI+li;
            paraminfo[pi].paramtype = M;
            paraminfo[pi].locus = li;
            sprintf(paraminfo[pi].str,"%dm2",li);
            while (strlen(paraminfo[pi].str)<4) strcat(paraminfo[pi].str," ");
			if (progopts[COMMONMIGRATION])
				paraminfo[pi].inmodel = 0;
			else
				paraminfo[pi].inmodel = 1;
            }
        }
	ui = 5 + 2*MAXLOCI;
	if (nloci > 1  || L[0][0]->numsmm >= 1) 
        {
        for (li=0;li<nloci;li++)
            {
            paraminfo[pi].listpos = ui;
            paraminfo[pi].paramtype = U;
            paraminfo[pi].locus = li;
			// locusulookup contains the position in the Q[]->U of the first mutation rate for this locus 
			locusulookup[li] = nurates;
			//enum {INFINITESITES,HKY,STEPWISE,JOINT_IS_SW,SW_PARTOFSWM,SW_PARTOFJOINT};
			if (L[0][li]->model == INFINITESITES || L[0][li]->model == HKY)
				{
				paraminfo[pi].utype = L[0][li]->model;
				sprintf(paraminfo[pi].str,"%du ",li);
				paraminfo[pi].inmodel = 1;
				pi++;
				ui++;
				nurates++;
				}
			if (L[0][li]->model == STEPWISE)
				{
				paraminfo[pi].utype = L[0][li]->model;
				paraminfo[pi].Apos = 0;
				sprintf(paraminfo[pi].str,"%dSW%d",li,0);
				paraminfo[pi].inmodel = 1;
				pi++;
				ui++;
				nurates++;
				for (i = 1; i< L[0][li]->numsmm; i++)
					{
					paraminfo[pi].listpos = ui;
					paraminfo[pi].paramtype = U;
					paraminfo[pi].locus = li;
					paraminfo[pi].utype = STEPWISE;
					paraminfo[pi].Apos = i;
					sprintf(paraminfo[pi].str,"%dSW%d",li,i);
					paraminfo[pi].inmodel = 1;
					ui++;
					pi++;
					nurates++;
					}
				}
			if (L[0][li]->model == JOINT_IS_SW)
				{
				paraminfo[pi].utype = INFINITESITES;
				sprintf(paraminfo[pi].str,"%du ",li);
				paraminfo[pi].inmodel = 1;
				pi++;
				ui++;
				nurates++;
				for (i = 0; i< L[0][li]->numsmm; i++)
					{
					paraminfo[pi].listpos = ui;
					paraminfo[pi].paramtype = U;
					paraminfo[pi].locus = li;
					paraminfo[pi].utype = STEPWISE;
					paraminfo[pi].Apos = i;
					sprintf(paraminfo[pi].str,"%dSW%d",li,i);
					paraminfo[pi].inmodel = 1;
					ui++;
					pi++;
					nurates++;
					}
				}
			}
		}
    if (progopts[UPDATEH])
        for (li=0;li<nloci;li++, pi++)
            {
            paraminfo[pi].listpos = 5 + 3*MAXLOCI + MAXLINKEDSMM + li;
            paraminfo[pi].paramtype = H;
            paraminfo[pi].locus = li;
            sprintf(paraminfo[pi].str,"h%d",li);
			paraminfo[pi].inmodel = 1;
            while (strlen(paraminfo[pi].str)<4) strcat(paraminfo[pi].str," ");
            }
    if (nurates==0) 
        nurates = 1;
    myassert(pi==numparams);
    } /* fillparaminfo */

#define MAXPRIORSCALETRY 10000000
#define log1000  6.9077553

void setinitialQ(void)
	{
	int i, j, k,li, ci, ui, uj ;
	double w, w2;
	double  sumq1, sumq2, temp, tempq1, tempq2;
    double uscale, hscale;
	int  numuprior=0, doneu, rcheck, priorscaletry = 0, numupair,*upriorpairlist1, *upriorpairlist2;
	double r, maxr, newr, U, d, prodcheck;

    /* some max values are from command line
    for Thetas, the range is set to watterson's estimate based on the entire data set
     initial parameter values are picked from a uniform distribution between the max and the min */
    /*if HKY model, then it is not known what would be a good theta value,  so a large scalar is used */
    /* for mutatation rates, max values also depend on the amount of variation that is found */
    
    tempq1 = 0;
    tempq2 = 0;
    sumq1 = sumq2 = 0;
//	if (firstuparam > lastuparam)  not sure why I used this to test for one single part locus
	if (nurates == 1) // only one single part locus 
		{
		li = 0;
		if (L[0][li]->model == INFINITESITES) 
			{
			for(j=1,w=0.0;j<L[0][li]->numpop1;j++)
				w += 1/(double) j;
			if (w==0) w = 1;
			sumq1 += tempq1 = (L[0][li]->pop1sites + 1) / w; 
			for(j=1,w=0.0;j<L[0][li]->numpop2;j++)
				w += 1/(double) j;
			if (w==0) w = 1;
			sumq2 += tempq2 = (L[0][li]->pop2sites + 1) / w; 
			}
		if (L[0][0]->model == HKY) 
			{
			for(j=1,w=0.0;j<L[0][li]->numgenes;j++)
				w += 1/(double) j;
			if (w==0) w = 1;
			sumq1 += tempq1 = numvar(0,li)/w;
			sumq2 += tempq2 = numvar(0,li)/w;
			}
		if (L[0][0]->model == STEPWISE) 
			{
		//	somestepwise=1;
			for(j=0,w=0,w2=0;j<L[0][li]->numpop1;j++)
				{
				w  += L[0][li]->tree[j].A[0];
				w2 += square(L[0][li]->tree[j].A[0]);
				}
			tempq1 = 2*(w2 - square(w)/L[0][li]->numpop1)/(L[0][li]->numpop1);
			if (tempq1 ==0) tempq1 = 10;
			sumq1  += tempq1;
			for(w=0,w2=0;j<L[0][li]->numgenes;j++)
				{
				w  += L[0][li]->tree[j].A[0];
				w2 += square(L[0][li]->tree[j].A[0]);
				}
			tempq2 = 2*(w2 - square(w)/L[0][li]->numpop2)/(L[0][li]->numpop2);
			if (tempq2 ==0) tempq2 = 10;
			sumq2 += tempq2;
			}
		}
	else
		for (ui = 0, k = firstuparam, temp=0 ; k <= lastuparam; ui++, k++)
			{
			if (paraminfo[k].utype == INFINITESITES) 
				{
				li = paraminfo[k].locus;
				for(j=1,w=0.0;j<L[0][li]->numpop1;j++)
					w += 1/(double) j;
				if (w==0) w = 1;
				sumq1 += tempq1 = (L[0][li]->pop1sites + 1) / w; 
				for(j=1,w=0.0;j<L[0][li]->numpop2;j++)
					w += 1/(double) j;
				if (w==0) w = 1;
				sumq2 += tempq2 = (L[0][li]->pop2sites + 1) / w; 
				Q[0]->u[ui] = log(tempq1 + tempq2);
				temp += Q[0]->u[ui];
				}
			if (paraminfo[k].utype == HKY) 
				{
				li = paraminfo[k].locus;
				for(j=1,w=0.0;j<L[0][li]->numgenes;j++)
					w += 1/(double) j;
				if (w==0) w = 1;
				sumq1 += tempq1 = numvar(0,li)/w;
				sumq2 += tempq2 = numvar(0,li)/w;
				Q[0]->u[ui] = log(tempq1 + tempq2);
				temp += Q[0]->u[ui];
				}
			if (paraminfo[k].utype == STEPWISE) 
				{
				li = paraminfo[k].locus;
				//somestepwise=1;
				for(j=0,w=0,w2=0;j<L[0][li]->numpop1;j++)
					{
					w  += L[0][li]->tree[j].A[paraminfo[k].Apos];
					w2 += square(L[0][li]->tree[j].A[paraminfo[k].Apos]);
					}
				tempq1 = 2*(w2 - square(w)/L[0][li]->numpop1)/(L[0][li]->numpop1);
				if (tempq1 ==0) tempq1 = 10;
				sumq1  += tempq1;
				for(w=0,w2=0;j<L[0][li]->numgenes;j++)
					{
					w  += L[0][li]->tree[j].A[paraminfo[k].Apos];
					w2 += square(L[0][li]->tree[j].A[paraminfo[k].Apos]);
					}
				tempq2 = 2*(w2 - square(w)/L[0][li]->numpop2)/(L[0][li]->numpop2);
				if (tempq2 ==0) tempq2 = 10;
				sumq2 += tempq2;
				Q[0]->u[ui] = log(tempq1 + tempq2);
				temp += Q[0]->u[ui];
				}
			}
	for (ui = 0; ui <nurates;ui++)
        {
        Qmax.u[ui] =  log(10000);
        Qmin.u[ui] = -Qmax.u[ui];
        Qwin.u[ui] = Qmax.u[ui]/nloci;
        }
	if (nurates > 1)
		{
		for (ui = 0; ui < nurates; ui++)
			{
			Q[0]->u[ui] = exp(Q[0]->u[ui] - temp/nurates);
			}
		for (prodcheck = 1,ui = 0; ui < nurates; ui++) 
			prodcheck *= Q[0]->u[ui];
		if (fabs(log(prodcheck)) > 1e-5)
			err(0,li,76);
		for (ui = 0; ui < nurates; ui++)
			if (ulow[ui] != 0) numuprior++;
		myassert(!(progopts[MUTATIONPRIORRANGE] && (numuprior <= 1)));
		if (progopts[MUTATIONPRIORRANGE])
			{
			myassert(numuprior > 1);
			numupair = numuprior * (numuprior-1)/2;
			upriorpairlist1 = calloc (numupair,sizeof(int));
			upriorpairlist2 = calloc (numupair,sizeof(int));
			k = 0;
			for (ui = 0; ui < nurates-1; ui++)
				for (uj = ui+1; uj < nurates; uj++)
					if (ulow[ui] != 0 && ulow[uj] != 0)
						{
						upriorpairlist1[k] = ui;
						upriorpairlist2[k] = uj;
						k++;
						}
			/* urri[i][j] has a 0 if neither i nor j has a prior. 1 if i has a prior and j does not,  -1 if i does not have a pior and j does  */
			for (ui = 0; ui < nurates; ui++)
				for (uj = 0; uj < nurates; uj++)
					{
					urri[ui][uj] = 0;
					if (ui != uj && ulow[ui] != 0 && ulow[uj] != 0)
						{
						urrlow[ui][uj] = log(ulow[ui]/uhi[uj]);
						urrhi[ui][uj] = log(uhi[ui]/ulow[uj]);
						urri[ui][uj] = urri[uj][ui] = 2;
						}
					else
						{
						if (ui != uj && ulow[ui] != 0 && ulow[uj] == 0)
							urri[ui][uj] = 1;
						if (ui != uj && ulow[uj] != 0 && ulow[ui] == 0)
							urri[ui][uj] = -1;
						}
					}
			/* need to set all of the uscalers so that their ratios are in the ranges defined by the priors */
			/* it is possible that suiteable sets of scalars will not be able to be found */
			maxr = 3*Qmax.u[0];	
			do	{
				doneu = 1;
				for (i=0;i< numupair;i++)
					{
					ui = upriorpairlist1[i];
					uj = upriorpairlist2[i];
					r = log(Q[0]->u[ui]/Q[0]->u[uj]);
					rcheck = (r >= urrlow[ui][uj] && r <= urrhi[ui][uj]);
					doneu = doneu && rcheck;
					if (!rcheck)
						{
						do
							{
							U = uniform();
							if (U > 0.5)
								newr = r + maxr*(2.0*U-1.0);
							else
								newr = r - maxr*U*2.0;
							if (newr > maxr)
								newr = 2.0*maxr - newr;
							else if (newr < -maxr)
								newr = 2.0*(-maxr) - newr; 
							d = exp((newr - r)/2);
							}
						while ((newr <= urrlow[ui][uj] || newr >= urrhi[ui][uj]));
						Q[0]->u[ui] *= d;
						Q[0]->u[uj] /= d;
						}
					}
				priorscaletry++;
				}
			while (!doneu && priorscaletry < MAXPRIORSCALETRY);
			if (priorscaletry >= MAXPRIORSCALETRY)
				err(0,li,77);
			for (prodcheck = 1,ui = 0; ui < nurates; ui++) 
				prodcheck *= Q[0]->u[ui];
			if (fabs(log(prodcheck)) > 1e-5)
				err(0,li,76);
			free(upriorpairlist1);
			free(upriorpairlist2);
			}
		}
	else 
		Q[0]->u[0] = 1.0;

    /* could remove this section and just have Qmax for thetas be set by the user */
    if (!progopts[RETURNPRIOR] && progopts[POPSIZEPRIORSETMODE] == 0 )
        {
        if (sumq2 > 0)
            Qmax.q2 *= sumq2/nurates;
        if (sumq1 > 0)
            Qmax.q1 *= sumq1/nurates;
        if (sumq1 > sumq2)
	        Qmax.qA *= sumq1/nurates;
        else 
            Qmax.qA *= sumq2/nurates;
        }
	// else leave the max values at what was specified on the command lines
	for (li=0;li<MAXLOCI;li++)
        for (ci=0; ci<MAXCHAINS; ci++) kappa[ci][li]=0;
    for (li=0;li<nloci;li++)
        {
        for (ci=0; ci<numchains; ci++) kappa[ci][li]=2.0;
        kappamax[li]=100.0;
        kappawindowsize[li]=2.0;
        }
    Qwin.q1 = MIN(10,Qmax.q1/5);
    Qwin.q2 = MIN(10,Qmax.q2/5);
    Qwin.qA = MIN(10,Qmax.qA/5);
    Qwin.s = (Qmax.s-Qmin.s)/5.0;
    Qwin.t = (Qmax.t -Qmin.t)/(5 + Qwin.t * nloci); 
    //Qwin.t = (Qmax.t)/(5 + Qwin.t * nloci);
        
    for((progopts[LOCUSMIGRATION]) ? (i=nloci) : (i=1), li=0;li<i;li++)
        {
        Qmax.m1[li] = Qmax.m1[0];
        Qmax.m2[li] = Qmax.m2[0];
        /* usually best to start out with lower migration */
        if (Qmax.m1[li] > 1)
            Q[0]->m1[li] = uniform();
        else
            Q[0]->m1[li] = uniform() * Qmax.m1[li];
        if (Qmax.m2[li] > 1)
            Q[0]->m2[li] = uniform();
        else
            Q[0]->m2[li] = uniform() * Qmax.m2[li];
        }
    if ((Qmax.m1[0] == 0 && Qmax.m2[0] > 0) || (Qmax.m2[0] == 0 && Qmax.m1[0] > 0))
        err(0,0,13);
    Q[0]->t =  uniform()*(Qmax.t - Qmin.t) + Qmin.t; 
    //Q[0]->t =  uniform() * Qmax.t;
    Q[0]->q1 = uniform() * Qmax.q1;
    Q[0]->q2 = uniform() * Qmax.q2;
    Q[0]->qA = uniform() * Qmax.qA;
    if (progopts[POPSIZECHANGEMODE]) 
      //  Q[0]->s = uniform()*(Qmax.s - Qmin.s)+Qmin.s;
        Q[0]->s = MIN(Qmax.s,MAX(Qmin.s,sumq1 /(sumq1+sumq2)));

    
    if (progopts[UPDATEH])
        for (li=0;li<nloci;li++)
	        {
		    Qmax.h[li] = log(100);
            Qmin.h[li] = -Qmax.h[li];
		    Q[0]->h[li] =1; 
		    Qwin.h[li] = Qmax.h[li]/5;
		    }
    if (progopts[COMMONTHETA])
        {
        Q[0]->q1 = Q[0]->q2 = Q[0]->qA;
        Qmax.q1 = Qmax.q2 = Qmax.qA;
        Qwin.q1 = Qwin.q2 = Qwin.qA;
        }
    if (progopts[ONEPOP])
        {
        Q[0]->t = -1;
        for (li=0;li<nloci;li++) 
            {
            Q[0]->m1[li] = -1;
            Q[0]->m2[li] = -1;
            }
        Qmax.q2 = Qmax.q1;
        Qmax.qA = 2*Qmax.q1;
        }
    
    if (progopts[COMMONMIGRATION])
        {
        for((progopts[LOCUSMIGRATION]) ? (i=nloci) : (i=1), li=0;li<i;li++)
            {
            Qmax.m1[li] = Qmax.m2[li] = MAX(Qmax.m1[li], Qmax.m2[li]);
            Q[0]->m1[li] = Q[0]->m2[li];
            }
        }
    if (progopts[EQUILIBRIUMMIGRATION])
        {
        Q[0]->t = TIMEMAX / 2;
        Q[0]->qA = 0;
        if (Qmax.m1[0] == 0 || Qmax.m2[0] == 0)
            err(-1,-1,11);
        }
    for (ci=1; ci<numchains; ci++)
        /* if multiple chains, first copy param values over from 0, then reset some of them to new random values */
        {
        memcpy(Q[ci],Q[0],sizeof(struct parameters));
        for((progopts[LOCUSMIGRATION]) ? (i=nloci) : (i=1), li=0;li<i;li++)
            {
            /* don't let migration rates start too large */
            if (Qmax.m2[li] > 1)
                Q[ci]->m2[li] = uniform();
            else
                Q[ci]->m2[li] = uniform() * Qmax.m2[li];
            if (progopts[COMMONMIGRATION])
                Q[ci]->m1[li] = Q[ci]->m2[li];
            else
                {
                if (Qmax.m1[li] > 1)
                    Q[ci]->m1[li] = uniform();
                else
                    Q[ci]->m1[li] = uniform() * Qmax.m1[li];
                }
            }
        Q[ci]->t =  uniform() * Qmax.t;
        Q[ci]->q1 = uniform() * Qmax.q1;
        Q[ci]->q2 = uniform() * Qmax.q2;
        Q[ci]->qA = uniform() * Qmax.qA;
        if (progopts[COMMONTHETA])
            Q[ci]->q1 = Q[ci]->q2 = Q[ci]->qA;
        if (progopts[EQUILIBRIUMMIGRATION])
            {
            Q[ci]->t = TIMEMAX / 2;
            Q[ci]->qA = 0;
            }
        if (progopts[ONEPOP])
            {
            Q[ci]->t = -1;
            for (li=0;li<nloci;li++) 
                {
                Q[ci]->m1[li] = -1;
                Q[ci]->m2[li] = -1;
                }
            }
        }
    
    /* these vectors are bins to contain counts of parameter values in each range 
    the vec vectors are the counts, the grid vectors are the boundaries of the bins*/
    /* one scale should be ok for all loci, because all have same max values of u and h */
    if (progopts[WIDELOGSCALE])
        {
        if (nurates>1)
            uscale = (Qmax.u[0]-Qmin.u[0] + 2*log1000)/gridsize;
        if (progopts[UPDATEH])
            hscale = (Qmax.h[0]-Qmin.h[0] + 2*log1000)/gridsize;
        }
    else
        {
        if (nurates>1)
            uscale = (Qmax.u[0]-Qmin.u[0])/gridsize;
        if (progopts[UPDATEH])
            hscale = (Qmax.h[0]-Qmin.h[0])/gridsize;
        }

    beforegrid = aftergrid = Qaccp0;
    for (i=0; i<gridsize; i++)
	    {
        Qvec[i] = Qaccp0;
        if (nurates > 1)
            {
		    for (ui=0;ui < nurates;ui++) 
			    {
                if (progopts[WIDELOGSCALE])
                    Qgrid[i].u[ui] = exp(Qmin.u[ui] - log1000 + (i+0.5) * uscale); 
			    else
                    Qgrid[i].u[ui] = exp(Qmin.u[ui] + (i+0.5) * uscale); 
				}
            if (progopts[UPDATEH])
                for (li=0;li<nloci;li++) 
			        {
                    if (progopts[WIDELOGSCALE])
                        Qgrid[i].h[li] = exp(Qmin.h[li] -log1000 + (i + 0.5) *   hscale);
                    else
    			        Qgrid[i].h[li] = exp(Qmin.h[li] + (i + 0.5) *   hscale);
			        }
            }
        
        Qgrid[i].q1 = Qmin.q1 + ((i+0.5) * (Qmax.q1 - Qmin.q1)) / gridsize;
        Qgrid[i].q2 = Qmin.q2 + ((i+0.5) * (Qmax.q2 - Qmin.q2)) / gridsize;
        Qgrid[i].qA = Qmin.qA + ((i+0.5) * (Qmax.qA - Qmin.qA)) / gridsize;
        for((progopts[LOCUSMIGRATION]) ? (j=nloci) : (j=1), li=0;li<j;li++)
            {
            Qgrid[i].m1[li] = Qmin.m1[li] + ((i+0.5) * (Qmax.m1[li] - Qmin.m1[li])) / gridsize;
            Qgrid[i].m2[li] = Qmin.m2[li] + ((i+0.5) * (Qmax.m2[li] - Qmin.m2[li])) / gridsize;
            }

		// should set up the grid for t,  assuming that Qmin.t = 0,  even if sometimes Qmin.t may not be zero. 
		//Qgrid[i].t = Qmin.t + ((i+0.5) * (Qmax.t - Qmin.t)) / gridsize;
		Qgrid[i].t = ((i+0.5) * Qmax.t) / gridsize;  
        Qgrid[i].s = (i+0.5)/ gridsize;
        if (printoptions[PRINTTMRCA])
            {
            tmrcagrid[i] = (i+0.5) * (10+Qmax.t)/gridsize;
            for (li=0;li<nloci;li++) 
			    {
			    tmrcadist[li][i] = 0.0;
                }
            }
        if (printoptions[MIGRATEDIST])
            {
            /* set up histograms for number of migration events in 
            each direction for each locus. Also the mean time of an event
            given that there was one or migration. For the mean time
            use the same time scale as t, so don't need a grid for this.
            For the # of events, just the index serves as the count so
            don't need a grid for this*/
            for (li=0;li<nloci;li++) 
			    {
                mtimevec[li][0][i] = mtimevec[li][1][i] = 0;
                meventvec[li][0][i] = meventvec[li][1][i] = 0;
                }
            }
		if (1 /*printoptions[DEMOGTEST] */ && progopts[POPSIZECHANGEMODE])
			{
			snadist[0][i] = snadist[1][i] = 0;
			snagrid[i] = Qgrid[i].qA;
			}
	    }	
    for (i = 0,li = 0; li < nloci; li++)
        if (i < L[0][li]->numgenes)  
			i = L[0][li]->numgenes;
	largestsamp = i;
    numlist = calloc(largestsamp,sizeof(int));
	mc = calloc(2*largestsamp, sizeof(int));
	step = 0;
	restartstep = -1;
	} /*setinitialQ */


int findsegsites(int ci, int li, int numbases, int initseg[], int *pop1seg, int *pop2seg, int MODEL)
/* jh modified this to find sites that cannot be used 
  suitable base values are A,a,C,c,G,g,T,t  other things cause the site to be ignored 
 also  added counting of sites for both populations */
    {
    char c, *zeroc, *altc, *zeroc1, *zeroc2, *altc1, *altc2;
    int i, j, k, v, totseg = 0, A;
	int *initseg1, *initseg2;
	

    zeroc = calloc(numbases,(sizeof(char)));
    altc = calloc(numbases,(sizeof(char)));
	zeroc1 = calloc(numbases,(sizeof(char)));
    altc1 = calloc(numbases,(sizeof(char)));
	zeroc2 = calloc(numbases,(sizeof(char)));
    altc2 = calloc(numbases,(sizeof(char)));
	initseg1 = calloc(numbases,(sizeof(int)));
	initseg2 = calloc(numbases,(sizeof(int)));
	*pop1seg = 0;
	*pop2seg = 0;
    for (k=0; k< L[ci][li]->numbases; k++)
	    {
	    L[ci][li]->badsite[k] = 0;
	    initseg[k] = initseg1[k] = initseg2[k]  = 0;

	    }
    for (i=0; i<L[ci][li]->numgenes; i++)
  	    {
	    for (v=0; v<10; v++)
		    { /*assumes that the first sequence of 10 characters that does not contain a carriage return is the species name*/
		    if (fgetc(infile) == '\n')
			    v = 0;
		    }
        if (MODEL==JOINT_IS_SW)
            {
			for (j=0;j<L[0][li]->numsmm;j++)
				fscanf(infile,"%d ",&A);
            }
	    j=0;
	    //while ((c=tolower((fgetc(infile))))!='\n' && c != '\r')  // bug found by Peter Ersts - was causing portability problems
		while ((c = tolower ((fgetc (infile)))) != '\n' && j < L[ci][li]->numbases ) // bug found by James Long - for badsites[j],  j was getting too large
		    {
		    if (c != ' ')
			    {
    	        if (i==0)
				    {
				    zeroc[j] = c;
				    altc[j] = ' ';
				    if ((c != 'a' && c != 'c') && (c != 't' && c != 'g'))
					    L[ci][li]->badsite[j] = 1;
				    }
			    else 
				    {
				    if ((c != 'a' && c != 'c') && (c != 't' && c != 'g'))
					    L[ci][li]->badsite[j] = 1;
				    if (L[ci][li]->badsite[j]==0 && c != zeroc[j] )
					    {
					    if (altc[j] == ' ')
						    altc[j] = c;
					    else
						    {
						    if (c != altc[j])
							    L[ci][li]->badsite[j]=1;
						    }
    	        	    initseg[j] = 1;
					    }
				    }
				if (i==0)
				    {
				    zeroc1[j] = c;
				    altc1[j] = ' ';
				    }
			    if (i > 0 && i < L[ci][li]->numpop1)
				    {
				    if (L[ci][li]->badsite[j]==0 && c != zeroc1[j] )
					    {
					    if (altc1[j] == ' ')
						    altc1[j] = c;
    	        	    initseg1[j] = 1;
					    }
				    }
				if (i==L[ci][li]->numpop1)
				    {
				    zeroc2[j] = c;
				    altc2[j] = ' ';
				    }
			    if (i > L[ci][li]->numpop1 && i < L[ci][li]->numgenes)
				    {
				    if (L[ci][li]->badsite[j]==0 && c != zeroc2[j] )
					    {
					    if (altc2[j] == ' ')
						    altc2[j] = c;
    	        	    initseg2[j] = 1;
					    }
				    }
    	        j++;
			    }
  		    }
  	    }
     for (i=0; i<numbases; i++)
 	    {
	    if (L[ci][li]->badsite[i] ==1)
			{
			initseg[i] = 0;
			initseg1[i] = 0;
			initseg2[i] = 0;
			}
 	    if (initseg[i] == 1)
 		    totseg++;
		if (initseg1[i] == 1)
 		    *pop1seg = *pop1seg + 1;
		if (initseg2[i] == 1)
 		    *pop2seg = *pop2seg + 1;
 	    }
    f_close(infile);
    free(zeroc);
    free(altc);
	free(zeroc1);
    free(altc1);
	free(zeroc2);
    free(altc2);
	free(initseg1);
    free(initseg2);
    return totseg;
    } /* findsegsites */


void elimfrom(int ci, int li, int site)
    {
    int i, j;

    for (i=0; i<L[ci][li]->numgenes; i++)
            {
            for (j=site; j<L[ci][li]->numsites-1; j++)
                    L[ci][li]->seq[i][j] = L[ci][li]->seq[i][j+1];
            }
    }

int seqid(int ci, int li, int i, int j)
    {
    int n;
    for (n=0; n<L[ci][li]->numgenes; n++)
            {
            if (L[ci][li]->seq[n][i] != L[ci][li]->seq[n][j])
                    return 0;
            }
    return 1;
    }

void sortseq(int ci, int li)
	{
	int i, j;

	L[ci][li]->mult = malloc((L[ci][li]->numsites)*(sizeof(int)));
	for (i=0; i<L[ci][li]->numsites; i++)
		L[ci][li]->mult[i] = 1;
	for (i=0; i<L[ci][li]->numsites; i++)
		{
		for (j=i+1; j<L[ci][li]->numsites; j++)
			{
			/*printf("compares codon %i and %i\n",i+1,j+1);*/
			if (seqid(ci,li,i,j) == 1)
				{
			/*	printf("eliminates codon %i\n",j+1);*/
				elimfrom(ci,li,j);
				j--;
				L[ci][li]->numsites--;
				L[ci][li]->mult[i]++;
				}
			}
		}
	}

void eliminategaps(int ci, int li)
    {
    int i, j;

    for (i=0; i<L[ci][li]->numsites; i++){
           for (j=0; j<L[ci][li]->numgenes; j++){
                    if (L[ci][li]->seq[j][i]==-1){
                            elimfrom(ci,li,i);
                            i--;
                            L[ci][li]->numsites--;
                            }
                    }
           }
    printf("Locus %i: HKY  model %i sites after elimination of gaps \n",li,L[ci][li]->numsites);
    }

int numvar(int ci, int li)
    {
    int i, j, tot=0;

    for (i=0; i<L[ci][li]->numsites; i++)
        {
        j=1;
        while (j<L[ci][li]->numgenes && L[ci][li]->seq[0][i]==L[ci][li]->seq[j][i])
            j++;
        if (j<L[ci][li]->numgenes)
            tot++;
        }
    return tot;
    }


void readseqHKY(int ci, int li)
    {
	int i,j,v,k=0;
	char c;
	double PIstandard;

    L[ci][li]->numsites = L[ci][li]->numbases;
	L[ci][li]->seq = malloc(L[ci][li]->numgenes*(sizeof(int *)));
	for (i=0; i<L[ci][li]->numgenes; i++)
                L[ci][li]->seq[i]=malloc(L[ci][li]->numsites*(sizeof(int)));
        for (i=0; i<4; i++)
                L[ci][li]->pi[i]=0.0;
	do
	{
	for (i=0; i<L[ci][li]->numgenes; i++){
		for (v=0; v<10; v++)
			{ /*assumes that the first sequence of 10 characters that does not contain a carriage return is the species name*/
			if ((c=fgetc(infile)) == '\n')
				v = 0;
			}
	   j=k;
	   while ((c=fgetc(infile))!='\n')
			{
			if ((c!=' ')&&(c!='\t'))
				{
                if (i>=L[ci][li]->numgenes||j>=L[ci][li]->numsites)
					{
					/*ERROR READING DATA */ 
					err(ci,li,41);
					}
				if (c=='a' || c=='A')
					{
					L[ci][li]->seq[i][j] = 0;
					L[ci][li]->pi[0]++;
					}
				else 
                    if (c=='c'||c=='C')
					    {
 					    L[ci][li]->seq[i][j] = 1;
					    L[ci][li]->pi[1]++;
					    }
				    else 
                        if (c=='g'||c=='G')
					        {
 					        L[ci][li]->seq[i][j] = 2;
					        L[ci][li]->pi[2]++;;
					        }
				        else 
                            if (c=='t' || c=='u' || c=='T' || c== 'U')
					            {
					            L[ci][li]->seq[i][j] = 3;
					            L[ci][li]->pi[3]++;
					            }
				            else 
                                if (c=='n' || c=='-' || c=='N' || c=='.')
					                L[ci][li]->seq[i][j] = -1;
				                else
                                    { 
                                    printf("\nBAD BASE in species %i base %i: %c",i+1,j+1,c);       
                                    scanf("%i",&i);
					                err(ci,li,42);
					                }
				j++;
				if (i==(L[ci][li]->numgenes-1)) k++;
				}
			}
	   }
	}
	while (k<L[ci][li]->numsites);
        if (L[ci][li]->numpop1+L[ci][li]->numpop2 != L[ci][li]->numgenes)
	        err(ci,li,84);
    eliminategaps(ci,li);
    L[ci][li]->totsites=L[ci][li]->numsites;
	sortseq(ci,li);
    L[ci][li]->numlines = 2*L[ci][li]->numgenes-1;
	PIstandard = 0.0;
    for (i=0; i<4; i++)
        PIstandard+=L[ci][li]->pi[i];
    for (i=0; i<4; i++)
        {
        L[ci][li]->pi[i]=L[ci][li]->pi[i]/PIstandard;
        /*L[ci][li]->pi[i]=0.25; JC only*/
        }
    infilelines += L[ci][li]->numgenes;
    } /* readseqHKY */

void allocatefracs(int ci, int li)
    {
    int i, j;
	struct edge *tree = L[ci][li]->tree;

    for (i= L[ci][li]->numgenes ; i<2*L[ci][li]->numgenes-1; i++){
            tree[i].frac=malloc(L[ci][li]->numsites*(sizeof(double *)));
            tree[i].newfrac=malloc(L[ci][li]->numsites*(sizeof(double *)));
            for (j=0; j<L[ci][li]->numsites; j++){
                    tree[i].frac[j]=malloc(4*(sizeof(double)));
                    tree[i].newfrac[j]=malloc(4*(sizeof(double)));
                    }
            }
    }

void readseqIS(int ci, int li, int MODEL)
    {
    int i, ai, j, v, k, sitek, sitej;
    int  *initseg;
    char c, *refseq;
    int numinvar;

    initseg = calloc(L[ci][li]->numbases,(sizeof(int)));
    L[ci][li]->badsite = calloc(L[ci][li]->numbases,(sizeof(int)));
    for (i=0; i<L[ci][li]->numbases; i++)
	    initseg[i] = 0;
    if (L[ci][li]->numbases > 0)
	    {
	    L[ci][li]->numsites = findsegsites(ci, li,L[ci][li]->numbases, initseg, &L[ci][li]->pop1sites,&L[ci][li]->pop2sites,MODEL);
        if (L[ci][li]->model == INFINITESITES)
	        printf("Locus %i : Infinite Sites model, %i sites are segregating\n",li,L[ci][li]->numsites);
        if (L[ci][li]->model == JOINT_IS_SW)
	        printf("Locus %i : Joint Infinite Sites/Stepwise model, %i sites are segregating\n",li,L[ci][li]->numsites);
	    if (NULL==(infile=fopen(infilename,"r")))
            {
  	        err(-1,-1,1);
            }
	    for (i=0;i< infilelines;i++)
		    //while ((c=(fgetc(infile)))!='\n' && c != '\r');
			while ((c=(fgetc(infile)))!='\n'); // bug found by Peter Ersts - was causing portability problems
  	    }

    else L[ci][li]->numsites = 0;
    numinvar = L[ci][li]->numbases - L[ci][li]->numsites;
    L[ci][li]->numlines = 2*L[ci][li]->numgenes-1;
    refseq = calloc(L[ci][li]->numbases,(sizeof(char)));
    L[ci][li]->seq=calloc(L[ci][li]->numgenes,(sizeof(int *))); 
    for (i=0; i<L[ci][li]->numgenes; i++)
	    L[ci][li]->seq[i]=calloc((L[ci][li]->numsites),(sizeof(int)));
    if (L[ci][li]->numbases > 0)
        {
        k = 0;
        sitek = 0;
        do{  // awkward overkill for reading in sequence 
	        for (i=0; i<L[ci][li]->numgenes; i++)
  		        {
		        for (v=0; v<10; v++)
			        { /*assumes that the first sequence of 10 characters that does not contain a carriage return is the species name*/
			        if ((c = fgetc(infile)) == '\n')
				        v = 0;
			        }
                if (MODEL==JOINT_IS_SW)
                    {
					for (ai =0; ai < L[ci][li]-> numsmm; ai++)
						fscanf(infile,"%d",&L[ci][li]->tree[i].A[ai]);
                    }
		        j = k;
		        sitej = sitek;
		        //while ((c=tolower((fgetc(infile))))!='\n' && c != '\r') // bug found by Peter Ersts - was causing portability problems
				while ((c=tolower((fgetc(infile))))!='\n' && j < L[ci][li]->numbases) // bug found by James Long.  j was getting to big for initseg[j]
			        {
                    if (isdigit(c))
                        err(ci,li,80);
			        if (c != ' ')
    	      	        {
    	      	        if (initseg[j] == 1)
					        {
					        if (i==0)
    		       		        {
    		       		        refseq[j] = c;
    		       		        L[ci][li]->seq[0][sitej] = 0;
    		           	        }
    		                else if (c == refseq[j])
    		        	        {
						        L[ci][li]->seq[i][sitej] = 0;
						        }
    		                else
    		        	        {
    		        	         L[ci][li]->seq[i][sitej] = 1;
    		        	         }
    		                sitej++;
    		   		        if (i==(L[ci][li]->numgenes-1)) 
								sitek++;
    		                }
    		            j++;
    		   	        if (i==(L[ci][li]->numgenes-1)) 
							k++;
				        }
  			        }
  		        }
          } while (k<L[ci][li]->numbases);
        }
    infilelines += L[ci][li]->numgenes;
    if (L[ci][li]->numpop1+L[ci][li]->numpop2 != L[ci][li]->numgenes)
	    err(ci,li,84);
    free(initseg);
    free(refseq);
    } /* readseqIS */

