/* IM  by Jody Hey and Rasmus Nielsen  2004-2009 */
/*last updates 12_17_09 */


/* out.c  results output to file */

#undef GLOBVARS
#include "im.h"

struct hlists
    {
    double v;
    double p;
    };


void shellhist(struct hlists *hptr, int length){
  double aln = 1.442695022, tiny = 1.0e-5;
  struct hlists h;
  int nn,m,lognb2,i,j,k,l;
  lognb2 = (int) floor(log(length)*aln + tiny);
  m = length;
  for (nn=1; nn<= lognb2; nn++){
      m = m /2;
      k = length - m;
      for (j = 0; j <= k-1; j++){
          i = j;
          reloop:
          l = i+m;
          if (((hptr+l)->p < (hptr+i)->p) || (((hptr+l)->p == (hptr+i)->p) && (((hptr+l)->v < (hptr+i)->v)) ) ){
             h = *(hptr+i);
             *(hptr+i) = *(hptr+l);
             *(hptr+l) = h;
             i = i - m;
             if (i>= 0) goto reloop;
             }
          }
      }
} /* shellfithet */



#define AUTOCCUTOFF 50
void intervaloutput(int changed0, int qswapped)
    {
    static int laststepcount = 0;
    double p, l;
    int li, ci;
    int i,j;
    double *gptr;
    static  int lc = -1,lastchanged[BASICPARAMS+2];
    static struct parameters  Qhold, holdchangedvals;
    double *holdptr;
    char c = 'I';
	double ac[AUTOCTERMS][BASICPARAMS+2],ac_lp[AUTOCTERMS], ess_lp, ess[BASICPARAMS+2],temp1,temp2;
	int stopsum[BASICPARAMS+2], stopsum_lp;
	double ltemp, pdsum;
	int ai, ui;
	int somestepwise;

    ci = 0; /* this function works only on chain 0 */
	for (l=0,p=0, li=0;li<nloci;li++)
        {
		if (L[0][li]->model != STEPWISE)
	        l += ltemp = L[ci][li]->oldlike;
		else
			l += ltemp = 0;
		if (L[0][li]->model == STEPWISE || L[0][li]->model == JOINT_IS_SW)
			for (ai=0;ai < L[0][li]->numsmm; ai++)
				{
				ltemp += L[ci][li]->oldlike_a[ai];
				l += L[ci][li]->oldlike_a[ai];
				}
        p += L[ci][li]->oldprob;
        if (hilocuslike[li] < ltemp)
            {
            hilocuslike[li] = ltemp;
            }
        if (hilocusprob[li] < L[ci][li]->oldprob)
            {
            hilocusprob[li] = L[ci][li]->oldprob;
            }
        }
    if (hilike < l)
        hilike = l;
    if (hiprob < p)
        hiprob = p;
    if (( step/(int) printint)* (int) printint == step && step > 0)
		{
		if (!burndone)
            {
            printf("-BURNIN-PERIOD-------------------------------\n");
            printf("STEP # %li  Current p(D|G,PARAMS): %.3f  Current p(G|PARAMS): %.3f\n",step,l,p);
            }
        else 
            {
            printf("---------------------------------------------\n");
            printf("STEP # %li  Current p(D|G,PARAMS): %.3f  Current p(G|PARAMS): %.3f\n",step - burnsteps,l,p);
            }
		if (nurates == 1 && L[0][0]->model == STEPWISE)
			somestepwise = 1;
		else
			{
			somestepwise = 0;
			for (ui = firstuparam; ui <= lastuparam; ui++)
				somestepwise = somestepwise || paraminfo[ui].utype == STEPWISE;
			}
        printf("CUMULATIVE UPDATE ACCEPTANCE RATES\n");
        printf("L# Mod\tG%%\tB%%\toutof#");
		if (progopts[UPDATEH])
                printf("\t\th%%\toutof#");
        if (nurates > 1)
            printf("\t\tu%%\toutof#");
        if (somestepwise)
            printf("\t\tA%%");
        printf("\n");
		for (ui=0,li = 0;li < nloci; li++)
			{
            switch (L[0][li]->model)
                {
                case INFINITESITES :  c = 'I'; break;
                case HKY :  c = 'H'; break;
                case STEPWISE :  c = 'S'; break;
                case JOINT_IS_SW :  c = 'J'; break;
                }
			printf("%2i %c\t%4.1f\t%4.1f\t%.1e",li,c,100.0*(double)gaccp[li]/(double) gupdatetries[li],100.0*(double)topolaccp[li]/(double) gupdatetries[li],(float) gupdatetries[li]);
            if (progopts[UPDATEH])
                 printf("\t%4.1f\t%.1e",100.0* Qaccp.h[li]/ Qupdatetries.h[li],Qupdatetries.h[li]);
			if (nurates > 1)
				{
				printf("\t%4.1f\t%.1e",100.0*Qaccp.u[ui]/Qupdatetries.u[ui],Qupdatetries.u[ui]);
				ui++;
				if (L[0][li]->model==STEPWISE)
					for (ai=1;ai < L[0][li]->numsmm; ai++)
						{
						printf("\t%4.1f\t%.1e",100.0*Qaccp.u[ui]/Qupdatetries.u[ui],Qupdatetries.u[ui]);
						ui++;
						}
				if (L[0][li]->model==JOINT_IS_SW)
					for (ai=0;ai < L[0][li]->numsmm; ai++)
						{
						printf("\t%4.1f\t%.1e",100.0*Qaccp.u[ui]/Qupdatetries.u[ui],Qupdatetries.u[ui]);
						ui++;
						}
				}
			if (L[0][li]->model==STEPWISE || L[0][li]->model==JOINT_IS_SW)
				for (ai=0;ai < L[0][li]->numsmm; ai++)
					printf("\t%4.1f",100*Aupdateratecount[li][ai]/((float) (L[0][li]->numgenes-1) * Aupdatetries[li][ai]));
            printf("\n");
			}
        printf("q1: %.2f%% out of %.1e, q2: %.2f%% out of %.1e\n",100*Qaccp.q1/Qupdatetries.q1,Qupdatetries.q1,100*Qaccp.q2/Qupdatetries.q2,Qupdatetries.q2);
        printf("qA  %.2f%% out of %.1e,  t: %.2f%% out of %.1e\n",100*Qaccp.qA/Qupdatetries.qA,Qupdatetries.qA,100*Qaccp.t/Qupdatetries.t,Qupdatetries.t);
            
        if (progopts[POPSIZECHANGEMODE])
            printf(" s  %.2f%% out of %.1e\n",100*Qaccp.s/Qupdatetries.s,Qupdatetries.s);
        if (!progopts[LOCUSMIGRATION])
            printf("m1: %.2f%% out of %.1e, m2: %.2f%% out of %.1e\n",100 * Qaccp.m1[0]/Qupdatetries.m1[0],Qupdatetries.m1[0],100 * Qaccp.m2[0]/Qupdatetries.m2[0],Qupdatetries.m2[0]);
        else
            {
            for (li = 0;li < nloci; li++)
                printf("Locus %d  m1: %.2f%% out of %.1e, m2: %.2f%% out of %.1e\n",li,100 * Qaccp.m1[li]/Qupdatetries.m1[li],Qupdatetries.m1[li],100 * Qaccp.m2[li]/Qupdatetries.m2[li],Qupdatetries.m2[li]);
            }
        printf("CURRENT PARAMETER VALUES AND LIKELIHOODS\n");
        printf("Locus# p(G|PARAMS) p(D|G,PARAMS)");
		if (nurates > 1)
			{
			if (progopts[UPDATEH]) printf("       h");
			printf("      u\n");
			}
		else 
			printf("\n");
		for (li = 0, ui = 0;li < nloci; li++)
            {
			printf("%2i     %10.3lf  ",li,L[ci][li]->oldprob);
			if (L[0][li]->model != STEPWISE)
				pdsum = L[0][li]->oldlike;
			else 
				pdsum = 0;
			if (L[0][li]->model==STEPWISE || L[0][li]->model==JOINT_IS_SW)
				{
				if (L[0][li]->numsmm > 0)
					{
					for (i=0;i<L[0][li]->numsmm; i++)
						{
						pdsum += L[0][li]->oldlike_a[i];
						}
					}
				}
			else
				printf("            ");
			printf("%10.3lf ",pdsum);
			if (nurates > 1)
				{
		        if (progopts[UPDATEH]) 
					printf("%9.3f   ", Q[ci]->h[li]);
				printf("%9.3lf   ",Q[ci]->u[ui]);
				ui++;
				if (L[0][li]->model==STEPWISE)
					for (ai=1;ai < L[0][li]->numsmm; ai++)
						{
						printf("%9.3lf   ",Q[ci]->u[ui]);
						ui++;
						}
				if (L[0][li]->model==JOINT_IS_SW)
					for (ai=0;ai < L[0][li]->numsmm; ai++)
						{
						printf("%9.3lf   ",Q[ci]->u[ui]);
						ui++;
						}
				}
			printf("\n");
			}
		printf("q1: %.4lf, q2: %.4lf, qA: %.4lf, ",Q[ci]->q1,Q[ci]->q2,Q[ci]->qA);
        if (Q[ci]->t < 0.001)
            printf("t: %.7lf",Q[ci]->t);
        else
            printf("t: %.4lf",Q[ci]->t);
        if (progopts[POPSIZECHANGEMODE])  printf(", s: %.5lf",Q[ci]->s);
        printf("\n");
        if (!progopts[LOCUSMIGRATION])
            printf("m1: %.4f       m2: %.4f\n",Q[ci]->m1[0],Q[ci]->m2[0]);
        else
            {
            printf("locus\tm1\tm2\n");
            for (li = 0;li < nloci; li++)
                printf(" %2d\t%.4f\t%.4f\n",li,Q[ci]->m1[li],Q[ci]->m2[li]);
            }

		if (autoc[0][0].n > AUTOCCUTOFF)
			{
            printf("\nAutocorrelations and Effective Sample Size Estimates\n");
            printf("\tstep\tL[P()]");
            for (i=0;i<basics;i++) if (paraminfo[i].inmodel)
                printf("\t%s",paraminfo[i].str);
            printf("\n");
		    for (i=0;i<AUTOCTERMS;i++)
			    {
			    if (autoc[i][0].n > AUTOCCUTOFF)
				    {
                    printf("\t%d",checkstep[i]);
					ac_lp[i] = ((autoc_lp[i].s2/autoc_lp[i].n) - square(autoc_lp[i].s/(2*autoc_lp[i].n)))
						/((variance_lp.s2/variance_lp.n)-square(variance_lp.s/variance_lp.n));
					if (ac_lp[i] > 1)
						ac_lp[i] = 1;
					printf("\t% .4f",ac_lp[i]);
				    for (j=0;j<basics;j++) if (paraminfo[j].inmodel)
					    {
					    ac[i][j] = ((autoc[i][j].s2/autoc[i][j].n) - square(autoc[i][j].s/(2*autoc[i][j].n)))
						    /((variance[j].s2/variance[j].n)-square(variance[j].s/variance[j].n));
					    if (ac[i][j] > 1)
						    ac[i][j] = 1;
					    printf("\t% .4f",ac[i][j]);
					    }
				    printf("\n");
				    }
			    }
			ess_lp = 0;
			stopsum_lp = 0;
			for (i=1;i<AUTOCTERMS;i++)
				if (autoc[i][0].n > AUTOCCUTOFF)
					{
					if (ac_lp[i] <0.03)
						temp1 = 0;
					else 
						temp1 = ac_lp[i];
					if (ac_lp[i-1] <0.03)
						temp2 = 0;
					else 
						temp2 = ac_lp[i-1];
					if (stopsum_lp==0)
						ess_lp += (checkstep[i]-checkstep[i-1])* (temp1+temp2)/2;
					stopsum_lp=  (stopsum_lp || temp1==0);
					}
			for (j=0;j<basics;j++) if (paraminfo[j].inmodel)
				{
				ess[j] = 0;
				stopsum[j] = 0;
				for (i=1;i<AUTOCTERMS;i++)
					{
					if (autoc[i][0].n > AUTOCCUTOFF)
						{
						if (ac[i][j] <0.03)
							temp1 = 0;
						else 
							temp1 = ac[i][j];
						if (ac[i-1][j] <0.03)
							temp2 = 0;
						else 
							temp2 = ac[i-1][j];
						if (stopsum[j]==0)
							ess[j] += (checkstep[i]-checkstep[i-1])* (temp1+temp2)/2;
						stopsum[j]=  (stopsum[j] || temp1==0);
						}
					}
				}
            printf("ESS estimates");
			if (stopsum_lp)
                printf("\t% 5.0f",step/(1+2*ess_lp));
            else
                printf("\t<% 5.0f",step/(1+2*ess_lp));
            for (j=0;j<basics;j++) if (paraminfo[j].inmodel)
                {
                if (stopsum[j])
                    printf("\t% 5.0f",step/(1+2*ess[j]));
                else
                    printf("\t<% 5.0f",step/(1+2*ess[j]));
                }
            printf("\n");
			}
		if (numchains > 1)
            {
            printf("CHAIN SWAPPING - ");
            switch (heatmode)
                {
                case HLINEAR: printf(" Linear Increment  term: %.4f\n",hval1);break;
                case HTWOSTEP: printf(" Twostep Increment  term1: %.4f term2: %.4f\n",hval1, hval2); break;
                case HADAPT: printf(" Twostep Adaptive Increment  term1: %.4f term2: %.4f\n",hval1, hval2);break;
                case HGEOMETRIC: printf(" Geometric Increment  term1: %.4f term2: %.4f\n",hval1, hval2);break;
                }
            if (heatmode == HADAPT)
                {
                printf("   Adaptive Heating -  update interval: %d steps  -  current beta terms:\n     ",adaptcheck);
                for (i=0;i< numchains;i++)
                    printf("%d: %.4f ",i, beta[i]);
                printf("\n");
                printf("   Current swap rates: Chains 0,1: %.5f",swap01/ (float)swap01d);
                if (numchains > 2)
                    printf("  Chains 1,2: %.5f",swap12/ (float) swap12d);
                printf("\n");
                }
            else
                {
                printf("   beta terms:\n     ");
                for (i=0;i< numchains;i++)
                    printf("%d: %.4f ",i, beta[i]);
                printf("\n");
                }
            printf("   Swap rates, between successive chains:\n     ");
            for (i=1;i< numchains;i++)
                if (swapcount[i][i-1]) 
                    printf("%d,%d: %.3f   ",i-1,i, swapcount[i-1][i]/(float) swapcount[i][i-1]);
            printf("\n");
            printf("   Swap counts, between successive chains:\n     ");
            for (i=1;i< numchains;i++)
                    printf("%d,%d: %d  ",i-1,i, swapcount[i-1][i]);
            printf("\n");
			j = IMIN(SWAPDIST,numchains);
            printf("   Swap rates, chain 0 with chain (up to %d):\n     ", j);
            for (i=1;i<= j;i++)
                printf("%d: %.3f ",i, swapcount[0][i]/(float) swapcount[i][0]);
            printf("\n"); 
            printf("   Swap counts, chain 0 with chain (up to %d):\n     ", j);
            for (i=1;i<= j;i++)
                printf("%d: %d ",i, swapcount[0][i]);
            printf("\n"); 
            }
        }
    if (printoptions[PRINTALLVALUES] && burndone) //does not work when each locus has its own rates 
    /* print a line when a parameter has changed  
    if no change stepcount += 1
    if a change  print the number of steps since last change.  print the parameter that changed before those steps
    save the position of the parameter that just changed.  */
        {
        if ((qswapped||changed0) && surfsetvals > 0)
            {
            laststepcount++;
            if (lc)
                {
                lc = 0;
                //fprintf(surfile,"%d\t%d\t",step,laststepcount);
				fprintf(surfile,"%d\t",laststepcount);
                for (j=0;j< basics;j++)
                    {
                    if (lastchanged[j])
                        {
                        if (*(&holdchangedvals.q1+j)>0.1) 
                            fprintf(surfile,"%.4f\t",*(&holdchangedvals.q1+ paraminfo[j].listpos));
                        else 
                            fprintf(surfile,"%.7f\t",*(&holdchangedvals.q1+ paraminfo[j].listpos));
                        }
                    else fprintf(surfile,"\t");
                    if (*(&Qhold.q1 + paraminfo[j].listpos) != *(&Q[ci]->q1 + paraminfo[j].listpos))
                        {
                        lastchanged[j] = 1;
                        lc = 1;
                        }
                    else 
                        lastchanged[j] = 0;
                    }
                fprintf(surfile,"\n");
                laststepcount = 0;
                for (j=0;j<basics;j++)
                    {
                    if (lastchanged[j])
                        {
                        *(&Qhold.q1+ paraminfo[j].listpos) = *(&holdchangedvals.q1+ paraminfo[j].listpos) = *(&Q[ci]->q1+ paraminfo[j].listpos);
                        }
                    }
                }
            else 
                lc = 1;  /* should not get here I don't think */
            }
        else
            {
            if (surfsetvals==0)
                {
                fprintf(surfile,"0\t");
                for (j=0;j< basics;j++)
                    {
                    gptr = (&Q[ci]->q1 + paraminfo[j].listpos);
                    holdptr = (&Qhold.q1 + paraminfo[j].listpos);
                    *holdptr = *gptr;
                    if (*gptr>0.1) 
                        fprintf(surfile,"%.4f\t",*gptr);
                    else 
                        fprintf(surfile,"%.7f\t",*gptr);
                    }
                fprintf(surfile,"\n");
                }
            lc = 1;
            laststepcount++;
            surfsetvals = 1;
            }
        } 
    } /* intervaloutput */

void asciicurve(double *x, double *y,char *qlabel, int logscale)
/* structure of graph 
0 name
1 ytop    |
40 ybot   |
41         -------
42        xbot        xtop
*/
	{
	char  graph[44][70];
	char  tc[12];
	double yt,ymax = -100000,ymin = 100000;
	int  i, xspot,yspot, pjump;
	pjump = sizeof(struct parameters) / sizeof(double);
	
	for (i=0;i<gridsize;i++)
		{
		yt = *(y + pjump * i);
		if (ymax < yt) ymax = yt;
		if (ymin > yt) ymin = yt;
		}
	strcpy(graph[0],qlabel);
    if (logscale)
        strcat(graph[0],"  log scale");
	sprintf(tc,"%8.4f",ymax/recordstep );
	strcpy(graph[1],tc);
	strcat(graph[1],"                                                     ");
	sprintf(tc,"%8.4f",ymin/recordstep );
	strcpy(graph[40],tc);
    while (strlen(graph[40]) < 69) strcat(graph[40]," ");
	strcpy(graph[41],"          --------------------------------------------------------");
	strcpy(graph[42],"          ");
	sprintf(tc,"%8.4f",*x);
	strcat(graph[42],tc);
	strcat(graph[42],"                                           ");
	sprintf(tc,"%8.4f",*(x + (gridsize-1)*pjump));
	strcat(graph[42],tc);
	for (i=2;i<40;i++)
		strcpy(graph[i],"                                                                   ");
	for (i=1;i<41;i++)
		graph[i][10] = '|';
	for (i=0;i<gridsize;i++)
		{
		yspot = (int) 1 + 40  - (int) (40.0* (*(y+pjump*i) - ymin)/(ymax-ymin));
        if (logscale)
            xspot = (int) 11 + (int) (54.0 * (log(*(x + pjump*i)) - log(*x))/(2*log( *(x + (gridsize-1)*pjump))));
        else
            xspot = (int) 11 + (int) (54.0 * (*(x + pjump*i)-*x)/  (*(x + (gridsize-1)*pjump) - *x));
		if (xspot < 70) graph[yspot][xspot] = '*';
		}
	for (i=0;i<43;i++)
		FP"%s \n",graph[i]);
	fprintf(outfile,"\n");
    } /* asciicurve */

#define MAXLENX  200
#define MAXLENY  104
void asciitrend(double *y,char *qlabel, int xlen, int ylen, int logscale, int pjump)
/* structure of graph 
0 name
1 ytop    |
40 ybot   |
41         -------
42        xbot        xtop
*/
	{
	char  graph[MAXLENY][MAXLENX];
	char  tc[12];
	double yt,ymax = -100000,ymin = 100000;
	int  i,xspot,yspot;

	if (xlen > MAXLENX) xlen = MAXLENX;
	if (ylen > MAXLENY) ylen = MAXLENY;
	for (i=0;i<TRENDDIM;i++)
		{
		yt = *(y + pjump * i);
		if (ymax < yt) ymax = yt;
		if (ymin > yt && (!logscale || yt > 0)) ymin = yt;
		}
	strcpy(graph[0],qlabel);
	if (logscale)
		{
        strcat(graph[0],"  log scale");
		sprintf(tc,"%8.4f",log(ymax));
		}
	else
		sprintf(tc,"%8.4f",ymax);
	strcpy(graph[1],tc);
	while (strlen(graph[1]) < xlen-1) strcat(graph[1]," ");
	if (logscale)
		{
		sprintf(tc,"%8.4f",log(ymin));
		}
	else
		sprintf(tc,"%8.4f",ymin);
	strcpy(graph[ylen-2],tc);
    while (strlen(graph[ylen-2]) < xlen-1) strcat(graph[ylen-2]," ");
	strcpy(graph[ylen-1],"          ");
	while (strlen(graph[ylen-1]) < xlen-1) strcat(graph[ylen-1],"-");
	for (i=2;i<ylen-2;i++)
		{
		graph[i][0] = '\0';
		while (strlen(graph[i]) < xlen-1) strcat(graph[i]," ");
		}
	for (i=1;i<ylen-1;i++)
		graph[i][10] = '|';

	for (i=0;i<TRENDDIM;i++)
		{
		if (logscale)
			yspot = (int) 1 + (ylen-2) - (int) ((ylen-2) * ( log(*(y+pjump*i)) - log(ymin))/(log(ymax)-log(ymin)));
		else
			yspot = (int) 1 + (ylen-2) - (int) ((ylen-2) * (*(y+pjump*i) - ymin)/(ymax-ymin));
        xspot = (int) 11 + (int) ((xlen - 12) * i/TRENDDIM);
		if (xspot < xlen && yspot >=0 && xspot >= 0 && yspot < ylen) 
			graph[yspot][xspot] = '*';
		}
	for (i=0;i<ylen;i++)
		FP"%s \n",graph[i]);
	FP"\n");
    } /* asciitrend */


void printhist(int mode)
    {
   	int i, j,k, ci, numparamsh;
	int    pjump,imax = -1;
	double *gptr,*sptr,maxval;
    double sum, tempsum, taillast,tailprelast;
    struct parameters Qsum;
    double smoothsum, smoothterm, smoothdenom;
    int /*countsmooth,*/cellnum, smoothcellnum = 20;
    struct hlists hlist[gridsize];
    double hpdmax, hpdmin, hpdlo[5*MAXLOCI + BASICPARAMS], hpdhi[5*MAXLOCI + BASICPARAMS];
    char hpdchar[5*MAXLOCI + BASICPARAMS];
	double scaleu, timeu, gridadjust[4], holdgrid[gridsize+1][4];
    int ui, numu, agi;

    pjump = sizeof(struct parameters) / sizeof(double);
    if (mode== 0)
        {
        FP"\n\nMARGINAL HISTOGRAMS\n"); 
        numparamsh = numparams;
        }
    else
    /* print out on demographic scales using mutation and generation time adjustments 
    only do first 4 parameters */
        {
        FP"\n\nMARGINAL HISTOGRAMS IN DEMOGRAPHIC UNITS\n"); 
        FP"\tCalculations use mutation rates (in years) and generation time (in years) input at runtime\n");
        FP"\tParameter\tMeaning\tUnits \n");
        FP"\tq1\tPop1 Ne\tIndividuals \n");
        FP"\tq2\tPop2 Ne\tIndividuals \n");
        FP"\tqa\tAncest.Pop Ne\tIndividuals \n");
        FP"\tt\tYears Div.\tYears\n");
        numparamsh = 4;
        scaleu = timeu = 0;
        for (ui=0,numu =0;ui<nurates;ui++)
            {
            if (uperyear[ui] > 0)
                {
                timeu += log(uperyear[ui]);
                scaleu += log(uscaleml[ui]);
				numu++;
                }
            }
        if (numu == 0)
            {
            FP"MUTATION RATE(S) NOT GIVEN IN INPUT FILE - DEMOGRAPHIC SCALES CANNOT BE CALCULATED \n");
            return;
            }
        myassert(timeu != 0);
        myassert(scaleu != 0);
        timeu = exp(timeu/numu);
        if (numu == nurates)
            scaleu = 1;
        else
            scaleu = exp(scaleu/numu);
        FP"\tGeneration time in years specified at runtime: %lf \n",generationtime);
        FP"\tGeometric mean of mutation rates per year (based on rates specified in input file): %le\n",timeu);
        FP"\tGeometric mean of ML estimates of relevant mutation rate scalars: %le\n",scaleu);
		gridadjust[0] = gridadjust[1] = gridadjust[2] = scaleu /(4 * timeu * generationtime);
        gridadjust[3] = scaleu/timeu;
        for (j=0;j< numparamsh;j++) if (paraminfo[j].inmodel)
		    {
            for (i=0;i<gridsize;i++)
				{
				holdgrid[i][j] = *(&Qgrid[0].q1 + paraminfo[j].listpos + i*pjump);
                *(&Qgrid[0].q1 + paraminfo[j].listpos + i*pjump) *= gridadjust[j];
				}
            }
        }

    FP"----------------------------------\n");

	ci = 0;
    FP" Summaries\n\t");
    for (i=0;i<numparamsh;i++) if (paraminfo[i].inmodel)
        FP"\t%s",paraminfo[i].str);
    FP"\n\tMinbin");
    for (j=0;j< numparamsh;j++) if (paraminfo[j].inmodel)
		{
        gptr = (&Qvec[0].q1 + paraminfo[j].listpos);
        i = 0;
        while (i< gridsize -1 && *gptr <= 0)
            {
            gptr += pjump;
            i++;
            }
        FP"\t%9.4f",*(&Qgrid[0].q1 + paraminfo[j].listpos + i*pjump));
        }
    FP"\n\tMaxbin");
    for (j=0;j< numparamsh;j++) if (paraminfo[j].inmodel)
		{
        i = gridsize-1;
        gptr = (&Qvec[0].q1 + paraminfo[j].listpos + i*pjump);
        while (i>0 && *gptr <= 0)
            {
            gptr -= pjump;
            i--;
            }
        FP"\t%9.4f",*(&Qgrid[0].q1 + paraminfo[j].listpos + i*pjump));
        }
    FP"\n\tHiPt");
    Qsum = Qaccp0;
	for (j=0;j< numparamsh;j++) if (paraminfo[j].inmodel)
		{
        gptr = (&Qvec[0].q1 + paraminfo[j].listpos);
		maxval = -1;
		for (i=0;i<gridsize;i++)
			{
            *(&Qsum.q1 + paraminfo[j].listpos) += *gptr;
			if (maxval < *gptr)
				{
				maxval = *gptr;
				imax = i;
				}
			gptr += pjump;
			}
        FP"\t%9.4f",*(&Qgrid[0].q1 + paraminfo[j].listpos + imax*pjump));
        }
    FP"\n\tHiSmth");
	for (j=0;j< numparamsh;j++) if (paraminfo[j].inmodel)
		{
		maxval = -1;
		if (paraminfo[j].paramtype == U) // awkward work arround for some unidentified bug  - for some reason mutation rate distributions that cross the boundary often get a spurious peak right at the boundary 
			{
			agi = gridsize -2;  /* don't include positions 0 and gridsize - 1 */
			gptr = (&Qvec[1].q1 + paraminfo[j].listpos);
			}
		else
			{
			agi = gridsize;
			gptr = (&Qvec[0].q1 + paraminfo[j].listpos);
			}
		for (i=0;i<agi;i++)
			{
            cellnum = MIN(smoothcellnum, 2*i);
            cellnum = MIN(cellnum, 2*(agi-1 - i));
            k=MAX(0,i-(cellnum/2));
            sptr=gptr + k * pjump;
            //countsmooth=1;
            //smoothsum = *sptr;
			smoothterm = 1.0/(0.5+abs(k-i));
			smoothsum= *sptr * smoothterm;
			smoothdenom  = smoothterm; 
            for (;k<MIN(agi-1,i+(cellnum/2));k++)
                {
                sptr += pjump;
               // smoothsum += *sptr;
               // countsmooth++;
				smoothterm = 1.0/(0.5 + abs(k-i));
				smoothsum += *sptr * smoothterm;
				smoothdenom  += smoothterm; 
                }
            //smoothsum /= (double) countsmooth;
			smoothsum /= smoothdenom;
            if (maxval < smoothsum)
                {
                maxval = smoothsum;
                imax = i;
                }
			}
		if (paraminfo[j].paramtype == U)
			imax++; // because we skipped position 0 when finding the smoothed peak for mutation rate scalards
        if (mode==0 && ci==0 && paraminfo[j].paramtype==U)
            { /* save the mutation rate estimates */
            uscaleml[j - firstuparam] = *(&Qgrid[0].q1 + paraminfo[j].listpos + imax*pjump);
            }
        FP"\t%9.4lf",*(&Qgrid[0].q1 + paraminfo[j].listpos + imax*pjump));
        }

    FP"\n\tMean");
	for (j=0;j< numparamsh;j++) if (paraminfo[j].inmodel)
		{
		gptr = (&Qvec[0].q1 + paraminfo[j].listpos);
        i=0;
        sum=0;
		if (paraminfo[j].inmodel)
			{
			while((sum + *gptr)/ *(&Qsum.q1 + paraminfo[j].listpos) <= 0.5 && i < gridsize )
				{
				sum += *gptr;
				gptr += pjump;
				i++;
				}
			FP"\t%9.4lf",*(&Qgrid[i].q1 + paraminfo[j].listpos));
			}
		else
			FP"\t%9.4lf",-1.0);
		}
/* print out 95% confidence points */	
	FP"\n\t95Lo"); 
	for (j=0;j< numparamsh;j++) if (paraminfo[j].inmodel)
		{
		gptr = (&Qvec[0].q1 + paraminfo[j].listpos);
        i=0;
        sum=0;
		if (paraminfo[j].inmodel)
			{
			while((sum + *gptr)/ *(&Qsum.q1 + paraminfo[j].listpos) <= 0.025 && i < gridsize)
				{
				sum += *gptr;
				gptr += pjump;
				i++;
				}
			FP"\t%9.4lf",*(&Qgrid[i].q1 + paraminfo[j].listpos));
			}
		else
			FP"\t%9.4lf",-1.0);
		}
    FP"\n\t95Hi");
	for (j=0;j< numparamsh;j++) if (paraminfo[j].inmodel)
		{
		gptr = (&Qvec[gridsize-1].q1 + paraminfo[j].listpos);
        i=gridsize-1;
        sum=0;
		if (paraminfo[j].inmodel)
			{
			while((sum + *gptr)/ *(&Qsum.q1 + paraminfo[j].listpos) <= 0.025 && i > 0)
				{
				sum += *gptr;
				gptr -= pjump;
				i--;
				}
			FP"\t%9.4lf",*(&Qgrid[i].q1 + paraminfo[j].listpos));
			}
		else
			FP"\t%9.4lf",-1.0);
		}
/* print out 90% Highest Posterior Density intervals  - first, smooth the curve*/	
	smoothcellnum = 30;
	for (j=0;j< numparamsh;j++) if (paraminfo[j].inmodel)
		{
		gptr = (&Qvec[0].q1 + paraminfo[j].listpos);
        tempsum = 0;
        for (i=0;i<gridsize;i++)
			{
            cellnum = MIN(smoothcellnum, 2*i);
            cellnum = MIN(cellnum, 2*(gridsize-1 - i));
            k=MAX(0,i-(cellnum/2));
            sptr=gptr + k* pjump;
            //countsmooth=1;
            //smoothsum=*sptr;

			smoothterm = 1.0/(0.5+abs(k-i));
			smoothsum = *sptr * smoothterm;
			smoothdenom  = smoothterm; 

            for (;k<MIN(gridsize-1,i+(cellnum/2));k++)
                {
                sptr += pjump;
                //smoothsum += *sptr;
                //countsmooth++;
				smoothterm = 1.0/(0.5+abs(k-i));
				smoothsum += *sptr * smoothterm;
				smoothdenom  += smoothterm; 
                }
            hlist[i].v =  *(&Qgrid[i].q1 + paraminfo[j].listpos);
            //tempsum += smoothsum /(double) countsmooth;
			tempsum += smoothsum /smoothdenom;
            //hlist[i].p =  smoothsum /(double) countsmooth;
			hlist[i].p =  smoothsum /smoothdenom;
            }
        shellhist(&(hlist[0]),gridsize); 
        sum = 0;
        hpdmax = -1;
        hpdmin = 1e10;
        i = gridsize-1;
        sum = hlist[i].p;
        while (i >= 0 && sum <= (0.90 * tempsum))
            {
            if (i > 0 && (hlist[i].p < hlist[i-1].p))
                err(0,0,93);
            if (hlist[i].v > hpdmax) 
                hpdmax = hlist[i].v;
            if (hlist[i].v < hpdmin) 
                hpdmin = hlist[i].v;
            i--;
            sum += hlist[i].p;
            }
        hpdlo[paraminfo[j].listpos] = hpdmin;
        hpdhi[paraminfo[j].listpos] = hpdmax;
        while (i > 0 && (hlist[i].v < hpdmin || hlist[i].v > hpdmax)) 
            i--;
        if (i> 0)
            hpdchar[paraminfo[j].listpos] = '?';
        else
            hpdchar[paraminfo[j].listpos] = ' ';
		}
    FP"\n\tHPD90Lo");
    for (j=0;j< numparamsh;j++) if (paraminfo[j].inmodel)
		{
        FP"\t%8.4f%c",hpdlo[paraminfo[j].listpos],hpdchar[paraminfo[j].listpos]);
        }
    FP"\n\tHPD90Hi");
    for (j=0;j< numparamsh;j++) if (paraminfo[j].inmodel)
		{
        FP"\t%8.4f%c",hpdhi[paraminfo[j].listpos],hpdchar[paraminfo[j].listpos]);
        }
	smoothcellnum = 20;

    FP"\n\tTail?");
    for (j=0;j< numparamsh;j++) if (paraminfo[j].inmodel)
		{
		taillast = tailprelast = 0;
        i= (int) (gridsize*0.90 - 1);
        gptr = (&Qvec[0].q1 + paraminfo[j].listpos);
        gptr += pjump * i;
        for (;i < (int) gridsize*0.95 - 1;i++)
            {
            tailprelast += *gptr;
			gptr += pjump;
			}
        for (;i < gridsize;i++)
            {
            taillast += *gptr;
			gptr += pjump;
			}
        if (taillast < (0.01 * *(&Qsum.q1+paraminfo[j].listpos)))
            {
            if (taillast <= tailprelast * *(&Qsum.q1+paraminfo[j].listpos))
                FP"\tcomplete");
            else
                FP"\tunclear");
            }
        else
            {
            if (taillast > 0.98 * tailprelast  && taillast < 1.02 * tailprelast)
                FP"\tflat");
            else
                {
                if (taillast > tailprelast)
                    FP"\trising");
                else
                    FP"\tfalling");
                }
            }
		}

	FP"\n\n");
    FP"\tValue");
    for (i=0;i<numparamsh;i++) if (paraminfo[i].inmodel)
        FP"\t%s\tL",paraminfo[i].str);
	FP"\n\tHiPt");
    Qsum = Qaccp0;
	for (j=0;j< numparamsh;j++) if (paraminfo[j].inmodel)
		{
        gptr = (&Qvec[0].q1 + paraminfo[j].listpos);
		maxval = -1;
		for (i=0;i<gridsize;i++)
			{
            *(&Qsum.q1 + paraminfo[j].listpos) += *gptr;
			if (maxval < *gptr)
				{
				maxval = *gptr;
				imax = i;
				}
			gptr += pjump;
			}
        if (*(&Qgrid[0].q1 + paraminfo[j].listpos + imax*pjump) < 0.005)
            FP"\t%9.6f\t%8.5f ",*(&Qgrid[0].q1 + paraminfo[j].listpos + imax*pjump),*(&Qvec[0].q1 + paraminfo[j].listpos + imax*pjump)/recordstep );
        else
            FP"\t%9.4f\t%8.5f ",*(&Qgrid[0].q1 + paraminfo[j].listpos + imax*pjump),*(&Qvec[0].q1 + paraminfo[j].listpos + imax*pjump)/recordstep );
        }
    FP"\n\n");
	for (i=0;i<gridsize;i++) 
		{
        FP"\t%4d",i);
        for (j=0;j<numparamsh;j++) if (paraminfo[j].inmodel)
            {
            if (*(&Qgrid[i].q1 + paraminfo[j].listpos) < 0.005)
                {
                 if (*(&Qgrid[i].q1 + paraminfo[j].listpos) < 0.00005)
                    FP"\t%9.8f\t%8.5f",*(&Qgrid[i].q1 + paraminfo[j].listpos),*(&Qvec[i].q1 + paraminfo[j].listpos)/recordstep) ;
                 else
                    FP"\t%9.6f\t%8.5f",*(&Qgrid[i].q1 + paraminfo[j].listpos),*(&Qvec[i].q1 + paraminfo[j].listpos)/recordstep) ;
                }
            else
                FP"\t%9.4f\t%8.5f",*(&Qgrid[i].q1 + paraminfo[j].listpos),*(&Qvec[i].q1 + paraminfo[j].listpos)/recordstep) ;
            }
		FP"\n");
		}
    FP" Before\t");
    for (j=0;j<numparamsh;j++) if (paraminfo[j].inmodel)
    	FP"\t<%-9.4f\t%8.5f",*(&Qmin.q1+paraminfo[j].listpos),*(&beforegrid.q1 + paraminfo[j].listpos)/recordstep );
	FP"\n");
	FP" After\t");
    for (j=0;j<numparamsh;j++) if (paraminfo[j].inmodel)
    	FP"\t<%-9.4f\t%8.5f",*(&Qmax.q1+paraminfo[j].listpos),*(&aftergrid.q1 + paraminfo[j].listpos)/recordstep );
	FP"\n");
	if (mode==1)
        /* put the scales back to the usual */
        {
        for (j=0;j< numparamsh;j++) if (paraminfo[j].inmodel)
		    {
            for (i=0;i<gridsize;i++)
				*(&Qgrid[0].q1 + paraminfo[j].listpos + i*pjump) = holdgrid[i][j];
                //*(&Qgrid[0].q1 + paraminfo[j].listpos + i*pjump) /= gridadjust[j];
            }
        }
    } /* printhist */


void printdtest(void)
	{
	int i,ip, j,jp, k;
	FP"\nTests of Parameter Differences \n");
	FP"     Proportion of time N1 > N2 : %8.5f  (complement:%8.5f)\n", (float) ntest[0]/ (float) (recordstep), 1.0 - (float) ntest[0]/ (float) (recordstep));
	FP"     Proportion of time N1 > NA : %8.5f  (complement:%8.5f)\n", (float) ntest[1]/ (float) (recordstep), 1.0 - (float) ntest[1]/ (float) (recordstep));
	FP"     Proportion of time N2 > NA : %8.5f  (complement:%8.5f)\n", (float) ntest[2]/ (float) (recordstep), 1.0 - (float) ntest[2]/ (float) (recordstep));
	if (!progopts[LOCUSMIGRATION])
		FP"     Proportion of time m1 > m2 : %8.5f  (complement:%8.5f)\n", (float) mtest[0]/ (float) (recordstep), 1.0 - (float) mtest[0]/ (float) (recordstep));
	else
		{
		for (i=0;i<nloci;i++)
			FP"     Proportion of time m1[%d] > m2[%d] : %8.5f  (complement:%8.5f)\n",i,i,(float) mtest[i]/ (float) (recordstep), 1.0 - (float) mtest[i]/ (float) (recordstep));
		}
	if (!progopts[LOCUSMIGRATION])
		FP"     Proportion of time 2N1m1 > 2N2m2 : %8.5f  (complement:%8.5f)\n", (float) nmtest[0]/ (float) (recordstep), 1.0 - (float) nmtest[0]/ (float) (recordstep));
	else
		{
		for (i=0;i<nloci;i++)
			FP"     Proportion of time 2N1m1[%d] > 2N2m2[%d] : %8.5f  (complement:%8.5f)\n",i,i,(float) nmtest[i]/ (float) (recordstep), 1.0 - (float) nmtest[i]/ (float) (recordstep));
		}
	if (progopts[LOCUSMIGRATION])
		{
		for (k=0;k<2;k++)
			{
			if (k==0)
				FP"\n     Compare m1 values among loci, above diagonal m1[row] > m1[col], below diagonal m1[col] > m1[row]\n"); 
			else 
				FP"\n     Compare m2 values among loci, above diagonal m2[row] > m2[col], below diagonal m2[col] > m2[row]\n"); 
			FP"     -");
			for (i=0;i<nloci;i++)
				FP"\t%2d",i);
			FP"\n");
			for (i=0;i<nloci;i++)
				{
				FP"     %2d",i);
				for (j=0;j<nloci;j++)
					{
					if (i==j)
						FP"\t-");
					else
						{
						if (i<j)
							FP"\t%8.5f",(float) mcomp[k][i][j]/ (float) (recordstep));
						else
							FP"\t%8.5f",1.0 - (float) mcomp[k][j][i]/ (float) (recordstep));
						}
					}
				FP"\n");
				}
			}
		}
	if (nurates > 1)
		{
		FP"\n     Compare mutation rate scalars among loci, above diagonal u[row] > u[col], below diagonal u[col] > u[row]\n"); 
		FP"     -");
		for (i=0, ip = firstuparam;i<nurates;i++)
			FP"\t%s",paraminfo[ip].str);
		FP"\n");
		for (i=0, ip = firstuparam;i<nurates;i++)
			{
			FP"     %s",paraminfo[ip].str);
			for (j=0,jp = firstuparam ;j<nurates;j++)
				{
				if (i==j)
					FP"\t-");
				else
					{
					if (i<j)
						FP"\t%8.5f",(float) ucomp[i][j]/ (float) (recordstep));
					else
						FP"\t%8.5f",1.0 - (float) ucomp[j][i]/ (float) (recordstep));
					}
				}
			FP"\n");
			}
		}
	FP"\n");
	} /* printdtest */

void printoutput(void)
	{
	int i, j,k, li, ci, si;
	int    imax = -1;
	double maxval;
    double seconds; 
    double sum, tempsum;
	double smoothsum, smoothterm, smoothdenom;
    int /*countsmooth, */cellnum, smoothcellnum = 20;
	double ac[AUTOCTERMS][BASICPARAMS+2],ac_lp[AUTOCTERMS], ess_lp, ess[BASICPARAMS+2],temp1,temp2;
	int stopsum[BASICPARAMS+2], stopsum_lp;
	int ai, ui;
	int somestepwise;

    if (cdurationmode == TIMEINF || checkinmode) 
        {
        remove(oldoutfilename);
        rename(outfilename, oldoutfilename);
        }
    if ((outfile = fopen(outfilename,"w")) == NULL)
        {
        printf("Error opening text file for writing\n"); 
        err(-1,-1,7);
        }

    FP"%s",fpstr);
    FP"\n\nRUN INFORMATION\n");
    FP"---------------------------\n\n");
	if (checkinmode) 
		{
		FP"Restart Run from file: %s\n",dckfilename);
		FP"---------------------------\n\n");
		}
    FP"Number of steps in chain following burnin: %10ld \n",(step-burnsteps));
	FP"Number of steps between recording: %d  Number of record steps: %ld \n",recordint,recordstep);
	FP"Number of genealogy updates per step: %d \n",gupdateint);
    time(&endtime);
    seconds = difftime(endtime,starttime);
    FP"Time Elapsed : %d hours, %d minutes, %d seconds \n\n", 
        (int) seconds / (int) 3600,
       ((int) seconds / (int) 60) - ((int) 60 * ((int) seconds / (int) 3600)),
	   (int) seconds  - (int) 60* ((int) seconds / (int) 60)
	   );
	
	if (checkinmode) 
		{
		seconds = difftime(endtime,restarttime);
		FP"Time Elapsed Since Resart: %d hours, %d minutes \n\n", 
			(int) seconds / (int) 3600,
		   ((int) seconds / (int) 60) - ((int) 60 * ((int) seconds / (int) 3600)));
		}
	
	if (cdurationmode==TIMEINF)
		FP"Number of Time Periods :%d   each of  %ld  seconds\n",chaintimeintervals,chainduration);
	FP"Highest Total P(D|G, Params) (log) : %10.3f \n\n", hilike);
    FP"Highest P(D|G, Params) (log) for each Locus \n");
    FP"\tLocus\tP(D|G, Params)\n");
    for (li = 0;li < nloci; li++)
        {
		FP"\t%d\t%.3f\n",li,hilocuslike[li]);
        }
    FP"\n");
    FP"Highest P(G|PARAMS) (log) for each Locus \n");
    for (li = 0;li < nloci; li++)
        {
		FP" Locus %2d: %.3f \n",li,hilocusprob[li]);
        }
    FP"\n");
    FP"Mean Time of Most Recent Common Ancestor \n");
    FP"\tLocus\tMean Time\tVariance \n");
	for (li=0;li<nloci;li++)
		if (tmrca[li].n > 1)
            FP"\t%d\t%10.3f\t%10.3f\n",li,tmrca[li].s/tmrca[li].n,(tmrca[li].s2 - (tmrca[li].s/tmrca[li].n))/(tmrca[li].n-1));
    FP"\n");
    FP"\nDemographic Parameter Update Rates\n");
    FP"\tParam\tUpdates\tAttempts\t%%\n");

    for (i=0;i<firstuparam;i++) if (paraminfo[i].inmodel)
        FP"\t%s\t%.2e\t%.2e\t%.2f\n",paraminfo[i].str,*(&Qaccp.q1+paraminfo[i].listpos),*(&Qupdatetries.q1+paraminfo[i].listpos),100* *(&Qaccp.q1+paraminfo[i].listpos)/ *(&Qupdatetries.q1+paraminfo[i].listpos));

    FP"\nGenealogy and Branching Update Rates \n");
  	FP"\tLocus#\tG updates\tG attempts\tG%%\tB updates\tB attempts\tB%%\n");
	for (li = 0;li < nloci; li++)
        {
        FP"\t%2i\t%.2e\t%.2e\t%.2f\t%.2e\t%.2e\t%.2f\n",li,(float) gaccp[li],(float) gupdatetries[li],100.0*(double)gaccp[li]/(double) gupdatetries[li],(float) topolaccp[li],(float) gupdatetries[li],100.0*(double)topolaccp[li]/(double) gupdatetries[li]);
        }
    FP"\n");
	if (nurates == 1 && L[0][0]->model == STEPWISE)
		somestepwise = 1;
	else
		{
		somestepwise = 0;
		for (ui = firstuparam; ui <= lastuparam; ui++)
			somestepwise = somestepwise || paraminfo[ui].utype == STEPWISE;
		}
    if (nurates > 1)
        {
        FP"\nMutation Update Rates");
        FP"\nLocus#\tu#\toutof#\tu%%");
		if (progopts[UPDATEH])
			FP"\nH \tH attempts\t H%%");
        if (somestepwise)
            FP"\tSTRs%%");
        FP"\n");
		for (ui = 0, k = firstuparam; k <= lastuparam; ui++, k++)
			{
			if (paraminfo[k].utype == STEPWISE) 
				{
				li = paraminfo[k].locus;
				ai = ui - (locusulookup[li] + (L[0][li]->model == JOINT_IS_SW));
				FP"%dSW%d",li,ai);
				FP"\t%.2e\t%.2e\t%.2f",Qaccp.u[ui],Qupdatetries.u[ui],100.0*Qaccp.u[ui]/Qupdatetries.u[ui]);
				if (progopts[UPDATEH] && ai == 0)
                    FP"\t%.2e\t%.2e\t%.2f",Qaccp.h[li],Qupdatetries.h[li],100.0* Qaccp.h[li]/ Qupdatetries.h[li]);
				FP"\t%.2f",100*Aupdateratecount[li][ai]/((float) (L[0][li]->numgenes-1) * Aupdatetries[li][ai]));
				}
			else 
				{
				li = paraminfo[k].locus;
				FP"%d",li);
				FP"\t%.2e\t%.2e\t%.2f",Qaccp.u[ui],Qupdatetries.u[ui],100.0*Qaccp.u[ui]/Qupdatetries.u[ui]);
				if (progopts[UPDATEH])
                    FP"\t%.2e\t%.2e\t%.2f",Qaccp.h[li],Qupdatetries.h[li],100.0* Qaccp.h[li]/ Qupdatetries.h[li]);
				}
            FP"\n");
            }
		if(progopts[MUTATIONPRIORRANGE] && countuprior > 1)
			{
			FP"\nFailed Mutation Updates Because of Prior Ranges");
			FP"\nLocus#\tu#\toutof#\tu%%\n");
			for (ui = 0, k = firstuparam; k <= lastuparam; ui++, k++)
				{
				if (paraminfo[k].utype == STEPWISE) 
					{
					li = paraminfo[k].locus;
					ai = ui - (locusulookup[li] + (L[0][li]->model == JOINT_IS_SW));
					FP"%dSW%d",li,ai);
					FP"\t%.2e\t%.2e\t%.2f",(float) uprior_failedupdate[ui],Qupdatetries.u[ui],100.0*uprior_failedupdate[ui]/Qupdatetries.u[ui]);
					}
				else 
					{
					li = paraminfo[k].locus;
					FP"%d",li);
					FP"\t%.2e\t%.2e\t%.2f",(float) uprior_failedupdate[ui],Qupdatetries.u[ui],100.0*uprior_failedupdate[ui]/Qupdatetries.u[ui]);
					}
				FP"\n");
				}
			}
		}
	if (autoc[0][0].n > AUTOCCUTOFF)
		{
	    FP"\nAutocorrelations and Effective Sample Size Estimates\n");
        FP"\tstep\tL[P()]");
        for (i=0;i<basics;i++) if (paraminfo[i].inmodel)
            FP"\t%s",paraminfo[i].str);
        FP"\n");
		for (i=0;i<AUTOCTERMS;i++)
			{
			if (autoc[i][0].n > AUTOCCUTOFF)
				{
                FP"\t%d",checkstep[i]);
				ac_lp[i] = ((autoc_lp[i].s2/autoc_lp[i].n) - square(autoc_lp[i].s/(2*autoc_lp[i].n)))
					/((variance_lp.s2/variance_lp.n)-square(variance_lp.s/variance_lp.n));
				if (ac_lp[i] > 1)
					ac_lp[i] = 1;
				FP"\t% .4f",ac_lp[i]);
				for (j=0;j<basics;j++) if (paraminfo[j].inmodel)
					{
					ac[i][j] = ((autoc[i][j].s2/autoc[i][j].n) - square(autoc[i][j].s/(2*autoc[i][j].n)))
						/((variance[j].s2/variance[j].n)-square(variance[j].s/variance[j].n));
					if (ac[i][j] > 1)
						ac[i][j] = 1;
					FP"\t% .4f",ac[i][j]);
					}
				FP"\n");
				}
			}
		ess_lp = 0;
		stopsum_lp = 0;
		for (i=1;i<AUTOCTERMS;i++)
			if (autoc[i][0].n > AUTOCCUTOFF)
				{
				if (ac_lp[i] <0.03)
					temp1 = 0;
				else 
					temp1 = ac_lp[i];
				if (ac_lp[i-1] <0.03)
					temp2 = 0;
				else 
					temp2 = ac_lp[i-1];
				if (stopsum_lp==0)
					ess_lp += (checkstep[i]-checkstep[i-1])* (temp1+temp2)/2;
				stopsum_lp=  (stopsum_lp || temp1==0);
				}
		for (j=0;j<basics;j++) if (paraminfo[j].inmodel)
			{
			ess[j] = 0;
			stopsum[j] = 0;
			for (i=1;i<AUTOCTERMS;i++)
				{
				if (autoc[i][0].n > AUTOCCUTOFF)
					{
					if (ac[i][j] <0.03)
						temp1 = 0;
					else 
						temp1 = ac[i][j];
					if (ac[i-1][j] <0.03)
						temp2 = 0;
					else 
						temp2 = ac[i-1][j];
					if (stopsum[j]==0)
						ess[j] += (checkstep[i]-checkstep[i-1])* (temp1+temp2)/2;
					stopsum[j]=  (stopsum[j] || temp1==0);
					}
				}
			}
        FP"\tESS");
		if (stopsum_lp)
            FP"\t% 5.0f",step/(1+2*ess_lp));
        else
            FP"\t<% 5.0f",step/(1+2*ess_lp));
		for (j=0;j<basics;j++) if (paraminfo[j].inmodel)
			{
			if (stopsum[j])
				FP"\t% 5.0f",step/(1+2*ess[j]));
			else
				FP"\t<% 5.0f",step/(1+2*ess[j]));
			}
		FP"\n");
		}
    if (numchains > 1)
        {
        if (heatmode == HADAPT)
            {
            FP"\nAdaptive Heating Option Selected \n");
            FP"Latest Beta values for chain swapping \n");
            }
        else
            {
            FP"\nBeta values for chain swapping \n");
            }
        FP"\tchain#\tBeta\n");
        for (ci=0;ci<numchains;ci++)
             FP"\t%2d\t%.5f\n",ci,beta[ci]);
        for (ci=0, tempsum=0;ci<numchains-1;ci++)
            for (j=ci+1; j< numchains;j++)
                tempsum += swapcount[j][ci];
        tempsum /= (numchains * (numchains-1)/2);

        FP"\nMean # of swap attempts between pairs of chains: %9.0lf\n",tempsum);
        FP"\nOverall Chain swapping - %% above diagonal,  counts below \n");
        FP"          ");
        for (ci = 0; ci < numchains; ci++)
            if (ci==0) FP"\t \tchain%d",ci);
            else FP"\t|chain%d",ci);
        FP"\n");

        for (ci = 0; ci < numchains; ci++)
            {
            FP"\tchain%d",ci);
            for (j=0;j<numchains;j++)
                    {
                    if (j==ci) 
                        {
                        FP"\t-");
                        }
                    else 
                        {
                        if (ci < j) FP"\t%7.3f",100.0* swapcount[ci][j]/(float) swapcount[j][ci]);
                        else 
                            {
                            FP"\t%10ld",swapcount[j][ci]);
                            }
                        }
                    }
            FP"\n");
            }
        }

    FP"\nCorrelations among Parameters \n          ");
    for (i=0;i<numparams;i++) if (paraminfo[i].inmodel)
        FP"%s\t",paraminfo[i].str);
	FP"\n");
    for (i=0; i < numparams;i++) if (paraminfo[i].inmodel)
        {
        FP"%s",paraminfo[i].str);
		for (j=0;j< numparams;j++) if (paraminfo[j].inmodel)
			{
            if (j<=i) FP"\t-");
            else
                {
				if ( ((c[i][j].si2 -  square(c[i][j].si)/c[i][j].n)*(c[i][j].sj2 -  square(c[i][j].sj)/c[i][j].n)) >= 0)
					{
					correlations[i][j] = (c[i][j].sij -  (c[i][j].si*c[i][j].sj)/c[i][j].n) / sqrt((c[i][j].si2 -  square(c[i][j].si)/c[i][j].n)*(c[i][j].sj2 -  square(c[i][j].sj)/c[i][j].n));
					FP"\t%.2f",correlations[i][j]);
					}
				else 
					FP"\tundef");
                }
            }
		FP"\n");
        }
	if (1 /*printoptions[DEMOGTEST] */)
		printdtest();
    printhist(0);
    if (printoptions[DEMOGHIST])
        printhist(1);
    if (printoptions[SMOOTHDIST])
        printsmoothdistoutput();

    if (printoptions[PRINTASCIICURVE])            
		{
        ci = 0;
		FP"\n\nASCII Curves - Approximate Posterior Densities \n\n");
        for (j=0;j<numparams;j++)
			if (paraminfo[j].inmodel)
				{
				if (paraminfo[j].paramtype == U || paraminfo[j].paramtype == H)
					asciicurve(&Qgrid[0].q1 + paraminfo[j].listpos,&Qvec[0].q1 + paraminfo[j].listpos,paraminfo[j].str,1);
				else
					asciicurve(&Qgrid[0].q1 + paraminfo[j].listpos,&Qvec[0].q1 + paraminfo[j].listpos,paraminfo[j].str,0);
				}
		}
	if (printoptions[PRINTASCIITREND])
		{
        ci = 0;
		FP"\n\nASCII Plots of Parameter Trends \n\n");
		asciitrend(&lptrend[0],"Log[P]", 100, 30, 0,1);
        for (j=0;j<numparams;j++)
			if (paraminfo[j].inmodel)
				{
				if (paraminfo[j].paramtype == U || paraminfo[j].paramtype == H)
					asciitrend(&Qtrend[0].q1 + paraminfo[j].listpos,paraminfo[j].str, 100, 30,1,sizeof(struct parameters) / sizeof(double));
				else
					asciitrend(&Qtrend[0].q1 + paraminfo[j].listpos,paraminfo[j].str, 100, 30,0,sizeof(struct parameters) / sizeof(double));
				}
		}
	
    if (printoptions[PRINTTMRCA])
        {
        FP"TMRCA distributions \n\n\t");
        FP"\t\t");
        for (li=0;li<nloci;li++)
		    {
		    FP"\tLocus%-2d",li);
		    }
        FP"\n\tHiPt\t");
        for (li=0;li<nloci;li++)
		    {
		    maxval = -1;
		    for (i=0;i<gridsize;i++)
                {
			    if (maxval < tmrcadist[li][i])
				    {
				    maxval = tmrcadist[li][i];
				    imax = i;
				    }
                }
            FP"\t%8.4f",tmrcagrid[imax]);
            }
        FP"\n\tHiSmth\t");
        for (li=0;li<nloci;li++)
		    {
	        maxval = -1;
		    for (i=0;i<gridsize;i++)
			    {
				cellnum = MIN(smoothcellnum, 2*i);
                cellnum = MIN(cellnum, 2*(gridsize-1 - i));
                k=MAX(0,i-(cellnum/2));
                //countsmooth=1;
                //smoothsum=tmrcadist[li][k];
				smoothterm = 1.0/(0.5+abs(k-i));
				smoothsum= tmrcadist[li][k] * smoothterm;
				smoothdenom  = smoothterm; 
				k++;
                while(k<MIN(gridsize,i+(cellnum/2)))
                    {
                    //smoothsum += tmrcadist[li][k];
                    //countsmooth++;
					smoothterm = 1.0/(0.5+abs(k-i));
					smoothsum += tmrcadist[li][k] * smoothterm;
					smoothdenom  += smoothterm; 
					k++;
                    }
                //smoothsum /= (double) countsmooth;
				smoothsum /= smoothdenom;
                if (maxval < smoothsum)
                    {
                    maxval = smoothsum;
                    imax = i;
                    }
			    }
            FP"\t%8.4f",tmrcagrid[imax]);
            }
        FP"\n\tMean\t");
        for (li=0;li<nloci;li++)
		    {
            sum=0;
            for (i=0;i<gridsize;i++)
                sum += tmrcadist[li][i] * tmrcagrid[i];
            sum /= recordstep ;
            FP"\t%8.4f",sum);
		    }
        FP"\n\n");
        FP"\t\tTMRCA");
        for (li=0;li<nloci;li++)
		    {
		    FP"\tLike_%-2d",li);
		    }
        FP"\n");
        for (i=0;i<gridsize;i++)
		    {
            FP"\t\t%8.4f",tmrcagrid[i]);
            for (li=0;li<nloci;li++)
		        {
		        FP"\t%8.5f",tmrcadist[li][i]/recordstep );
		        }
            FP"\n");
            }
		FP"\tafter");
		for (li=0;li<nloci;li++)
		    {
		    FP"\t%8.5f",tmrcaafter[li]/recordstep );
		    }
        FP"\n");
        }
	if (progopts[POPSIZECHANGEMODE])
			{
			FP"\nDistributions of s*Theta_A  and (1-s)*Theta_A \n\t");
			FP"\t\t");
			
			FP"\n\tHiPt\t");
			for (si=0;si<2;si++)
				{
				maxval = -1;
				for (i=0;i<gridsize;i++)
					{
					if (maxval < snadist[si][i])
						{
						maxval = snadist[si][i];
						imax = i;
						}
					}
				FP"\t%8.4f",snagrid[imax]);
				}
			FP"\n\tHiSmth\t");
			for (si=0;si<2;si++)
				{
				maxval = -1;
				for (i=0;i<gridsize;i++)
					{
					cellnum = MIN(smoothcellnum, 2*i);
					cellnum = MIN(cellnum, 2*(gridsize-1 - i));
					k=MAX(0,i-(cellnum/2));
					smoothterm = 1.0/(0.5+abs(k-i));
					smoothsum= snadist[si][k] * smoothterm;
					smoothdenom  = smoothterm; 
					//countsmooth=1;
					//smoothsum=snadist[si][k];
					k++;
					while(k<MIN(gridsize,i+(cellnum/2)))
						{
						//smoothsum += snadist[si][k];
						//countsmooth++;
						smoothterm = 1.0/(0.5+abs(k-i));
						smoothsum += snadist[si][k] * smoothterm;
						smoothdenom  += smoothterm; 
						k++;
						}
					//smoothsum /= (double) countsmooth;
					smoothsum /= smoothdenom;
					if (maxval < smoothsum)
						{
						maxval = smoothsum;
						imax = i;
						}
					}
				FP"\t%8.4f",snagrid[imax]);
				}
			FP"\n\tMean\t");
			for (si=0;si<2;si++)
				{
				sum=0;
				for (i=0;i<gridsize;i++)
					sum += snadist[si][i] * snagrid[i];
				sum /= recordstep ;
				FP"\t%8.4f",sum);
				}
			FP"\n\n");
			FP"\t\tNa_scale");
			FP"\tLike_sQ_A\tLike_(1-s)Q_A\n");
			FP"\n");
			for (i=0;i<gridsize;i++)
				{
				FP"\t\t%8.4f",snagrid[i]);
				for (si=0;si<2;si++)
					{
					FP"\t%8.5f",snadist[si][i]/recordstep );
					}
				FP"\n");
				}
			}
    if (printoptions[MIGRATEDIST])
        {
        FP"Migration Distributions \n");
        for (li=0;li<nloci;li++)
		    {
            FP"\t-\tLocus_%-2d\t-\t-\t-\t-\t-\t-",li);
            }
        FP"\n");
        FP"\tpt");
        for (li=0;li<nloci;li++)
		    {
		    FP"\tm1#\tp\tm1time\tp\tm2#\tp\tm2time\tp");
		    }
        FP"\n");
        for (i=0;i<gridsize;i++)
		    {
            FP"\t%4d",i);
            for (li=0;li<nloci;li++)
		        {
                FP"\t%4d\t%8.5f\t%9.4f\t%8.5f\t%4d\t%8.5f\t%9.4f\t%8.5f",
                    i,meventvec[li][0][i]/recordstep,
    		        Qgrid[i].t,mtimevec[li][0][i]/(recordstep - meventvec[li][0][0]),
                    i,meventvec[li][1][i]/recordstep,
		            Qgrid[i].t,mtimevec[li][1][i]/(recordstep - meventvec[li][1][0]));
                }
            FP"\n");
            }
        }
    FP"\nEND OF OUTPUT\n");

	/*printf("Results written to file '%s' \n",outfilename); */
	f_close(outfile);
    outfile = NULL;
	} /* printoutput*/

void printsmoothdistoutput(void)
	{
	int i, j,k, ci;
	int    pjump,imax = -1;
	double *gptr,*sptr,maxval;
    double smoothsum, smoothterm, smoothdenom;
    double densescale;
    char   likeprint[11];
	int cellnum, smoothcellnum = 20;
    //int countsmooth

    ci = 0;
    FP"\nMARGINAL LOG LIKELIHOODS - SMOOTHED\n"); 
    FP"----------------------------------\n");
	FP"\n pt      ");
    for (j=0;j<numparams;j++) if (paraminfo[j].inmodel)
        FP"%s\tL\t",paraminfo[j].str);
    FP"\n HiPeak\t");
    pjump = sizeof(struct parameters) / sizeof(double);
	for (j=0;j< numparams;j++) if (paraminfo[j].inmodel)
		{
        if (paraminfo[j].paramtype == U || paraminfo[j].paramtype == H)
            densescale = gridsize/(exp(*(&Qmax.q1+ paraminfo[j].listpos)) - exp(*(&Qmin.q1+ paraminfo[j].listpos)));
        else    
            densescale = gridsize/(*(&Qmax.q1+ paraminfo[j].listpos) - *(&Qmin.q1+ paraminfo[j].listpos));
        gptr = (&Qvec[0].q1 + paraminfo[j].listpos);
		maxval = -1;
		for (i=0;i<gridsize;i++)
			{
            cellnum = MIN(smoothcellnum, 2*i);
            cellnum = MIN(cellnum, 2*(gridsize-1 - i));
            k=MAX(0,i-(cellnum/2));
            sptr=gptr + k* pjump;
            //countsmooth=1;
            //smoothsum=*sptr;
			smoothterm = 1.0/(0.5+abs(k-i));
			smoothsum= *sptr * smoothterm;
			smoothdenom  = smoothterm; 
            for (;k<MIN(gridsize-1,i+(cellnum/2));k++)
                {
                sptr += pjump;
                //smoothsum += *sptr;
                //countsmooth++;
				smoothterm = 1.0/(0.5 + abs(k-i));
				smoothsum += *sptr * smoothterm;
				smoothdenom  += smoothterm; 
                }
            //smoothsum /= (double) countsmooth;
			smoothsum /= smoothdenom;
            if (maxval < smoothsum)
                {
                maxval = smoothsum;
                imax = i;
                }
			}
        if ((densescale * *(&Qvec[0].q1 + paraminfo[j].listpos + imax*pjump)/recordstep ) < MYDBL_MIN)
           strcpy(likeprint,"   -     ");
        else
           sprintf(likeprint,"% 9.5f",log(densescale * *(&Qvec[0].q1 + paraminfo[j].listpos + imax*pjump)/recordstep ));
         FP"%9.4f %s ",*(&Qgrid[0].q1 + paraminfo[j].listpos + imax*pjump),likeprint);
        }
    FP"\n\n");
	for (i=0;i<gridsize;i++)
		{
		FP" %4d\t",i);
        for (j=0;j< numparams;j++) if (paraminfo[j].inmodel)
		    {
            if (paraminfo[j].paramtype == U || paraminfo[j].paramtype == H)
                densescale = gridsize/(exp(*(&Qmax.q1+ paraminfo[j].listpos)) - exp(*(&Qmin.q1+ paraminfo[j].listpos)));
            else    
                densescale = gridsize/(*(&Qmax.q1+ paraminfo[j].listpos) - *(&Qmin.q1+ paraminfo[j].listpos));
            gptr = (&Qvec[0].q1 + paraminfo[j].listpos);
            cellnum = MIN(smoothcellnum, 2*i);
            cellnum = MIN(cellnum, 2*(gridsize-1 - i));
            k=MAX(0,i-(cellnum/2));
            sptr=gptr + k * pjump;
            //countsmooth=1;
            //smoothsum=*sptr;
			smoothterm = 1.0/(0.5+abs(k-i));
			smoothsum= *sptr * smoothterm;
			smoothdenom  = smoothterm; 

            for (;k< MIN(gridsize-1,i+(cellnum/2));k++)
                {
                sptr += pjump;
                //smoothsum += *sptr;
                //countsmooth++;
				smoothterm = 1.0/(0.5 + abs(k-i));
				smoothsum += *sptr * smoothterm;
				smoothdenom  += smoothterm; 
                }
            //smoothsum /= (double) countsmooth;
			smoothsum /= smoothdenom;
            if (densescale * smoothsum/recordstep  < MYDBL_MIN)
                strcpy(likeprint,"   -     ");
            else
                sprintf(likeprint,"% 9.5f",log(densescale * smoothsum/recordstep ));
            FP"%9.4f %s ",*(&Qgrid[0].q1 + paraminfo[j].listpos + i*pjump),likeprint);
            }
        FP"\n");
		}
    FP" Before\t");
    for (j=0;j< numparams;j++) if (paraminfo[j].inmodel)
        {
        if (paraminfo[j].paramtype == U || paraminfo[j].paramtype == H)
            densescale = gridsize/(exp(*(&Qmax.q1+ paraminfo[j].listpos)) - exp(*(&Qmin.q1+ paraminfo[j].listpos)));
        else    
            densescale = gridsize/(*(&Qmax.q1+ paraminfo[j].listpos) - *(&Qmin.q1+ paraminfo[j].listpos));
	    FP"<%-9.4f %8.5f ",*(&Qmin.q1 + paraminfo[j].listpos),*(&beforegrid.q1 + paraminfo[j].listpos)*densescale/recordstep );
        }
	FP"\n");
	FP" After\t");
    for (j=0;j< numparams;j++) if (paraminfo[j].inmodel)
        {
        if (paraminfo[j].paramtype == U || paraminfo[j].paramtype == H)
            densescale = gridsize/(exp(*(&Qmax.q1+ paraminfo[j].listpos)) - exp(*(&Qmin.q1+ paraminfo[j].listpos)));
        else    
            densescale = gridsize/(*(&Qmax.q1+ paraminfo[j].listpos) - *(&Qmin.q1+ paraminfo[j].listpos));
        FP">%-9.4f %8.5f ",*(&Qmax.q1 + paraminfo[j].listpos),*(&aftergrid.q1 + paraminfo[j].listpos)*densescale/recordstep );
        }
    FP"\n");
    }/* printsmoothdistoutput*/

