/* IM  by Jody Hey and Rasmus Nielsen  2004-2009 */
/*last updates 12_17_09 */


/* stepwise.c  stepwise mutation model related functions */

#undef GLOBVARS
#include "im.h"

double bessi0(double x)
    {
    double ax,ans;
    double y;

    if ((ax=fabs(x)) < 3.75) {
        y=x/3.75;
        y*=y;
        ans=1.0+y*(3.5156229+y*(3.0899424+y*(1.2067492
            +y*(0.2659732+y*(0.360768e-1+y*0.45813e-2)))));
    } else {
        y=3.75/ax;
        ans=(exp(ax)/sqrt(ax))*(0.39894228+y*(0.1328592e-1
            +y*(0.225319e-2+y*(-0.157565e-2+y*(0.916281e-2
            +y*(-0.2057706e-1+y*(0.2635537e-1+y*(-0.1647633e-1
            +y*0.392377e-2))))))));
    }
    return ans;
    }


double bessi1(double x)
    {
    double ax,ans;
    double y;

    if ((ax=fabs(x)) < 3.75) {
        y=x/3.75;
        y*=y;
        ans=ax*(0.5+y*(0.87890594+y*(0.51498869+y*(0.15084934
            +y*(0.2658733e-1+y*(0.301532e-2+y*0.32411e-3))))));
    } else {
        y=3.75/ax;
        ans=0.2282967e-1+y*(-0.2895312e-1+y*(0.1787654e-1
            -y*0.420059e-2));
        ans=0.39894228+y*(-0.3988024e-1+y*(-0.362018e-2
            +y*(0.163801e-2+y*(-0.1031555e-1+y*ans))));
        ans *= (exp(ax)/sqrt(ax));
        }
    return x < 0.0 ? -ans : ans;
    }

#define ACC 40.0
#define BIGNO 1.0e10
#define BIGNI 1.0e-10

double bessi(int n, double x)
    {
    int j;
    double bi,bim,bip,tox,ans;

    myassert(x>=0);
    n = abs(n);
    if (x > 700)
        return (MYDBL_MAX); 
    if (n==0)
        return bessi0(x);
    if (n==1)
        return bessi1(x);
    if (x == 0.0)
        return 0.0;
    else {
        tox=2.0/fabs(x);
        bip=ans=0.0;
        bi=1.0;
        for (j=2*(n+(int) sqrt(ACC*n));j>0;j--) {
            bim=bip+j*tox*bi;
            bip=bi;
            bi=bim;
            if (fabs(bi) > BIGNO) {
                ans *= BIGNI;
                bi *= BIGNI;
                bip *= BIGNI;
            }
            if (j == n) ans=bip;
        }
        ans *= bessi0(x)/bi;
        return x < 0.0 && (n & 1) ? -ans : ans;
    }
    }
#undef ACC
#undef BIGNO
#undef BIGNI


/* read in the allele sizes for a data set under the STEPWISE model */
void readseqSW(int ci, int li)
    {
    int i, j;
    char tempname[9], *c;
	for (i=0; i<L[ci][li]->numgenes; i++)
  		{
		c = &textline[0];
		fgets(c,300,infile);
		sscanf(c,"%s ",&tempname[0]);
		c = nextwhite(c);
		for (j=0; j< L[ci][li]->numsmm; j++)
			{
			if (sscanf(c,"%d",&L[ci][li]->tree[i].A[j]) <= 0)
				err(ci,li,85);
			c = nextwhite(c);
			}
		}
	printf("Locus %i : Stepwise Mutation Model\n",li);
    L[ci][li]->numlines = 2*L[ci][li]->numgenes-1;
    infilelines += L[ci][li]->numgenes;
    } /* readseqSW */



int geometric(double p)
/* returns a geometrically distributed random variable, where  the variable is an integer >= 0 */
/* this distribution is given by prob(k) = p*(1-p)^(k-1)  where k = 1,2,...  which has a mode of 1 and an expectation of 1/p */
/* it is a bit different from prob(k) = p*(1-p)^k   where k  = 0,1, 2... , which has a mode of 0 and an expectation of (1-p)/p */
/* the variance of these two different versions is the same, i.e. (1-p)/p^2 */
/* checked this in various ways - seems ok */
    {
    /*double U; 
    int temp;
    U = uniform();
    temp = (int) ceil(log(1.0 - U) / log(1.0 - p));
    myassert(temp >= 1);
    return temp; */
	return (int) ceil(log(uniform()) / log(1.0 - p));
    }

/*  when  finishSWupdateA() is entered the tree is not complete, as the allele state of the new downedge is not known
    must pick an allele state for the new downedge:
    the new downedge has the same number as the old downedge, so it is just called downedge hereafter

    at the start the current allele value for downedge is oldA - this however comes from a different part 
       of the tree from the old downedge that was erased
   
    consider - the point at the base of edge is connected to 3 other nodes (2 up and 1 down) unless
    edge is the root in which case there are only 2 ups
    
    start w/ a old value of A at the top of downedge = oldA

    determine the mean (weighted by the length of the branch to the node) of the difference between the A values
    of the connecting nodes and oldA 
    Treat this mean value as the parameter of a geometric distribution.
    pick an rv that is in the necessary direction (+ or -) and add this to oldA  this becomes newA. 
    
    the allele value for downedge becomes newA. the new genealogy is now complete.
    
    now consider the reverse update from new to old A

    again, calculate the weighted mean difference (for the old genealogy) between adjacent allele states and newA. 
    pick a geometric rv 

    Consider the update as this - When the tree jumped from one genealogy to another, this caused oldA to be set to newA
        
    Aterm = log(Pr(oldstate in node | T* -> T)/Pr(new state in node | T -> T*)) is the ratio of two geometric probabilities. 
    This is passed to the calling function along with the new likelihood. */

double finishSWupdateA(int ci, int li, int ai, int edge, int downedge, int sisedge, int newsisedge, double u, double *Aterm)
    {
    int i, j, newA, oldA;
    int d,dA, e[3];
    double geotermnew,geotermold; 
    double upt, time[3];
	int wsumdiff;
    double oldlikeadj=0, likeadj=0;
	struct edge *tree = L[ci][li]->tree;
        
    oldA = tree[downedge].A[ai];
    if (newsisedge != sisedge)
        holdsisdlikeA[ai] = tree[newsisedge].dlikeA[ai]; 
    else 
        holdsisdlikeA[ai] = 0;
    oldlikeadj = copyedge[0].dlikeA[ai] + copyedge[1].dlikeA[ai] + copyedge[2].dlikeA[ai] + holdsisdlikeA[ai];
    e[0] = edge; 
    e[1] = newsisedge;
    e[2] = tree[e[0]].down;

    for (i=0;i<3;i++)
        {
        if (e[i] >= L[ci][li]->numgenes)
            {
            upt = tree[tree[e[i]].up[0]].time;
            myassert(upt== tree[tree[e[i]].up[1]].time);
            }
        else upt = 0;
        if (tree[e[i]].down != -1)
            {
            time[i] = tree[e[i]].time - upt;
            myassert(time[i] >=0.0);
            }
        }
    myassert(tree[e[0]].time==tree[e[1]].time);
    wsumdiff = 0;
    for (i=0, j=0;i<3;i++)
        {
        if (tree[e[i]].down != -1)
            {
            if (i < 2) 
                d = tree[e[i]].A[ai] - oldA;
            else 
                d = tree[tree[e[i]].down].A[ai] - oldA;
            wsumdiff += abs(d);
            j++;
            }
        }
    /* wsumdiff will be > 0 if oldA is too small */ 
	/*if (wsumdiff > 0)
		geotermnew = j/wsumdiff;
	else 
		geotermnew = 0.5;
    if (geotermnew <= 0 || geotermnew >= 1)
        geotermnew = 0.5; 
		*/
	geotermnew = j/((double) (wsumdiff + j));
	myassert(geotermnew > 0);
	if (geotermnew > 0.95)
        geotermnew = 0.95;

    dA = geometric(geotermnew)-1; 
    if (bitran() /*uniform() < 0.5 */)
        dA = -dA;
    if (dA >= 0)
        newA  = MIN(L[ci][li]->maxA[ai],oldA+dA);
    else
        newA  = MAX(L[ci][li]->minA[ai],oldA+dA);
    tree[downedge].A[ai] = newA;
    myassert(newA >= L[ci][li]->minA[ai]);
    dA = newA-oldA;/* difference between new value, and what it would be based simply on weighted mean */
    if (tree[sisedge].down != -1 && sisedge != newsisedge)
        {
        if (sisedge >= L[ci][li]->numgenes)
            {
            upt = tree[tree[sisedge].up[0]].time;
            }
        else upt = 0;

        /* set dlikeA for the old sisedge (which is now continuous with the old downedge */ 
        d = tree[sisedge].A[ai] - tree[tree[sisedge].down].A[ai];
        myassert(d<=L[ci][li]->maxA[ai]);
        tree[sisedge].dlikeA[ai] = -(tree[sisedge].time - upt)*u + log(bessi(d,(tree[sisedge].time - upt)*u));
        }
    else
        {
        tree[sisedge].dlikeA[ai] = 0; 
        }
    likeadj = tree[sisedge].dlikeA[ai];
    for (i=0, j=0;i<3;i++)
        {
        if (tree[e[i]].down != -1)
            {
            if (i < 2) 
                d = tree[e[i]].A[ai] - newA;
            else 
                d = tree[tree[e[i]].down].A[ai] - newA;
            tree[e[i]].dlikeA[ai] = -(time[i]*u) + log(bessi(d,time[i]*u));
            likeadj += tree[e[i]].dlikeA[ai];
            }
        }
    wsumdiff = 0;
    j = 0;
    for (i=0;i<2;i++)
        {
        d = copyedge[i].A[ai] - newA;
        wsumdiff += abs(d);
        j++;
        }
    if (copyedge[2].down != -1)
        {
        d = holddownA[ai] - newA;
        wsumdiff += abs(d);
        j++;
        }

		/*
	if (wsumdiff > 0)
		geotermold = j /wsumdiff;
	else
		geotermold = 0.5;
    if (geotermold <= 0 || geotermold >= 1)
        geotermold = 0.5;
	*/
	geotermold = j /((double) (wsumdiff + j));
    if (geotermold > 0.95)
        geotermold = 0.95;

    if (progopts[RETURNPRIOR]) 
        {
        *Aterm = 0;
        return 0;
        } 
    else 
        { 
        *Aterm = (abs(dA) * log(1-geotermold) + log(geotermold))- (abs(dA) * log(1-geotermnew) + log(geotermnew)); 
        return (likeadj - oldlikeadj);
        } 
    } /* finishSWupdate*/

    

/* likelihoodSW() calculates and  sums the dlikeA values on each branch */
double likelihoodSW(int ci, int li, int ai, double u)
    {
    int i, up, d; 
    double t, like;
	struct edge *tree = L[ci][li]->tree;
    like = 0;
    for (i=0;i<2*L[ci][li]->numgenes-1;i++)
        {
        if (tree[i].down != -1)
            {
            d = tree[i].A[ai] - tree[tree[i].down].A[ai];
            if (tree[i].up[0] == -1)
                t = tree[i].time;
            else
                {
                up = tree[i].up[0];
                t = tree[i].time -  tree[up].time;
                }
            tree[i].dlikeA[ai] = -(t*u) + log(bessi(d,t*u));
            like += tree[i].dlikeA[ai];
            }
        else
            tree[i].dlikeA[ai] = 0.0;
        }
    if (progopts[RETURNPRIOR])
        return 1;
    else 
        return like;
    } /* likelihoodSW */

/* use this for debugging, to make sure likelihoodSW has set the dlikeA values properly */
void checklikelihoodSW(int ci, int li, int ai, double u)
    {
    int i, up, d; 
    double t, dlikeA;
	struct edge *tree = L[ci][li]->tree;

    for (i=0;i<2*L[ci][li]->numgenes-1;i++)
        {
        if (tree[i].down != -1)
            {
            d = tree[i].A[ai] - tree[tree[i].down].A[ai];
            if (tree[i].up[0] == -1)
                t = tree[i].time;
            else
                {
                up = tree[i].up[0];
                t = tree[i].time -  tree[up].time;
                }
            dlikeA = -(t*u) + log(bessi(d,t*u));
            if (tree[i].dlikeA[ai] != dlikeA)
                err(ci,li,91);
            }
        }
    } /* checklikelihoodSW */


double updateA(int ci, int li, int ai, double u, int *count, double uprop)
/* implements a geometric distribution based on the weighted mean difference in allele sizes surrounding the value in the 
node to be updated. branch lengths are used for the weighting */
/* would it be good to randomize the order in which nodes are updated ?  */
    {
    int i, upA[2], downA, newA, oldA;
    int d;
    int up[2],upup[2],down;
    double oldlike, like, dlikeup[2],dlikedown;
    double tup[2], tdown, weightsum, weight;
    double wsumdiff,geotermnew,geotermold, Aterm; 
	struct edge *tree = L[ci][li]->tree;
	int ng = L[ci][li]->numgenes;

    *count = 0;
    if (progopts[RETURNPRIOR]) 
        {
        *count = ng-1;
        return 1;
        }
    for (i=ng;i<2*ng-1;i++)
        {
        /* don't bother with all nodes  just do uprop of them */
        if (uniform() < uprop)
            {
            up[0] = tree[i].up[0];
            up[1] = tree[i].up[1];
            upup[0] = tree[up[0]].up[0];
            upup[1] = tree[up[1]].up[0];
            down = tree[i].down;
            if (upup[0] == -1)
                tup[0] = tree[up[0]].time;
            else 
                tup[0] = tree[up[0]].time - tree[upup[0]].time;
            if (upup[1] == -1)
                tup[1] = tree[up[1]].time;
            else 
                tup[1] = tree[up[1]].time - tree[upup[1]].time;
            oldA = tree[i].A[ai];
            upA[0] = tree[tree[i].up[0]].A[ai];
            upA[1] = tree[tree[i].up[1]].A[ai];
            oldlike = tree[tree[i].up[0]].dlikeA[ai] + tree[tree[i].up[1]].dlikeA[ai];
            wsumdiff = abs(oldA-upA[0])/tup[0]  + abs(oldA-upA[1])/tup[1] ; 
            weightsum = 1/tup[0] + 1/tup[1];
            if (down != -1)
                {
                tdown = tree[i].time - tree[up[0]].time;
                downA =  tree[tree[i].down].A[ai];
                wsumdiff += abs(oldA-downA)/tdown;
                weightsum += 1/tdown;
                oldlike += tree[i].dlikeA[ai];
                }
            else 
                {
                downA = -1;
                }
            /*
            if (wsumdiff > 0)
                geotermnew = weightsum/wsumdiff;
			else 
				geotermnew = 0.5;
            if (geotermnew < 0 || geotermnew >= 1 || wsumdiff <= 0)
                geotermnew = 0.5;
			*/
			geotermnew = weightsum/(wsumdiff + weightsum);
			myassert(geotermnew > 0);
            if (geotermnew > 0.95)
                geotermnew = 0.95;

            d = geometric(geotermnew)-1;
            myassert(d >= 0);
            if (bitran() /*uniform() < 0.5 */)
                newA  = MAX(L[ci][li]->minA[ai],oldA-d);
            else
                newA  = MIN(L[ci][li]->maxA[ai],oldA+d);
            if (newA != oldA)
                {
                wsumdiff = abs(newA-upA[0])/tup[0]  + abs(newA-upA[1])/tup[1] ; 
                if (down != -1)
                    {
                    wsumdiff += abs(newA-downA)/tdown;
                    }
				/*
                if (wsumdiff > 0)
                    geotermold = weightsum/wsumdiff;
				else
					geotermold = 0.5;
                if (geotermold < 0 || geotermold >= 1 || wsumdiff <= 0)
                    geotermold = 0.5;
				*/
				geotermold = weightsum/(wsumdiff + weightsum);
				myassert(geotermold > 0);
                if (geotermold > 0.95)
                    geotermold = 0.95;
				

                d = newA - upA[0];
                like = dlikeup[0] = -(tup[0]*u) + log(bessi(d,tup[0]*u));
                d =  newA - upA[1];
                like += dlikeup[1] = -(tup[1]*u) + log(bessi(d,tup[1]*u));
                if (down != -1)
                    {
                    d = newA - downA;
                    like += dlikedown = -(tdown*u) + log(bessi(d,tdown*u));
                    }
                Aterm = abs(newA-oldA) * log((1-geotermold)/(1- geotermnew)) + log(geotermold/geotermnew); 
                weight = exp(beta[ci]*(like - oldlike)+Aterm);
                if (weight >= 1.0 || weight > uniform())
                    {
                    tree[i].A[ai] = newA;
                    if (down != -1) 
                        tree[i].dlikeA[ai] = dlikedown;
                    tree[up[0]].dlikeA[ai] = dlikeup[0];
                    tree[up[1]].dlikeA[ai] = dlikeup[1];
                    //*count = *count + 1;
					(*count)++;
                    }
                }
            }
        }
    like = 0;
    for (i=0;i<2*ng-1;i++)
        {
        if (tree[i].down != -1)
            {
            like += tree[i].dlikeA[ai];
            }
        }
    return like;
    } /*updateA */


