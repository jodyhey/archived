/* IM  by Jody Hey and Rasmus Nielsen  2004-2009 */
/*last updates 12_17_09 */


/* util.c   probabilty and update calculations, misc stuff */

#undef GLOBVARS
#include "im.h" 



#ifdef USE_MYASSERT
void myassert(int isit)
	{
	if (!isit)
		{
        if (outfile != NULL) 
            f_close(outfile);
		exit(-9);
		}
	}
#endif

void err(int ci, int li, int i)
	{
	printf("Error # %i in step #d",i, step);
    if (ci>=0)
       printf(" chain  %d ",ci);
    if (li >= 0)
        printf(" locus %d ",li);
    printf(" step %ld  seed %ld\n",step,seed_for_ran1);
	exit(-1);                                                                
	}
/*
miscellaneous errors
1  cannot open data file
3  cannot open surface file
6  cannot create treeprint file
7 cannot create output file
8  input and output file names are identical
9  cannot write checkpoint file
10 cannot open checkpoint file
11 equilibrium migration model, but migration set to 0
13 one migration prior set to zero  (if one is set to 0, must have both)
14  -p1 option not permited when each locus has its own migration rate parameters
18  too few chains for heating model 
19 not enough information on command line 
21 problem w/ number of loci indicated in data file
22  either Qmax.q1 or Qmax.q2 set to 0, but sample size for that population is not zero

30 - to much migration called for on a single branch of a tree
31  - roottime > TIMEMAX after makecoal
32  - roottime > TIMEMAX  in changet
34  - too much migration in startnummig()
35  - #'s of gene copies and migration events out of synch when sorting tree events in geteventinfo 

41 error reading data
42 error in data
43 variable name mistmatch when reading checkpoint file
44 variable type mismatch when reading checkpoint file
45 checkpoint file versions do not match

51 model not recognized in changeq
55  NR vector allocation error
56  NR NSTACK too small in indexx
76 - product of uscalers != 1;
77 - could not solve for uscaler priors - ranges not compatible
79 - problem with mutation rate ranges

80 - formatting of input file causes wrong lines to be read as data
81  data not compatible with infinite sites model
82  data not compatible with infinite sites model
83  data not compatible with infinite sites model
84 - sample sizes do not have add up for one locus
85  non-numerical allele 
91  likelihoods do not add up for stepwise model
93  problem generating hpd intervals

*/



__forceinline double square(double x) {
  return x*x;
}

void SetSeed(int seed)
    {
    z_rndu = 170*(seed%178) + 137;
    }

double uniform()  // for some reason mvc++ 6.0 will not inline this
	{
	/*
		U(0,1): AS 183: Appl. Stat. 31:188-190
	   Wichmann BA & Hill ID.  1982.  An efficient and portable
	   pseudo-random number generator.  Appl. Stat. 31:188-190

	   x, y, z are any numbers in the range 1-30000.  Integer operation up
	   to 30323 required.

	   Suggested to me by Z. Yang who also provided me with
	   the source code used here.
	*/
//	   static int x_rndu=11, y_rndu=23;
	   double r;

	   x_rndu = 171*(x_rndu%177) -  2*(x_rndu/177);
	   y_rndu = 172*(y_rndu%176) - 35*(y_rndu/176);
	   z_rndu = 170*(z_rndu%178) - 63*(z_rndu/178);
	   if (x_rndu<0) x_rndu+=30269;
	   if (y_rndu<0) y_rndu+=30307;
	   if (z_rndu<0) z_rndu+=30323;
	   r = x_rndu/30269.0 + y_rndu/30307.0 + z_rndu/30323.0;
	   return (r-(int)r);
	}

/* for binary random numbers  -	quick - based on Press et al irbit2() */
#define IB1 1
//#define IB2 2
//#define IB5 16
#define IB18 131072
//#define MASK (IB1+IB2+IB5)
#define MASK 19
__forceinline int bitran(void)    
	{
	if (*iseed & IB18) 
		{
		*iseed=((*iseed ^ MASK) << 1) | IB1;
		return 1;
		} 
	else 
		{
		*iseed <<= 1;
		return 0;
		} 
	}
#undef MASK
#undef IB18
//#undef IB5
//#undef IB2
#undef IB1 


double expo(double c)
    {
    return - log(uniform())/c;
    }

/* Delete the substring of length "len" at index "pos" from "s". Delete less if out-of-range. */
void strdelete(char *s,int pos,int len)
	{
    int slen;
    if (--pos < 0) return;
    slen = strlen(s) - pos;
    if (slen <= 0) return;
    s += pos;
    if (slen <= len)
		{
        *s = 0;
        return;
		}
    while ((*s = s[len])) s++;
	}

char *nextnonspace(char *textline)
/* finds the next non-space character after the next space */
	{
	char *cc;
	if (textline == NULL)
		return NULL;
	cc = textline;
	while (*cc != ' ' && *cc != '\0')
		cc++;
	while (*cc == ' ')
		cc++;
	if (*cc == '\0')
		return NULL;
	else
		return cc;
	}

/* find next whitespace, after next non-whitespace */
char *nextwhite(char *c)
   {
   int nonw;
   nonw = !isspace(*c);
   while (*c != '\0')
      {
      while ((nonw==1 && !isspace(*c))  || (nonw==0 && isspace(*c)))
         {
         c++;
         if (nonw==0 && !isspace(*c))
            nonw = 1;
         }
      return c;
      }
   return  c;
   } /* nextwhite */


void ieevent(struct eevent *a)
	{
	a->n = 0;
	a->s = 0;
	a->s2 = 0;
	}

__forceinline void checkmig(int i, double **mig, int *nmig)
	{
	if (i+2 > *nmig)
		{
		*nmig += MIGINC;
		if (*nmig > ABSMAXMIG)
			err(-1,-1,30);
		*mig = realloc(*mig, *nmig * sizeof(double));
		}
	}

struct treevals  *savetree[MAXLOCI];

/* for sorting the edges used in treeprint() */
void shelltreevals(struct treevals *lptr, int length){
  double aln = 1.442695022, tiny = 1.0e-5;
  struct treevals t;
  int nn,m,lognb2,i,j,k,l;
  lognb2 = (int) floor(log(length)*aln + tiny);
  m = length;
  for (nn=1; nn<= lognb2; nn++){
      m = m /2;
      k = length - m;
      for (j = 0; j <= k-1; j++){
          i = j;
          reloop:
          l = i+m;
          if ((lptr+l)->dtime < (lptr+i)->dtime){
             t = *(lptr+i);
             *(lptr+i) = *(lptr+l);
             *(lptr+l) = t;
             i = i - m;
             if (i>= 0) goto reloop;
             }
          }
      }
} /* shellfithet */

/* flag values output by treeprint, if something does not seem right about an edge 

1 - final pop does not match what it should be, accounting for migration
2 - down pop does not match the up of the down 
3 - up pop does not match the down of up[0]
4 - up pop does not match the down of up[1]
*/

/* only gets used when debugging  - to see what a genealogy looks like for a particular parameter set */

void treeprint(int ci, int li)
    {
    int i,j, site, node, up1, up2;
    double upt, templike, nextsplittime;
	char sc0[3] = "t>";
	int p0 = 0;
    struct treevals *tvptr;
    tvptr = malloc((2*L[ci][li]->numgenes-1)*(sizeof(struct treevals)));
    for (i=0; i<2*L[ci][li]->numgenes-1; i++)
        tvptr[i].mut = 0;
    for (site=0; site < L[ci][li]->numsites; site++)
		{
        for (j=0; j<L[ci][li]->numgenes; j++)
		    L[ci][li]->tree[j].mut = L[ci][li]->seq[j][site];
	    for (j=L[ci][li]->numgenes; j<L[ci][li]->numlines; j++)
		    L[ci][li]->tree[j].mut = -1;
        for (j=0; j<L[ci][li]->numgenes; j++)
			labeltree(ci,li, j);
        for (node=L[ci][li]->numgenes; node<L[ci][li]->numlines; node++)
            {
			up1 = L[ci][li]->tree[node].up[0];
			up2 = L[ci][li]->tree[node].up[1];
			if ((L[ci][li]->tree[up1].mut == 0 && L[ci][li]->tree[up2].mut == 1) || (L[ci][li]->tree[up1].mut== 1 && L[ci][li]->tree[up2].mut == 0))
				{
				if (L[ci][li]->tree[node].down == -1) /* root - not clear where mutation is , put it on left */
					{
                    tvptr[up1].mut++;
					}
				else
					{
					if (L[ci][li]->tree[L[ci][li]->tree[node].down].mut == L[ci][li]->tree[up1].mut)
						{						
                        tvptr[up2].mut++;
						}
					else
						{
                        tvptr[up1].mut++;
						}
					}
				}
			}
		}
    for (i=0; i<2*L[ci][li]->numgenes-1; i++)
        {
        tvptr[i].nodenum = i;
        j=0;
        while (L[ci][li]->tree[i].mig[j] > -1) j++;
		tvptr[i].flag = 0;
        tvptr[i].up1 = L[ci][li]->tree[i].up[0];
        tvptr[i].up2 = L[ci][li]->tree[i].up[1];
        tvptr[i].down = L[ci][li]->tree[i].down;
		if (L[ci][li]->tree[i].down != -1)
			if (i != L[ci][li]->tree[L[ci][li]->tree[i].down].up[0] && i != L[ci][li]->tree[L[ci][li]->tree[i].down].up[1])
				tvptr[i].flag = 2;
		if (L[ci][li]->tree[i].up[0] != -1)
			if (i != L[ci][li]->tree[ L[ci][li]->tree[i].up[0]].down)
				tvptr[i].flag = 3;
		if (L[ci][li]->tree[i].up[1] != -1)
			if (i != L[ci][li]->tree[L[ci][li]->tree[i].up[1]].down)
				tvptr[i].flag = 4;
        tvptr[i].dtime = L[ci][li]->tree[i].time;
        if (i >= L[ci][li]->numgenes)
            upt = L[ci][li]->tree[L[ci][li]->tree[i].up[0]].time;
        else upt = 0;
		tvptr[i].utime = upt;
        tvptr[i].timei = L[ci][li]->tree[i].time - upt;
        tvptr[i].migcount = j;
        tvptr[i].pop = L[ci][li]->tree[i].pop;
		if (tvptr[i].migcount == 0 )
			tvptr[i].finpop = tvptr[i].pop;
		else
			{
			if (ODD(tvptr[i].migcount)) 
				tvptr[i].finpop = 1 - tvptr[i].pop;
			else
				tvptr[i].finpop = tvptr[i].pop;
			}
		if (tvptr[i].dtime < Q[ci]->t && tvptr[i].finpop != L[ci][li]->tree[L[ci][li]->tree[i].down].pop)
			tvptr[i].flag = 1;
        if (L[ci][li]->model == STEPWISE || L[ci][li]->model == JOINT_IS_SW)
            {
			for (j = 0; j< L[0][li]->numsmm; j++)
				{
				tvptr[i].A[j] = L[ci][li]->tree[i].A[j];
				tvptr[i].ldA[j] = L[ci][li]->tree[i].dlikeA[j];
				}
            }
        }
    shelltreevals(tvptr,L[ci][li]->numgenes);
    shelltreevals(tvptr + L[ci][li]->numgenes,L[ci][li]->numgenes-1);

    if ((treeprintfile = fopen("treeprint.out","a")) == NULL)
        {
		printf("Error opening text file for writing\n"); 
        err(ci,li,6);
	    }

    fprintf(treeprintfile,"\nLocus: %d   Chain:   %d  Step: %li\n",li,ci,step);
	fprintf(treeprintfile,"popsize parameter estimates :");
    for (j=0;j< numparams;j++)
        if (paraminfo[j].paramtype == Q1 || paraminfo[j].paramtype == Q2 || paraminfo[j].paramtype == QA) fprintf(treeprintfile," %8.4f",*(&Q[ci]->q1 + paraminfo[j].listpos));
	fprintf(treeprintfile,"\n");
	fprintf(treeprintfile,"mutation parameter estimates :");
    for (j=0;j< numparams;j++)
        if (paraminfo[j].paramtype == M) fprintf(treeprintfile," %8.4f",*(&Q[ci]->q1 + paraminfo[j].listpos));
    fprintf(treeprintfile,"\n");
	fprintf(treeprintfile,"splittime parameter estimates :");
    for (j=0;j< numparams;j++)
        if (paraminfo[j].paramtype == T) fprintf(treeprintfile," %8.4f",*(&Q[ci]->q1 + paraminfo[j].listpos));
    fprintf(treeprintfile,"\n");
	fprintf(treeprintfile,"mutation parameter estimates :");
    for (j=0;j< numparams;j++)
        if (paraminfo[j].paramtype == U) fprintf(treeprintfile," %8.4f",*(&Q[ci]->q1 + paraminfo[j].listpos));
    fprintf(treeprintfile,"\n");

	if (L[ci][li]->model == STEPWISE || L[ci][li]->model == JOINT_IS_SW)
		{
		if (L[ci][li]->model == JOINT_IS_SW)
			templike = L[ci][li]->oldlike;
		else
			templike = 0;
		for (j = 0;j < L[ci][li]->numsmm; j++)
			templike += L[ci][li]->oldlike_a[j];
		}
	else 
		templike = L[ci][li]->oldlike;

    fprintf(treeprintfile,"  current likelihood: %.5f  current treeprob: %.5f\n",templike,L[ci][li]->oldprob);
    fprintf(treeprintfile,"Node#\tup1\tup2\tdown\tdtime\tutime\ttimei\t#mig\tpop\tfinpop\tmut\tflag");
    if (L[ci][li]->model == STEPWISE || L[ci][li]->model == JOINT_IS_SW)
        fprintf(treeprintfile,"\tA\tld\n");
	else
		fprintf(treeprintfile,"\n");
	fprintf(treeprintfile,"-----------------------------------------------------------------------------------------\n");
	nextsplittime = Q[ci]->t;
	fprintf(treeprintfile,"external branches \n");
    for (i=0; i<2*L[ci][li]->numgenes-1; i++)
        {
		if (i == L[ci][li]->numgenes)
			{
			fprintf(treeprintfile,"internal branches \n");
			p0 = 0;
			}
		if (tvptr[i].dtime > Q[ci]->t && p0 == 0)
			{
			fprintf(treeprintfile,"%s========================================================================================\n",sc0);
			p0 = 1;
			}
        fprintf(treeprintfile,"%3d\t%3d\t%3d\t%3d\t%7.4f\t%7.4f\t%7.4f\t%3d\t%3d\t%3d\t%d\t%d",
            tvptr[i].nodenum,
            tvptr[i].up1,
            tvptr[i].up2,
            tvptr[i].down,
            tvptr[i].dtime,
			tvptr[i].utime,
            tvptr[i].timei,
            tvptr[i].migcount,
            tvptr[i].pop,
			tvptr[i].finpop,
            tvptr[i].mut,
			tvptr[i].flag);
        if (L[ci][li]->model == STEPWISE || L[ci][li]->model == JOINT_IS_SW)
			{
			for (j = 0; j< L[0][li]->numsmm; j++)
				{
				fprintf(treeprintfile,"\t%3d\t%5.2f",tvptr[i].A[j],tvptr[i].ldA[j]);
				}
			}
		fprintf(treeprintfile,"\n");
        }
    f_close(treeprintfile);
    treeprintfile = NULL;
    free(tvptr);
    } /* treeprint */

/* not sure how to use this 
int _matherr( struct _exception *except )
{
    if( except->type == _DOMAIN )
    {
        if( strcmp( except->name, "log" ) == 0 )
        {
            except->retval = log( -(except->arg1) );
            printf( "Special: using absolute value: %s: _DOMAIN "
                     "error\n", except->name );
            return 1;
        }
        else if( strcmp( except->name, "log10" ) == 0 )
        {
            except->retval = log10( -(except->arg1) );
            printf( "Special: using absolute value: %s: _DOMAIN "
                     "error\n", except->name );
            return 1;
        }
    }
    else
    {
        printf( "Normal: " );
        return 0;   
    }
} */





