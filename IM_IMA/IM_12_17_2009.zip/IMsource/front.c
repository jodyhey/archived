/* IM  by Jody Hey and Rasmus Nielsen  2004-2009 */
/*last updates 12_17_09 */


/* front.c  functions for starting run, main update and run loops, histogram recording */

#define GLOBVARS
#include "im.h"

/* 7/24/09 fixed a bad bug - kappa was not being updated for single locus HKY data sets */

/* 
floating point and optimization notes. 
with full optimization on in MVC++ 6.0  the release code does not give identical results to the debug code. 
spent sometime trying to track this down,  but no success.  Not due to uniform(), but perhaps to the inequalities that are used in lots of places
It could slow things down to trap these differences. 

If release exec is compiled with the following optimizations, then release and debug do seem to give the same numbers (checked up to 500000 steps on IMstandtest3a.u)
- favor faster code /Ot
- improve float consistency  /Op

This takes about twice as long to run as without /Op  and with the Maximize Speed flag /O2  

But when these are used,  the results are not identical to the debugging case


updates 8/24/06

new sorting method for events in tree - use indexx which does quicksort on an index.  requires new array, eindex, kept with each tree - complicates a bit, but speeds things up some

some things added for speed - suggestiongs by Jim Long.   He revised makefrac().  labeltree() is now not recursive. 

use __forecedinline for some functions frequently called 

add  bitran()  for random binary values 

restructured Qupdate() a bit so that there is only one loop of ci over numchains 


last updates 7/28/06 
Some changes since previous version

 now handle migration arrays with dynamic memory 

-note the -j and -p option numbers have shifted and there are some new ones

now collects posteriors for differences among parameters \n");
based on an idea from Robbie Young,  this generates posterior distributiosn for a number of test quantities
e.g. is N1 > N2  etc

-j7  include prior ranges on mutation rates of scalars  (ranges must be included in input file);

-e  and -x   using checkpoint files 
to save a complete dump of all values and data structures  use the '-e' flag
the 'e' must be followed by a number that represents the number of hours in between  saving the checkpoint file.
The file is also saved immediately after the burnin,  and at the end of the run
e.g. -e1  will save files after the burn,  and then every hour until the run is done, and then at the end of the run
-e0 saves after the burn and at the end of the run (assuming it finishes normally), and not inbetween.
each successive checkpoint file save overwrites the previous file  
the name of the checkpoint file is the fullname of the regular output file,  with '.dck' added to the end of it 

to restart from a saved checkpoint file, start a run with only the -x flag
the 'x' is followed by the full name of the checkpoint file. 
This will start up a new run, where the previous one stopped, and will use all the same parameters as the old run.
Immediately after starting, an output file is produced that shows where everthing was at when that file was saved. 
that output file will have the same name as (and will over write) the file that was used in the run that generated the checkpoint file,

To restart a run, and treat it as if the burn had just been completed, add -y to the command line along with the -x flag. This 
should reset everything to the point of not having any record of the previous run,  however the state of the chain will be where it was at the 
end of the previous run.  This option could be used as a way to burn along to the point where you know it is mixing well. 

-bh  invokes a ramped heating scheme during the burnin 
if there is a number following the 'h' then this becomes burnheatinc,  otherwise burnheatinc is set to the default value of DEFBURNHEATINC 
There are 10 heating values in the sequence burnheatvals[10] = {0.1, 0.44, 0.657, 0.7942, 0.87995, 0.932772, 0.964705, 0.983529, 0.994235, 1};
all chains start at burnheatvals[0], and then every burnheatinc steps they go to the next value in burnheatvals[]
if burnheatvals[i] is greater than the set heating point for a given chain, then that set point is used. 
It takes 9 * burnheatinc  to get to the end of the ramped heating
After that an additional 5*burnheatinc is done until the end of the burn to make sure that the update rate for chain 0 has settled to what it should be 

This scheme does help the chain get started, particularly for difficult STR data sets.  However it does not allow the user to see just what the swapping
rates are likely to be at the final heating values, until after the burn is done.   Thus, if you don't know what you want the final heating values to be
it is easer to start with a regular burnin, and watch the swapping rains for awhile to get a feel for what they should be.  Then you can go back and use 
the -bh flag. 
*/


#define DEFBURNHEATINC  7000
static double burnheatvals[10] = {0.1, 0.44, 0.657, 0.7942, 0.87995, 0.932772, 0.964705, 0.983529, 0.994235, 1};

void start(int argc, char *argv[])
	{
	int i,j, li, ci, ui;
	char  ch, ch1;
	char  pstr[256];
    char  command_line[201];
    int Ap,Bp,Dp,Ep,Fp,G1p,G2p,Hp,Ip,Jp,Lp,Kp,m1p,m2p,Np,Op,Pp,Q1p,Q2p,QAp,Sp,SLp,SUp,Tp,Up,Vp,Wp,Xp,Yp, Zp;
    double tempf;

    time(&starttime);
	Ap = 0; /* # of steps between recording */ 
    Bp = 0; /* duration of burnin */
    Hp = 1; /* comment */
	Dp = 0; /* number of genealogy updates per step */
	Ep = 0;  /* use a checkpoint file */
    Fp = 0; /* heat mode term */
    G1p = 0; /* heat term */
    G2p = 0; /* heat term */
    Ip = 0; /*input file */
    Jp = 0; /* used for programmer options */
    Kp = 0; /* number of swap attempts per step */
    Lp = 0; /* duration of chain */
	m1p = 0; /* migration rate 1 max */
	m2p = 0; /* migration rate 2 max */
    Np = 0; /* # of chains */
	Op = 0; /* output file */
	Pp = 0; /* output options */
    Q1p = 0; /* Theta1 max scalar*/
    Q2p = 0; /* Theta1 max scalar*/
    QAp = 0; /* Theta1 max scalar*/
	Sp = 0; /* random number seed */
    SLp = 0; /* lower limit on s */
    SUp = 0; /* upper limit on s */
	Tp = 0; /* Time maximum */
	Up = 0;  /* generatino time */
    Wp = 0; /* Time minimum */
    Vp = 0;  /* time window scalar  - set window (Tmax-Tmin)/(10 + nloci * scalar) */
	Xp = 0;  /* file name for starting from previous check file */
	Yp = 0; /* is using restart, w/ Xp,  Yp indicates that the restart should begin as if the burn had just completed */
    Zp = 0; /* screen printout frequency */
    printf("executing program ...\n");
    strcpy(command_line,"");
    if ((argc == 2 && toupper(argv[1][1]) ==  'H') ||  argc == 1)
        {
		printf("IM Program - copyright 2004-2009 by Jody Hey and Rasmus Nielsen\n");
		printf("This program is run through a command line interface\n");  
		printf("The program file and the data file should be in the same directory \n");
		printf("To execute the program type the program name, followed by the necessary command line flags and instructions \n");
		printf(" -- this program cannot be sensibly used without an understanding of the method and the options (see documentation)\n");
		printf("Command line usage: - upper or lower case letters can be used\n");
		printf("-a  number of steps between record keeping (default is 10)\n");
        printf("-b  duration of burn \n");
        printf("    - if integer, the number of burnin steps \n");
        printf("    - if floating point, the time in hours of burnin period\n");
		printf("-bh ramped heating scheme for burn, -bh default is ~100,000 steps\n");
		printf("-d  number of genealogy updates per step (default is 1) \n");
		printf("-e  time (hours) between save of checkpoint file (e0 for only after burn)\n");
        printf("-f  heat mode: l linear (default); t twostep; a adaptive twostep; g geometric\n");
        printf("-g1 first heating parameter,effect depends on heating mode (default 0.05) \n");
        printf("-g2 second heating parameter,effect depends on heating mode  \n");
		printf("-h  comment for output file (no spaces) \n");
        printf("-i  input file name (no spaces) \n");
        printf("-j  run options: \n");
        printf("    0  likelihood() functions return 1 - posterior should equal prior \n");
		printf("    1  for 4Nu priors (q1,q2,qa) use command-line values as actual piors\n");
		printf("         default: priors = product of command-line values and data estimates\n");
		printf("    2  treat inheritance scalars as parameters.(default= input file value or 1)\n");
		printf("    3  include ranges on mutation rates as priors on mutation rate scalars\n");
        printf("    4  set t to a very large value, mimics two population island model\n");
        printf("    5  set t = 0 to mimic one large panmictic population of size thetaA\n");
        printf("    6  set theta1 = theta2 = thetaA \n");
        printf("    7  set m1 = m2\n");
        printf("    8  each locus has a pair of migration rates, m1 and m2\n");
#ifdef INCLUDESIZECHANGE
        printf("    9  turn on population size change (include splitting parameter)\n");
#endif 
     //   printf("    ??  use very wide log scale for output of u scalars \n");
        printf("-k  with multiple chains (-n) the number of chain swap attempts per step \n");
        printf("-l  duration of run \n");
        printf("    - if integer, the number of steps in the chains \n");
        printf("    - if floating point, the time in hours between outputs. \n");
        printf("        run continues until file ""IMrun"" is no longer present\n");
        printf("        in the directory, or if present, does not begin with 'y'\n");
        printf("-m1 maximum migration rate from population 1 to population 2 \n");
        printf("-m2 maximum migration rate from population 2 to population 1 \n");
        printf("-n  number of chains  \n");
        printf("-o  output file name (no spaces)  default is 'outfile.txt' \n");
        printf("-p  output options (default is no options): \n");
        printf("    0 - print file of values of basic parameters (file can be enormous!)\n");
        printf("    1 - print TMRCA histogram for each locus \n");
        printf("    2 - print histogram of parameters on demographic scales \n");
        printf("    3 - print histograms of # migration events and migration times \n"); //12/16/09 jh changed from mean times to all times
		printf("    4 - print ASCII-based trends of parameters\n");
		printf("    5 - print ASCII-based posterior density curves \n");
		printf("    6 - print smoothed distributions of marginal log likelihoods \n");
        printf("-q1  scalar for theta1 maximum \n");
        printf("-q2  scalar for theta2 maximum (default =  scalar for theta1 maximum)\n");
        printf("-qA  scalar for thetaA maximum (default =  scalar for theta1 maximum)\n");
        printf("-s  random number seed (default is taken from current time)\n");
#ifdef INCLUDESIZECHANGE
        printf("-sl  lower limit of range for population split parameter s \n");
        printf("-su  upper limit of range for population split parameter s \n");
#endif
        printf("-t  maximum time of population splitting \n");
        printf("-u  generation time in years  (default is 1) \n");
        printf("-w  minimum time of population splitting \n"); 
        printf("-v  window width adjust for t updating - reduce window size w/ multiple loci \n");
		printf("-x '*.dck' file name for starting from a previous run \n");
		printf("-y  restart as if burn just ended, use with -x and '*.dck' file \n");
        printf("-z  number of steps between output to the monitor (default 10000)\n");
        exit(0);
        }
    else
        {
        for (i = 1; i < argc; i++) 
		    {
            strcpy(pstr, argv[i]);
           
		    if ((strlen(pstr)==2) || ( (strlen(pstr)==3) && (
                (toupper(pstr[1])=='G') ||
                (toupper(pstr[1])=='M') ||
                (toupper(pstr[1])=='Q') ||
                (toupper(pstr[1])=='S' && toupper(pstr[2])=='L') || 
                (toupper(pstr[1])=='S' && toupper(pstr[2])=='U') 
                ) ) )
                {
                strcat(command_line," ");
                strcat(command_line,pstr);
                ch = toupper(pstr[1]);
				if (ch != 'Y')  // the only symbol that can appear without additional characters 
					{
					if (strlen(pstr) > 2)
						ch1 = toupper(pstr[2]);
					else
						ch1 = ' ';
					i++;
					strcat(command_line," ");
					strcpy(pstr, argv[i]);
					strcat(command_line,pstr);
					}
                }
            else
                {
                strcat(command_line," ");
                strcat(command_line,pstr);
                ch = toupper(pstr[1]);
                ch1 = toupper(pstr[2]);
                if ((ch=='G') || (ch=='M') || (ch=='Q') || (ch=='S' && ch1=='L') || (ch=='S' && ch1=='U'))
                    strdelete(pstr,1,3);
                else
                    strdelete(pstr,1,2);
                }

		    switch (ch) 
				    {
			    case 'H':
			      sprintf(textline, "%s", pstr);
                  if (strlen(textline) > 0)
                      {
                      Hp = 1;
                      }
                  else Hp = 0;
			      break;
			    case 'I':
			      strcpy(infilename,pstr);
			      if ((infile = fopen(infilename,"r")) == NULL)
				      {
					    printf("Error opening text file for reading\n"); 
                        err(-1,-1,1);
				      }
			      Ip = 1;
			      break;
			    case 'O':
			      strcpy(outfilename,pstr);
			      Op = 1;
			      break;
                case 'S' :
                    if (!(ch1=='U' || ch1=='L'))
                        {
				        seed_for_ran1 = atoi(&pstr[0]);
				        if (!seed_for_ran1) seed_for_ran1 = 1;
				        Sp = 1;
                        }
                    else
                        {
                        switch (ch1)
                            {
                            case 'U' : Qmax.s = (double) atof(&pstr[0]); SUp = 1;break;
                            case 'L' : Qmin.s = (double) atof(&pstr[0]); SLp = 1;break;
                            }
                        };
				    break;
			    case 'B' :
					if (isdigit(pstr[0]))
						{
						tempf =  atof(&pstr[0]);
						/* check to see if the value is floating point, in which case treat it as being in fractions of an hour  and convert to seconds*/
						if (strchr(pstr,'.'))
							{
							burnduration = (int) (3600 * tempf);
							bdurationmode = TIMEINF;
							time(&lasttime);
							}
						else
							{
							burnduration = (int) tempf;
							bdurationmode = TIMESTEPS;
							}
						}
					else // an h after the b means a special heating model 
						{
						bdurationmode = HEATALT1;
						if (isdigit(pstr[1]))
							burnheatinc = atoi(&pstr[1]);
						else
							burnheatinc = DEFBURNHEATINC;
						burnduration = 14*burnheatinc;
						/* this ramped burn mode use these ramped values for heating
						static float burnheatvals[10] = {0.1, 0.44, 0.657, 0.7942, 0.87995, 0.932772, 0.964705, 0.983529, 0.994235, 1};
						all chains start at burnheatvals[0], and then every burnheatinc steps it goes to the next value in burnheatvals[]
						if burnheatvals[i] is greater than the set heating point for a given chain, then that set point is used. 
						This will take 9 * burnheatinc  to get to the end of the ramped heating
						After that an additional 5*burnheatinc is done until the end of the burn */
						}
					Bp = 1;
					break;
			    case 'L' :
                    tempf =  atof(&pstr[0]);
                    /* check to see if the value is floating point, in which case treat it as being in fractions of an hour  and convert to seconds*/
                    if ( strchr(pstr,'.'))
                        {
                        chainduration = (int) (3600 * tempf);
                        cdurationmode = TIMEINF;
                        }
                    else
                        {
                        chainduration = (int) tempf;
                        cdurationmode = TIMESTEPS;
                        }
				    Lp = 1;
				    break;
			    case 'E' :
					checkmode = 1;
                    tempf =  atof(&pstr[0]);
					if (tempf <= 0)
						checkduration = LONG_MAX;
					else
						checkduration = (int) (3600 * tempf);
				    Ep = 1;
				    break;
				case 'X' :
					checkinmode = 1;
  				    strcpy(dckfilename,pstr);
					if (strstr(dckfilename,".dck") == NULL)
						strcat(dckfilename,".dck");
					strcpy(olddckfilename,dckfilename);
					strcat(olddckfilename,".old");
					Xp = 1;
					break;
				case 'Y' :
				    Yp = 1;
				    break;
			    case 'T' :
				    Qmax.t =  atof(&pstr[0]);
				    Tp = 1;
				    break;
                case 'U' :
				    generationtime =  atof(&pstr[0]);
				    Up = 1;
				    break;
                case 'W' :
				    Qmin.t =  atof(&pstr[0]);
				    Wp = 1;
				    break; 
                case 'V' :
                    tempf =  atof(&pstr[0]);
                    Qwin.t = tempf;
                    Vp = 1;
                    break;
			    case 'M' :
				    if (ch1=='1')
					    j=1;
				    else 
					    j=2;
				    if (j==1)
					    {
					    Qmax.m1[0] = (double) atof(&pstr[0]);
					    m1p = 1;
					    }
				    else 
					    {
					    Qmax.m2[0] = (double) atof(&pstr[0]);
					    m2p = 1;
					    }	
				    break;
                case 'Q' :
                    switch (ch1)
                        {
                        case '1'   : Qmax.q1 = (double) atof(&pstr[0]); Q1p = 1; singlepopmode = (singlepopmode || Qmax.q1 <= 0); break;
                        case '2'   : Qmax.q2 = (double) atof(&pstr[0]); Q2p = 1; singlepopmode = (singlepopmode || Qmax.q2 <= 0);break;
                        case 'A'   : Qmax.qA = (double) atof(&pstr[0]); QAp = 1;break;
                        }
                    break; 
                case 'P' :
                    j=strlen(pstr)-1;
                    while (j>=0)
                        {
                        printoptions[atoi(&pstr[j])] = 1;
                        pstr[j] = '\0';
                        j--;
                        }
                    break;
                case 'J' :
                    j=strlen(pstr)-1;
                    while (j>=0)
                        {
                        progopts[atoi(&pstr[j])] = 1;
                        pstr[j] = '\0';
                        j--;
                        }
                    break;
				case 'A' :
				    recordint = atoi(&pstr[0]);
				    Ap = 1;
                    break;
				case 'D' :
				    gupdateint = atoi(&pstr[0]);
				    Dp = 1;
                    break;
                case 'N' :
				    numchains = atoi(&pstr[0]);
				    Np = 1;
                    break;
                case 'Z' :
				    printint = atoi(&pstr[0]);
				    Zp = 1;
                    break;
                case 'F' :
                    Fp = 1;
                    switch (toupper(pstr[0]))
                        {
                        case 'T'    : heatmode = HTWOSTEP;break;
                        case 'A'    : heatmode = HADAPT; break;
                        case 'G'    : heatmode = HGEOMETRIC; break;
                        default : heatmode  = HLINEAR;
                        }
                    break; 
                case 'G' :
                    if (ch1=='1')
					    j=1;
				    else 
					    j=0;
				    if (j==1)
					    {
					    hval1 = atof(&pstr[0]);
					    G1p = 1;
					    }
				    else 
					    {
					    hval2 = atof(&pstr[0]);
					    G2p = 1;
					    }	
				    break;
                case 'K' :
                    swaptries = atoi(&pstr[0]);
				    Kp = 1;
                    break;
                	}
		    }
        }

	if (Xp)
		{
		if (Yp)
			restartburn = 1;
		else
			restartburn = 0;
		return;
		}
	if (!Ip) 
		{
        strcpy(infilename,"infile.txt");
		if ((infile = fopen(infilename,"r")) == NULL)
			{
			printf("Error opening text file for reading\n"); 
            err(-1,-1,1);
			}
		}
	if (Ep)
		{
		strcpy(dckfilename,outfilename);
		strcat(dckfilename,".dck");
        strcpy(olddckfilename,dckfilename);
        strcat(olddckfilename,".old");
		if (checkduration > chainduration)
			checkduration = LONG_MAX;
		}
	if (!Op) 
		strcpy(outfilename,"outfile.txt");
	if (!Lp)
		{
        printf(" No information provided for run duration '-L'\n"); 
        err(-1,-1,19);
		}
    if (!Np)
        {
        numchains = DEFCHAINS; /* default value */
        }
    else
        {
        if ((heatmode==HGEOMETRIC  && numchains < 4) || (heatmode==HTWOSTEP  && numchains < 3) || (heatmode==HADAPT  && numchains < 3))
            {
            err(-1,-1,18);
            }
        if (!Fp)
            {
            heatmode = HLINEAR;
            if (!G1p)
                hval1 = 0.05; /* default value */
            }
        else 
            {
            if (heatmode > HLINEAR)
                {
                if (heatmode == HTWOSTEP )
                    {
                    if (!G1p) hval1 = 0.05;
                    if (!G2p) hval2 = 2;
                    }
                if (heatmode == HADAPT)
                    {
                    if (!G1p) hval1 = 0.05;
                    if (!G2p) hval2 = 1;
                    }
                if (heatmode == HGEOMETRIC)
                    {
                    if (!G1p) hval1 = 0.9;
                    if (!G2p) hval2 = 0.8;
                    }
                }
            else
                if (!G1p)
                    hval1 = 0.05; /* default value */
            }
        }
	if (!Ap)
		recordint = RECORDINTDEFAULT;
    if (!Up)
        generationtime = 1;
	if (!Dp)
		gupdateint = GUPDATEDEFAULT;
    if (!Bp)
		{
        printf(" No information provided for burn-in duration '-B'\n"); 
        err(-1,-1,19);
		}
	if (!m1p && progopts[ONEPOP] == 0)
		{
        printf(" No information provided for maximum value for m1 '-m1'\n"); 
        err(-1,-1,19);
		}
	if (!m2p && progopts[ONEPOP] == 0)
		{
        printf(" No information provided for maximum value for m2 '-m2'\n"); 
        err(-1,-1,19);
		}
	if (!Tp && progopts[EQUILIBRIUMMIGRATION]==0 && progopts[ONEPOP] == 0)
		{
        printf(" No information provided for maximum separation time '-t'\n"); 
        err(-1,-1,19);
		}
    if (!Wp)
        {
        Qmin.t = 0.0;
        } 
    if (!Kp)
        {
        swaptries = 1;
        } 
    else
        {
        if (numchains > 1 && swaptries > numchains*(numchains-1)/2)
            swaptries = numchains*(numchains-1)/2;
        } 
	if (!Q1p)
		{
        printf(" No information provided for maximum value of theta1 '-q1'\n"); 
        err(-1,-1,19);
		}
    if (strcmp(infilename,outfilename)==0)
        {
        printf("input and output file names are identical\n");
        err(-1,-1,8);
        }
    if (!Q2p) Qmax.q2 = Qmax.q1;
    if (!QAp) Qmax.qA = Qmax.q1;
    if (!Sp) seed_for_ran1 = time(NULL);
    if (!SUp) Qmax.s = 1;
    if (!SLp) Qmin.s = 0;
    if (!Vp)  Qwin.t = 0;
    if (!Zp) printint = PRINTINTDEFAULT;
	SetSeed(seed_for_ran1);
	iseed = malloc(sizeof(unsigned long));
	*iseed = ULONG_MAX / 2  + (unsigned long) seed_for_ran1; // just set it so that iseed points to a large number - probably not necessary
    fpstri=0;
    SP"IM  -  Jody Hey and Rasmus Nielsen\n\n");
	SP"revision date: 12/17/09 \n");
    SP"\nINPUT AND STARTING INFORMATION \n");
    SP"-------------------------------\n");
    SP"\nCommand line string : %s \n",command_line);
	SP"Comment at runtime : %s\n",textline);
	SP"Input filename : %s \n",infilename);
	SP"Output filename: %s \n",outfilename);
	SP"Random number seed : %li \n",seed_for_ran1);
    if (progopts[RETURNPRIOR])
        SP"**DEBUGGING MODE - no data ** \n");
    SP"IM Model:\n");

#ifdef INCLUDESIZECHANGE
    if (!progopts[POPSIZECHANGEMODE]) 
        {
#endif
        basics = 2 + BASICPARAMS-1;
        ptreeprob = treeprobc;
        SP"     - each population is constant in size  \n");
#ifdef INCLUDESIZECHANGE
        }
    else
        {
        basics = 2 + BASICPARAMS;
        ptreeprob = treeprob;
        pc = pcexp;
        pnc = pncexp;
        pm = pmexp;
        pnm = pnmexp;
        SP"     - 's', population size change parameter included \n");
        SP"     - Exponential Population Size Change Model \n"); 
        }
#endif
    if (progopts[LOCUSMIGRATION])
		{
        SP"      - Each Locus has a Pair of Migration Rate Parameters \n"); 
		if (printoptions[PRINTALLVALUES])
			err(-1,-1,14);
		}
    else
        SP"      - All Loci Share the Same Two Migration Rate Parameters \n"); 
    if (progopts[ONEPOP])
        {
        SP"     - Single population model, divergence time fixed at 0 \n");
        }
    if (progopts[COMMONTHETA])
        {
        SP"     - Common Theta Model, Theta1 = Theta2 = ThetaA \n");
        }
    if (progopts[COMMONMIGRATION])
        {
        SP"     - Common Migration Model, m1 = m2 \n");
        }
    
    if (progopts[UPDATEH])
        SP"     - Inheritance Scalars are treated as parameters to be estimated \n");
    else
        SP"     - Inheritance Scalars are treated as constants, as given in input file\n");
    SP"- Run Duration - \n");
    switch (bdurationmode)
        {
	    case TIMESTEPS:SP"     Burn period, # steps: %li \n",burnduration); break;
        case TIMEINF:SP"     Burn period, # seconds: %li \n",burnduration);break;
		case HEATALT1:SP"     Burn period, ramped heating mode, # steps: %li \n",burnduration); break;
           };
    switch (cdurationmode)
        {
         case TIMESTEPS: SP"     Record period, # steps: %li \n",chainduration); break;
         case TIMEINF: SP"      Record period, # seconds per interval: %ld \n",chainduration);break;
        };
    SP"- Metropolis Coupling -\n");
    if (numchains > 1) 
        {
        SP"     Metropolis Coupling implemented using %d chains \n",numchains);
        switch (heatmode)
            {
            case HLINEAR:  SP"     Linear Increment Model   term: %.3f\n", hval1);break;
            case HTWOSTEP: SP"     Twostep Increment Model   term1: %.3f  term2: %.3f\n", hval1, hval2);break;
            case HADAPT:   SP"     Twostep Adaptive Model  starting term1: %.3f  starting term2: %.3f\n", hval1, hval2);break;
            case HGEOMETRIC: SP"     Geometric Increment Model   term1: %.3f  term2: %.3f\n", hval1, hval2);break;
            }
        }
    else
        SP"     None \n");

    beta[0] = 1.0;
    for (ci = 1; ci< numchains;ci++)
        switch (heatmode)
            {
            case HLINEAR:  beta[ci] = 1.0/ (1.0 + hval1 * ci);
                break;
            case HTWOSTEP:
            case HADAPT:   beta[ci] = 1.0/ (1.0 + hval1  +  hval1 * (ci-1)* hval2); 
                break;
            case HGEOMETRIC:beta[ci] = 1 - (1 - hval2) * ci * pow(hval1,(numchains - 1 - ci))/(numchains-1);
                break;
            }
	if (bdurationmode == HEATALT1)
		for (ci = 0; ci< numchains;ci++)
			{
			holdbeta[ci] = beta[ci];
			beta[ci] = burnheatvals[0];
			}
		
    for (ci = 0; ci< numchains;ci++)
        Q[ci] = calloc(1,sizeof(struct parameters));
    for (ci = 0; ci< numchains-1;ci++)
        swaporder[ci] = ci;
    if (nloci==1) 
        progopts[UPDATEH]=0;
	for (ui=0;ui<MAXLOCI + MAXLINKEDSMM;ui++) 
		Qaccp0.u[ui]=0;
    for (li=0;li<MAXLOCI;li++) 
	    {
	    Qaccp0.h[li] = 0;
        Qaccp0.m1[li] = 0;
        Qaccp0.m2[li] = 0;
	    gaccp[li] = 0;
        topolaccp[li] = 0;
		gupdatetries[li] = 0;
	    }
    Qaccp0.q1 = Qaccp0.q2 = Qaccp0.qA = Qaccp0.t = 0;
    Qaccp = Qaccp0;
    Qupdatetries = Qaccp0;
    Qold = Qaccp0;
	for (ci = 0; ci< numchains;ci++)
        *Q[ci] = Qaccp0;
	 readdata();
    fillparaminfo();
    setinitialQ();
    SP"\n");
    SP"- Maximum Parameter Values -\n");
    if (progopts[POPSIZEPRIORSETMODE]==1)
        SP"   - upper bounds on q1,q2 and qA  set directly from command line values \n");
    SP"     Max for q1 : %.2f \n",Qmax.q1);
    SP"     Max for q2 : %.2f \n",Qmax.q2);
    SP"     Max for m1 : %.2f \n",Qmax.m1[0]);
    SP"     Max for m2 : %.2f \n",Qmax.m2[0]);
    if (progopts[EQUILIBRIUMMIGRATION])
        {
        SP"\nEquilibrium Migration Model, divergence time fixed at %.0f \n\n",Q[0]->t);
        }
    else
        {
        SP"     Max for qA : %.2f \n",Qmax.qA);
        SP"     Max for t  : %.2f \n",Qmax.t);
        SP"     Min for t  : %.2f \n",Qmin.t); 
        }
    SP"\n");
	if (infile) f_close(infile);
    
    copyedge = malloc(3*(sizeof(struct edge)));
	for (i=0;i<3;i++)
		copyedge[i].mig = malloc(ABSMAXMIG * sizeof(double));
	for (li=0;li< nloci;li++)
        ieevent(&tmrca[li]);
	ieevent(&variance_lp);
	for (i=0;i< AUTOCTERMS;i++)
	    ieevent(&autoc_lp[i]);
	for (j=0;j< basics;j++)
		{
		ieevent(&variance[j]);
		for (i=0;i< AUTOCTERMS;i++)
	        ieevent(&autoc[i][j]);
		} 
	
    if (printoptions[PRINTALLVALUES]) SP"All parameter values printed to file: %s\n",surfilename);
    if (printoptions[PRINTTMRCA]) SP"TMRCA  histograms printed at end of this file\n");
    if (cdurationmode == TIMEINF) 
        {
        strcpy(oldoutfilename,outfilename);
        strcat(oldoutfilename,".old");
        }
    for (i=0;i<MAXLOCI;i++) 
        hilocuslike[i] = -1e20;
    for (i=0;i<MAXLOCI;i++) 
        hilocusprob[i] = -1e20;
    
    for (i=0;i<numparams-1;i++)
        for (j=i+1;j<=numparams-1;j++)
            {
            c[i][j].n = 0;
            c[i][j].si = 0;
            c[i][j].si2 = 0;
            c[i][j].sj = 0;
            c[i][j].sj2 = 0;
            c[i][j].sij = 0;
            correlations[i][j] = 0;
            }
    if (Up)
        SP"Generation time specified (in years): %.2lf\n",generationtime);
    } /* start*/



void checkautoc(void)
    {
    int i,ai, j , li;
    static int ina = 0;
    double *qptr, temp, templp;

	if (ina==0)
		{
		for (i=0;i<AUTOCTERMS;i++)
			{
			nextstepsave[i] = CHECKAUTOCWAIT+AUTOCINT;
			nextstepcalc[i] = CHECKAUTOCWAIT+AUTOCINT + checkstep[i];
			nextpossave[i]= 0;
			nextposcalc[i] = 0;
			if (checkstep[i] <= AUTOCINT)
				maxpos[i] = 0;
			else
				maxpos[i] = (checkstep[i]/ AUTOCINT)-1;
			}
		ina = 1;
		}
	else
		{
		templp = 0;
		for (li =0; li < nloci; li++)
			{
			templp = L[0][li]->oldprob; 
			if (L[0][li]->model != STEPWISE)
				templp += L[0][li]->oldlike; 
			if (L[0][li]->model == STEPWISE || L[0][li]->model == JOINT_IS_SW)
				{
				for (ai=0;ai < L[0][li]->numsmm; ai++)
					{
					templp += L[0][li]->oldlike_a[ai];
					}
				}
			}
		for (i=0;i<AUTOCTERMS;i++)
			{
			if (step== nextstepcalc[i])
				{
				autoc_lp[i].n++;
				autoc_lp[i].s += autocvals_lp[i][nextposcalc[i]] + templp;
				autoc_lp[i].s2 += (autocvals_lp[i][nextposcalc[i]] * templp);
			
				qptr = &(Q[0]->q1);
				for (j=0;j< basics;j++)
					{
                    temp = *(qptr + paraminfo[j].listpos);
					autoc[i][j].n++;
					autoc[i][j].s += autocvals[i][j][nextposcalc[i]] + temp;
					autoc[i][j].s2 += (autocvals[i][j][nextposcalc[i]] * temp);
					}
				nextposcalc[i]++;
				if (nextposcalc[i] > maxpos[i])
					nextposcalc[i] = 0;
				nextstepcalc[i] += AUTOCINT;
				}
			}
		if ((long) AUTOCINT * (long)(step/AUTOCINT) == step)
			{
			for (i=0;i<AUTOCTERMS;i++)
				{
				autocvals_lp[i][nextpossave[i]] = templp;
				variance_lp.n++;
				variance_lp.s += templp;
				variance_lp.s2 += square(templp);
				qptr = &(Q[0]->q1);
				for (j=0;j<basics;j++)
					{
                    temp = *(qptr + paraminfo[j].listpos);
					autocvals[i][j][nextpossave[i]] = temp;
					variance[j].n++;
					variance[j].s += temp;
					variance[j].s2 += square(temp);
					}
				nextpossave[i]++;
				if (nextpossave[i] > maxpos[i])
					nextpossave[i] = 0;
				}
			}
		}
    } /* checkautoc */

int pickparam(int p)
    {
//JH changed 7/24/09  so that updating would goto U even if only one HKY locus
    int stopatU;
    if (step==0)
        {
        //pmax = M + (nurates > 1) + progopts[UPDATEH];
        //JH changed 7/24/09  so that updating would goto U even if only one HKY locus
          stopatU = (nurates > 1 || (L[0][0]->model == HKY && nloci == 1));
          pmax = M + stopatU + progopts[UPDATEH];
		return(-1);
        }
    p++;
    p += (p==S && !progopts[POPSIZECHANGEMODE]);
    if (p> pmax) p=Q1;
    return(p);
    }

double  swapweight(int ci, int cj)
    {
    int li, ai;
    double sumi=0, sumj=0, w;
    for (li = 0; li < nloci; li++)
        {
		if (L[ci][li]->model == STEPWISE || L[ci][li]->model == JOINT_IS_SW)
			{
			for (ai=0;ai < L[ci][li]->numsmm; ai++)
				{
				sumi += L[ci][li]->oldlike_a[ai];
				sumj += L[cj][li]->oldlike_a[ai];
				}
			}
		if (L[ci][li]->model != STEPWISE)
			{
			sumi += L[ci][li]->oldlike;
			sumj += L[cj][li]->oldlike;
			}
		sumi += L[ci][li]->oldprob;
		sumj += L[cj][li]->oldprob;
        }
    w = exp((beta[ci]-beta[cj])* (sumj-sumi));
    /*w = 0; */
    return(w);
    }

/* swaps chains,  adjust heating levels if adaptive heating is invoked.
will do multiple swaps if swaptries > 1.  If a swap was done involving chain0 then swap0ok =1. Sometimes, with 
swaptries > 1,  chain 0 will swap with another chain, and then swap back, restoring the current parameter 
values and genealogies. This is not detected, so stuff later that checks the return from this function
will think that parameters have changed.  This should not matter */
int swapchains(void)
    {
    int li, ci, cj, i, swap0ok;
    double weight;
    double swapval;
    void  *swapptr;
    int updateheat;
    double estrate, incrate;
	static int nextheatalt1 = 1;
    double newhval1, newhval2;
int cl, ch;	

#define  MINSWAP  0.2
#define  BETADJUST  1.414
#define  INCADJUST  1.414
#define  MINHEAT  0.0001
#define  MAXHEAT  0.8
#define  MAXINC  100
#define  MININC  0.1
#define  PAUSESWAP 1000


    if (heatmode == HADAPT)
        {
        updateheat = 0;
        if (sw01d >= adaptcheck)
            {
            
            estrate  =  sw01/ (float) sw01d;
            newhval1 =  hval1 = 1.0/beta[1]  - 1.0;
            if (estrate < (MINSWAP * 0.9))
                newhval1 = MAX(MINHEAT, hval1/BETADJUST);
            if (estrate > (MINSWAP / 0.9))
                newhval1 = MIN(MAXHEAT, hval1*BETADJUST);
            swap01 = sw01; swap01d = sw01d;
            sw01 = sw01d = 0;
            hval1 = newhval1;
            updateheat = 1;
            
            }
        if (numchains > 2 && sw12d >= adaptcheck)
            {
            incrate  =  sw12/ (float) sw12d;
            newhval2  = hval2 =  ((1/beta[2] - 1)/hval1) - 1;
            if (incrate < (MINSWAP * 0.9))
                newhval2 = MAX(MININC, hval2 / INCADJUST);
            if (incrate > (MINSWAP / 0.9))
                newhval2 = MIN(MAXINC, hval2 * INCADJUST);
            swap12 = sw12; swap12d = sw12d;
            sw12 = sw12d = 0;
            hval2 = newhval2;
            updateheat = 1;
            }
        if (updateheat)
            {
            for (ci = 1; ci< numchains;ci++)
                beta[ci] = 1.0/ (1.0 + hval1  +  hval1 * (ci-1)* hval2);
            holdswap = swaptries * PAUSESWAP; 
            }
        }
    else holdswap = 0;
    if (holdswap == 0)
        {
		if (!burndone && bdurationmode == HEATALT1)
			{
			if (step > nextheatalt1 * burnheatinc) 
				{
				for (ci = 0; ci< numchains;ci++)
					if (nextheatalt1 < 10)
						beta[ci] = MIN(holdbeta[ci], burnheatvals[nextheatalt1]);
				nextheatalt1++;
				}
			}
        for (i=0, swap0ok = 0;i<swaptries;i++)
            {
            do  {
                ci = (int) (uniform() * numchains);
                }
            while (ci < 0 || ci >= numchains);
            do  {
				if (numchains > 3*SWAPDIST)  /* only propose swaps with chain number difference <= SWAPDIST apart */
					{
					cl = IMAX(0,(ci - SWAPDIST));
					ch = IMIN(numchains,ci + SWAPDIST);
					cj = cl + (int) (uniform() * (ch-cl));
					//cj = IMIN(numchains - 1,IMAX(0,(ci - SWAPDIST) + (int) (uniform() * (2 * SWAPDIST + 1))));
					}
				else
					cj = (int) (uniform() * numchains);
				myassert( numchains <= 3* SWAPDIST || abs(ci-cj) <= SWAPDIST);
                }
            while (cj < 0 || cj >= numchains || cj == ci);
            if ((ci==0 && cj ==1)|| (ci==1 && cj ==0))
                sw01d++;
            if ((ci==1 && cj ==2)|| (ci==2 && cj ==1))
                sw12d++;
            if (ci<cj)
                {
                swapcount[cj][ci]++;
                }
            else 
                {
                swapcount[ci][cj]++;
                }
            weight = swapweight(ci,cj);
            if (weight >= 1.0 || weight > uniform())
		        {
                for (li=0;li<nloci;li++)
                    {
                    if (L[ci][li]->model == HKY)
                        {
                        swapval = kappa[ci][li];
                        kappa[ci][li] = kappa[cj][li];
                        kappa[cj][li] = swapval;
                        }
                    swapptr = L[ci][li];
                    L[ci][li] = L[cj][li];
                    L[cj][li] = swapptr;
                    }
                swapptr = Q[ci];
                Q[ci] = Q[cj];
                Q[cj] = swapptr;
                if (ci<cj)
                    {
                    swapcount[ci][cj]++;
                    }
                else
                    {
                    swapcount[cj][ci]++;
                    }
                if ((ci==0 && cj ==1)|| (ci==1 && cj ==0))
                    sw01++;
                if ((ci==1 && cj ==2)|| (ci==2 && cj ==1))
                    sw12++;
                if (ci==0 || cj==0)
                    swap0ok |= 1;
                }
            }
        return swap0ok;
        }
    else
        {
        holdswap--;
        return 0;
        }
    }  /* swapchains */

/* for stepwise and joint models, this is the rate at which internal nodes have their allele values updated
/* it mostly seems not to be necessary to do these, as those values get updated anyway when branches get moved
   to we can set it to a low value */
#define uprop 0.25
   //this is a configured qupdate, with only 1 loop 
void Qupdate(void)
	    {
        //static int preburn = 1;
        int j,k,li, ci, ai, ui;
        int changed, changed0;
        int static ppick = 0;
        int hi;
        int qswapped = 0;
        int updateAcount;
        int topolchange;

        /* redundant if (burndone && preburn)
                {
                if (!checkinmode && printoptions[PRINTALLVALUES])
                    {
                    surfsetvals = 0;
                    }
                preburn = 0;
                } */
        /* update genealogies */
		 memcpy(&Qold, Q[0], sizeof(struct parameters));
         ppick = pickparam(ppick);
         for (ci=0;ci<numchains;ci++)
			{
            for (li=0;li<nloci;li++)
               for (k=0;k<gupdateint;k++)
                {
                if (ci==0) 
					gupdatetries[li]++;
                if (doMCMC(ci,li, kappa[ci][li], L[ci][li]->model, &topolchange))
                   {
                   if (ci==0) 
                       {
                       gaccp[li]++;
                        if (topolchange) 
                            topolaccp[li]++;
                        }
                   myassert(topolaccp[li] <= gaccp[li]);
                   } 

                 if (L[ci][li]->model == STEPWISE || L[ci][li]->model == JOINT_IS_SW)
                    {
					for (ai  = 0; ai < L[ci][li]->numsmm; ai++)
						{
						updateAcount = 0;
						if (L[ci][li]->model == STEPWISE)
							ui = locusulookup[li]+ai;
						else
							ui = locusulookup[li]+ai + 1; 
						L[ci][li]->oldlike_a[ai] = updateA(ci,li,ai,Q[ci]->u[ui], &updateAcount, uprop);
						if (ci==0)
							{
							Aupdateratecount[li][ai] += updateAcount/uprop; 
							Aupdatetries[li][ai]++;
							}
						}
                    
                    }   
				}

			changed = 0;
			if (progopts[ONEPOP])
				{
				Q[ci]->qA = changeq(ci,3, Q[ci]->qA, Qwin.qA,  Qmax.qA);
				Q[ci]->q1 = Q[ci]->q2 = Q[ci]->qA/2;  
				if (ci==0)
					{
					if (Q[ci]->qA != Qold.qA)
						{
						changed=1;
						Qaccp.qA++;
						}
					Qupdatetries.qA++;
					}
				 if (nurates > 1)
					 {
					 for (k=0,j = firstuparam;j <=(lastuparam - (nurates==2));j++, k++)
						{
						myassert(paraminfo[j].paramtype == U);
						if (ci==0) 
							Qupdatetries.u[k]++;
						ui = changeu(ci,j,k);
						if (ci==0)
							{
							if (ui == -1)
								uprior_failedupdate[k]++;
							if (ui == 1)
								Qaccp.u[k]++;
							}
						}
					 }
				}
			else
				{
				switch (ppick)
					{
					case Q1  /* 1*/ : if (progopts[COMMONTHETA] == 0)
								{
								Q[ci]->q1 = changeq(ci,1, Q[ci]->q1, Qwin.q1,  Qmax.q1);
								if (ci==0)
									{
									if (Qaccp.q1 += (Q[ci]->q1 != Qold.q1)) changed++;
									Qupdatetries.q1++;
									}
								 }
							else
								{
								Q[ci]->q1 = Q[ci]->q2 = Q[ci]->qA = changecommonq(ci,Q[ci]->q1, Qwin.q1,  Qmax.q1);
								if (ci==0)
									{
									if (Qaccp.q1 += (Q[ci]->q1 != Qold.q1)) changed++;
									Qupdatetries.q1++;
									}
								ppick += 2;
								}
							break;
					case  Q2 /* 2 */ : 
							if (progopts[COMMONTHETA] == 0)
								Q[ci]->q2 = changeq(ci,2, Q[ci]->q2, Qwin.q2,  Qmax.q2);
							if (ci==0)
								{
								if (Qaccp.q2 += (Q[ci]->q2 != Qold.q2)) changed++;
								Qupdatetries.q2++;
								}
							break;
					case  QA /* 3 */  : if (progopts[EQUILIBRIUMMIGRATION] == 0 && progopts[COMMONTHETA] == 0)
								{
								Q[ci]->qA = changeq(ci,3, Q[ci]->qA, Qwin.qA,  Qmax.qA);
								if (ci==0)
									{
									if (Qaccp.qA += (Q[ci]->qA != Qold.qA)) changed++;
									Qupdatetries.qA++;
									}
								 }
							break;
					case  T /* 0*/ :if (progopts[EQUILIBRIUMMIGRATION] == 0)
								{
								if (changet(ci,&Q[ci]->t, Qmax.t, Qmin.t, Qwin.t))
									changed=1;
								if (ci==0)
									{
									li = 0;
									while (li< nloci && L[ci][li]->roottime < Q[ci]->t  && L[ci][li]->roottime < Qold.t )
										{
										li++;
										} 
									if (li!=nloci && changed)
										{
										Qaccp.t++;
										} 
									Qupdatetries.t++;
									}
								}
							break;
#ifdef INCLUDESIZECHANGE
					case  S /* 5 */ : Q[ci]->s = changes(ci,Q[ci]->s, Qmax.s, Qmin.s, Qwin.s);
							if (ci==0)
								{
								if (Qaccp.s += (Q[ci]->s != Qold.s)) changed++;
								Qupdatetries.s++;
								} 
							break;
#endif
					case M /* 4 */: if (!progopts[COMMONMIGRATION])
								{
								if (progopts[LOCUSMIGRATION])
									{
									for (li=0;li<nloci;li++)
										{
										Q[ci]->m2[li] = changemsingle(ci,li,Q[ci]->m2[li], Qmax.m2[li], 1);
										if (ci==0)
											{
											if (Qaccp.m2[li] += (Q[ci]->m2[li] != Qold.m2[li])) changed++;
											Qupdatetries.m2[li]++;
											}
										Q[ci]->m1[li] = changemsingle(ci,li,Q[ci]->m1[li], Qmax.m1[li], 0);
										if (ci==0)
											{
											if (Qaccp.m1[li] += (Q[ci]->m1[li] != Qold.m1[li])) changed++;
											Qupdatetries.m1[li]++;
											}
										}
									}
								else
									{
									Q[ci]->m2[0] = changemall(ci,Q[ci]->m2[0], Qmax.m2[0], 1);
									if (ci==0)
										{
										if (Qaccp.m2[0] += (Q[ci]->m2[0] != Qold.m2[0])) changed++;
										Qupdatetries.m2[0]++;
										}
									Q[ci]->m1[0] = changemall(ci,Q[ci]->m1[0], Qmax.m1[0], 0);
									if (ci==0)
										{
										if (Qaccp.m1[0] += (Q[ci]->m1[0] != Qold.m1[0])) changed++;
										Qupdatetries.m1[0]++;
										}
									}
								}
							else
								{
								if (progopts[LOCUSMIGRATION])
									{
									for (li=0;li<nloci;li++)
										{
										Q[ci]->m1[0] = Q[ci]->m2[li] = changecommonmsingle(ci,li,Q[ci]->m1[0], Qmax.m1[0]);
										if (ci==0)
											{
											if (Qaccp.m1[li] += (Q[ci]->m1[li] != Qold.m1[li])) changed++;
											Qupdatetries.m1[li]++;
											}
										}
									}
								else
									{
									Q[ci]->m1[0] = Q[ci]->m2[0] = changecommonmall(ci,Q[ci]->m1[0], Qmax.m1[0]);
									if (ci==0)
										{
										if (Qaccp.m1[0] += (Q[ci]->m1[0] != Qold.m1[0])) changed++;
										Qupdatetries.m1[0]++;
										}
									}
								}
							break;
					case  U  /* 6 */ : myassert(nurates > 1 || (nloci==1 && L[0][0]->model == HKY));
                            if (nurates==1 && L[0][0]->model == HKY)
                              changekappa(ci);
                            else
							  for (k=0,j = firstuparam;j <=(lastuparam - (nurates==2));j++, k++)
								  {
								  myassert(paraminfo[j].paramtype == U);
								  if (ci==0) 
									  Qupdatetries.u[k]++;
								  ui = changeu(ci,j,k);
								  if (ci==0)
									  {
									  if (ui == -1)
										  uprior_failedupdate[k]++;
									  if (ui == 1)
										  Qaccp.u[k]++;
									  }
								  }
							break;
					case  H /* 7 */  :	for (hi=0; hi < nloci; hi++)
								{
								if (changeh(ci, hi))
									{
									if (ci==0) Qaccp.h[hi]++;
									}
								if (ci==0) Qupdatetries.h[hi]++;
								}
							break;
					}
				}
		if (ci==0)
			changed0 = changed;
        }
    if (numchains > 1)
        qswapped = swapchains(); 
        
    intervaloutput(changed0,qswapped);
    if (step >= CHECKAUTOCWAIT)
		checkautoc();
	} /* reconfigured update */

void record(void)
	{
	int i,j,k, li, ci, ai;
    double *qi,*qj;
    int nowpop,mc, mcount[2];
    double mtime[2];   
	
    ci = 0;
    for (li = 0; li< nloci; li++)
		{
		tmrca[li].n++;
		tmrca[li].s += L[ci][li]->roottime;
		tmrca[li].s2 += square(L[ci][li]->roottime);
        }
	if (printoptions[PRINTTMRCA])
		for (li = 0; li< nloci; li++)
			{
			k = IMAX(0,(int) (gridsize * L[ci][li]->roottime /(Qmax.t + 10)));
			if (k > gridsize-1)
				tmrcaafter[li]++;
			else
				tmrcadist[li][k]++;
			}
    if (printoptions[MIGRATEDIST])
        for (li = 0; li< nloci; li++)
			{
#ifndef ALTMIGRATEDIST
            mcount[0] = mcount[1] = 0;
            mtime[0] = mtime[1] = 0;
            for (i=0; i<2*L[ci][li]->numgenes-1; i++)
                if (L[ci][li]->tree[i].down > -1)
                    {
                    nowpop =  L[ci][li]->tree[i].pop;
                    mc = 0;
                    while (L[ci][li]->tree[i].mig[mc] > -0.5 && L[ci][li]->tree[i].mig[mc] < Q[ci]->t) 
				        {
                        mcount[nowpop]++;
                        mtime[nowpop] += L[ci][li]->tree[i].mig[mc];
				        myassert(L[ci][li]->tree[i].mig[mc]>=0.0 && L[ci][li]->tree[i].mig[mc] < Q[ci]->t);
				        mc++;
                        nowpop = 1-nowpop;
				        }
                    }
            for (i=0;i<=1;i++)
                {
                meventvec[li][i][mcount[i]]++;
                if (mcount[i])
                    {
                    mtime[i] /= mcount[i];
					// use full range of t,  evin if Qmin.t is not zero
                    //k = (int) (gridsize * (mtime[i] - Qmin.t)/(Qmax.t-Qmin.t));
					k = (int) (gridsize * mtime[i] /Qmax.t);
					myassert(k>=0  && k <= gridsize);
                    mtimevec[li][i][k]++;
                    }
                } 
#else
            for (i=0; i<2*L[ci][li]->numgenes-1; i++)
                if (L[ci][li]->tree[i].down > -1)
                    {
                    nowpop =  L[ci][li]->tree[i].pop;
                    mc = 0;
                    while (L[ci][li]->tree[i].mig[mc] > -0.5 && L[ci][li]->tree[i].mig[mc] < Q[ci]->t) 
				        {
						// use full range of t,  evin if Qmin.t is not zero
						//k = (int) (gridsize * (L[ci][li]->tree[i].mig[mc] - Qmin.t)/(Qmax.t-Qmin.t));
						k = (int) (gridsize * (L[ci][li]->tree[i].mig[mc] )/(Qmax.t));
						mtimevec[li][nowpop][k]++;
				        mc++;
                        nowpop = 1-nowpop;
				        }
                    }
#endif
			}
	ci = 0;
    for (j = 0; j< nurates;j++)
        {
		if (log(Q[ci]->u[j]) < -Qmax.u[j]) 
			beforegrid.u[j]++;
		else
			{
			if (log(Q[ci]->u[j]) > Qmax.u[j]) 
				aftergrid.u[j]++;
			else
				{
				k = IMIN(gridsize-1,IMAX(0,(int) (gridsize * (log(Q[ci]->u[j])+Qmax.u[j])/(2*Qmax.u[j]))));
				Qvec[k].u[j]++;
				}
			}
        }
    if (progopts[UPDATEH])
        for (li = 0; li< nloci; li++)
            {
            k = (int) (gridsize * (log(Q[ci]->h[li])+Qmax.h[li])/(2*Qmax.h[li]));
            if (k < 0) beforegrid.h[li]++;
            else 
                {
                if (k >  gridsize-1) 
                    aftergrid.h[li]++;
                else
		            Qvec[k].h[li]++;
                }
            }
    k = (int) (gridsize * Q[ci]->q1 /Qmax.q1);
    if (k < 0) beforegrid.q1++;
    else 
        {
        if (k >  gridsize-1) aftergrid.q1++;
        else Qvec[k].q1++;
        }
	k = (int) (gridsize * Q[ci]->q2 /Qmax.q2);
    if (k < 0) beforegrid.q2++;
    else 
        {
        if (k >  gridsize-1) aftergrid.q2++;
        else Qvec[k].q2++;
        }
	k = (int) (gridsize * Q[ci]->qA/Qmax.qA);
    if (k < 0) beforegrid.qA++;
    else 
        {
        if (k >  gridsize-1) aftergrid.qA++;
        else Qvec[k].qA++;
        }
    for((progopts[LOCUSMIGRATION]) ? (i=nloci) : (i=1), li=0;li<i;li++)
        {
	    k = (int) (gridsize * Q[ci]->m1[li]/Qmax.m1[li]);
        if (k < 0) beforegrid.m1[li]++;
        else 
            {
            if (k >  gridsize-1) aftergrid.m1[li]++;
            else Qvec[k].m1[li]++;
            }
	    k = (int) (gridsize * Q[ci]->m2[li]/Qmax.m2[li]);
        if (k < 0) beforegrid.m2[li]++;
        else 
            {
            if (k >  gridsize-1) aftergrid.m2[li]++;
            else Qvec[k].m2[li]++;
            }
        }
	// use full range of t, 0 to Qmax.t,  evin if Qmin.t is not zero
	//k = (int) (gridsize * (Q[ci]->t - Qmin.t)/(Qmax.t-Qmin.t));
	k = (int) (gridsize * (Q[ci]->t)/(Qmax.t));
    if (k < 0) beforegrid.t++;
    else 
        {
        if (k >  gridsize-1) aftergrid.t++;
        else Qvec[k].t++;
        }
    if (progopts[POPSIZECHANGEMODE])
        {
        k = (int) (gridsize * (Q[ci]->s));
        if (k < 0) beforegrid.s++;
        else 
            {
            if (k >  gridsize-1) aftergrid.s++;
            else Qvec[k].s++;
            }
        }
    for (i=0;i<numparams-1;i++)
        {
        qi = (&Q[ci]->q1 + paraminfo[i].listpos);
        for (j=i+1;j<numparams;j++)
            {
            qj = (&Q[ci]->q1 + paraminfo[j].listpos);
            c[i][j].n++;
            c[i][j].si += *qi;
            c[i][j].sj += *qj;
            c[i][j].si2 += square(*qi);
            c[i][j].sj2 += square(*qj);
            c[i][j].sij += *qi * *qj;
            }
        }
	/* explanation for how trendline data are accumulated:
	movespot is the point at which values are deleted from the array, 
	by shifting all values from above that point down one,to make more for new values added at the end of the array (i.e. at trendspot)
	values are added mores slowly as the run proceeds.  Each time the replacement point (movespot) reaches the end of the array the time period between additions doubles 
	Because the time period doubles when movespot reaches the end the points to the left of movespot have half the density (in time) of those to the right 
	*/
	if (printoptions[PRINTASCIITREND])
		{
		recordinc++;
		if (recordinc == recordtrendinc)
			{
			if (movespot == TRENDDIM -1 && trendspot == TRENDDIM-1)
				{
				movespot = 0;
				recordtrendinc *= 2;
				}
			for (j= movespot; j < TRENDDIM - 1; j++)
				lptrend[j]  = lptrend[j+1];
			lptrend[trendspot] = 0;
			for (li =0; li < nloci; li++)
				{
				lptrend[trendspot] +=  L[0][li]->oldprob; 
				if (L[ci][li]->model != STEPWISE)
					lptrend[trendspot] += L[0][li]->oldlike; 
				if (L[ci][li]->model == STEPWISE || L[ci][li]->model == JOINT_IS_SW)
					{
					for (ai=0;ai < L[ci][li]->numsmm; ai++)
						lptrend[trendspot] += L[ci][li]->oldlike_a[ai];
					}
				}
			for (i = 0; i< numparams; i++)
				if (paraminfo[i].inmodel)
					{
					for (j= movespot; j < TRENDDIM - 1; j++)
						{
						*(&Qtrend[j].q1 + paraminfo[i].listpos)  = *(&Qtrend[j+1].q1 + paraminfo[i].listpos);
						}
					*(&Qtrend[trendspot].q1 + paraminfo[i].listpos) = *(&Q[0]->q1 + paraminfo[i].listpos);

					}
			if (movespot < TRENDDIM - 1)
				movespot++;
			trendspot += (trendspot < TRENDDIM - 1);
			recordinc = 0;
			}
		}
	if (1 /*printoptions[DEMOGTEST] */)
		{

		mtest[0] += (Q[0]->m1[0] > Q[0]->m2[0]);
		nmtest[0] += (Q[0]->q1*Q[0]->m1[0] > Q[0]->q2*Q[0]->m2[0]);
		if (progopts[LOCUSMIGRATION])
			for (i=1;i<nloci;i++)
				{
				mtest[i] += (Q[0]->m1[i] > Q[0]->m2[i]);
				nmtest[i] += (Q[0]->q1*Q[0]->m1[i] > Q[0]->q2*Q[0]->m2[i]);
				}

		ntest[0] += (Q[0]->q1 > Q[0]->q2);
		ntest[1] += (Q[0]->q1 > Q[0]->qA);
		ntest[2] += (Q[0]->q2 > Q[0]->qA);
		if (progopts[LOCUSMIGRATION])
			for (i=0;i<nloci-1;i++)
				for (j=i+1;j<nloci;j++)
					{
					mcomp[0][i][j] += (Q[0]->m1[i] > Q[0]->m1[j]);
					mcomp[1][i][j] += (Q[0]->m2[i] > Q[0]->m2[j]);
					}
		if (nurates > 1)
			for (i=0;i<nurates-1;i++)
				for (j=i+1;j<nurates;j++)
					ucomp[i][j] += (Q[0]->u[i] > Q[0]->u[j]);
		if (progopts[POPSIZECHANGEMODE])
			{
			k = (int) (gridsize * (Q[ci]->s * Q[ci]->qA)/Qmax.qA);
			snadist[0][k]++;
			k = (int) (gridsize * (1-Q[ci]->s) * Q[ci]->qA/Qmax.qA);
			snadist[1][k]++;
			}
		
		}
	} /* record */

void startsurf(void)
	{
	strcpy(surfilename,outfilename);
	sprintf(surfilenumstr,"_%04d",surfilecount);
	strcat(surfilename,surfilenumstr);
	surfilecount++;
	strcat(surfilename,".surf");
	if (surfile != NULL)
		f_close(surfile);
	if ((surfile = fopen(surfilename,"w")) == NULL)
	   {
	   printf("Error surface file for writing\n"); 
       err(-1,-1,3);
	   }
    surfsetvals = 0;
	}

int run(void)
    {
#define RUNINTERVALSTEPS 1000
    int i,j,li;
    char ch;
	static int nextheatalt1 = 1;

    if (burndone)
        {
		if (checkmode)
			{
			if (checkinterval < RUNINTERVALSTEPS)
                {
                checkinterval++;
                }
            else
                {
                checkinterval=0;
                time(&checktimer);
                if ((checktimer - checklasttime) > checkduration)
                    {
                    checklasttime = checktimer;
					writedck();
                    }
                }
			}
        switch (cdurationmode)
            {
	        case TIMESTEPS: return(step < (chainduration+burnsteps)); break;
            case TIMEINF:   if (runinterval < RUNINTERVALSTEPS)
                                {
                                runinterval++;
                                return(1);
                                }
                            else
                                {
                                runinterval=0;
                                time(&timer);
                                if ((timer - lasttime) > chainduration)
                                    {
                                    lasttime = timer;
                                    if ((checkdonefile = fopen("IMrun","r"))==NULL)
                                        {
                                        return(0);
                                        }
                                    else 
                                        {
                                        ch = getc(checkdonefile);
                                        f_close(checkdonefile);
                                        if (toupper(ch) !='Y')
                                            {
                                            return(0);
                                            }
										else
                                            {
                                            printoutput();
                                            chaintimeintervals++;
											if (checkmode)
												{
												checkinterval=0;
												checklasttime = checktimer;
												time(&checktimer);
												writedck();
												}
                                            }
                                        }
									if (printoptions[PRINTALLVALUES])
										startsurf();
                                    }
                                return(1);
                                }
                                break;
            default : return(0); break;
            }
		
        }
    else
        {
        switch (bdurationmode)
            {
            case TIMESTEPS: burndone = (step > burnduration); break;
			case TIMEINF:   if (runinterval < RUNINTERVALSTEPS)
                                {
                                runinterval++;
                                return(1);
                                }
                            else
                                {
                                runinterval=0;
                                time(&timer);
								burndone = (timer - lasttime) > burnduration;
								}
                            break;
			case HEATALT1:  if (numchains == 1 && bdurationmode >= HEATALT1)
								{
								if (step > nextheatalt1 * burnheatinc) 
									{
									if (nextheatalt1 < 10)
										beta[0] = MIN(holdbeta[0], burnheatvals[nextheatalt1]);
									nextheatalt1++;
									}
								}
							burndone = (step > burnduration); break;
            default : return(0); break;
            }
        if (burndone)
            {
            time(&chainstarttime);
            burnsteps = step-1;
			if (cdurationmode == TIMEINF)
				{
                time(&lasttime);
				time(&timer);
				}
			if (checkmode)
				{
				time(&checklasttime);
				checkinterval=0;
				writedck();
				}
            for (li=0;li<nloci;li++) 
		        {
                gaccp[li] = 0;
                topolaccp[li] = 0;
                gupdatetries[li] = 0;
		        }
	        Qaccp = Qupdatetries = Qaccp0;
            adaptcheck = 10000;
            if (printoptions[PRINTALLVALUES])
				startsurf();
			if (numchains > 1)
				{
				for (i=0;i< numchains;i++)
					for (j=0;j< numchains;j++)
						swapcount[i][j] = 0;
				}
            }
        return(1);
        }
    } /* run */

void finish(void)
    {
    int li, i, j, ci;
    for (ci=0;ci<numchains;ci++)
        {
        for (li=0;li < nloci;li++)
	        {
            if (L[ci][li]->model != STEPWISE)
                {
	            for (i=0; i<L[ci][li]->numgenes; i++)
		            free(L[ci][li]->seq[i]);
	            free(L[ci][li]->seq);
                }
	        if (L[ci][li]->model == HKY)
		        {
		        for (i=L[ci][li]->numgenes; i<2*L[ci][li]->numgenes-1; i++)
			        {
			        for (j=0; j<L[ci][li]->numsites; j++)
				        {
				        free(L[ci][li]->tree[i].frac[j]);
				        free(L[ci][li]->tree[i].newfrac[j]);
				        }
			        free(L[ci][li]->tree[i].frac);
			        free(L[ci][li]->tree[i].newfrac);
					free(L[ci][li]->tree[i].scalefactor);
					free(L[ci][li]->tree[i].oldscalefactor);
			        }
		        free(L[ci][li]->mult);
		        }
			for (i=0; i<L[ci][li]->numlines; i++)
				free (L[ci][li]->tree[i].mig);
	        }
        for (li=0;li<nloci;li++)
		    free(L[ci][li]->tree);
        }
    if (printoptions[PRINTALLVALUES]) f_close(surfile);
	free(iseed);
    free(copyedge);
    free(paraminfo);
	exit(0);
    } /* finish */

int main(int argc, char *argv[]) 
	{
    int li,mli, ci, i, ai;
int j;
// Get current flag
//int tmpFlag = _CrtSetDbgFlag( _CRTDBG_REPORT_FLAG );
//tmpFlag |= _CRTDBG_CHECK_ALWAYS_DF; 
//tmpFlag |= _CRTDBG_LEAK_CHECK_DF;
//tmpFlag |= _CRTDBG_CHECK_CRT_DF;
// Set flag to the new value
//_CrtSetDbgFlag( tmpFlag );

	start(argc, argv);
	if (checkinmode) 
		{
		readdck();
		if (restartburn)
			reinitialize();
		else
			printoutput();
		if (printoptions[PRINTALLVALUES])
			{
			startsurf();
			}
		goto restart;
		}
	for (ci = 0; ci < numchains; ci++)
        {
	    for (li=0;li<nloci;li++) 
		    {
            if (progopts[LOCUSMIGRATION])
                mli=li;
            else
                mli = 0;
			for (ai=0;ai < L[ci][li]->numsmm; ai++)
				{
				L[ci][li]->oldlike_a[ai] = 0;
				}
            switch(L[ci][li]->model)
                {
                case INFINITESITES :
                    makeIS(ci,li,Q[ci]->m1[mli],Q[ci]->m2[mli],Q[ci]->t); 
                    L[ci][li]->oldlike = likelihoodIS(ci,li, Q[ci]->u[locusulookup[li]]); 
                    break;
                case HKY :
			        allocatefracs(ci,li);
 			        makeHKY(ci,li,Q[ci]->m1[mli],Q[ci]->m2[mli],Q[ci]->t);
			        L[ci][li]->oldlike = likelihoodHKY(ci,li,Q[ci]->u[locusulookup[li]], kappa[ci][li], -1, -1, -1, -1);
			        copyfraclike(ci,li);
					storescalefactors(ci,li);
                    break;
                case STEPWISE :
                    makeSW(ci,li,Q[ci]->m1[mli],Q[ci]->m2[mli],Q[ci]->t); 
					for (ai=0;ai < L[ci][li]->numsmm; ai++)
						L[ci][li]->oldlike_a[ai] = likelihoodSW(ci,li,ai,Q[ci]->u[locusulookup[li]+ai]);
                    break;
                case JOINT_IS_SW:
                    makeJOINT_IS_SW(ci,li,Q[ci]->m1[mli],Q[ci]->m2[mli],Q[ci]->t); 
					L[ci][li]->oldlike = likelihoodIS(ci,li, Q[ci]->u[locusulookup[li]]); 
					for (ai=0;ai < L[ci][li]->numsmm; ai++)
						{
						L[ci][li]->oldlike_a[ai] = likelihoodSW(ci,li,ai,Q[ci]->u[locusulookup[li]+ai+1]);
						}
                }
            //L[ci][li]->oldprob = ptreeprob(Q[ci]->q1,Q[ci]->q2,Q[ci]->qA,Q[ci]->m1[mli],Q[ci]->m2[mli], Q[ci]->t, Q[ci]->h[li], &L[ci][li]->ecount, L[ci][li]->elist,Q[ci]->s);
			//printf("here ci  %d  li %d \n",ci,li);
			newgeteventinfo(ci, li, &L[ci][li]->ecount, &L[ci][li]->elist, &L[ci][li]->eindex);
			L[ci][li]->oldprob = ptreeprob(Q[ci]->q1,Q[ci]->q2,Q[ci]->qA,Q[ci]->m1[mli],Q[ci]->m2[mli], Q[ci]->t, Q[ci]->h[li], &L[ci][li]->ecount, L[ci][li]->elist,L[ci][li]->eindex,Q[ci]->s);
			//treeprint(ci,li);
		    }
        }
	printf("Starting Markov chain.\n");
    step = 0;
	recordstep = 0;
restart:  
	i = 0;
	while (run())
        {
        Qupdate();
		if (burndone)
            {
			if (i== recordint)
				{
				record();
				recordstep++;
				i=0;
				}
			else
				i++;
            }
        step++;
       }
	if (checkmode)
		writedck();
    printoutput();
    finish();
    return 0;
	} /* main */


