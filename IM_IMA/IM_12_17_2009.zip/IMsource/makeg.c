/* IM  by Jody Hey and Rasmus Nielsen  2004-2009 */
/*last updates 12_17_09 */


/*last updates 8/28/07 */
#undef GLOBVARS
#include "im.h" 


/*used to be used in the original changet method.  Now only used in the initial building of tree */


/* build starting genealogies */
/* revised extensively on 4/23/07

  now all these make.. functions call the same function addedge() to pick coalescent times

  There is a new makeJOINT_IS_SW() 

  now for JOINT_IS_SW makeIS() uses IS criteria to identify the set of pairs that have zero distance, and then uses a distance matrix based on 
	STR distance to pick the pair
 
   addA() is now called both from makeSW()  and from makeJOINT_IS_SW()  (when JOINT_IS_SW)  to add note values
	the node allele values are equal to the descentant allele values when they are identical
	when they are not,  a value from a distribution of lengths in the interval of the descent values is picked

Not really sure how best to do the SW trees.  here is the algorithm
- build a distance matrix
- pick pair with lowest distance
- make a node
- pack an ancestral allele, based on distribution of alleles sizes, given the mutation rate and the branck lengths
- build a new distance matrix and repeat

  */
/*** LOCAL STUFF *****/


/* prototypes of local functions*/
int nummig(double startt, double endt, int startpop, int endpop, int tmode, double m1, double m2, double times[]);
int oldnummig(double startt, double endt, int startpop, int endpop, int tmode,double m1, double m2);
void addedge(int ci, int li, int newedge, int c[], int curgenes, double divt, double *time, double m1, double m2);
void addA(int ci, int li, int newedge, int *nd0, int *nd1);

int nummig(double startt, double endt, int startpop, int endpop, int tmode, double m1, double m2, double times[])
	{
	int n, locpop;
	double t, startn;

	do{
		startn = 0;
		if (startpop != endpop  && tmode)
			{/*the first mig. time is simulated conditional on at least one migration event*/
			/*if (startpop == 0)
				ms0++;
			if (startpop == 1)
				ms1++; */
            if ((m1==0 && startpop == 0) || (m2==0 && startpop == 1))  
				return -1;
			if (startpop == 0)		/*this saves time if M is small*/
				//t = startt-(log(1.0-uniform()*(1.0-exp(-m1*(endt-startt)))))/m1;
				times[0] = startt-(log(1.0-uniform()*(1.0-exp(-m1*(endt-startt)))))/m1;
			else 
				//t = startt-(log(1.0-uniform()*(1.0-exp(-m2*(endt-startt)))))/m2;
				times[0] = startt-(log(1.0-uniform()*(1.0-exp(-m2*(endt-startt)))))/m2;
			t = times[0];
			startn++;
			}
		else
			t = startt;
		locpop = endpop;
		n = (int) startn;
		while (t<endt)
			{
			if (locpop == 0)
                {
                if (m1==0)
                    return n;
				else
                    t = t + expo(m1);
                }
			else
                {
                if (m2==0)
                    return n;
                else
                    t = t + expo(m2); 
                }
			if (t < endt)
				{
				locpop=1-locpop;
				times[n] = t;
				n++;
                if (n >= STARTMIGMAX)
                    {
                    printf("migration fault in nummig in step %li\n",step);
		            err(0,-1,30);
                    } 
				}
			}
		}while (locpop!=endpop);
    if (n >= STARTMIGMAX)
        {
        printf("migration fault in nummig in step %li\n",step);
		err(0,-1,30);
        } 
	return n;
	} /* nummig */

int oldnummig(double startt, double endt, int startpop, int endpop, int tmode, double m1, double m2)
	{
	int n, locpop;
	double t, startn;

	do{
		startn = 0;
		if (startpop != endpop  && tmode)
			{/*the first mig. time is simulated conditional on at least one migration event*/
			/*if (startpop == 0)
				ms0++;
			if (startpop == 1)
				ms1++; */
            if ((m1==0 && startpop == 0) || (m2==0 && startpop == 1))  
				return -1;
			if (startpop == 0)		/*this saves time if M is small*/
				t = startt-(log(1.0-uniform()*(1.0-exp(-m1*(endt-startt)))))/m1;
			else 
				t = startt-(log(1.0-uniform()*(1.0-exp(-m2*(endt-startt)))))/m2;
			startn++;
			}
		else
			t = startt;
		locpop = endpop;
		n = (int) startn;
		while (t<endt)
			{
			if (locpop == 0)
                {
                if (m1==0)
                    return n;
				else
                    t = t + expo(m1);
                }
			else
                {
                if (m2==0)
                    return n;
                else
                    t = t + expo(m2); 
                }
			if (t < endt)
				{
				locpop=1-locpop;
				n++;
                if (n >= STARTMIGMAX)
                    {
                    printf("migration fault in nummig in step %li\n",step);
		            err(0,-1,30);
                    } 
				}
			}
		}while (locpop!=endpop);
    if (n >= STARTMIGMAX)
        {
        printf("migration fault in nummig in step %li\n",step);
		err(0,-1,30);
        } 
	return n;
	} /* nummig */


void addedge(int ci, int li, int newedge, int c[], int curgenes, double divt, double *time, double m1, double m2)
	{
	struct edge *tree = L[ci][li]->tree;
	double upt, t, q;
	int i,num,j;
	double times[STARTMIGMAX];

	if (*time < divt)
		{
		if (tree[c[0]].pop != tree[c[1]].pop && m1 == 0)
			{
			t = divt;
			q = Q[ci]->qA;
			}
		else
			{
			t = *time;
			if (tree[c[0]].pop == 0 && tree[c[1]].pop == 0)
				q = Q[ci]->q1;
			else
				if (tree[c[0]].pop == 1 && tree[c[1]].pop == 1)
					q = Q[ci]->q2;
				else
					q = (Q[ci]->q1+Q[ci]->q2)/2; // just use the average if it is necessary to have a migration event
			}
		}
	else
		{
		t = *time;
		q = Q[ci]->qA;
		}
	*time = t + expo(((double)(curgenes*(curgenes -1))/(q * Q[ci]->h[li]/2)));
    tree[c[0]].time = tree[c[1]].time = *time;
	tree[newedge].up[0] = c[0];
	tree[newedge].up[1] = c[1];
	tree[c[0]].down = tree[c[1]].down = newedge;
	if ((tree[c[0]].pop != tree[c[1]].pop) && *time < divt)
        {
        if (uniform() < 0.5)
           tree[newedge].pop = 0;
        else tree[newedge].pop = 1;
        }
	else 
        if (*time < divt)
            tree[newedge].pop = tree[c[0]].pop;
        else
            tree[newedge].pop = 0;

	for (i=0; i<2; i++)
		{
		if (tree[c[i]].up[0] != -1)
			upt = tree[tree[c[i]].up[0]].time;
		else upt = 0;
		if (upt < divt && m1 > 0)
			{
			if (*time < divt)
				t = *time - upt;
			else t = divt - upt;
			num=nummig(0.0, t, tree[c[i]].pop, tree[newedge].pop, *time < divt, m1,m2,times);
			//num=nummig(0.0, t, tree[c[i]].pop, tree[newedge].pop, *time < divt, m1, m2);
//			L[ci][li]->mignum += num;
			for (j=0; j<num; j++)
				{
				checkmig(j,&(tree[c[i]].mig), &(tree[c[i]].cmm));
			//	*(tree[c[i]].mig +j) = upt + ((double)(j+1))*t/(double)(num+1); 
				*(tree[c[i]].mig +j) = upt + times[j];
				}
			}
		else j=0;
		*(tree[c[i]].mig +j) = -1;	
		}
	} /* addedge */

/* under JOINT_IS_SW model, alleles states must be added for the SW portion of the genealogy at the beginning */
/* pick a number over the span of the interval between the descendant allele values (+1 on each side), following the bessel function distribution */
void addA(int ci, int li, int newedge, int *nd0, int *nd1)
    {
    int j, ai, aj, up[2], down, newA; 
	struct edge *tree = L[ci][li]->tree;
	int d0, d1;
	double u, t0, t1, r;
	double *p;

	for (ai = 0;ai< L[ci][li]->numsmm ;ai++)
		{
		if (L[ci][li]->model==STEPWISE)
			u = Q[ci]->u[locusulookup[li]+ai];
		if (L[ci][li]->model==JOINT_IS_SW)
			u = Q[ci]->u[locusulookup[li]+ai + 1];
		up[0] = tree[newedge].up[0];
		up[1] = tree[newedge].up[1];
		down = tree[newedge].down;
		p = malloc((abs(tree[up[0]].A[ai] - tree[up[1]].A[ai]) + 3)*sizeof(double));
		if(up[0] < L[ci][li]->numgenes)
			t0 = tree[up[0]].time;
		else
			t0 =  tree[up[0]].time - tree[tree[up[0]].up[0]].time;
		myassert(t0 > 0);
		if(up[1] < L[ci][li]->numgenes)
			t1 = tree[up[1]].time;
		else
			t1 =  tree[up[1]].time - tree[tree[up[1]].up[0]].time;
		myassert(t1 > 0);
		for (j = 0, aj = IMIN(tree[up[0]].A[ai],tree[up[1]].A[ai]) - 1; aj<= 1+IMAX(tree[up[0]].A[ai],tree[up[1]].A[ai]); aj++, j++)
			{
			d0 = abs(aj-tree[up[0]].A[ai]);
			d1 = abs(aj-tree[up[1]].A[ai]);
			p[j] = exp( -t0 * u + log(bessi(d0, t0*u)) +  -t1 * u + log(bessi(d1, t1*u)));
			if (j > 0) p[j] += p[j-1];
			}
		r = uniform() * p[j-1];
		j = 0;
		while (r > p[j]) j++;
		newA = IMIN(tree[up[0]].A[ai],tree[up[1]].A[ai]) - 1 + j;
		newA = IMAX(L[ci][li]->minA[ai],newA);
		newA = IMIN(L[ci][li]->maxA[ai],newA);
		*nd0 = abs(newA-tree[up[0]].A[ai]);
		*nd1= abs(newA-tree[up[1]].A[ai]);
		free(p);
		tree[newedge].A[ai] = newA;
		myassert(newA >= L[ci][li]->minA[ai]);
		}
    } /* addA */

/*** GLOBAL FUNCTIONS ***/

void makeHKY(int ci, int li, double m1, double m2, double divt)
	{
	int c[2], newedge, curgenes, i,j,k, *edgevec;
	double time;

    edgevec=malloc((2*L[ci][li]->numgenes-1)*sizeof(int));
    for (i=0; i<L[ci][li]->numgenes; i++)
            edgevec[i]=1;
	for (i=L[ci][li]->numgenes; i<2*L[ci][li]->numgenes-1; i++)
            edgevec[i]=-1;

	for (i=0; i<L[ci][li]->numpop1; i++)
		L[ci][li]->tree[i].pop = 0;
    for (i=L[ci][li]->numpop1; i<L[ci][li]->numgenes; i++)
		if (progopts[ONEPOP])
            {
            L[ci][li]->tree[i].pop = 0;
            L[ci][li]->numpop1 += L[ci][li]->numpop2;
            L[ci][li]->numpop2 = 0;
            }
        else
            L[ci][li]->tree[i].pop = 1; 
	for (i=0; i<2*L[ci][li]->numgenes-1; i++)
		{
		L[ci][li]->tree[i].up[0] = L[ci][li]->tree[i].up[1] = L[ci][li]->tree[i].down = -1;
		}
	//for (i=0; i<2*L[ci][li]->numgenes-1; i++)
	for (i= L[ci][li]->numgenes ; i<2*L[ci][li]->numgenes-1; i++)
		{
		L[ci][li]->tree[i].scalefactor=malloc((L[ci][li]->numsites)*sizeof(double));
		L[ci][li]->tree[i].oldscalefactor=malloc((L[ci][li]->numsites)*sizeof(double));
		for (k=0; k<L[ci][li]->numsites; k++)
			{
            L[ci][li]->tree[i].scalefactor[k]=0.0;
            L[ci][li]->tree[i].oldscalefactor[k]=0.0;
            }
		 }
//	L[ci][li]->mignum  = 0;
	time = 0.0;
    curgenes = L[ci][li]->numgenes;
	while (curgenes > 1)
		{
        for (k=0; k<2; k++)
			{
            i= (int) ((curgenes-k) * uniform());
            c[k]=j=-1;
            do{
                c[k]++;
                if (edgevec[c[k]]==1)
                      j++;
                }while (j<i);
            edgevec[c[k]]=-1;
            }
		newedge = 2*L[ci][li]->numgenes-curgenes;
        edgevec[newedge]=1;

		addedge(ci,li, newedge, c,curgenes,divt, &time, m1, m2);
		curgenes--;
		}
	L[ci][li]->roottime = time;
	L[ci][li]->root = L[ci][li]->numlines - 1;
	*(L[ci][li]->tree[L[ci][li]->root].mig) = -1;
	L[ci][li]->tree[L[ci][li]->root].time = TIMEMAX;
    free(edgevec);
	} /* makeHKYtree */

/* Rasmus's original code,  but added stuff for SW model
 when the model is JOINT_IS_SW  the sets of pairs of genes are picked following the IS criteria as in Rasmus's code
 but the actual pair that is picked has the smallest squared STR distance among those pairs
 use a matrix of squared STR distances  that goes down one row and column each time thru the loop, using UPGMA-like contraction of matrix*/

void makeIS( int ci, int li, double m1, double m2, double divt)
	{
	int c[2], newedge, cursites, curgenes, num,coalnum, i,j,k, site, *curid, **distmat, coal[2], *singletons, **tempseq;
	double time;
	struct edge *tree = L[ci][li]->tree;

	distmat = malloc((L[ci][li]->numgenes)*(sizeof(int *)));
	for (i=0; i<L[ci][li]->numgenes; i++)
		distmat[i] = malloc((L[ci][li]->numgenes)*(sizeof(int)));
	tempseq = malloc(L[ci][li]->numgenes*(sizeof(int *)));
	for (i=0; i<L[ci][li]->numgenes; i++)
		tempseq[i]=malloc((L[ci][li]->numsites)*(sizeof(int)));
	curid = malloc((L[ci][li]->numgenes)*(sizeof(int)));
	singletons = malloc((L[ci][li]->numsites)*(sizeof(int)));
	curgenes = L[ci][li]->numgenes;
	cursites = L[ci][li]->numsites;
	for (i=0; i<L[ci][li]->numgenes; i++)
		curid[i] = i;
	for (i=0; i<L[ci][li]->numpop1; i++)
		tree[i].pop = 0;
	for (i=L[ci][li]->numpop1; i<L[ci][li]->numgenes; i++)
		if (progopts[ONEPOP])
            {
            tree[i].pop = 0;
            L[ci][li]->numpop1 += L[ci][li]->numpop2;
            L[ci][li]->numpop2 = 0;
            }
        else
            tree[i].pop = 1;  
//	L[ci][li]->mignum  = 0;
	for (i=0; i<2*L[ci][li]->numgenes-1; i++)
		{
		tree[i].up[0] = tree[i].up[1] = tree[i].down = -1;
		}
	for (i=0; i<L[ci][li]->numgenes; i++)
		{
		for (j=0; j<L[ci][li]->numsites; j++)
			tempseq[i][j] = L[ci][li]->seq[i][j];
		}
	time = 0.0;
	while (curgenes > 1)
		{
		num = 0;
		for (i=0; i<curgenes; i++)
			{
			for (j=i+1; j<curgenes; j++)
				{
				distmat[i][j] = distmat[j][i] = 0;
				for (site=0; site<cursites; site++)
					{
					if (tempseq[i][site] != tempseq[j][site])
						{
						distmat[i][j]++;
						distmat[j][i]++;
						}
					}
				if (distmat[i][j] == 0)
					num++;
				}
			}
		if (num == 0)
			{
			for (i=0; i<cursites; i++)
				{
				num = 0;
				for (j=0; j<curgenes; j++)
					num = num + tempseq[j][i];
				if (num == 1 || num == (curgenes - 1))
					singletons[i] = 1;
				else singletons[i] = 0;
				}
			num = 0;
			for (i=0; i<curgenes; i++)
				{
				for (j=i+1; j<curgenes; j++)
					{
					distmat[i][j] = distmat[j][i] = 0;
					for (site=0; site<cursites; site++)
						{
						if (tempseq[i][site] != tempseq[j][site] && singletons[site] == 0)
							{
							distmat[i][j]++;
							distmat[j][i]++;
							}
						}
					if (distmat[i][j] == 0)
							num++;
					}
				}
			}
		if (num == 0)
			{
			printf("Data not compatible with infinite sites model\n");
			for (i=0; i<curgenes; i++)
				{
				printf("seq %i: ",curid[i]);
				for (j=0; j<cursites; j++)
					printf("%i",tempseq[i][j]);
				printf("\n");
				}
			 err(ci, li,81);
			 }
		coalnum = (int)  (uniform()*num);
		num = 0;
		for (i=0; i<curgenes; i++)
			{
			for (j=i+1; j<curgenes; j++)
				{
				if (distmat[i][j] == 0)
					{
					num++;
					if (num > coalnum)
						{
						if (i < j)
							{
							coal[0] = i;
							coal[1] = j;
							}
						else 
							{
							coal[0] = j;
							coal[1] = i;							
							}
						i = curgenes;
						j = curgenes;
						}
					}
				}
			}
		for (i=0; i<cursites; i++)
			{
			if (tempseq[coal[0]][i]!=tempseq[coal[1]][i])
				{
				for (j=0; j<curgenes; j++)
					{
					for (k=i; k<cursites-1; k++)
						tempseq[j][k] = tempseq[j][k+1];
					}
				i--;
				cursites--;
				}
			}
		newedge = 2*L[ci][li]->numgenes-curgenes;
		c[0] = curid[coal[0]];
		c[1] = curid[coal[1]];
		addedge(ci,li, newedge, c,curgenes,divt, &time, m1, m2);

		for (i=coal[1]; i<curgenes-1; i++)
			{
			for (j=0; j<cursites; j++)
				tempseq[i][j] = tempseq[i+1][j];
			curid[i] = curid[i+1];
			}
		curid[coal[0]]=newedge;
		curgenes--;
		}
	L[ci][li]->roottime = time;
	L[ci][li]->root = L[ci][li]->numlines - 1;
	*(tree[L[ci][li]->root].mig) = -1;
	tree[L[ci][li]->root].time = TIMEMAX;
	for (i=0; i<L[ci][li]->numgenes; i++)
		free(tempseq[i]);
	free(tempseq);
	for (i=0; i<L[ci][li]->numgenes; i++)
		free(distmat[i]);
	free(distmat);
	free(curid);
	free(singletons);
    } /* makeIStree */


void makeJOINT_IS_SW( int ci, int li, double m1, double m2, double divt)
	{
	int c[2], newedge, cursites, curgenes, num,i,j,k, site, *curid, **distmat, *singletons, **tempseq;
	double time;
	struct edge *tree = L[ci][li]->tree;
	double **distmatA;  // for microsats if locus is JOINT_IS_SW
	double distAmax;
	int ai, aj, minA, maxA;
	int  found;  //debugging
	int sumd =0,nd0, nd1;

	distmat = malloc((L[ci][li]->numgenes)*(sizeof(int *)));
	for (i=0; i<L[ci][li]->numgenes; i++)
		distmat[i] = malloc((L[ci][li]->numgenes)*(sizeof(int)));
	distmatA = malloc((L[ci][li]->numgenes)*(sizeof(double *)));
	for (i=0; i<L[ci][li]->numgenes; i++)
		{
		distmatA[i] = malloc((L[ci][li]->numgenes)*(sizeof(double)));
		}
	for (ai = 0;ai< L[ci][li]->numsmm ;ai++)
		{
		minA = 1000;
		maxA = 0;
		for (i=0;i < L[ci][li]->numgenes;i++)
			{
			if (minA > tree[i].A[ai])
				minA = tree[i].A[ai];
			if (maxA < tree[i].A[ai])
				maxA = tree[i].A[ai];
			}

		L[ci][li]->minA[ai] = IMAX(1, ((maxA+minA)/2) - (maxA-minA) );
		L[ci][li]->maxA[ai] = IMIN(1000, ((maxA+minA)/2) + (maxA-minA) );
		for (i=L[ci][li]->numgenes;i<2*L[ci][li]->numgenes-1;i++)
			tree[i].A[ai] = -1;
		}

	tempseq = malloc(L[ci][li]->numgenes*(sizeof(int *)));
	for (i=0; i<L[ci][li]->numgenes; i++)
		tempseq[i]=malloc((L[ci][li]->numsites)*(sizeof(int)));
	curid = malloc((L[ci][li]->numgenes)*(sizeof(int)));
	singletons = malloc((L[ci][li]->numsites)*(sizeof(int)));
	curgenes = L[ci][li]->numgenes;
	cursites = L[ci][li]->numsites;
	for (i=0; i<L[ci][li]->numgenes; i++)
		curid[i] = i;
	for (i=0; i<L[ci][li]->numpop1; i++)
		tree[i].pop = 0;
	for (i=L[ci][li]->numpop1; i<L[ci][li]->numgenes; i++)
		if (progopts[ONEPOP])
            {
            tree[i].pop = 0;
            L[ci][li]->numpop1 += L[ci][li]->numpop2;
            L[ci][li]->numpop2 = 0;
            }
        else
            tree[i].pop = 1;  
	for (i=0; i<2*L[ci][li]->numgenes-1; i++)
		{
		tree[i].up[0] = tree[i].up[1] = tree[i].down = -1;
		}
	for (i=0; i<L[ci][li]->numgenes; i++)
		{
		for (j=0; j<L[ci][li]->numsites; j++)
			tempseq[i][j] = L[ci][li]->seq[i][j];
		}
	time = 0.0;
	while (curgenes > 1)
		{
		num = 0;
		for (i=0; i<curgenes; i++)
			{
			for (j=i+1; j<curgenes; j++)
				{
				distmat[i][j] = distmat[j][i] = 0;
				for (site=0; site<cursites; site++)
					{
					if (tempseq[i][site] != tempseq[j][site])
						{
						distmat[i][j]++;
						distmat[j][i]++;
						}
					}
				if (distmat[i][j] == 0)
					num++;
				}
			}
		if (num == 0)
			{
			for (i=0; i<cursites; i++)
				{
				num = 0;
				for (j=0; j<curgenes; j++)
					num = num + tempseq[j][i];
				if (num == 1 || num == (curgenes - 1))
					singletons[i] = 1;
				else singletons[i] = 0;
				}
			num = 0;
			for (i=0; i<curgenes; i++)
				{
				for (j=i+1; j<curgenes; j++)
					{
					distmat[i][j] = distmat[j][i] = 0;
					for (site=0; site<cursites; site++)
						{
						if (tempseq[i][site] != tempseq[j][site] && singletons[site] == 0)
							{
							distmat[i][j]++;
							distmat[j][i]++;
							}
						}
					if (distmat[i][j] == 0)
							num++;
					}
				}
			}
		if (num == 0)
			{
			printf("Data not compatible with infinite sites model\n");
			for (i=0; i<curgenes; i++)
				{
				printf("seq %i: ",curid[i]);
				for (j=0; j<cursites; j++)
					printf("%i",tempseq[i][j]);
				printf("\n");
				}
			 err(ci, li,81);
			 }
		for (i=0; i< L[ci][li]->numgenes - 1; i++)
			{
			distmatA[i][i] = 0;
			for (j=i+1; j< L[ci][li]->numgenes ; j++)
				distmatA[j][i] = distmatA[i][j] = 0;
			}

		for (i=0; i<curgenes - 1; i++)
			{
			distmatA[i][i] = 0;
			for (j=i+1; j<curgenes; j++)
				{
				distmatA[i][j] = distmatA[j][i] = 0;
				for (k = 1;k < L[ci][li]->numsmm; k++)
					distmatA[i][j] += square(abs(tree[curid[i]].A[k] - tree[curid[j]].A[k]));
				distmatA[j][i] = distmatA[i][j];
				}
			}

		distAmax = 1e20; // large value;	 
		num = 0;
		found = 0;
		for (i=0; i<curgenes -1; i++)
			{
			for (j=i+1; j<curgenes; j++)
				{
				if (distmat[i][j] == 0)
					{
					if (distAmax > distmatA[i][j])
						{
						distAmax = distmatA[i][j];
						ai = i;
						aj = j;
						found = 1;
						}
					}
				}
			}
		for (i=0; i<cursites; i++)
			{
			if (tempseq[ai][i]!=tempseq[aj][i])
				{
				for (j=0; j<curgenes; j++)
					{
					for (k=i; k<cursites-1; k++)
						tempseq[j][k] = tempseq[j][k+1];
					}
				i--;
				cursites--;
				}
			}
		c[0] = curid[ai];
		c[1] = curid[aj];
		myassert(found);
		newedge = 2*L[ci][li]->numgenes-curgenes;
		addedge(ci,li, newedge, c,curgenes,divt, &time, m1,m2);
		addA(ci,li, newedge, &nd0,&nd1);
		sumd += (nd0+nd1);

		for (i=aj; i<curgenes-1; i++)
			{
			for (j=0; j<cursites; j++)
				tempseq[i][j] = tempseq[i+1][j];
			curid[i] = curid[i+1];
			}
		curid[ai]=newedge;
		curgenes--;
		}
	L[ci][li]->roottime = time;
	L[ci][li]->root = L[ci][li]->numlines - 1;
	*(tree[L[ci][li]->root].mig) = -1;
	tree[L[ci][li]->root].time = TIMEMAX;
	for (i=0; i<L[ci][li]->numgenes; i++)
		free(tempseq[i]);
	free(tempseq);
	for (i=0; i<L[ci][li]->numgenes; i++)
		free(distmat[i]);
	free(distmat);
	if (L[ci][li]->model == JOINT_IS_SW)
		{
		for (i=0; i<L[ci][li]->numgenes; i++)
			{
			free(distmatA[i]);
			}
		free(distmatA);
		}
	free(curid);
	free(singletons);
    } /* makeJOINT_IS_SWtree */

void makeSW(int ci, int li, double m1, double m2, double divt)
	{
    int i, j, k, ai,aj;
    int curgenes, newedge, c[2];
	double time;
	struct edge *tree = L[ci][li]->tree;
	double **distmatA; 
	int *ids;
	double distAmax;
	int minA, maxA;
	int sumd = 0,nd0, nd1;
	
	for (ai = 0;ai< L[ci][li]->numsmm ;ai++)
		{
		minA = 1000;
		maxA = 0;
		for (i=0;i < L[ci][li]->numgenes;i++)
			{
			if (minA > tree[i].A[ai])
				minA = tree[i].A[ai];
			if (maxA < tree[i].A[ai])
				maxA = tree[i].A[ai];
			}

		L[ci][li]->minA[ai] = IMAX(1, ((maxA+minA)/2) - (maxA-minA) );
		L[ci][li]->maxA[ai] = IMIN(1000, ((maxA+minA)/2) + (maxA-minA) );
		for (i=L[ci][li]->numgenes;i<2*L[ci][li]->numgenes-1;i++)
			tree[i].A[ai] = -1;
		}

	distmatA = malloc((L[ci][li]->numgenes)*(sizeof(double *)));
	ids = malloc((L[ci][li]->numgenes)*(sizeof(int)));
	for (i=0; i<L[ci][li]->numgenes; i++)
		{
		ids[i] = i;
		distmatA[i] = malloc((L[ci][li]->numgenes)*(sizeof(double)));
		}
	time = 0;
    curgenes = L[ci][li]->numgenes;
    for (i=0; i<L[ci][li]->numpop1; i++)
		tree[i].pop = 0;
	for (i=L[ci][li]->numpop1; i<L[ci][li]->numgenes; i++)
		tree[i].pop = 1;
	for (i=0; i<2*L[ci][li]->numgenes-1; i++)
        {
		tree[i].up[0] = tree[i].up[1] = tree[i].down = -1;
        tree[i].mig[0] = -1;
        }
    newedge = L[ci][li]->numgenes; 
    do  {
		for (i=0; i< L[ci][li]->numgenes - 1; i++)
			{
			distmatA[i][i] = 0;
			for (j=i+1; j< L[ci][li]->numgenes ; j++)
				distmatA[j][i] = distmatA[i][j] = 0;
			}

		for (i=0; i<curgenes - 1; i++)
			for (j=0; j<curgenes; j++)
				{
				distmatA[i][j] = distmatA[j][i] = 0;
				for (k = 0;k < L[ci][li]->numsmm ; k++)
					distmatA[i][j] += square(abs(tree[ids[i]].A[k] - tree[ids[j]].A[k]));
				distmatA[j][i] = distmatA[i][j];
				}
		distAmax = 1e20; // large value;	 
		for (i=0; i<curgenes; i++)
			for (j=i+1; j<curgenes; j++)
				{
				if (distAmax > distmatA[i][j])
					{
					distAmax = distmatA[i][j];
					ai = i;
					aj = j;
					}
				}
		/* give new ids to positions ai and aj */
		
		//replace columns and rows associated with coal[0] with the average of values involving coal[0] and coal[1];
			//like a upgma contraction of matrix
		c[0] = ids[ai];
		c[1] = ids[aj];
		addedge(ci,li, newedge, c,curgenes,divt, &time, m1, m2);
		addA(ci,li, newedge, &nd0,&nd1);
		ids[ai] = newedge;
		for (i = aj; i< curgenes - 1; i++)
			ids[i] = ids[i+1];
		sumd += (nd0+nd1);
		newedge++;
        curgenes--;
        }
    while (newedge < 2*L[ci][li]->numgenes-1);
	L[ci][li]->roottime = time;
	L[ci][li]->root = L[ci][li]->numlines - 1;
	*(tree[L[ci][li]->root].mig) = -1;
	tree[L[ci][li]->root].time = TIMEMAX;
	for (i=0; i<L[ci][li]->numgenes; i++)
		{
		free(distmatA[i]);
		}
	free(distmatA);
	free(ids);
    } /* makeSWtree */


