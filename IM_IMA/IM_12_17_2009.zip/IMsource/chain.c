/* IM  by Jody Hey and Rasmus Nielsen  2004-2009 */
/*last updates 12_17_09 */



/* chain.c   probabilty and update calculations */

#undef GLOBVARS
#include "im.h" 



/* stuff from numerical recipes - needed for indexx() */
#define NR_END 1
#define FREE_ARG char*

int *ivector(long nl, long nh)
/* allocate an int vector with subscript range v[nl..nh] */
{
   int *v;

   v=(int *)malloc((size_t) ((nh-nl+1+NR_END)*sizeof(int)));
   if (!v) err(-1,-1,55);//nrerror("allocation failure in ivector()");
   return v-nl+NR_END;
}

void free_ivector(int *v, long nl, long nh)
/* free an int vector allocated with ivector() */
{
   free((FREE_ARG) (v+nl-NR_END));
}

/* sort an index of locations */
#define SWAP(a,b) itemp=(a);(a)=(b);(b)=itemp;
#define M 7
#define NSTACK 50

void indexx(unsigned long n, struct treeevent *arr, unsigned long *indx)
{
	unsigned long i,indxt,ir=n,itemp,j,k,l=1;
	int jstack=0,*istack;
	double a;

	istack=ivector(1,NSTACK);
	for (j=1;j<=n;j++) indx[j]=j;
	for (;;) {
		if (ir-l < M) {
			for (j=l+1;j<=ir;j++) {
				indxt=indx[j];
				a=arr[indxt].time;
				for (i=j-1;i>=l;i--) {
					if (arr[indx[i]].time <= a) break;
					indx[i+1]=indx[i];
				}
				indx[i+1]=indxt;
			}
			if (jstack == 0) break;
			ir=istack[jstack--];
			l=istack[jstack--];
		} else {
			k=(l+ir) >> 1;
			SWAP(indx[k],indx[l+1]);
			if (arr[indx[l]].time > arr[indx[ir]].time) {
				SWAP(indx[l],indx[ir])
			}
			if (arr[indx[l+1]].time > arr[indx[ir]].time) {
				SWAP(indx[l+1],indx[ir])
			}
			if (arr[indx[l]].time > arr[indx[l+1]].time) {
				SWAP(indx[l],indx[l+1])
			}
			i=l+1;
			j=ir;
			indxt=indx[l+1];
			a=arr[indxt].time;
			for (;;) {
				do i++; while (arr[indx[i]].time < a);
				do j--; while (arr[indx[j]].time > a);
				if (j < i) break;
				SWAP(indx[i],indx[j])
			}
			indx[l+1]=indx[j];
			indx[j]=indxt;
			jstack += 2;
			if (jstack > NSTACK) err(-1,-1,56);//nrerror("NSTACK too small in indexx.");
			if (ir-i+1 >= j-l) {
				istack[jstack]=ir;
				istack[jstack-1]=i;
				ir=j-1;
			} else {
				istack[jstack]=j-1;
				istack[jstack-1]=l;
				l=i;
			}
		}
	}
	free_ivector(istack,1,NSTACK);
}

#undef M
#undef NSTACK
#undef SWAP
#undef NR_END 
#undef FREE_ARG 

/* (C) Copr. 1986-92 Numerical Recipes Software */

/* heap sort is slightly faster than shell sort but slower than quicksort 
void hpsort (struct treeevent *lptr,int  n)
    {
    unsigned long i,ir,j,l;
    struct treeevent t;
    if (n < 2) return;
    l=(n >> 1)+1;
    ir=n;
    for (;;) 
        {
        if (l > 1) 
            {
            t= *(lptr + --l);
            } 
        else 
            {
            t = *(lptr+ir);
            *(lptr + ir) = *(lptr+1);
            if (--ir == 1) 
                {
                *(lptr + 1)=t;
                break;
                }
            }
        i=l;
        j=l+l;
        while (j <= ir) 
            {
            if (j < ir && (lptr+j)->time < (lptr+(j+1))->time) j++;
            if (t.time < (lptr+j)->time) 
                {
                *(lptr+i) = *(lptr+j);
                i=j;
                j <<= 1;
                } 
            else j=ir+1;
            }
        *(lptr+i)=t;
        }
    }  hpsort */

/* spent some time on the sorting of elist.   quicksort is slightly faster than heapsort.
quicksort on an index is about 6% faster, but it requires maintining, not only elist and ec, but also an index array 
for every locus in every chain */

void newgeteventinfo(int ci,int li, int *ec, struct treeevent **e, unsigned long **eindex)
/* events are migrations, m = 1, or coalescent, c = 0 or population splitting, t = -1
e contains information for events. event i is contained in e+i and includes
the time till the next event, time
the event that happens at that time cmt (0 or 1 or -1)
the population in which the event happens 
if that event is migration, the pop is the one from which the migrant is leaving
the number of individuals in each population, just before the event happens.
*/
    {
    int i,j,ji,k, nowpop, n0, n1,  ncount;
    double upt, ttemp, lasttime /*, latest = 0*/, sumtime=0;
	struct edge *tree = L[ci][li]->tree;
	
	if (Q[ci]->t > 0 && Q[ci]->t < L[ci][li]->roottime)
        ncount = L[ci][li]->numgenes;
    else
        ncount = L[ci][li]->numgenes-1;
	for (i=0; i< L[ci][li]->numlines; i++)
		{
		mc[i] = 0;
        if (tree[i].down > -1)
            while (*(tree[i].mig + mc[i]) > -0.5 && tree[i].mig[mc[i]] < Q[ci]->t) 
				{
				myassert(*(tree[i].mig + mc[i]) >=0.0);
				mc[i]++;
				}
		ncount += mc[i];
		myassert(tree[i].up[0] >= -1 && tree[i].up[0] < L[ci][li]->numlines
			&& tree[i].up[1] >= -1 && tree[i].up[1] < L[ci][li]->numlines); 
		}

	*e = malloc(ncount*sizeof(struct treeevent));
	*eindex = malloc(ncount * sizeof(unsigned long));
    *ec = 0;

    for (i=0; i< L[ci][li]->numlines; i++)
        {
        if (tree[i].up[0] > -0.5)
				upt = tree[tree[i].up[0]].time;
			else 
                upt = 0;
        nowpop = tree[i].pop;
        if (upt > 0) /* must be a coalescent */ 
            {
            myassert(i>= L[ci][li]->numgenes); 
            (*e + *ec)->time = upt;
        //    if ((*e + *ec)->time > latest)  latest = (*e + *ec)->time;
            (*e + *ec)->cmt = 0;
			if (upt >= Q[ci]->t) 
				(*e + *ec)->pop = 0;
			else  
				(*e + *ec)->pop = nowpop;
		    *ec += 1;
            }
        for (j = 0;j<mc[i];j++)
            {
            ttemp =  *(tree[i].mig +j);
            myassert(ttemp >= upt); 
            if (tree[i].down > -0.5 && tree[i].time < Q[ci]->t )
                myassert((tree[i].pop + mc[i]%2)%2 == tree[tree[i].down].pop); 
			if (ttemp < Q[ci]->t)
				{
				(*e + *ec)->time = ttemp;
				(*e + *ec)->pop = nowpop;
                nowpop = 1-nowpop;
				(*e + *ec)->cmt = 1;
				 *ec += 1;
				}
			}
        }
	//myassert(latest == L[ci][li]->roottime);  // should not need 'latest'  
    if (L[ci][li]->roottime /*latest*/ > Q[ci]->t && Q[ci]->t > 0)
        {
        (*e + *ec)->time = Q[ci]->t;
        (*e + *ec)->cmt = -1;
         *ec += 1;
        }
    myassert(ncount==*ec);
	indexx(*ec,*e-1,(*eindex)-1);  // sorts an index of locations in ec by time 

    n0=L[ci][li]->numpop1;
    n1=L[ci][li]->numpop2;
    lasttime = 0;
    L[ci][li]->length = 0;
	for (ji=0;ji<  *ec;ji++)
       {
	   j = *(*eindex +ji)-1;  // subtract - 1 because indexx sorts by assigning position values that begin at 1
	   myassert(j < *ec);
        (*e +j)->num0 = n0;
        (*e +j)->num1 = n1;
        ttemp = (*e +j)->time - lasttime;
        lasttime = (*e +j)->time;
        (*e +j)->time = ttemp;
		myassert((*e +j)->time > 0);
        L[ci][li]->length += (n0 + n1) * (*e +j)->time;
        sumtime += ttemp;
        if ((*e +j)->cmt==0)
            {
            if ((*e +j)->pop==0)
                n0--;
            else 
                n1--;
            }
        if ((*e +j)->cmt ==1)
            {
            if ((n0==0 && (*e +j)->pop==0) ||(n1==0 && (*e +j)->pop==1))
                {
				err(ci,li,35);
                /*if (j <  *ec-1 && (*e +j+1)->cmt == 1) switch order of two migrations 
                    {
                    k = (*e +j)->pop;
                    (*e +j)->pop = (*e +j+1)->pop;
                    (*e +j+1)->pop = k;
                    } */
                }
			if ((*e +j)->pop==0)
                {
                n0--;
                n1++;
                } 
            else 
                {
                n0++;
                n1--;
                }
            }
         if ((*e +j)->cmt==-1)
            {
            n0 += n1;
			n1 = 0;
            }
        }
    } /*newgeteventinfo */

/* events are migrations, m = 1, or coalescent, c = 0 or population splitting, t = -1
e contains information for events. event i is contained in e+i and includes
the time till the next event, time
the event that happens at that time cmt (0 or 1 or -1)
the population in which the event happens 
if that event is migration, the pop is the one from which the migrant is leaving
the number of individuals in each population, just before the event happens.
*/
/* older version used heapsort on the actual list */
/*void oldgeteventinfo(int ci,int li, int *ec, struct treeevent **e)
    {
    int i,j,k, nowpop, n0, n1,  ncount;
    double upt, ttemp, lasttime, latest = 0, sumtime=0;
	struct edge *tree = L[ci][li]->tree;
	
	if (Q[ci]->t > 0 && Q[ci]->t < L[ci][li]->roottime)
        ncount = L[ci][li]->numgenes;
    else
        ncount = L[ci][li]->numgenes-1;
	for (i=0; i< L[ci][li]->numlines; i++)
		{
		mc[i] = 0;
        if (tree[i].down > -1)
            while (*(tree[i].mig + mc[i]) > -0.5 && tree[i].mig[mc[i]] < Q[ci]->t) 
				{
				myassert(*(tree[i].mig + mc[i]) >=0.0);
				mc[i]++;
				}
		ncount += mc[i];
		myassert(tree[i].up[0] >= -1 && tree[i].up[0] < L[ci][li]->numlines
			&& tree[i].up[1] >= -1 && tree[i].up[1] < L[ci][li]->numlines); 
		}

	*e = malloc(ncount*sizeof(struct treeevent));
    *ec = 0;

    for (i=0; i< L[ci][li]->numlines; i++)
        {
        if (tree[i].up[0] > -0.5)
				upt = tree[tree[i].up[0]].time;
			else 
                upt = 0;
        nowpop = tree[i].pop;
        if (upt > 0) 
            {
            myassert(i>= L[ci][li]->numgenes); 
            (*e + *ec)->time = upt;
            (*e + *ec)->cmt = 0;
			if (upt >= Q[ci]->t) 
				(*e + *ec)->pop = 0;
			else  
				(*e + *ec)->pop = nowpop;
		    *ec += 1;
            }
        for (j = 0;j<mc[i];j++)
            {
            ttemp =  *(tree[i].mig +j);
            myassert(ttemp >= upt); 
            if (tree[i].down > -0.5 && tree[i].time < Q[ci]->t )
                myassert((tree[i].pop + mc[i]%2)%2 == tree[tree[i].down].pop); 
			if (ttemp < Q[ci]->t)
				{
				(*e + *ec)->time = ttemp;
				(*e + *ec)->pop = nowpop;
                nowpop = 1-nowpop;
				(*e + *ec)->cmt = 1;
				 *ec += 1;
				}
			}
        }
    if (L[ci][li]->roottime > Q[ci]->t && Q[ci]->t > 0)
        {
        (*e + *ec)->time = Q[ci]->t;
        (*e + *ec)->cmt = -1;
         *ec += 1;
        }
    myassert(ncount==*ec);
    hpsort(*e-1, *ec);
    n0=L[ci][li]->numpop1;
    n1=L[ci][li]->numpop2;
    lasttime = 0;
    L[ci][li]->length = 0;
    for (j=0;j<  *ec;j++)
       {
        (*e +j)->num0 = n0;
        (*e +j)->num1 = n1;
        ttemp = (*e +j)->time - lasttime;
        lasttime = (*e +j)->time;
        (*e +j)->time = ttemp;
        L[ci][li]->length += (n0 + n1) * (*e +j)->time;
        sumtime += ttemp;
        if ((*e +j)->cmt==0)
            {
            if ((*e +j)->pop==0)
                n0--;
            else 
                n1--;
            }
        if ((*e +j)->cmt ==1)
            {
            if ((n0==0 && (*e +j)->pop==0) ||(n1==0 && (*e +j)->pop==1))
                {
                if (j <  *ec-1 && (*e +j+1)->cmt == 1) 
                    {
                    k = (*e +j)->pop;
                    (*e +j)->pop = (*e +j+1)->pop;
                    (*e +j+1)->pop = k;
                    }
                }
			if ((*e +j)->pop==0)
                {
                n0--;
                n1++;
                } 
            else 
                {
                n0++;
                n1--;
                }
            }
         if ((*e +j)->cmt==-1)
            {
            n0 += n1;
			n1 = 0;
            }
        }
    } old geteventinfo */

// added single pop mode to avoid dividing by 0 in cases when it is assumed that there is only a single population 
// this will slow it down - could break out a separate function, so that singlepopmode is called only once 
//__forceinline  double treeprobc (double q1, double q2, double qA, double m1, double m2, double t, double h, int *ec, struct treeevent *e, double junk)
__forceinline  double treeprobc(double q1, double q2, double qA, double m1, double m2, double t, double h, int *ec, struct treeevent *e, unsigned long *eindex, double junk)
/* atp holds the value of treeprob that would be calculated under the old parameterization and scaling */
	{
	double p, tp, ps, pz;
	double time, sumtime=0;
    int ei;
	int j;

    q1 *= h;
    q2 *= h;
    qA *= h;
	pz = 0;
    /*myassert((e+0)->num0 + (e+0)->num1 == L[0][0]->numgenes); */
	//for (ei=0;ei < *ec; ei++)
	for (j=0;j < *ec; j++)
		{
		ei = *(eindex+j) - 1;   // subtract -1 because indexx sorts by assigning position values that begin at 1
        if ((e + ei)->cmt == -1)
            {
			if (singlepopmode)
				{
				if (q1<= 0)
					ps = ((e + ei)->num1 * m2) + 
						((e + ei)->num0 * m1) +
						((e + ei)->num1 * ((e + ei)->num1 - 1)/ (q2));
				if (q2 <=0)
					ps = ((e + ei)->num1 * m2) + 
						((e + ei)->num0 * m1) +
						((e + ei)->num0 * ((e + ei)->num0 - 1)/ (q1));
				}
			else
				{
				ps = ((e + ei)->num1 * m2) + 
				 ((e + ei)->num0 * m1) +
				 ((e + ei)->num1 * ((e + ei)->num1 - 1)/ (q2)) + 
				 ((e + ei)->num0 * ((e + ei)->num0 - 1)/ (q1));
				}
            tp = -ps*(e + ei)->time;
			sumtime = t; 
            }
        else 
            {
            if (((e +ei)->time + sumtime) > t) 
			    {
			    if ((e + ei)->num0 >1)
				    {
				    p =  2.0/(qA);
				    ps= (e + ei)->num0 * ((e + ei)->num0 - 1)/ (qA);
                    time = (e + ei)->time;
                    sumtime += time;
                    tp = log(p) - time * ps;
				    }
                else tp = 0;
		        }
            else
                {
			    if ((e + ei)->cmt==1)
				    {
				    if ((e + ei)->pop == 1)
					    p = m2;
				    else 
					    p = m1;
				    }
                else 
				    {
				    if ((e + ei)->pop == 1)
    				    p =  2.0/(q2);
				    else 
					    p = 2.0/(q1);
				    }
				if (singlepopmode)
					{
					if (q1 <= 0)
						ps = ((e + ei)->num1 * m2) + 
							((e + ei)->num0 * m1) +
							(((e + ei)->num1 * ((e + ei)->num1 - 1))/ (q2));

					if (q2 <= 0)
						ps = ((e + ei)->num1 * m2) + 
						 ((e + ei)->num0 * m1) +
						 (((e + ei)->num0 * ((e + ei)->num0 - 1))/ (q1));
					}
				else
					{
					ps = ((e + ei)->num1 * m2) + 
						 ((e + ei)->num0 * m1) +
						 (((e + ei)->num1 * ((e + ei)->num1 - 1))/ (q2)) + 
						 (((e + ei)->num0 * ((e + ei)->num0 - 1))/ (q1));
					}
                time = (e + ei)->time;
                sumtime += time;
                tp = log(p) - time * ps;
			    }
            }
		pz += tp;
		}
	return(pz);
    } /* treeprobc */

//double treeprob(double q1, double q2, double qA, double m1, double m2, double t, double h, int *ec, struct treeevent *e, double s)    
double treeprob(double q1, double q2, double qA, double m1, double m2, double t, double h, int *ec, struct treeevent *e, unsigned long *eindex, double s)    
/* atp holds the value of treeprob that would be calculated under the old parameterization and scaling */
	{
	double p, ps, pz;
	double sumtime=0;
    int ei;
	int j;
/* calculation of the prob, given tree, checked pretty thoroughly against limiting case of no growth model */
    //return 1;

    q1 *= h;
    q2 *= h;
    qA *= h;
	pz = 0;
	//for (ei=0;ei < *ec; ei++)
	for (j=0;j < *ec; j++)
		{
		ei = *(eindex + j)-1;  // subtract - 1 because indexx sorts by assigning position values that begin at 1
        if ((e + ei)->cmt == -1)
            {
            ps = 1;
            if ((e + ei)->num0>1)
			    ps *= pnc(q1,qA,t,s,(e + ei)->time, sumtime,  (e + ei)->num0);
            if ((e + ei)->num1>1)
			    ps *=pnc(q2,qA,t,1-s,(e + ei)->time, sumtime, (e + ei)->num1);
            if ((e + ei)->num0)
			    ps *=pnm(q2,qA,m1,t,1-s,(e + ei)->time, sumtime, (e + ei)->num0);
            if ((e + ei)->num1)
			    ps *=pnm(q1,qA,m2,t,s,(e + ei)->time, sumtime, (e + ei)->num1);
            //myassert(sumtime + (e+ei)->time == t);
            sumtime = t;
            }
        else 
            {
            if (((e +ei)->time + sumtime) > t) 
			    {
                myassert((e + ei)->num1 == 0);
			    if ((e + ei)->num0 >1)
				    {
				    p =  2.0/(qA);
				    ps= (e + ei)->num0 * ((e + ei)->num0 - 1)/ (qA);
                    ps = p * exp(- (e + ei)->time * ps);
                    if (ps < MYDBL_MIN) 
                        ps = MYDBL_MIN;
				    }
                else 
                    {
                    ps = 0;
                    }
		        }
            else
                {
                ps = 1;
			    if ((e + ei)->cmt==1)
				    {
				    if ((e + ei)->pop == 1)
						{
                        myassert((e + ei)->num1>0);
                        myassert((q1 - (s) * qA) <0 ||sumtime + (e + ei)->time < t*q1/(q1 - s * qA));
                        if ((e + ei)->num0>1)
						    ps *= pnc(q1,qA,t,s,(e + ei)->time, sumtime, (e + ei)->num0);
                        if ((e + ei)->num1>1)
						    ps *=pnc(q2,qA,t,1-s,(e + ei)->time, sumtime, (e + ei)->num1);
                        if ((e + ei)->num0)
						    ps *=pnm(q2,qA,m1,t,1-s,(e + ei)->time, sumtime, (e + ei)->num0);
                        if ((e + ei)->num1)
						    ps *= pm(q1,qA,m2,t,s,(e + ei)->time, sumtime, (e + ei)->num1);
                        ps = ps;
						}
				    else 
						{
                        myassert((e + ei)->num0>0);
                        myassert((q2 - (1-s) * qA) <0 || sumtime + (e + ei)->time < t*q2/(q2 - (1-s) * qA));
                        if ((e + ei)->num0>1)
						    ps *= pnc(q1,qA,t,s,(e + ei)->time, sumtime, (e + ei)->num0);
                        if ((e + ei)->num1>1)
						    ps *=pnc(q2,qA,t,1-s,(e + ei)->time, sumtime, (e + ei)->num1);
                        if ((e + ei)->num0)
						    ps *=pm(q2,qA,m1,t,1-s,(e + ei)->time, sumtime, (e + ei)->num0);
                        if ((e + ei)->num1)
						    ps *=pnm(q1,qA,m2,t,s,(e + ei)->time, sumtime, (e + ei)->num1);
						}
				    }
                else 
				    {
				    if ((e + ei)->pop == 1)
						{
                        myassert((e + ei)->num1>1);
                        myassert((q2 - (1-s) * qA) <0 || sumtime + (e + ei)->time < t*q2/(q2 - (1-s) * qA));
                        if ((e + ei)->num0>1)
						    ps *= pnc(q1,qA,t,s,(e + ei)->time, sumtime, (e + ei)->num0);
                        if ((e + ei)->num1>1)
						    ps *=pc(q2,qA,t,1-s,(e + ei)->time, sumtime, (e + ei)->num1);
                        if ((e + ei)->num0)
						    ps *=pnm(q2,qA,m1,t,1-s,(e + ei)->time, sumtime, (e + ei)->num0);
                        if ((e + ei)->num1)
						    ps *=pnm(q1,qA,m2,t,s,(e + ei)->time, sumtime, (e + ei)->num1);
						}
				    else 
						{
                        myassert((e + ei)->num0>1);
                        myassert((q1 - (s) * qA) <0 || sumtime + (e + ei)->time < t*q1/(q1 - s * qA));
                        if ((e + ei)->num0>1)
						    ps *= pc(q1,qA,t,s,(e + ei)->time, sumtime, (e + ei)->num0);
                        if ((e + ei)->num1>1)
						    ps *=pnc(q2,qA,t,1-s,(e + ei)->time, sumtime, (e + ei)->num1);
                        if ((e + ei)->num0)
						    ps *=pnm(q2,qA,m1,t,1-s,(e + ei)->time, sumtime, (e + ei)->num0);
                        if ((e + ei)->num1)
						    ps *=pnm(q1,qA,m2,t,s,(e + ei)->time, sumtime, (e + ei)->num1);
						}
				    }
			    }
            sumtime += (e + ei)->time;
            }
        
        myassert(ps>=0);
        if (ps < MYDBL_MIN)
            ps = MYDBL_MIN;
		pz += log(ps);
        myassert(pz < MYDBL_MAX); 
		}
	return(pz );
    } /* treeprob */

/* labeltree
Rasmus's version a recursive function - it gets called for every tip branch,
 each time thru a value for .mut  for the down branch is determined.
   gets called recurseviely until the down branch is not defined.

before it is called,  all tip branches get mut = 0 or  mut = 1 depending on sequence
and all internal nodes get mut = -1

all values of -1 must be set to 0,1 or 2

states 0 and 1 are interchangeable but necessarly alternatives under infinite sites
state 2  means unknown
*/

/* void labeltree(int ci, int li, int edge)
	{
	int dow1, sis;
	
	dow1 = L[ci][li]->tree[edge].down;
	if (dow1 != -1)
		{
		
		if ((sis = L[ci][li]->tree[dow1].up[0]) == edge)
				sis = L[ci][li]->tree[dow1].up[1];
		if (L[ci][li]->tree[dow1].mut != L[ci][li]->tree[edge].mut)
			{
			if (L[ci][li]->tree[edge].mut == 2)
				{
				if (L[ci][li]->tree[sis].mut != -1)
					L[ci][li]->tree[dow1].mut = L[ci][li]->tree[sis].mut;
				else 
					L[ci][li]->tree[dow1].mut = 2;
				}
			else if ((L[ci][li]->tree[sis].mut != -1 && L[ci][li]->tree[sis].mut != 2) && (L[ci][li]->tree[sis].mut != L[ci][li]->tree[edge].mut))
				L[ci][li]->tree[dow1].mut = 2;
			else
				L[ci][li]->tree[dow1].mut = L[ci][li]->tree[edge].mut;
			labeltree(ci,li, dow1);
			}
		else if (L[ci][li]->tree[dow1].mut == 2)
			{
			if (L[ci][li]->tree[sis].mut != -1 && L[ci][li]->tree[sis].mut != 2)
				{
				L[ci][li]->tree[dow1].mut = L[ci][li]->tree[sis].mut;	
				labeltree(ci,li, dow1);
				}
			}
		}
	}	labeltree */

/* version without recursion, suggested by Jim Long as it allows inlining of the function */
__forceinline void labeltree(int ci, int li, int edge)
	{
	int dow1, sis, flag;
	struct edge *tree = L[ci][li]->tree;

	flag = 1;
	while(flag)
		{
		flag = 0;
		dow1 = tree[edge].down;
		if(dow1 == -1) break;

		if ((sis = tree[dow1].up[0]) == edge) sis = tree[dow1].up[1];

		if (tree[dow1].mut != tree[edge].mut)
			{
			  if (tree[edge].mut == 2)
			  {
				if (tree[sis].mut != -1) tree[dow1].mut = tree[sis].mut;
				else tree[dow1].mut = 2;
			  }
			  else if ((tree[sis].mut != -1 && tree[sis].mut != 2)
					&& (tree[sis].mut != tree[edge].mut))
				tree[dow1].mut = 2;
			  else
				tree[dow1].mut = tree[edge].mut;
			  flag = 1;
			}
		else if (tree[dow1].mut == 2)
			{
			  if (tree[sis].mut != -1 && tree[sis].mut != 2)
			  {
				tree[dow1].mut = tree[sis].mut;
				flag = 1;
			  }
			}
		edge = dow1;
		}
	} /* labeltree non-recursive */


/* for F84 model A=kappa+1.0; 
   for HKY85 model  A=1.0+PIj*(kappa-1.0); */
/* rasmus's function.  Jim Long  inlined this within makefrac */
 /*
double pijt(int ci, int li, double mutrate, double t, double kappa, int from, int to)
    {     
    double A, PIj, minus_t_mutrate;

    if  (to==0 || to==2) PIj=L[ci][li]->pi[0]+L[ci][li]->pi[2];
    else PIj=L[ci][li]->pi[1]+L[ci][li]->pi[3];
    A=1.0+PIj*(kappa-1.0); 
	minus_t_mutrate = -t*mutrate;
    if (from==to)
            return L[ci][li]->pi[to]+L[ci][li]->pi[to]*exp(minus_t_mutrate)*(1.0/PIj-1.0)+exp(minus_t_mutrate*A)*((PIj-L[ci][li]->pi[to])/PIj);
    else if (from+to==2 || from+to==4)
            return L[ci][li]->pi[to]+L[ci][li]->pi[to]*(1.0/PIj-1.0)*exp(minus_t_mutrate)-(L[ci][li]->pi[to]/PIj)*exp(minus_t_mutrate*A);
    else return L[ci][li]->pi[to]*(1.0-exp(minus_t_mutrate));
    }
*/
/* rasmuses makefrac */
/*Jim Long rewrote this, with inlining of pijt and some other things   
int makefrac(int node, int ci, int li, double mutrate, double kappa, int e1, int e2, int e3, int e4)
    {
     int i, j, k, up1, up2, ret=0;
    double **fracpoint1, **fracpoint2, sum[4];

    if (node == e1 || node ==  e2 || node ==  e3 || node ==  e4 || e1 == -1) ret=1; 
    up1=L[ci][li]->tree[node].up[0];
    if (up1!=-1)
        {
        up2=L[ci][li]->tree[node].up[1];
        i=makefrac(up1,ci,li, mutrate, kappa, e1, e2, e3, e4);
        if (i==0) 
			fracpoint1 = L[ci][li]->tree[up1].frac;
        else {
			fracpoint1 = L[ci][li]->tree[up1].newfrac; ret=1;}
        i=makefrac(up2,ci,li,mutrate, kappa, e1, e2, e3, e4);
        if (i==0) 
			fracpoint2 = L[ci][li]->tree[up2].frac;
        else {
			fracpoint2 = L[ci][li]->tree[up2].newfrac; ret=1;}
        if (ret>0)
            {
            if (L[ci][li]->tree[up1].up[0]==-1 && L[ci][li]->tree[up2].up[0]==-1){
                    for (i=0; i<L[ci][li]->numsites; i++)
                            for (j=0; j<4; j++)
                                   L[ci][li]->tree[node].newfrac[i][j]=pijt(ci,li,mutrate, L[ci][li]->tree[up1].time, kappa, j, L[ci][li]->seq[up1][i])*pijt(ci, li,mutrate, L[ci][li]->tree[up2].time, kappa, j, L[ci][li]->seq[up2][i]);
                    }
           else if (L[ci][li]->tree[up1].up[0]==-1)
               {
                for (i=0; i<L[ci][li]->numsites; i++){
                    for (j=0; j<4; j++)
                        {
                        L[ci][li]->tree[node].newfrac[i][j]=0;
                        for (k=0; k<4; k++)
                              L[ci][li]->tree[node].newfrac[i][j]+=pijt(ci, li,mutrate, L[ci][li]->tree[up2].time-L[ci][li]->tree[L[ci][li]->tree[up2].up[0]].time, kappa, j, k)*fracpoint2[i][k];
                        L[ci][li]->tree[node].newfrac[i][j]=L[ci][li]->tree[node].newfrac[i][j]*pijt(ci,li,mutrate, L[ci][li]->tree[up1].time, kappa, j, L[ci][li]->seq[up1][i]);
                        }
                    }
                }
           else 
               if (L[ci][li]->tree[up2].up[0]==-1)
                   {
                   for (i=0; i<L[ci][li]->numsites; i++)
                       {
                        for (j=0; j<4; j++)
                            {
                            L[ci][li]->tree[node].newfrac[i][j]=0;
                            for (k=0; k<4; k++)
                                  L[ci][li]->tree[node].newfrac[i][j]+=pijt(ci, li,mutrate, L[ci][li]->tree[up1].time-L[ci][li]->tree[L[ci][li]->tree[up1].up[0]].time, kappa, j, k)*fracpoint1[i][k];
                            L[ci][li]->tree[node].newfrac[i][j]=L[ci][li]->tree[node].newfrac[i][j]*pijt(ci,li,mutrate, L[ci][li]->tree[up2].time, kappa, j, L[ci][li]->seq[up2][i]);
                            }
                        }
                    }
           else
               {
                for (i=0; i<L[ci][li]->numsites; i++){
                    for (j=0; j<4; j++)
                        {
                        sum[j]=0;
                        for (k=0; k<4; k++)
                              sum[j]+=pijt(ci, li,mutrate, L[ci][li]->tree[up1].time-L[ci][li]->tree[L[ci][li]->tree[up1].up[0]].time, kappa, j, k)*fracpoint1[i][k];
                        L[ci][li]->tree[node].newfrac[i][j]=0;
                        for (k=0; k<4; k++)
                              L[ci][li]->tree[node].newfrac[i][j]+=pijt(ci,li,mutrate, L[ci][li]->tree[up2].time-L[ci][li]->tree[L[ci][li]->tree[up2].up[0]].time, kappa, j, k)*fracpoint2[i][k];
                        L[ci][li]->tree[node].newfrac[i][j]=L[ci][li]->tree[node].newfrac[i][j]*sum[j];
                        }
                    }
                }
            }
        }
    return ret;
    }  Rasmuses makefrac */

/* Long's faster makefrac  - but does not have scalefactors 
int makefrac (int node, int ci, int li, double mutrate, double kappa,   int e1, int e2, int e3, int e4)
{
  int i, j, up1, up2, ret = 0;
  double **fracpoint1, **fracpoint2;

  int stmp[2];
  double expp[2], kpa=kappa-1.0, A_j[2], L_to[4], PI_j[2], sum[4], temp[4];
  double minus_t_mutrate1, minus_t_mutrate2, exp1[2], exp2[2], onem[2];
  double A[2], PIj[2], divm[2], mdiv[2], pijt1, pijt2, ptmp[4], *pi  = L[ci][li]->pi;
  struct edge *tree = L[ci][li]->tree;

  if (node == e1 || node == e2 || node == e3 || node == e4 || e1 == -1)
    ret = 1;

  up1 = tree[node].up[0];

  if (up1 != -1)
  {
    up2 = tree[node].up[1];

    i = makefrac (up1, ci, li, mutrate, kappa, e1, e2, e3, e4);

    if (i == 0)
      fracpoint1 = tree[up1].frac;
    else
    {
      fracpoint1 = tree[up1].newfrac;
      ret = 1;
    }

    i = makefrac (up2, ci, li, mutrate, kappa, e1, e2, e3, e4);

    if (i == 0)
      fracpoint2 = tree[up2].frac;
    else
    {
      fracpoint2 = tree[up2].newfrac;
      ret = 1;
    }

    if (ret > 0)
    {
      if (tree[up1].up[0]== -1 && tree[up2].up[0]== -1)
      {
        minus_t_mutrate1 = -mutrate * tree[up1].time;
        minus_t_mutrate2 = -mutrate * tree[up2].time;
        expp[0] = exp(minus_t_mutrate1);
        expp[1] = exp(minus_t_mutrate2);

        for (i = 0; i < L[ci][li]->numsites; i++)
        {
          stmp[0] = L[ci][li]->seq[up1][i];
          stmp[1] = L[ci][li]->seq[up2][i];
        
          L_to[0] = pi[stmp[0]];
          L_to[1] = pi[stmp[1]];
          
          if(stmp[0] == 0 || stmp[0] == 2) PIj[0] = pi[0] + pi[2];
          else  PIj[0] = pi[1] + pi[3];
          if(stmp[1] == 0 || stmp[1] == 2) PIj[1] = pi[0] + pi[2];
          else  PIj[1] = pi[1] + pi[3];
          
          A[0] = 1.0 + PIj[0] * kpa;
          divm[0] = 1.0 / PIj[0] - 1.0;
          mdiv[0] = (PIj[0] - L_to[0]) / PIj[0];
          
          A[1] = 1.0 + PIj[1] * kpa;
          divm[1] = 1.0 / PIj[1] - 1.0;
          mdiv[1] = (PIj[1] - L_to[1]) / PIj[1];
          
          for(j=0; j<4; j++)
          {
            if(stmp[0] == j)
              pijt1 = L_to[0] + L_to[0] * expp[0] * divm[0] +
        	      exp(minus_t_mutrate1*A[0])  * mdiv[0];
            else if(stmp[0] + j == 2 || stmp[0] + j == 4)
              pijt1 = L_to[0] + L_to[0] * expp[0] * divm[0] -
        	     (L_to[0] / PIj[0]) * exp(minus_t_mutrate1*A[0]);
            else
              pijt1 = L_to[0] * (1.0 - expp[0]);
            
            if(stmp[1] == j)
              pijt2 = L_to[1] + L_to[1] * expp[1] * divm[1] +
        	      exp(minus_t_mutrate2*A[1])  * mdiv[1];
            else if(stmp[1] + j == 2 || stmp[1] + j == 4)
              pijt2 = L_to[1] + L_to[1] * expp[1] * divm[1] -
        	     (L_to[1] / PIj[1]) * exp(minus_t_mutrate2*A[1]);
            else
              pijt2 = L_to[1] * (1.0 - expp[1]);
            
            tree[node].newfrac[i][j] = pijt1 * pijt2;
          }
        }
      }
      else if (tree[up1].up[0] == -1)
      {
        minus_t_mutrate1 = -mutrate*(tree[up2].time-tree[tree[up2].up[0]].time);
        minus_t_mutrate2 = -mutrate* tree[up1].time;
        expp[0] = exp(minus_t_mutrate1);
        onem[0] = 1.0 - expp[0];
        expp[1] = exp(minus_t_mutrate2);
        
        PI_j[0] = pi[0] + pi[2];
        PI_j[1] = pi[1] + pi[3];
        A_j[0]  = 1.0 + PI_j[0] * kpa;
        A_j[1]  = 1.0 + PI_j[1] * kpa;
        divm[0] = 1.0 / PI_j[0] - 1.0;
        divm[1] = 1.0 / PI_j[1] - 1.0;
        exp1[0] = exp(minus_t_mutrate1*A_j[0]);
        exp1[1] = exp(minus_t_mutrate1*A_j[1]);
	exp2[0] = exp(minus_t_mutrate2*A_j[0]);
	exp2[1] = exp(minus_t_mutrate2*A_j[1]);
        
        for (i = 0; i < L[ci][li]->numsites; i++)
        {
          tree[node].newfrac[i][0] = 0;
          tree[node].newfrac[i][1] = 0;
          tree[node].newfrac[i][2] = 0;
          tree[node].newfrac[i][3] = 0;
        
	  stmp[0] = L[ci][li]->seq[up1][i];
          
          if(stmp[0] == 0 || stmp[0] == 2) 
          {
            for(j=0; j<4; j++)
            {
              if(stmp[0] == j)
        	ptmp[j] = pi[stmp[0]] + pi[stmp[0]] * expp[1] * divm[0] +
        		  exp2[0] * ((PI_j[0] - pi[stmp[0]])/PI_j[0]);
              else if(stmp[0] + j == 2 || stmp[0] + j == 4)
        	ptmp[j] = pi[stmp[0]] + pi[stmp[0]] * expp[1] * divm[0] -
        		 (pi[stmp[0]]/PI_j[0]) * exp2[0];
              else
        	ptmp[j] = pi[stmp[0]] * (1.0 - expp[1]);
            }
          }
          else 
          {
            for(j=0; j<4; j++)
            {
              if(stmp[0] == j)
        	ptmp[j] = pi[stmp[0]] + pi[stmp[0]] * expp[1] * divm[1] +
        		  exp2[1] * ((PI_j[1] - pi[stmp[0]])/PI_j[1]);
              else if(stmp[0] + j == 2 || stmp[0] + j == 4)
        	ptmp[j] = pi[stmp[0]] + pi[stmp[0]] * expp[1] * divm[1] -
        		 (pi[stmp[0]]/PI_j[1]) * exp2[1];
              else
        	ptmp[j] = pi[stmp[0]] * (1.0 - expp[1]);
            }
          }

          temp[0] = (pi[0] + pi[0] * expp[0] * divm[0] + exp1[0] *
        	   ((PI_j[0] - pi[0]) / PI_j[0])) * fracpoint2[i][0];
          temp[1] = (pi[1] * onem[0]) * fracpoint2[i][1];
          temp[2] = (pi[2] + pi[2] * expp[0] * divm[0] - exp1[0] *
        	    (pi[2] / PI_j[0])) * fracpoint2[i][2];
          temp[3] = (pi[3] * onem[0]) * fracpoint2[i][3];
          tree[node].newfrac[i][0] += temp[0]+temp[1]+temp[2]+temp[3];
          tree[node].newfrac[i][0] *= ptmp[0];


          temp[0] = (pi[0] * onem[0]) * fracpoint2[i][0];
          temp[1] = (pi[1] + pi[1] * expp[0] * divm[1] + exp1[1] *
        	    ((PI_j[1] - pi[1]) / PI_j[1])) * fracpoint2[i][1];
          temp[2] = (pi[2] * onem[0]) * fracpoint2[i][2];
          temp[3] = (pi[3] + pi[3] * expp[0] * divm[1] - exp1[1] *
        	    (pi[3] / PI_j[1])) * fracpoint2[i][3];
          tree[node].newfrac[i][1] += temp[0]+temp[1]+temp[2]+temp[3];
          tree[node].newfrac[i][1] *= ptmp[1];


          temp[0] = (pi[0] + pi[0] * expp[0] * divm[0] - exp1[0] *
        	    (pi[0] / PI_j[0])) * fracpoint2[i][0];
          temp[1] = (pi[1] * onem[0]) * fracpoint2[i][1];
          temp[2] = (pi[2] + pi[2] * expp[0] * divm[0] + exp1[0] *
        	    ((PI_j[0] - pi[2]) / PI_j[0])) * fracpoint2[i][2];
          temp[3] = (pi[3] * onem[0]) * fracpoint2[i][3];
          tree[node].newfrac[i][2] += temp[0]+temp[1]+temp[2]+temp[3];
          tree[node].newfrac[i][2] *= ptmp[2];


          temp[0] = (pi[0] * onem[0]) * fracpoint2[i][0];
          temp[1] = (pi[1] + pi[1] * expp[0] * divm[1] - exp1[1] *
        	    (pi[1] / PI_j[1])) * fracpoint2[i][1];
          temp[2] = (pi[2] * onem[0]) * fracpoint2[i][2];
          temp[3] = (pi[3] + pi[3] * expp[0] * divm[1] + exp1[1] *
        	    ((PI_j[1] - pi[3]) / PI_j[1])) * fracpoint2[i][3];
          tree[node].newfrac[i][3] += temp[0]+temp[1]+temp[2]+temp[3];
          tree[node].newfrac[i][3] *= ptmp[3];
        }
      }
      else if (tree[up2].up[0] == -1)
      {
        minus_t_mutrate1 = -mutrate*(tree[up1].time-tree[tree[up1].up[0]].time);
        minus_t_mutrate2 = -mutrate* tree[up2].time;
        expp[0] = exp(minus_t_mutrate1);
        onem[0] = 1.0 - expp[0];
        expp[1] = exp(minus_t_mutrate2);
        
	PI_j[0] = pi[0] + pi[2];
	PI_j[1] = pi[1] + pi[3];
	A_j[0]  = 1.0 + PI_j[0] * kpa;
	A_j[1]  = 1.0 + PI_j[1] * kpa;
	divm[0] = 1.0 / PI_j[0] - 1.0;
	divm[1] = 1.0 / PI_j[1] - 1.0;
	exp1[0] = exp(minus_t_mutrate1*A_j[0]);
	exp1[1] = exp(minus_t_mutrate1*A_j[1]);
	exp2[0] = exp(minus_t_mutrate2*A_j[0]);
	exp2[1] = exp(minus_t_mutrate2*A_j[1]);

        for (i = 0; i < L[ci][li]->numsites; i++)
        {
          tree[node].newfrac[i][0] = 0;
          tree[node].newfrac[i][1] = 0;
          tree[node].newfrac[i][2] = 0;
          tree[node].newfrac[i][3] = 0;
          
	  stmp[0] = L[ci][li]->seq[up2][i];
          
          if(stmp[0] == 0 || stmp[0] == 2) 
          {
            for(j=0; j<4; j++)
            {
              if(stmp[0] == j)
        	ptmp[j] = pi[stmp[0]] + pi[stmp[0]] * expp[1] * divm[0] +
        		  exp2[0] * ((PI_j[0] - pi[stmp[0]])/PI_j[0]);
              else if(stmp[0] + j == 2 || stmp[0] + j == 4)
        	ptmp[j] = pi[stmp[0]] + pi[stmp[0]] * expp[1] * divm[0] -
        		 (pi[stmp[0]]/PI_j[0]) * exp2[0];
              else
        	ptmp[j] = pi[stmp[0]] * (1.0 - expp[1]);
            }
          }
          else 
          {
            for(j=0; j<4; j++)
            {
              if(stmp[0] == j)
        	ptmp[j] = pi[stmp[0]] + pi[stmp[0]] * expp[1] * divm[1] +
        		  exp2[1] * ((PI_j[1] - pi[stmp[0]])/PI_j[1]);
              else if(stmp[0] + j == 2 || stmp[0] + j == 4)
        	ptmp[j] = pi[stmp[0]] + pi[stmp[0]] * expp[1] * divm[1] -
        		 (pi[stmp[0]]/PI_j[1]) * exp2[1];
              else
        	ptmp[j] = pi[stmp[0]] * (1.0 - expp[1]);
            }
          }

          temp[0] = (pi[0] + pi[0] * expp[0] * divm[0] + exp1[0] *
        	    ((PI_j[0] - pi[0]) / PI_j[0])) * fracpoint1[i][0];
          temp[1] = (pi[1] * onem[0]) * fracpoint1[i][1];
          temp[2] = (pi[2] + pi[2] * expp[0] * divm[0] - exp1[0] *
        	    (pi[2] / PI_j[0])) * fracpoint1[i][2];
          temp[3] = (pi[3] * onem[0]) * fracpoint1[i][3];
          tree[node].newfrac[i][0] += temp[0]+temp[1]+temp[2]+temp[3];
          tree[node].newfrac[i][0] *= ptmp[0];


          temp[0] = (pi[0] * onem[0]) * fracpoint1[i][0];
          temp[1] = (pi[1] + pi[1] * expp[0] * divm[1] + exp1[1] *
        	    ((PI_j[1] - pi[1]) / PI_j[1])) * fracpoint1[i][1];
          temp[2] = (pi[2] * onem[0]) * fracpoint1[i][2];
          temp[3] = (pi[3] + pi[3] * expp[0] * divm[1] - exp1[1] *
        	    (pi[3] / PI_j[1])) * fracpoint1[i][3];
          tree[node].newfrac[i][1] += temp[0]+temp[1]+temp[2]+temp[3];
          tree[node].newfrac[i][1] *= ptmp[1];


          temp[0] = (pi[0] + pi[0] * expp[0] * divm[0] - exp1[0] *
        	    (pi[0] / PI_j[0])) * fracpoint1[i][0];
          temp[1] = (pi[1] * onem[0]) * fracpoint1[i][1];
          temp[2] = (pi[2] + pi[2] * expp[0] * divm[0] + exp1[0] *
        	    ((PI_j[0] - pi[2]) / PI_j[0])) * fracpoint1[i][2];
          temp[3] = (pi[3] * onem[0]) * fracpoint1[i][3];
          tree[node].newfrac[i][2] += temp[0]+temp[1]+temp[2]+temp[3];
          tree[node].newfrac[i][2] *= ptmp[2];


          temp[0] = (pi[0] * onem[0]) * fracpoint1[i][0];
          temp[1] = (pi[1] + pi[1] * expp[0] * divm[1] - exp1[1] *
        	    (pi[1] / PI_j[1])) * fracpoint1[i][1];
          temp[2] = (pi[2] * onem[0]) * fracpoint1[i][2];
          temp[3] = (pi[3] + pi[3] * expp[0] * divm[1] + exp1[1] *
        	    ((PI_j[1] - pi[3]) / PI_j[1])) * fracpoint1[i][3];
          tree[node].newfrac[i][3] += temp[0]+temp[1]+temp[2]+temp[3];
          tree[node].newfrac[i][3] *= ptmp[3];
        }
      }
      else
      {
        minus_t_mutrate1 = -mutrate*(tree[up1].time-tree[tree[up1].up[0]].time);
        minus_t_mutrate2 = -mutrate*(tree[up2].time-tree[tree[up2].up[0]].time);
        expp[0] = exp(minus_t_mutrate1);
        onem[0] = 1.0 - expp[0];
        expp[1] = exp(minus_t_mutrate2);
        onem[1] = 1.0 - expp[1];
        
	PI_j[0] = pi[0] + pi[2];
	PI_j[1] = pi[1] + pi[3];
	A_j[0]  = 1.0 + PI_j[0] * kpa;
	A_j[1]  = 1.0 + PI_j[1] * kpa;
	divm[0] = 1.0 / PI_j[0] - 1.0;
	divm[1] = 1.0 / PI_j[1] - 1.0;
	exp1[0] = exp(minus_t_mutrate1*A_j[0]);
	exp1[1] = exp(minus_t_mutrate1*A_j[1]);
	exp2[0] = exp(minus_t_mutrate2*A_j[0]);
	exp2[1] = exp(minus_t_mutrate2*A_j[1]);

        for (i = 0; i < L[ci][li]->numsites; i++)
        {
          sum[0] = 0;
          sum[1] = 0;
          sum[2] = 0;
          sum[3] = 0;
          tree[node].newfrac[i][0] = 0;
          tree[node].newfrac[i][1] = 0;
          tree[node].newfrac[i][2] = 0;
          tree[node].newfrac[i][3] = 0;

          temp[0] = (pi[0] + pi[0] * expp[0] * divm[0] + exp1[0] *
        	    ((PI_j[0] - pi[0]) /PI_j[0])) * fracpoint1[i][0];
          temp[1] = (pi[1] * onem[0]) * fracpoint1[i][1];
          temp[2] = (pi[2] + pi[2] * expp[0] * divm[0] - exp1[0] *
        	    (pi[2] / PI_j[0])) * fracpoint1[i][2];
          temp[3] = (pi[3] * onem[0]) * fracpoint1[i][3];
          sum[0] += temp[0]+temp[1]+temp[2]+temp[3];
        	    
          temp[0] = (pi[0] + pi[0] * expp[1] * divm[0] + exp2[0] *
        	    ((PI_j[0] - pi[0]) / PI_j[0])) * fracpoint2[i][0];
          temp[1] = (pi[1] * onem[1]) * fracpoint2[i][1];
          temp[2] = (pi[2] + pi[2] * expp[1] * divm[0] - exp2[0] *
        	    (pi[2] / PI_j[0])) * fracpoint2[i][2];
          temp[3] = (pi[3] * onem[1]) * fracpoint2[i][3];
	  tree[node].newfrac[i][0] += temp[0]+temp[1]+temp[2]+temp[3];
	  tree[node].newfrac[i][0] *= sum[0];

        
          temp[0] = (pi[0] * onem[0]) * fracpoint1[i][0];
          temp[1] = (pi[1] + pi[1] * expp[0] * divm[1] + exp1[1] *
        	    ((PI_j[1] - pi[1]) /PI_j[1])) * fracpoint1[i][1];
          temp[2] = (pi[2] * onem[0]) * fracpoint1[i][2];
          temp[3] = (pi[3] + pi[3] * expp[0] * divm[1] - exp1[1] *
        	    (pi[3] / PI_j[1])) * fracpoint1[i][3];
          sum[1] += temp[0]+temp[1]+temp[2]+temp[3];
        	    
          temp[0] = (pi[0] * onem[1]) * fracpoint2[i][0];
          temp[1] = (pi[1] + pi[1] * expp[1] * divm[1] + exp2[1] *
        	    ((PI_j[1] - pi[1]) / PI_j[1])) * fracpoint2[i][1];
          temp[2] = (pi[2] * onem[1]) * fracpoint2[i][2];
          temp[3] = (pi[3] + pi[3] * expp[1] * divm[1] - exp2[1] *
        	    (pi[3] / PI_j[1])) * fracpoint2[i][3];
          tree[node].newfrac[i][1] += temp[0]+temp[1]+temp[2]+temp[3];
          tree[node].newfrac[i][1] *= sum[1];

        
          temp[0] = (pi[0] + pi[0] * expp[0] * divm[0] - exp1[0] *
        	    (pi[0] / PI_j[0])) * fracpoint1[i][0];
          temp[1] = (pi[1] * onem[0]) * fracpoint1[i][1];
          temp[2] = (pi[2] + pi[2] * expp[0] * divm[0] + exp1[0] *
        	    ((PI_j[0] - pi[2]) / PI_j[0])) * fracpoint1[i][2];
          temp[3] = (pi[3] * onem[0]) * fracpoint1[i][3];
          sum[2] += temp[0]+temp[1]+temp[2]+temp[3];
        	    
          temp[0] = (pi[0] + pi[0] * expp[1] * divm[0] - exp2[0] *
        	    (pi[0] / PI_j[0])) * fracpoint2[i][0];
          temp[1] = (pi[1] * onem[1]) * fracpoint2[i][1];
          temp[2] = (pi[2] + pi[2] * expp[1] * divm[0] + exp2[0] *
        	    ((PI_j[0] - pi[2]) /PI_j[0])) * fracpoint2[i][2];
          temp[3] = (pi[3] * onem[1]) * fracpoint2[i][3];
          tree[node].newfrac[i][2] += temp[0]+temp[1]+temp[2]+temp[3];
          tree[node].newfrac[i][2] *= sum[2];

        
          temp[0] = (pi[0] * onem[0]) * fracpoint1[i][0];
          temp[1] = (pi[1] + pi[1] * expp[0] * divm[1] - exp1[1] *
        	    (pi[1] / PI_j[1])) * fracpoint1[i][1];
          temp[2] = (pi[2] * onem[0]) * fracpoint1[i][2];
          temp[3] = (pi[3] + pi[3] * expp[0] * divm[1] + exp1[1] *
        	    ((PI_j[1] - pi[3]) /PI_j[1])) * fracpoint1[i][3];
          sum[3] += temp[0]+temp[1]+temp[2]+temp[3];
        	    
          temp[0] = (pi[0] * onem[1]) * fracpoint2[i][0];
          temp[1] = (pi[1] + pi[1] * expp[1] * divm[1] - exp2[1] *
        	    (pi[1] / PI_j[1])) * fracpoint2[i][1];
          temp[2] = (pi[2] * onem[1]) * fracpoint2[i][2];
          temp[3] = (pi[3] + pi[3] * expp[1] * divm[1] + exp2[1] *
        	    ((PI_j[1] - pi[3]) /PI_j[1])) * fracpoint2[i][3];
          tree[node].newfrac[i][3] += temp[0]+temp[1]+temp[2]+temp[3];
          tree[node].newfrac[i][3] *= sum[3];
        }
      }
    }
  }

  return ret;
}  Long's makefrac but without scalefactors */

 // Jim Long's unwrapped makefrac()  with scalefactors

int makefrac (int node, int ci, int li, double mutrate, double kappa,   int e1, int e2, int e3, int e4)
{
  int i, j, up1, up2, ret = 0;
  double **fracpoint1, **fracpoint2;

  /* variables to precompute values */

  int stmp[2];
  double expp[2], kpa=kappa-1.0, A_j[2], L_to[4], PI_j[2], sum[4], temp[4];
  double minus_t_mutrate1, minus_t_mutrate2, exp1[2], exp2[2], onem[2];
  double A[2], PIj[2], divm[2], mdiv[2], pijt1, pijt2, ptmp[4], *pi  = L[ci][li]->pi;
  struct edge *tree = L[ci][li]->tree;
  double max;


  if (node == e1 || node == e2 || node == e3 || node == e4 || e1 == -1)
    ret = 1;

  up1 = tree[node].up[0];

  if (up1 != -1)
  {
    up2 = tree[node].up[1];

    i = makefrac (up1, ci, li, mutrate, kappa, e1, e2, e3, e4);

    if (i == 0)
      fracpoint1 = tree[up1].frac;
    else
    {
      fracpoint1 = tree[up1].newfrac;
      ret = 1;
    }

    i = makefrac (up2,ci, li,mutrate, kappa, e1, e2, e3, e4);

    if (i == 0)
      fracpoint2 = tree[up2].frac;
    else
    {
      fracpoint2 = tree[up2].newfrac;
      ret = 1;
    }

    if (ret > 0)
    {
      if (tree[up1].up[0]== -1 && tree[up2].up[0]== -1)
      {
        minus_t_mutrate1 = -mutrate * tree[up1].time;
        minus_t_mutrate2 = -mutrate * tree[up2].time;
        expp[0] = exp(minus_t_mutrate1);
        expp[1] = exp(minus_t_mutrate2);

        for (i = 0; i < L[ci][li]->numsites; i++)
        {
          stmp[0] = L[ci][li]->seq[up1][i];
          stmp[1] = L[ci][li]->seq[up2][i];
        
          L_to[0] = pi[stmp[0]];
          L_to[1] = pi[stmp[1]];
          
          if(stmp[0] == 0 || stmp[0] == 2) PIj[0] = pi[0] + pi[2];
          else  PIj[0] = pi[1] + pi[3];
          if(stmp[1] == 0 || stmp[1] == 2) PIj[1] = pi[0] + pi[2];
          else  PIj[1] = pi[1] + pi[3];
          
          A[0] = 1.0 + PIj[0] * kpa;
          divm[0] = 1.0 / PIj[0] - 1.0;
          mdiv[0] = (PIj[0] - L_to[0]) / PIj[0];
          
          A[1] = 1.0 + PIj[1] * kpa;
          divm[1] = 1.0 / PIj[1] - 1.0;
          mdiv[1] = (PIj[1] - L_to[1]) / PIj[1];
          max=0.0;
          for(j=0; j<4; j++)
          {
            if(stmp[0] == j)
              pijt1 = L_to[0] + L_to[0] * expp[0] * divm[0] +
        	      exp(minus_t_mutrate1*A[0])  * mdiv[0];
            else if(stmp[0] + j == 2 || stmp[0] + j == 4)
              pijt1 = L_to[0] + L_to[0] * expp[0] * divm[0] -
        	     (L_to[0] / PIj[0]) * exp(minus_t_mutrate1*A[0]);
            else
              pijt1 = L_to[0] * (1.0 - expp[0]);
            
            if(stmp[1] == j)
              pijt2 = L_to[1] + L_to[1] * expp[1] * divm[1] +
        	      exp(minus_t_mutrate2*A[1])  * mdiv[1];
            else if(stmp[1] + j == 2 || stmp[1] + j == 4)
              pijt2 = L_to[1] + L_to[1] * expp[1] * divm[1] -
        	     (L_to[1] / PIj[1]) * exp(minus_t_mutrate2*A[1]);
            else
              pijt2 = L_to[1] * (1.0 - expp[1]);
            
            tree[node].newfrac[i][j] = pijt1 * pijt2;
			if (tree[node].newfrac[i][j]>max) max=tree[node].newfrac[i][j];
          }
		for (j=0; j<4; j++)
		   tree[node].newfrac[i][j]=tree[node].newfrac[i][j]/max;
        tree[node].scalefactor[i]=log(max);
        }
      }
      else if (tree[up1].up[0] == -1)
      {
        minus_t_mutrate1 = -mutrate*(tree[up2].time-tree[tree[up2].up[0]].time);
        minus_t_mutrate2 = -mutrate* tree[up1].time;
        expp[0] = exp(minus_t_mutrate1);
        onem[0] = 1.0 - expp[0];
        expp[1] = exp(minus_t_mutrate2);
        
        PI_j[0] = pi[0] + pi[2];
        PI_j[1] = pi[1] + pi[3];
        A_j[0]  = 1.0 + PI_j[0] * kpa;
        A_j[1]  = 1.0 + PI_j[1] * kpa;
        divm[0] = 1.0 / PI_j[0] - 1.0;
        divm[1] = 1.0 / PI_j[1] - 1.0;
        exp1[0] = exp(minus_t_mutrate1*A_j[0]);
        exp1[1] = exp(minus_t_mutrate1*A_j[1]);
	exp2[0] = exp(minus_t_mutrate2*A_j[0]);
	exp2[1] = exp(minus_t_mutrate2*A_j[1]);
        
        for (i = 0; i < L[ci][li]->numsites; i++)
        {
		  max = 0.0;
          tree[node].newfrac[i][0] = 0;
          tree[node].newfrac[i][1] = 0;
          tree[node].newfrac[i][2] = 0;
          tree[node].newfrac[i][3] = 0;
        
	  stmp[0] = L[ci][li]->seq[up1][i];
          
          if(stmp[0] == 0 || stmp[0] == 2) /* use PI_j[0] & A_j[0] */
          {
            for(j=0; j<4; j++)
            {
              if(stmp[0] == j)
        	ptmp[j] = pi[stmp[0]] + pi[stmp[0]] * expp[1] * divm[0] +
        		  exp2[0] * ((PI_j[0] - pi[stmp[0]])/PI_j[0]);
              else if(stmp[0] + j == 2 || stmp[0] + j == 4)
        	ptmp[j] = pi[stmp[0]] + pi[stmp[0]] * expp[1] * divm[0] -
        		 (pi[stmp[0]]/PI_j[0]) * exp2[0];
              else
        	ptmp[j] = pi[stmp[0]] * (1.0 - expp[1]);
            }
          }
          else /* use PI_j[1] & A_j[1] */
          {
            for(j=0; j<4; j++)
            {
              if(stmp[0] == j)
        	ptmp[j] = pi[stmp[0]] + pi[stmp[0]] * expp[1] * divm[1] +
        		  exp2[1] * ((PI_j[1] - pi[stmp[0]])/PI_j[1]);
              else if(stmp[0] + j == 2 || stmp[0] + j == 4)
        	ptmp[j] = pi[stmp[0]] + pi[stmp[0]] * expp[1] * divm[1] -
        		 (pi[stmp[0]]/PI_j[1]) * exp2[1];
              else
        	ptmp[j] = pi[stmp[0]] * (1.0 - expp[1]);
            }
          }

          temp[0] = (pi[0] + pi[0] * expp[0] * divm[0] + exp1[0] *
        	   ((PI_j[0] - pi[0]) / PI_j[0])) * fracpoint2[i][0];
          temp[1] = (pi[1] * onem[0]) * fracpoint2[i][1];
          temp[2] = (pi[2] + pi[2] * expp[0] * divm[0] - exp1[0] *
        	    (pi[2] / PI_j[0])) * fracpoint2[i][2];
          temp[3] = (pi[3] * onem[0]) * fracpoint2[i][3];
          tree[node].newfrac[i][0] += temp[0]+temp[1]+temp[2]+temp[3];
          tree[node].newfrac[i][0] *= ptmp[0];


          temp[0] = (pi[0] * onem[0]) * fracpoint2[i][0];
          temp[1] = (pi[1] + pi[1] * expp[0] * divm[1] + exp1[1] *
        	    ((PI_j[1] - pi[1]) / PI_j[1])) * fracpoint2[i][1];
          temp[2] = (pi[2] * onem[0]) * fracpoint2[i][2];
          temp[3] = (pi[3] + pi[3] * expp[0] * divm[1] - exp1[1] *
        	    (pi[3] / PI_j[1])) * fracpoint2[i][3];
          tree[node].newfrac[i][1] += temp[0]+temp[1]+temp[2]+temp[3];
          tree[node].newfrac[i][1] *= ptmp[1];


          temp[0] = (pi[0] + pi[0] * expp[0] * divm[0] - exp1[0] *
        	    (pi[0] / PI_j[0])) * fracpoint2[i][0];
          temp[1] = (pi[1] * onem[0]) * fracpoint2[i][1];
          temp[2] = (pi[2] + pi[2] * expp[0] * divm[0] + exp1[0] *
        	    ((PI_j[0] - pi[2]) / PI_j[0])) * fracpoint2[i][2];
          temp[3] = (pi[3] * onem[0]) * fracpoint2[i][3];
          tree[node].newfrac[i][2] += temp[0]+temp[1]+temp[2]+temp[3];
          tree[node].newfrac[i][2] *= ptmp[2];


          temp[0] = (pi[0] * onem[0]) * fracpoint2[i][0];
          temp[1] = (pi[1] + pi[1] * expp[0] * divm[1] - exp1[1] *
        	    (pi[1] / PI_j[1])) * fracpoint2[i][1];
          temp[2] = (pi[2] * onem[0]) * fracpoint2[i][2];
          temp[3] = (pi[3] + pi[3] * expp[0] * divm[1] + exp1[1] *
        	    ((PI_j[1] - pi[3]) / PI_j[1])) * fracpoint2[i][3];
          tree[node].newfrac[i][3] += temp[0]+temp[1]+temp[2]+temp[3];
          tree[node].newfrac[i][3] *= ptmp[3];
		  for(j=0; j<4; j++)
			if (tree[node].newfrac[i][j]>max) max=tree[node].newfrac[i][j];
		  for (j=0; j<4; j++)
            tree[node].newfrac[i][j]=tree[node].newfrac[i][j]/max;
		  tree[node].scalefactor[i]=tree[up2].scalefactor[i]+log(max);
        }
      }
      else if (tree[up2].up[0] == -1)
      {
        minus_t_mutrate1 = -mutrate*(tree[up1].time-tree[tree[up1].up[0]].time);
        minus_t_mutrate2 = -mutrate* tree[up2].time;
        expp[0] = exp(minus_t_mutrate1);
        onem[0] = 1.0 - expp[0];
        expp[1] = exp(minus_t_mutrate2);
        
		PI_j[0] = pi[0] + pi[2];
		PI_j[1] = pi[1] + pi[3];
		A_j[0]  = 1.0 + PI_j[0] * kpa;
		A_j[1]  = 1.0 + PI_j[1] * kpa;
		divm[0] = 1.0 / PI_j[0] - 1.0;
		divm[1] = 1.0 / PI_j[1] - 1.0;
		exp1[0] = exp(minus_t_mutrate1*A_j[0]);
		exp1[1] = exp(minus_t_mutrate1*A_j[1]);
		exp2[0] = exp(minus_t_mutrate2*A_j[0]);
		exp2[1] = exp(minus_t_mutrate2*A_j[1]);

        for (i = 0; i < L[ci][li]->numsites; i++)
        {
		  max = 0.0;
          tree[node].newfrac[i][0] = 0;
          tree[node].newfrac[i][1] = 0;
          tree[node].newfrac[i][2] = 0;
          tree[node].newfrac[i][3] = 0;
          
	  stmp[0] = L[ci][li]->seq[up2][i];
          
          if(stmp[0] == 0 || stmp[0] == 2) /* use PI_j[0] & A_j[0] */
          {
            for(j=0; j<4; j++)
            {
              if(stmp[0] == j)
        	ptmp[j] = pi[stmp[0]] + pi[stmp[0]] * expp[1] * divm[0] +
        		  exp2[0] * ((PI_j[0] - pi[stmp[0]])/PI_j[0]);
              else if(stmp[0] + j == 2 || stmp[0] + j == 4)
        	ptmp[j] = pi[stmp[0]] + pi[stmp[0]] * expp[1] * divm[0] -
        		 (pi[stmp[0]]/PI_j[0]) * exp2[0];
              else
        	ptmp[j] = pi[stmp[0]] * (1.0 - expp[1]);
            }
          }
          else /* use PI_j[1] & A_j[1] */
          {
            for(j=0; j<4; j++)
            {
              if(stmp[0] == j)
        	ptmp[j] = pi[stmp[0]] + pi[stmp[0]] * expp[1] * divm[1] +
        		  exp2[1] * ((PI_j[1] - pi[stmp[0]])/PI_j[1]);
              else if(stmp[0] + j == 2 || stmp[0] + j == 4)
        	ptmp[j] = pi[stmp[0]] + pi[stmp[0]] * expp[1] * divm[1] -
        		 (pi[stmp[0]]/PI_j[1]) * exp2[1];
              else
        	ptmp[j] = pi[stmp[0]] * (1.0 - expp[1]);
            }
          }

          temp[0] = (pi[0] + pi[0] * expp[0] * divm[0] + exp1[0] *
        	    ((PI_j[0] - pi[0]) / PI_j[0])) * fracpoint1[i][0];
          temp[1] = (pi[1] * onem[0]) * fracpoint1[i][1];
          temp[2] = (pi[2] + pi[2] * expp[0] * divm[0] - exp1[0] *
        	    (pi[2] / PI_j[0])) * fracpoint1[i][2];
          temp[3] = (pi[3] * onem[0]) * fracpoint1[i][3];
          tree[node].newfrac[i][0] += temp[0]+temp[1]+temp[2]+temp[3];
          tree[node].newfrac[i][0] *= ptmp[0];


          temp[0] = (pi[0] * onem[0]) * fracpoint1[i][0];
          temp[1] = (pi[1] + pi[1] * expp[0] * divm[1] + exp1[1] *
        	    ((PI_j[1] - pi[1]) / PI_j[1])) * fracpoint1[i][1];
          temp[2] = (pi[2] * onem[0]) * fracpoint1[i][2];
          temp[3] = (pi[3] + pi[3] * expp[0] * divm[1] - exp1[1] *
        	    (pi[3] / PI_j[1])) * fracpoint1[i][3];
          tree[node].newfrac[i][1] += temp[0]+temp[1]+temp[2]+temp[3];
          tree[node].newfrac[i][1] *= ptmp[1];


          temp[0] = (pi[0] + pi[0] * expp[0] * divm[0] - exp1[0] *
        	    (pi[0] / PI_j[0])) * fracpoint1[i][0];
          temp[1] = (pi[1] * onem[0]) * fracpoint1[i][1];
          temp[2] = (pi[2] + pi[2] * expp[0] * divm[0] + exp1[0] *
        	    ((PI_j[0] - pi[2]) / PI_j[0])) * fracpoint1[i][2];
          temp[3] = (pi[3] * onem[0]) * fracpoint1[i][3];
          tree[node].newfrac[i][2] += temp[0]+temp[1]+temp[2]+temp[3];
          tree[node].newfrac[i][2] *= ptmp[2];


          temp[0] = (pi[0] * onem[0]) * fracpoint1[i][0];
          temp[1] = (pi[1] + pi[1] * expp[0] * divm[1] - exp1[1] *
        	    (pi[1] / PI_j[1])) * fracpoint1[i][1];
          temp[2] = (pi[2] * onem[0]) * fracpoint1[i][2];
          temp[3] = (pi[3] + pi[3] * expp[0] * divm[1] + exp1[1] *
        	    ((PI_j[1] - pi[3]) / PI_j[1])) * fracpoint1[i][3];
          tree[node].newfrac[i][3] += temp[0]+temp[1]+temp[2]+temp[3];
          tree[node].newfrac[i][3] *= ptmp[3];
		  for (j=0; j<4; j++)
			if (tree[node].newfrac[i][j]>max) max=tree[node].newfrac[i][j];
   		  for (j=0; j<4; j++)
			tree[node].newfrac[i][j]=tree[node].newfrac[i][j]/max;
		  tree[node].scalefactor[i]=tree[up1].scalefactor[i]+log(max);
        }
      }
      else
      {
        minus_t_mutrate1 = -mutrate*(tree[up1].time-tree[tree[up1].up[0]].time);
        minus_t_mutrate2 = -mutrate*(tree[up2].time-tree[tree[up2].up[0]].time);
        expp[0] = exp(minus_t_mutrate1);
        onem[0] = 1.0 - expp[0];
        expp[1] = exp(minus_t_mutrate2);
        onem[1] = 1.0 - expp[1];
        
		PI_j[0] = pi[0] + pi[2];
		PI_j[1] = pi[1] + pi[3];
		A_j[0]  = 1.0 + PI_j[0] * kpa;
		A_j[1]  = 1.0 + PI_j[1] * kpa;
		divm[0] = 1.0 / PI_j[0] - 1.0;
		divm[1] = 1.0 / PI_j[1] - 1.0;
		exp1[0] = exp(minus_t_mutrate1*A_j[0]);
		exp1[1] = exp(minus_t_mutrate1*A_j[1]);
		exp2[0] = exp(minus_t_mutrate2*A_j[0]);
		exp2[1] = exp(minus_t_mutrate2*A_j[1]);

        for (i = 0; i < L[ci][li]->numsites; i++)
        {
		  max = 0.0;
          sum[0] = 0;
          sum[1] = 0;
          sum[2] = 0;
          sum[3] = 0;
          tree[node].newfrac[i][0] = 0;
          tree[node].newfrac[i][1] = 0;
          tree[node].newfrac[i][2] = 0;
          tree[node].newfrac[i][3] = 0;

          temp[0] = (pi[0] + pi[0] * expp[0] * divm[0] + exp1[0] *
        	    ((PI_j[0] - pi[0]) /PI_j[0])) * fracpoint1[i][0];
          temp[1] = (pi[1] * onem[0]) * fracpoint1[i][1];
          temp[2] = (pi[2] + pi[2] * expp[0] * divm[0] - exp1[0] *
        	    (pi[2] / PI_j[0])) * fracpoint1[i][2];
          temp[3] = (pi[3] * onem[0]) * fracpoint1[i][3];
          sum[0] += temp[0]+temp[1]+temp[2]+temp[3];
        	    
          temp[0] = (pi[0] + pi[0] * expp[1] * divm[0] + exp2[0] *
        	    ((PI_j[0] - pi[0]) / PI_j[0])) * fracpoint2[i][0];
          temp[1] = (pi[1] * onem[1]) * fracpoint2[i][1];
          temp[2] = (pi[2] + pi[2] * expp[1] * divm[0] - exp2[0] *
        	    (pi[2] / PI_j[0])) * fracpoint2[i][2];
          temp[3] = (pi[3] * onem[1]) * fracpoint2[i][3];
	  tree[node].newfrac[i][0] += temp[0]+temp[1]+temp[2]+temp[3];
	  tree[node].newfrac[i][0] *= sum[0];

        
          temp[0] = (pi[0] * onem[0]) * fracpoint1[i][0];
          temp[1] = (pi[1] + pi[1] * expp[0] * divm[1] + exp1[1] *
        	    ((PI_j[1] - pi[1]) /PI_j[1])) * fracpoint1[i][1];
          temp[2] = (pi[2] * onem[0]) * fracpoint1[i][2];
          temp[3] = (pi[3] + pi[3] * expp[0] * divm[1] - exp1[1] *
        	    (pi[3] / PI_j[1])) * fracpoint1[i][3];
          sum[1] += temp[0]+temp[1]+temp[2]+temp[3];
        	    
          temp[0] = (pi[0] * onem[1]) * fracpoint2[i][0];
          temp[1] = (pi[1] + pi[1] * expp[1] * divm[1] + exp2[1] *
        	    ((PI_j[1] - pi[1]) / PI_j[1])) * fracpoint2[i][1];
          temp[2] = (pi[2] * onem[1]) * fracpoint2[i][2];
          temp[3] = (pi[3] + pi[3] * expp[1] * divm[1] - exp2[1] *
        	    (pi[3] / PI_j[1])) * fracpoint2[i][3];
          tree[node].newfrac[i][1] += temp[0]+temp[1]+temp[2]+temp[3];
          tree[node].newfrac[i][1] *= sum[1];

        
          temp[0] = (pi[0] + pi[0] * expp[0] * divm[0] - exp1[0] *
        	    (pi[0] / PI_j[0])) * fracpoint1[i][0];
          temp[1] = (pi[1] * onem[0]) * fracpoint1[i][1];
          temp[2] = (pi[2] + pi[2] * expp[0] * divm[0] + exp1[0] *
        	    ((PI_j[0] - pi[2]) / PI_j[0])) * fracpoint1[i][2];
          temp[3] = (pi[3] * onem[0]) * fracpoint1[i][3];
          sum[2] += temp[0]+temp[1]+temp[2]+temp[3];
        	    
          temp[0] = (pi[0] + pi[0] * expp[1] * divm[0] - exp2[0] *
        	    (pi[0] / PI_j[0])) * fracpoint2[i][0];
          temp[1] = (pi[1] * onem[1]) * fracpoint2[i][1];
          temp[2] = (pi[2] + pi[2] * expp[1] * divm[0] + exp2[0] *
        	    ((PI_j[0] - pi[2]) /PI_j[0])) * fracpoint2[i][2];
          temp[3] = (pi[3] * onem[1]) * fracpoint2[i][3];
          tree[node].newfrac[i][2] += temp[0]+temp[1]+temp[2]+temp[3];
          tree[node].newfrac[i][2] *= sum[2];

        
          temp[0] = (pi[0] * onem[0]) * fracpoint1[i][0];
          temp[1] = (pi[1] + pi[1] * expp[0] * divm[1] - exp1[1] *
        	    (pi[1] / PI_j[1])) * fracpoint1[i][1];
          temp[2] = (pi[2] * onem[0]) * fracpoint1[i][2];
          temp[3] = (pi[3] + pi[3] * expp[0] * divm[1] + exp1[1] *
        	    ((PI_j[1] - pi[3]) /PI_j[1])) * fracpoint1[i][3];
          sum[3] += temp[0]+temp[1]+temp[2]+temp[3];
        	    
          temp[0] = (pi[0] * onem[1]) * fracpoint2[i][0];
          temp[1] = (pi[1] + pi[1] * expp[1] * divm[1] - exp2[1] *
        	    (pi[1] / PI_j[1])) * fracpoint2[i][1];
          temp[2] = (pi[2] * onem[1]) * fracpoint2[i][2];
          temp[3] = (pi[3] + pi[3] * expp[1] * divm[1] + exp2[1] *
        	    ((PI_j[1] - pi[3]) /PI_j[1])) * fracpoint2[i][3];
          tree[node].newfrac[i][3] += temp[0]+temp[1]+temp[2]+temp[3];
          tree[node].newfrac[i][3] *= sum[3];
		  for (j=0; j<4; j++)
		    if (tree[node].newfrac[i][j]>max) max=tree[node].newfrac[i][j];
          for (j=0; j<4; j++)
                tree[node].newfrac[i][j]=tree[node].newfrac[i][j]/max;
          tree[node].scalefactor[i]=tree[up1].scalefactor[i]+tree[up2].scalefactor[i]+log(max);
        }
      }
    }
  }
  return ret;
}  // Jim Long's unwrapped makefrac()  with scalefactors 

double getstandfactor(int ci, int li, double kappa)
    {
    int i, j;
    double p=0;

    for (i=0; i<4; i++)
		{
        for (j=0; j<4; j++)
			{
            if (i!=j)
				{
                if (i+j==2 || i+j==4)
					p+=L[ci][li]->pi[i]*L[ci][li]->pi[j]*kappa;    /*HKY*/
                else  p+=L[ci][li]->pi[i]*L[ci][li]->pi[j];
                }
			}
        }
    return p;
    }

double  likelihoodHKY (int ci, int li, double mutrate, double kappa, int e1, int e2, int e3, int e4)
	{ /* jlong */
	  int i, j;
	  double fracp, p = 0;
	  struct edge *tree = L[ci][li]->tree;

	  if (progopts[RETURNPRIOR]) return 1;
	  mutrate = mutrate/(L[ci][li]->totsites * getstandfactor (ci, li, kappa));

	  for (i=L[ci][li]->numgenes; i<L[ci][li]->numlines; i++)
		tree[i].newfrac[0][0] = -1;
    
	  makefrac (L[ci][li]->root, ci, li, mutrate, kappa, e1, e2, e3, e4);

	  /*for (i=0; i<L[ci][li]->numsites; i++)
		  {
			fracp = 0;
			for (j=0; j<4; j++)
			  fracp += L[ci][li]->pi[j] * tree[L[ci][li]->root].newfrac[i][j];
			p += L[ci][li]->mult[i] * log(fracp);
		  } */
	  for (i=0; i<L[ci][li]->numsites; i++)
		{
            fracp=0;
            for (j=0; j<4; j++)
				{
                 fracp+=L[ci][li]->pi[j]*tree[L[ci][li]->root].newfrac[i][j];
				}
			p+=L[ci][li]->mult[i]*(log(fracp)+tree[L[ci][li]->root].scalefactor[i]);
    	}
	  /* printf("likelihoodHKY returns %f",p);   */
	  return p;
	}

void calc_sumlogk(int ci, int li, double *sumlogk)
/* basically a copy of the likelihood function, and probably overkill for what it does */
	{
	int ret, node, site, up1, up2, upup;
	double t;
	int summ = 0,*mcounts, i,j;
	double fact, sum;
	struct edge *tree = L[ci][li]->tree;
	int ng = L[ci][li]->numgenes;

    mcounts = calloc(ng,(sizeof(int *)));
	for (site=0; site<L[ci][li]->numsites; site++)
		{
		for (j=0; j<ng; j++)
			tree[j].mut = L[ci][li]->seq[j][site];
		for (j=ng; j<L[ci][li]->numlines; j++)
			tree[j].mut = -1;
		for (j=0; j<ng; j++)
			labeltree(ci,li, j);
		ret = -1;
		t = 0;
		for (node=ng; node<L[ci][li]->numlines; node++)
			{
			i = node - ng;
			up1 = tree[node].up[0];
			up2 = tree[node].up[1];
			if ((tree[up1].mut == 0 && tree[up2].mut == 1) || (tree[up1].mut== 1 && tree[up2].mut == 0))
				{
				if (node != ret && ret != -1)
					{
					return ;
					}
				else {
					if (tree[node].down == -1)
						{
						if ((upup = tree[up1].up[0]) == -1)
							t = tree[up1].time;
						else
							t = tree[up1].time-tree[upup].time;
						if ((upup = tree[up2].up[0]) == -1)
							t = t + tree[up2].time;
						else
							t = t + tree[up2].time-tree[upup].time;
						}
					else
						{
						if (tree[tree[node].down].mut == tree[up1].mut)
							{						
							if ((upup = tree[up2].up[0]) == -1)
							t = tree[up2].time;
								else
							t = tree[up2].time-tree[upup].time;
							}
						else
							{
							if ((upup = tree[up1].up[0]) == -1)
								t = tree[up1].time;
							else
								t = tree[up1].time-tree[upup].time;								
							}
						}
					ret = node;				
					mcounts[i]++;
					summ++;
					}
				}
			}
		if (ret == -1)
			{
			err(ci,li,82);
			}
		}
	for (sum = 0.0,i=0; i< L[ci][li]->numlines - ng;i++)
		{
		fact = 1.0;
		for (j=1;j<=mcounts[i];j++)
			fact *= (double) j;
		sum += log(fact);
		}
	*sumlogk = sum;
    free(mcounts);
	}  /* calc_sumlogK */
	
__forceinline double likelihoodIS(int ci, int li, double mutrate)
/* written by Rasmus to return the following value
 - (total length of tree in time) * theta + SUM(log(t_i * theta)*k_i, over all branches)
  where k_i is the number of mutations on branch i. 
  This is equal to the logarithm of the product of a bunch of poisson variables, one for each branch, except that 
  one term is dropped out. [ -SUM(log(k_i !)  ]  is not included.  However this will be the same for two infinite 
  sites trees that fit the same data set.
 */
 /* under new parameterization
 - (total length of tree in time) * mutrate + SUM(log(t_i * mutrate)*k_i, over all branches) - SUM(log(k_i !) 
  where k_i is the number of mutations on branch i. 
  as before, do not need to include  the term : -SUM(log(k_i !) 

  Can also do it as 
  - (total length of tree in time) * mutrate + log(mutrate) * SUM(k_i) + Sum(log(t_i)*k_i, over all branches) - SUM(log(k_i !) 
  /* check out the method of getting tree length - seems ok.
  */
	{
	int ret, j, node, site, up1, up2, upup, down;
	double time, p ;
	static  int done_sumlogk[MAXLOCI] = {0};
	static  double *sumlogk[MAXLOCI]; 
	struct edge *tree = L[ci][li]->tree;
	int ng = L[ci][li]->numgenes;
    
    if (progopts[RETURNPRIOR]) return 1;
    if (done_sumlogk[li] == 0)
		{
		sumlogk[li] = calloc(1,sizeof(double));
		calc_sumlogk(ci,li,sumlogk[li]);
		done_sumlogk[li] = 1;
		}  
	p = 0;
	for (node=0; node<L[ci][li]->numlines; node++)
		{
		if ((down = tree[node].down) != -1)
			{
			if (down == L[ci][li]->root)
				p = p + tree[node].time;
			else p = p + tree[node].time/2.0;
			}
		}
    p = -p*mutrate;
	for (site=0; site < L[ci][li]->numsites; site++)
		{
		for (j=0; j<ng; j++)
			tree[j].mut = L[ci][li]->seq[j][site];
		for (j=ng; j<L[ci][li]->numlines; j++)
			tree[j].mut = -1;
		for (j=0; j<ng; j++)
			labeltree(ci, li, j);
		ret = -1;
		for (node=ng; node<L[ci][li]->numlines; node++)
			{
			up1 = tree[node].up[0];
			up2 = tree[node].up[1];
			if ((tree[up1].mut == 0 && tree[up2].mut == 1) || (tree[up1].mut== 1 && tree[up2].mut == 0))
				{
				if (node != ret && ret != -1)
					{
					/* more than one mutation at a site under this topology */
					return 0;
					}
				else {
                    /* i is the root node add together both branch times */
					if (tree[node].down == -1)
						{
						if ((upup = tree[up1].up[0]) == -1)
							time = tree[up1].time;
						else
							time = tree[up1].time-tree[upup].time;
						if ((upup = tree[up2].up[0]) == -1)
							time = time + tree[up2].time;
						else
							time = time + tree[up2].time-tree[upup].time;
						}
					else
                        /* i is not the root node  */
						{
						if (tree[tree[node].down].mut == tree[up1].mut)
							{						
							if ((upup = tree[up2].up[0]) == -1)
							time = tree[up2].time;
								else
							time = tree[up2].time-tree[upup].time;
							}
						else
							{
							if ((upup = tree[up1].up[0]) == -1)
								time = tree[up1].time;
							else
								time = tree[up1].time-tree[upup].time;								
							}
						}
					ret = node;				
					}
				}
			}
		if (ret == -1)
			{
			err(ci,li,83);
			}
		else
			{
			p = p + log(time*mutrate);
			}
		}
	 p -= *sumlogk[li];  
	return p;
	}	/* likelihoodIS */

/* info for edge goes in copyedge[0],
   info for sisedge goes in copyedge[1]
   info for downedge goes in copyedge[2] */
void storoldedges(int ci, int li, int edge, int sisedge, int downedge)
	{
	int i, ai;
	struct edge *tree = L[ci][li]->tree;

	copyedge[0].down = tree[edge].down;
	i = -1;
	do {
		i++;
		*(copyedge[0].mig + i) = *(tree[edge].mig +i);
		} 
    while (*(copyedge[0].mig + i) > -0.5 ); 
	copyedge[0].time = tree[edge].time;
	copyedge[0].pop = tree[edge].pop;
	copyedge[0].cmm = tree[edge].cmm;
	copyedge[1].down = tree[sisedge].down;
	i = -1;
	do {
		i++;
		*(copyedge[1].mig + i) = *(tree[sisedge].mig +i);
		} 
    while (*(copyedge[1].mig + i) > -0.5 ); 
	copyedge[1].time = tree[sisedge].time;
	copyedge[1].pop = tree[sisedge].pop;
	copyedge[1].cmm = tree[sisedge].cmm;
	copyedge[2].down = tree[downedge].down;
	i = -1;
	do {
		i++;
		*(copyedge[2].mig + i) = *(tree[downedge].mig +i);
		} 
    while (*(copyedge[2].mig + i) > -0.5 ); 
	copyedge[2].time = tree[downedge].time;
	copyedge[2].pop = tree[downedge].pop;
	copyedge[2].cmm = tree[downedge].cmm;
    copyedge[0].up[0] = tree[edge].up[0];
	copyedge[0].up[1] = tree[edge].up[1];	
    copyedge[1].up[0] = tree[sisedge].up[0];
	copyedge[1].up[1] = tree[sisedge].up[1];	
    copyedge[2].up[0] = tree[downedge].up[0];
	copyedge[2].up[1] = tree[downedge].up[1];	
    if (L[ci][li]->model == STEPWISE || L[ci][li]->model == JOINT_IS_SW)
        {
		for (ai = 0; ai < L[ci][li]->numsmm; ai++)
			{
			copyedge[0].A[ai] = tree[edge].A[ai];
			copyedge[0].dlikeA[ai] = tree[edge].dlikeA[ai];
	        copyedge[1].A[ai] = tree[sisedge].A[ai];
		    copyedge[1].dlikeA[ai] = tree[sisedge].dlikeA[ai];
	        copyedge[2].A[ai] = tree[downedge].A[ai];
			if (copyedge[2].down != -1)
				{
				copyedge[2].dlikeA[ai] = tree[downedge].dlikeA[ai];
				holddownA[ai] = tree[copyedge[2].down].A[ai];	
				}
			else 
				{
				holddownA[ai] = -1;
				copyedge[2].dlikeA[ai] = 0;
				}
			}
        }
    } /* storoldeges */

/* set the tree back to the way it was */ 
void restoreedges(int ci, int li, int edge, int sisedge, int downedge, int newsisedge)
/*all this can be optimized some*/
	{
	int i, j,ai, down;
	struct edge *tree = L[ci][li]->tree;

	if (newsisedge != sisedge)
		{
		down = tree[downedge].down;
		if (down != -1)
			{
			if (tree[down].up[0] == downedge)
				tree[down].up[0] = newsisedge;
			else tree[down].up[1] = newsisedge;
			}
		else 
			{
			L[ci][li]->root = newsisedge;
			L[ci][li]->roottime = tree[tree[newsisedge].up[0]].time;
			}
		tree[newsisedge].down = down;
		if (down != -1)
			{
			i = 0;
			while (*(tree[newsisedge].mig + i) > -0.5 ) 
				i++;
			j = -1;
			do
				{
				j++;
				checkmig(i+j,&(tree[newsisedge].mig),&(tree[newsisedge].cmm));
				*(tree[newsisedge].mig + (i+j)) = *(tree[downedge].mig + j);
				}while (*(tree[downedge].mig + j) > -0.5 ); 
			}
		else 
            {
            *(tree[newsisedge].mig) = -1;
			for (ai = 0; ai < L[ci][li]->numsmm; ai++)
				tree[newsisedge].dlikeA[ai] = 0;;
            }
		tree[newsisedge].time = tree[downedge].time;
		}	
	tree[edge].down = copyedge[0].down;
	i = -1;
	do {
		i++;
		checkmig(i,&(tree[edge].mig),&(tree[edge].cmm));
		*(tree[edge].mig + i) = *(copyedge[0].mig + i);
		} while (*(tree[edge].mig +i) > -0.5 ); 
	tree[edge].time = copyedge[0].time;
	myassert(tree[edge].pop == tree[edge].pop);
	down = tree[sisedge].down;
	tree[sisedge].down = copyedge[1].down;
	if (down != -1)
		{
		if (tree[down].up[0] == sisedge)
			tree[down].up[0] = downedge;
		else tree[down].up[1] = downedge;
		}
	i = -1;
	do {
		i++;
		checkmig(i,&(tree[sisedge].mig),&(tree[sisedge].cmm));
		*(tree[sisedge].mig + i) = *(copyedge[1].mig + i);
		} while (*(tree[sisedge].mig + i) > -0.5 ); 
	tree[sisedge].time = copyedge[1].time;
	tree[sisedge].pop = copyedge[1].pop;
	tree[downedge].down = copyedge[2].down;
	i = -1;
	do {
		i++;
		checkmig(i,&(tree[downedge].mig),&(tree[downedge].cmm));
		*(tree[downedge].mig + i) = *(copyedge[2].mig + i);
		} while (tree[downedge].mig[i] > -0.5 ); 
	tree[downedge].time = copyedge[2].time;
	tree[downedge].pop = copyedge[2].pop;
	tree[downedge].up[0] = copyedge[2].up[0];
	tree[downedge].up[1] = copyedge[2].up[1];
	if (tree[downedge].down == -1)
		{
		L[ci][li]->roottime = tree[tree[downedge].up[0]].time;
		L[ci][li]->root = downedge;
		}
    if (L[ci][li]->model == STEPWISE || L[ci][li]->model == JOINT_IS_SW )
		for (ai = 0; ai < L[ci][li]->numsmm; ai++)
			{
			tree[edge].A[ai] = copyedge[0].A[ai];
			tree[edge].dlikeA[ai] = copyedge[0].dlikeA[ai] ;
			tree[sisedge].A[ai] = copyedge[1].A[ai];
			tree[sisedge].dlikeA[ai] = copyedge[1].dlikeA[ai];
			tree[downedge].A[ai] = copyedge[2].A[ai];
			tree[downedge].dlikeA[ai] = copyedge[2].dlikeA[ai];
			if (holdsisdlikeA[ai] != 0)
				tree[newsisedge].dlikeA[ai] = holdsisdlikeA[ai];
			}
    } /* restoreedges  */

void storescalefactors(int ci, int li)
	{
	int i, k;
	struct edge *tree = L[ci][li]->tree;

	for(i=L[ci][li]->numgenes; i<2*L[ci][li]->numgenes-1; i++)
			for (k=0; k<L[ci][li]->numsites; k++)
					tree[i].oldscalefactor[k]=tree[i].scalefactor[k];
	}

void restorescalefactors(int ci, int li)
	{
	int i, k;
	struct edge *tree = L[ci][li]->tree;

	for(i=L[ci][li]->numgenes; i<2*L[ci][li]->numgenes-1; i++){
		   for (k=0; k<L[ci][li]->numsites; k++){
				tree[i].scalefactor[k]=tree[i].oldscalefactor[k];}}
	}

void copyfraclike(int ci, int li)
    {
    int i,j,k;
	struct edge *tree = L[ci][li]->tree;
	int ng = L[ci][li]->numgenes;
    
	for (i=ng; i<2*ng-1; i++)
        {
        if (tree[i].newfrac[0][0]!=-1)
            {
            for (j=0; j<L[ci][li]->numsites; j++)
                    for (k=0; k<4; k++)
                            tree[i].frac[j][k]=tree[i].newfrac[j][k];
            }
        }
    }


/* this is a quicker version - saves time by using a list of the other edges*/

__forceinline  double gettime(int ci, int li, int *returnnode, double oldt, int *num, int pop, double divt)
	{
	int i, j, up, bpop;
	double tempt, upt, t = TIMEMAX;
	struct edge *tree = L[ci][li]->tree;

    *returnnode = -1; 
	for (i=0; i<L[ci][li]->numlines; i++)
		{
		if ((up = tree[i].up[0]) == -1)
			upt = 0.0;
		else upt = tree[up].time;
		if (tree[i].time > oldt && upt <= oldt) // only consider branches that span oldt
			{
			if (oldt >= divt)  // no migrations to consider 
				{
                *(numlist+ *num) = i;
				(*num)++;
				tempt = tree[i].time;
				if (tempt < t)
					{
					*returnnode = i;
					t = tempt;
					}
				}
			else
				{
				bpop = tree[i].pop;
				j=0;
				while (*(tree[i].mig + j) > -0.5 && *(tree[i].mig + j) <= oldt) 
					{
					bpop = 1 - bpop;
					j++;
                    myassert(j < tree[i].cmm);
					}
				if (pop == bpop)
                    {
                    *(numlist + *num) = i;
					(*num)++;
                    }
				if (*(tree[i].mig + j) < -0.5 ) 
					tempt = tree[i].time;
				else tempt = *(tree[i].mig + j);
				if (tempt < t)
					{
					*returnnode = i;
					t = tempt;
					}
				}
			}
		}
	return t;
    }  /* gettime */


int simroot(int ci, int li, double m1, double m2, int edge, int downedge, int curpopedge,int edgemignum)

	{
	int i, stop, rootmignum, curpoproot;
	double rate, t, oldt;
	int ai;
	struct edge *tree = L[ci][li]->tree;
	
    oldt = t = L[ci][li]->roottime;
	rootmignum = 0;
	curpoproot = tree[L[ci][li]->root].pop;
	while ( *(tree[L[ci][li]->root].mig + rootmignum) > -0.5 && *(tree[L[ci][li]->root].mig + rootmignum) < t) 
		{
		rootmignum++;
		curpoproot = 1 - curpoproot;
        myassert(rootmignum < tree[L[ci][li]->root].cmm);
		}
	stop = 0;
	do
		{
		if (t < Q[ci]->t)
			{
			if (curpopedge == curpoproot)
				{
				if (curpopedge == 0)
					rate = 2.0*m1 + 2.0/(Q[ci]->q1 * Q[ci]->h[li]);
				else rate = 2.0*m2 + 2.0/(Q[ci]->q2 * Q[ci]->h[li]);
				t = t + expo(rate);
				}
			else t = t + expo(m1 + m2); 
			if (t >= Q[ci]->t)
				t = Q[ci]->t;
			}
        if (t >= Q[ci]->t || ((curpoproot == curpopedge) && 
            (  ((curpoproot == 0) && (uniform() <  (2.0/(Q[ci]->q1 * Q[ci]->h[li]))/(2.0*m1 + 2.0/(Q[ci]->q1 * Q[ci]->h[li])) )) 
            || ((curpoproot == 1) && (uniform() <  (2.0/(Q[ci]->q2 * Q[ci]->h[li]))/(2.0*m2 + 2.0/(Q[ci]->q2 * Q[ci]->h[li])) )))))
			{
			if (t >= Q[ci]->t)
				t = t + expo(2.0/(Q[ci]->qA * Q[ci]->h[li]));
			L[ci][li]->roottime = tree[L[ci][li]->root].time = tree[edge].time =  t; //MIN(t, TIMEMAX);  just make an error of the case when t > TIMEMAX
			tree[L[ci][li]->root].down = tree[edge].down = downedge;
			tree[downedge].time = TIMEMAX;
			tree[downedge].down = -1;
			for (ai = 0; ai < L[ci][li]->numsmm; ai++)
			    tree[downedge].dlikeA[ai] = 0;
			tree[downedge].up[0] = edge;
			tree[downedge].up[1] = L[ci][li]->root;
			tree[downedge].pop = curpopedge;
			*(tree[downedge].mig) = -1;
			*(tree[L[ci][li]->root].mig + rootmignum) = -1;
			*(tree[edge].mig + edgemignum) = -1;
			stop = 1;
			}
		else
			{
			if (((curpoproot == curpopedge) && bitran() /* uniform() < 0.5 */) || 
                   ((curpoproot == 0 && curpopedge == 1) && (uniform() < m1/(m1+m2))) 
                || ((curpoproot == 1 && curpopedge == 0) && (uniform() < m2/(m1+m2))))
				{
				curpoproot = 1 - curpoproot;
				checkmig(rootmignum + 1,&(tree[L[ci][li]->root].mig), &(tree[L[ci][li]->root].cmm));
				*(tree[L[ci][li]->root].mig + rootmignum) = t;
				rootmignum++;
				}
			else
				{
				 curpopedge = 1 - curpopedge;
				 checkmig(edgemignum + 1,&(tree[edge].mig), &(tree[edge].cmm));
				 *(tree[edge].mig + edgemignum) = t;
				 edgemignum++;
				 }
			}
		} while(stop == 0);
	i = L[ci][li]->root;
	L[ci][li]->root = downedge;
	return i;
    } /* simroot not g!*/

/* altered a bit from Rasmus's original - don't recall how */
int updateedge(int ci, int li, double curt, int edge, int downedge, int num, int pop, int oldsisedge)
	{
	int i, j, dow, newsis;
	struct edge *tree = L[ci][li]->tree;
	
	/* need to find the jth out of num branches that are suitable coalescent partners */
	j = (int) floor(uniform()*num);
    newsis = *(numlist+j); 
	tree[edge].time = curt;
    //myassert(newsis==*(numlist+j));
	tree[downedge].time = tree[newsis].time;
	tree[newsis].time = curt;
	if ((dow = tree[newsis].down) != -1)
		{
		if (tree[dow].up[0] == newsis)
			tree[dow].up[0] = downedge;
		else tree[dow].up[1] = downedge;
		}
	else
		{
		L[ci][li]->root = downedge;
		L[ci][li]->roottime = curt;
		*(tree[downedge].mig) = -1;
		}
	tree[downedge].down = dow;
	tree[downedge].pop = pop;
	i=0;
	 while (*(tree[newsis].mig + i) > -0.5 && *(tree[newsis].mig + i) < curt)
         i++;
	j = 0;
	if (dow != -1)
		{							
		while (*(tree[newsis].mig + (j+i)) > -0.5 /*&& tree[newsis].mig[i]*/)  /* HERE: CHECKIT */
			{
			checkmig(j,&(tree[downedge].mig),&(tree[downedge].cmm));
			*(tree[downedge].mig + j) = *(tree[newsis].mig + (j+i));
			j++;
			}
		}
	*(tree[downedge].mig + j) = -1;
	*(tree[newsis].mig + i) = -1;
	tree[newsis].down = tree[edge].down = downedge;
	tree[downedge].up[0] = newsis;
	tree[downedge].up[1] = edge;
	if (tree[oldsisedge].down == -1)
		{
		*(tree[oldsisedge].mig) = -1;
		L[ci][li]->roottime = tree[tree[oldsisedge].up[0]].time;
		}
	return newsis;
    } /* updateedge */

void makecoal(int ci, int li, double m1, double m2, int edge, int downedge, int sisedge, int *newsisedge)

	{
	int curpop, i,j, num, nextnode, stop, dow;
	double curt, time;
	int ai;
	struct edge *tree = L[ci][li]->tree;
	double qt1 = 2.0 / (Q[ci]->q1*Q[ci]->h[li]);
	double qt2 = 2.0 / (Q[ci]->q2*Q[ci]->h[li]);
	double qtA = 2.0 / (Q[ci]->qA*Q[ci]->h[li]);

	if (tree[edge].up[0] == -1)
		curt = 0;
	else
		curt = tree[tree[edge].up[0]].time;
	i = 0;
	while (*(tree[sisedge].mig + i) > -0.5 ) 
		i++;
	j = -1;
	do {
		j++;
		checkmig(i+1,&(tree[sisedge].mig),&(tree[sisedge].cmm));
		*(tree[sisedge].mig + i) = *(tree[downedge].mig + j);
		i++;
		} while (*(tree[downedge].mig + j) > -0.5 /* && i < MIGMAX */); 
	tree[sisedge].time = tree[downedge].time;
	tree[edge].time = curt;
	*(tree[edge].mig) = - 1;
	tree[downedge].time = 0;/*huh?*/
	dow = tree[sisedge].down = tree[downedge].down;
	if (dow != -1)
		{
		if (tree[dow].up[0] == downedge)
			tree[dow].up[0] = sisedge;
		else tree[dow].up[1] = sisedge;
		}
	else
		{ 
		L[ci][li]->root = sisedge;
		tree[sisedge].time = TIMEMAX;
		for (ai = 0; ai < L[ci][li]->numsmm; ai++)
			tree[sisedge].dlikeA[ai] = 0;
		}
	stop = 0;
	i = 0;
	curpop = tree[edge].pop;
	do
		{
		time = curt;
		do
			{
			num = 0;
			curt = time;
			time = gettime(ci,li,&nextnode, time, &num, curpop, Q[ci]->t);
			if (curt < Q[ci]->t)
				{
				if (curpop == 0)
                    {
                    if ( (m1 + num*qt1) >0) 
                        curt = curt + expo(m1 + num*qt1);
                    else curt = TIMEMAX;/*very large number*/
                    }
				else{
                    if ( (m2 + num*qt2) >0) 
                        curt = curt + expo(m2 + num*qt2);
                    else curt = TIMEMAX;/*very large number*/
                    }
				if (curt > Q[ci]->t && Q[ci]->t < time)
					{
					num = 0;
					time = gettime(ci, li, &nextnode, Q[ci]->t, &num, curpop, Q[ci]->t);
					curt = Q[ci]->t + expo(num * qtA);
					}
				}
			else 
               curt = curt + expo(num * qtA);
			}while (curt > time && time < L[ci][li]->roottime);
		if (curt >= L[ci][li]->roottime)
			{
			*newsisedge = simroot(ci,li,m1,m2,edge, downedge, curpop, i);
			stop = 1;
			}
		else 
            {
            if (/*i < MIGMAX && */curt < Q[ci]->t && 
                 ( (curpop == 0 && (uniform() < m1/(m1 + num* qt1 )  ) ) 
                || (curpop == 1 && (uniform() < m2/(m2 + num* qt2 )  ) ) ) )
                {
                curpop = 1-curpop;
				checkmig(i,&(tree[edge].mig),&(tree[edge].cmm));
                *(tree[edge].mig + i) = curt;
                i++;
                }
		    else
			    {
			    *(tree[edge].mig + i) = -1;
			    *newsisedge = updateedge(ci, li, curt, edge, downedge, num, curpop, sisedge);
			    stop = 1;
			    }
            }
		} while (stop == 0);
    } /* makecoal not g!*/

int doMCMC(int ci, int li, double kappa, int MODEL, int *topolchange)
	{
	int edge, sisedge, newsisedge, downedge, accp = 0;
	double like, like_a[MAXLINKEDSMM], like_asum, oldlike_asum;
    double weight, U;
    double tpw, tpnew;
    double Aterm[MAXLINKEDSMM], Atermsum;
    double tempfinishSW;
    struct treeevent  *tempelist;
	unsigned long *tempei;
    int tempecount;
	double templength;
    double m1, m2;
    int mi;
	int ai;
	struct edge *tree = L[ci][li]->tree;

//if (ci==12)
//	treeprint(ci,0);	
    (progopts[LOCUSMIGRATION]) ? (mi=li): (mi=0);
    m1 = Q[ci]->m1[mi];
    m2 = Q[ci]->m2[mi];
    do
		{
		edge = (int) floor(uniform()*L[ci][li]->numlines);
		} while (tree[edge].down  == -1);
	downedge = tree[edge].down;
	if ((sisedge = tree[downedge].up[0]) == edge)
		sisedge = tree[downedge].up[1];
	storoldedges(ci, li, edge, sisedge, downedge);
#ifdef INCLUDESIZECHANGE
	if (progopts[POPSIZECHANGEMODE])
        makecoalg(ci, li, m1, m2,edge, downedge, sisedge, &newsisedge);
    else
#endif
        makecoal(ci, li, m1, m2,edge, downedge, sisedge, &newsisedge);
	if (L[ci][li]->roottime >= TIMEMAX)
		err(ci,li,31);

	templength = L[ci][li]->length;
//if (ci==12)
//	treeprint(ci,0);			
    //geteventinfo(ci, li, &tempecount, &tempelist);
	newgeteventinfo(ci, li, &tempecount, &tempelist, &tempei);

    *topolchange = (sisedge != newsisedge);
    switch(MODEL)
        {
        case HKY :like = likelihoodHKY(ci, li, Q[ci]->u[locusulookup[li]], kappa, edge, downedge, sisedge, newsisedge); like_asum = 0;break;
        case INFINITESITES : like = likelihoodIS(ci, li,Q[ci]->u[locusulookup[li]]); like_asum = 0;break;
        case STEPWISE : 
            {
			like = 0;
			like_asum = 0;
			Atermsum = 0;
			oldlike_asum = 0;
			for (ai = 0;ai < L[ci][li]->numsmm; ai++)
				{
				tempfinishSW = finishSWupdateA(ci, li, ai, edge, downedge, sisedge, newsisedge,Q[ci]->u[locusulookup[li]+ai], &Aterm[ai]);
				oldlike_asum += L[ci][li]->oldlike_a[ai];
				like_a[ai] =  L[ci][li]->oldlike_a[ai] + tempfinishSW;
				like_asum += like_a[ai];
				Atermsum += Aterm[ai];
				}
			like = like_asum;
			break;
            /*checklikelihoodSW(ci,li,Q[ci]->u[li]);  */
            }
        case JOINT_IS_SW : 
            like  = likelihoodIS(ci, li,Q[ci]->u[locusulookup[li]]);
			like_asum = 0;
			Atermsum = 0;
			oldlike_asum = 0;
			for (ai = 0;ai < L[ci][li]->numsmm; ai++)
				{
				tempfinishSW = finishSWupdateA(ci, li, ai, edge, downedge, sisedge, newsisedge,Q[ci]->u[locusulookup[li]+ai+1],&Aterm[ai]);
				oldlike_asum += L[ci][li]->oldlike_a[ai];
				like_a[ai] = L[ci][li]->oldlike_a[ai] + tempfinishSW;
				like_asum += like_a[ai];
 				Atermsum += Aterm[ai];
				}
			break;
            /*checklikelihoodSW(ci,li,Q[ci]->uA[li]);  */
        }
/* in regard to the update criterion:
    without heating the full update term is P(G*|Theta)P(D|G*)P(G*->G)/(P(G|Theta)P(D|G)P(G->G*))
    However I gather that P(G*|Theta)/P(G|Theta) cancels out  P(G*->G)/P(G->G*) and so we are left with
    P(D|G*)/P(D|G).
    With a heating term beta however, the full term should be 
    (P(G*|Theta)P(D|G*))/(P(G|Theta)P(D|G))^beta  P(G*->G)/P(G->G*)) */
	if (like != 0.0)
	    {
        //tpnew = ptreeprob(Q[ci]->q1,Q[ci]->q2,Q[ci]->qA, m1,m2, Q[ci]->t,Q[ci]->h[li], &tempecount, tempelist,Q[ci]->s);
		tpnew = ptreeprob(Q[ci]->q1,Q[ci]->q2,Q[ci]->qA, m1,m2, Q[ci]->t,Q[ci]->h[li], &tempecount, tempelist,tempei,Q[ci]->s);
        if (ci != 0)
            tpw = tpnew-L[ci][li]->oldprob;
        else tpw = 0;

		switch(MODEL)
            {
            case JOINT_IS_SW:
                weight = exp( beta[ci]*(tpw + (like + like_asum - L[ci][li]->oldlike - oldlike_asum)) - tpw + Atermsum); break;
            case STEPWISE :
                weight = exp(beta[ci]*(tpw + (like_asum - oldlike_asum)) - tpw + Atermsum); break;
            default: 
				weight = exp(beta[ci]*(tpw + (like-L[ci][li]->oldlike)) - tpw);
            }

        U = uniform();
        if (weight >= 1.0 || weight > U)
			{
			if (MODEL != STEPWISE)
				L[ci][li]->oldlike = like;
            if (MODEL==JOINT_IS_SW || MODEL == STEPWISE)
				for (ai = 0;ai < L[ci][li]->numsmm; ai++)
					L[ci][li]->oldlike_a[ai] = like_a[ai];
            L[ci][li]->oldprob = tpnew;
            L[ci][li]->ecount = tempecount;
            free(L[ci][li]->elist);
			free(L[ci][li]->eindex);
            L[ci][li]->elist = tempelist;
			L[ci][li]->eindex = tempei;

            if (MODEL==HKY) 
				{
                copyfraclike(ci,li);
				storescalefactors(ci, li);
				}
			accp = 1;
			}
        }
	if (accp == 0)
        {
		restoreedges(ci,li, edge, sisedge, downedge, newsisedge);
		if (MODEL==HKY) 
			restorescalefactors(ci, li);
        free(tempelist);
		free(tempei);
		L[ci][li]->length = templength;
        }
	return accp;
    } /* domcmc */

double changeq(int ci, int qswitch, double oldq, double windowsize, double maxval)
	{
    double U, newq, weight;
    double tpn[MAXLOCI], tpsum;
    int mi,li;
    double m1, m2;

	U = uniform();
	if (U > 0.5)
		{
		newq = oldq + (2.0*U-1.0)*windowsize;
		if (newq > maxval)
			newq = 2.0*maxval - newq;
		}
	else
		{
		newq = oldq - windowsize*U*2.0;
		if (newq < 0)
			newq = - newq;
		}
    tpsum = 0.0;
    for (li = 0; li< nloci; li++)
        {
        (progopts[LOCUSMIGRATION]) ? (mi=li): (mi=0);
        m1 = Q[ci]->m1[mi];
        m2 = Q[ci]->m2[mi];

        tpsum -= L[ci][li]->oldprob; 
        switch (qswitch)
            {
            //case 1: tpn[li] = ptreeprob(newq,Q[ci]->q2,Q[ci]->qA,m1,m2, Q[ci]->t, Q[ci]->h[li], &L[ci][li]->ecount, L[ci][li]->elist,Q[ci]->s);
			case 1: tpn[li] = ptreeprob(newq,Q[ci]->q2,Q[ci]->qA,m1,m2, Q[ci]->t, Q[ci]->h[li], &L[ci][li]->ecount, L[ci][li]->elist, L[ci][li]->eindex,Q[ci]->s);
                    break;
            //case 2: tpn[li] = ptreeprob(Q[ci]->q1,newq,Q[ci]->qA,m1,m2, Q[ci]->t, Q[ci]->h[li], &L[ci][li]->ecount, L[ci][li]->elist,Q[ci]->s);
			case 2: tpn[li] = ptreeprob(Q[ci]->q1,newq,Q[ci]->qA,m1,m2, Q[ci]->t, Q[ci]->h[li], &L[ci][li]->ecount, L[ci][li]->elist, L[ci][li]->eindex,Q[ci]->s);
                    break;
            //case 3: tpn[li] = ptreeprob(Q[ci]->q1,Q[ci]->q2,newq,m1,m2, Q[ci]->t, Q[ci]->h[li], &L[ci][li]->ecount, L[ci][li]->elist,Q[ci]->s);
			case 3: tpn[li] = ptreeprob(Q[ci]->q1,Q[ci]->q2,newq,m1,m2, Q[ci]->t, Q[ci]->h[li], &L[ci][li]->ecount, L[ci][li]->elist, L[ci][li]->eindex,Q[ci]->s);
                    break;
            default: err(ci,li,51);
                     break;
            }
        tpsum += tpn[li];
        }
    weight = exp(beta[ci]*tpsum);
    U = uniform();
	if (weight >= 1.0 || weight > U)
        {
        for (li = 0; li< nloci; li++)
            {
            L[ci][li]->oldprob = tpn[li];
            }
		return newq;
        }
	else return oldq;
	} /* changeq */

double changecommonq(int ci, double oldq, double windowsize, double maxval)
	{
    double U, newq, weight;
    double tpn[MAXLOCI], tpsum;
    int mi,li;
    double m1, m2;

	U = uniform();
	if (U > 0.5)
		{
		newq = oldq + (2.0*U-1.0)*windowsize;
		if (newq > maxval)
			newq = 2.0*maxval - newq;
		}
	else
		{
		newq = oldq - windowsize*U*2.0;
		if (newq < 0)
			newq = - newq;
		}
    tpsum = 0.0;
    for (li = 0; li< nloci; li++)
        {
        (progopts[LOCUSMIGRATION]) ? (mi=li): (mi=0);
        m1 = Q[ci]->m1[mi];
        m2 = Q[ci]->m2[mi];
        tpsum -= L[ci][li]->oldprob; 
        //tpn[li] = ptreeprob(newq,newq,newq,m1,m2, Q[ci]->t, Q[ci]->h[li], &L[ci][li]->ecount, L[ci][li]->elist,Q[ci]->s);
		tpn[li] = ptreeprob(newq,newq,newq,m1,m2, Q[ci]->t, Q[ci]->h[li], &L[ci][li]->ecount, L[ci][li]->elist, L[ci][li]->eindex,Q[ci]->s);
        tpsum += tpn[li];
        }
    weight = exp(beta[ci]*tpsum);
    U = uniform();
	if (weight >= 1.0 || weight > U)
        {
        for (li = 0; li< nloci; li++)
            {
            L[ci][li]->oldprob = tpn[li];
            }
		return newq;
        }
	else return oldq;
	} /* changecommonq */

double changemall(int ci, double oldm, double maxm, int pop)
    {
	double U, weight, newm, d;
    double tpn[MAXLOCI], tpsum;  
	int li;

    if (maxm <= 0.0)
        return oldm;
    d=expo(nloci/oldm);
    U = uniform();
	if (U > 0.5) newm = oldm + 0.05/nloci + d;
	else newm = oldm - 0.05/nloci - d;
    while ((newm > maxm) || (newm < 0))
        {
        if (newm > maxm)
                newm = 2.0*maxm - newm;
        else if (newm < 0)
                newm = - newm;
        }
    tpsum = 0.0;
    for (li = 0; li< nloci; li++)
        {
        tpsum -= L[ci][li]->oldprob; 
        if (pop==0)
            //tpn[li] = ptreeprob(Q[ci]->q1,Q[ci]->q2,Q[ci]->qA,newm,Q[ci]->m2[0], Q[ci]->t, Q[ci]->h[li], &L[ci][li]->ecount, L[ci][li]->elist, Q[ci]->s);
		tpn[li] = ptreeprob(Q[ci]->q1,Q[ci]->q2,Q[ci]->qA,newm,Q[ci]->m2[0], Q[ci]->t, Q[ci]->h[li], &L[ci][li]->ecount, L[ci][li]->elist,L[ci][li]->eindex, Q[ci]->s);
        else 
           // tpn[li] = ptreeprob(Q[ci]->q1,Q[ci]->q2,Q[ci]->qA,Q[ci]->m1[0],newm, Q[ci]->t, Q[ci]->h[li], &L[ci][li]->ecount, L[ci][li]->elist, Q[ci]->s);
		tpn[li] = ptreeprob(Q[ci]->q1,Q[ci]->q2,Q[ci]->qA,Q[ci]->m1[0],newm, Q[ci]->t, Q[ci]->h[li], &L[ci][li]->ecount, L[ci][li]->elist, L[ci][li]->eindex, Q[ci]->s);
        tpsum += tpn[li];
        }
    weight = exp(beta[ci]*tpsum);
	weight *= (oldm/newm)*exp(-d*((nloci/newm) - (nloci/oldm))); /*this corrects for the difference in sim. probability*/
    U = uniform();
	if (weight >= 1.0 || weight > U)
        {
        for (li = 0; li< nloci; li++)
            {
            L[ci][li]->oldprob = tpn[li];
            }
		return newm;
        }
	else return oldm;
	} /* changemall */

double changemsingle(int ci, int li, double oldm, double maxm, int pop)
    {
	double U, weight, newm, d;
    double tpn, tpsum;  

    if (maxm <= 0.0)
        return oldm;
    d=expo(1/oldm);
    U = uniform();
	if (U > 0.5) newm = oldm + 0.05 + d;
	else newm = oldm - 0.05 - d;
    while ((newm > maxm) || (newm < 0))
        {
        if (newm > maxm)
                newm = 2.0*maxm - newm;
        else if (newm < 0)
                newm = - newm;
        }
    if (pop==0)
        //tpn = ptreeprob(Q[ci]->q1,Q[ci]->q2,Q[ci]->qA,newm,Q[ci]->m2[li], Q[ci]->t, Q[ci]->h[li], &L[ci][li]->ecount, L[ci][li]->elist, Q[ci]->s);
	tpn = ptreeprob(Q[ci]->q1,Q[ci]->q2,Q[ci]->qA,newm,Q[ci]->m2[li], Q[ci]->t, Q[ci]->h[li], &L[ci][li]->ecount, L[ci][li]->elist,L[ci][li]->eindex, Q[ci]->s);
    else 
    //    tpn = ptreeprob(Q[ci]->q1,Q[ci]->q2,Q[ci]->qA,Q[ci]->m1[li],newm, Q[ci]->t, Q[ci]->h[li], &L[ci][li]->ecount, L[ci][li]->elist, Q[ci]->s);
	tpn = ptreeprob(Q[ci]->q1,Q[ci]->q2,Q[ci]->qA,Q[ci]->m1[li],newm, Q[ci]->t, Q[ci]->h[li], &L[ci][li]->ecount, L[ci][li]->elist, L[ci][li]->eindex,Q[ci]->s);
    tpsum = tpn - L[ci][li]->oldprob; 
    weight = exp(beta[ci]*tpsum);
	weight *= (oldm/newm) * exp(-d*((1/newm) - (1/oldm))); /*this corrects for the difference in sim. probability*/
    U = uniform();
	if (weight >= 1.0 || weight > U)
        {
        L[ci][li]->oldprob = tpn;
		return newm;
        }
	else return oldm;
	} /* changemsingle */


double changecommonmall(int ci, double oldm, double maxm)
    {
	double U, weight, newm, d;
    double tpn[MAXLOCI], tpsum;  
	int li;
	
    d=expo(nloci/oldm);
    U = uniform();
	if (U > 0.5) newm = oldm + 0.05/nloci + d;
	else newm = oldm - 0.05/nloci - d;
    while ((newm > maxm) || (newm < 0))
        {
        if (newm > maxm)
                newm = 2.0*maxm - newm;
        else if (newm < 0)
                newm = - newm;
        }
    tpsum = 0.0;
    for (li = 0; li< nloci; li++)
        {
        tpsum -= L[ci][li]->oldprob; 
        //tpn[li] = ptreeprob(Q[ci]->q1,Q[ci]->q2,Q[ci]->qA,newm,newm, Q[ci]->t, Q[ci]->h[li], &L[ci][li]->ecount, L[ci][li]->elist,Q[ci]->s);
		tpn[li] = ptreeprob(Q[ci]->q1,Q[ci]->q2,Q[ci]->qA,newm,newm, Q[ci]->t, Q[ci]->h[li], &L[ci][li]->ecount, L[ci][li]->elist,L[ci][li]->eindex,Q[ci]->s);
        tpsum += tpn[li];
        }
    weight = exp(beta[ci]*tpsum);
	weight *= (oldm/newm)*exp(-d*((nloci/newm) - (nloci/oldm))); /*this corrects for the difference in sim. probability*/
    U = uniform();
	if (weight >= 1.0 || weight > U)
        {
        for (li = 0; li< nloci; li++)
            {
            L[ci][li]->oldprob = tpn[li];
            }
		return newm;
        }
	else return oldm;
	} /* changecommonmall */

double changecommonmsingle(int ci, int li, double oldm, double maxm)
    {
	double U, weight, newm, d;
    double tpn, tpsum;  
	
    d=expo(1/oldm);
    U = uniform();
	if (U > 0.5) newm = oldm + 0.05 + d;
	else newm = oldm - 0.05 - d;
    while ((newm > maxm) || (newm < 0))
        {
        if (newm > maxm)
                newm = 2.0*maxm - newm;
        else if (newm < 0)
                newm = - newm;
        }
    //tpn = ptreeprob(Q[ci]->q1,Q[ci]->q2,Q[ci]->qA,newm,newm, Q[ci]->t, Q[ci]->h[li], &L[ci][li]->ecount, L[ci][li]->elist, Q[ci]->s);
	tpn = ptreeprob(Q[ci]->q1,Q[ci]->q2,Q[ci]->qA,newm,newm, Q[ci]->t, Q[ci]->h[li], &L[ci][li]->ecount, L[ci][li]->elist,L[ci][li]->eindex, Q[ci]->s);
    tpsum = tpn - L[ci][li]->oldprob;
    weight = exp(beta[ci]*tpsum);
	weight *= (oldm/newm)*exp(-d*((1/newm) - (1/oldm))); /*this corrects for the difference in sim. probability*/
    U = uniform();
	if (weight >= 1.0 || weight > U)
        {
        L[ci][li]->oldprob = tpn;
		return newm;
        }
	else return oldm;
	} /* changecommonmsingle */

/* changeu picks new values on a log scale over a very wide range
the recorded range is set to be 1/10000 -10000  (i.e. over a
100,000,000 fold range.  However the actual range is set to be much greater
This effectively sets the range to be infinite, and causes mutation rates to be picked without a prior.
By setting the actual range to be very wide, the prior probability within the range of 1/10000 -10000 becomes fairly flat */

#define MAXURCHECK 100  /* not sure how difficult it will be to find random ratios that fit the priors */

int changeu(int ci, int j, int uj)
	{
    /* update the ratio between two mutation rate scalars .  The upate is drawn from a uniform log scale between 1/maxval and maxval */
    double U, newr, weight, olduj,olduk;
    double newlike[2], newkappa[2];
    double d, r;
    int k, uk,lj, lk, ul;
	int aj, ak;
    static int start = 0;
	static double windowsize, maxval;
	double tempr;
	int urcheck, counturcheck;

    /* windowsize and maxval are on log scales */
	/* j and k are the positions in the list of parameters
		uj and uk are the positions in Q[]->u 
		lj and lk  are the corresponding locus numbers
		aj and ak  are the positions in A[] for loci with multiple SMM components  */
	
     if (start == 0)
        {
		maxval =  3*Qmax.u[0];
		if (progopts[MUTATIONPRIORRANGE])
			windowsize = Qmax.u[0];
		else
			windowsize = Qwin.u[0];
        start = 1;
        }
    if (nurates > 2)
        do {
            uk = (int) (uniform() * nurates);
            }
        while (uk == uj || uk < 0 || uk >=nurates);
    else 
        {
        myassert(uj==0);
        uk = 1;
        }
    k = firstuparam +uk ;
    lj = paraminfo[j].locus;
    lk = paraminfo[k].locus;
	if (paraminfo[j].utype == STEPWISE)
		aj = uj - (locusulookup[lj] + (L[0][lj]->model == JOINT_IS_SW));
	if (paraminfo[k].utype == STEPWISE)
		ak = uk - (locusulookup[lk] + (L[0][lk]->model == JOINT_IS_SW));
	olduj = Q[ci]->u[uj];
	olduk = Q[ci]->u[uk];
    r = log(olduj/olduk);
	if (progopts[MUTATIONPRIORRANGE])
		{
		counturcheck = 0;
		do
			{
			if (counturcheck >= MAXURCHECK)
				return -1;
			U = uniform();
			if (U > 0.5)
				newr = r + (2.0*U-1.0)*windowsize;
			else
				newr = r - windowsize*U*2.0;
			if (newr > maxval)
				newr = 2.0*maxval - newr;
			else if (newr < -maxval)
				newr = 2.0*(-maxval) - newr; 
			d = exp((newr - r)/2);
			/* urri[i][j] has a 0 if neither i nor j has a prior. 1 if i has a prior and j does not,  -1 if i does not have a pior and j does  */
			/* must check if the new rates will cause the ratios among scalars to fall outside of the allowed ranges of ratios  */
			/* if they do, then they are rejected */
			urcheck = 0;
			counturcheck++;
			if (urri[uj][uk] == 2)  // both scalars have priors 
				{
				urcheck = (newr <= urrlow[uj][uk] || newr >= urrhi[uj][uk]);
				for (ul = 0; ul < nurates; ul++)
					{
					if (urri[uj][ul] == 2 && ul != uk)
						{
						tempr = log(d*Q[ci]->u[uj] / Q[ci]->u[ul]);
						urcheck = urcheck || (tempr <= urrlow[uj][ul] || tempr >= urrhi[uj][ul]);
						}
					if (urcheck)
						break;
					}
				for (ul = 0; ul < nurates; ul++)
						{
						if (urri[ul][uk] == 2 && ul != uj)
							{
							tempr = log(Q[ci]->u[ul] / (Q[ci]->u[uk]/d));
							urcheck = urcheck || (tempr <= urrlow[ul][uk] || tempr >= urrhi[ul][uk]);
							}
						if (urcheck)
							break;
						}
				}
			else
				{
				if (urri[uj][uk] == 1)  // the uj scalar has a prior, but not the uk scalar
					{
					for (ul = 0; ul < nurates; ul++)
						{
						if (urri[uj][ul] == 2)
							{
							tempr = log(d*Q[ci]->u[uj] / Q[ci]->u[ul]);
							urcheck = urcheck || (tempr <= urrlow[uj][ul] || tempr >= urrhi[uj][ul]);
							}
						if (urcheck)
							break;
						}
					}
				if (urri[uj][uk] == -1) // the uk scalar has a prior, but not the uj scalar
					{
					for (ul = 0; ul < nurates; ul++)
						{
						if (urri[ul][uk] == 2)
							{
							tempr = log(Q[ci]->u[ul] / (Q[ci]->u[uk]/d));
							urcheck = urcheck || (tempr <= urrlow[ul][uk] || tempr >= urrhi[ul][uk]);
							}
						if (urcheck)
							break;
						}
					}
				}
			}
		while (urcheck);
		}
	else
		{
		U = uniform();
		if (U > 0.5)
			newr = r + (2.0*U-1.0)*windowsize;
		else
			newr = r - windowsize*U*2.0;
		if (newr > maxval)
			newr = 2.0*maxval - newr;
		else if (newr < -maxval)
			newr = 2.0*(-maxval) - newr; 
		d = exp((newr - r)/2);
		}

	Q[ci]->u[uj] *= d;
	Q[ci]->u[uk] /= d;

	switch(paraminfo[j].utype)
        {
        case HKY:
                U = uniform();
                if (U > 0.5)
                    {
                    newkappa[0] = kappa[ci][lj] + (2.0*U-1.0)*kappawindowsize[lj];
                    if (newkappa[0] > kappamax[lj])
                        newkappa[0] = 2.0*kappamax[lj] - newkappa[0];
                    }
                else
                    {
                    newkappa[0] = kappa[ci][lj] - kappawindowsize[lj]*U*2.0;
                    if (newkappa[0] < 0)
                        newkappa[0] = - newkappa[0];
                    }
                newlike[0] = likelihoodHKY(ci, lj, Q[ci]->u[uj], newkappa[0], -1, -1, -1, -1);
                break;
        case INFINITESITES:
               newlike[0] = likelihoodIS(ci, lj, Q[ci]->u[uj]); 
               break;
        case STEPWISE :
              newlike[0] = likelihoodSW(ci, lj, aj, Q[ci]->u[uj]); 
              break;
        }
	if (paraminfo[j].utype == STEPWISE)
		weight = newlike[0] - L[ci][lj]->oldlike_a[aj]; 
	else 
		weight = newlike[0] - L[ci][lj]->oldlike; 
	switch(paraminfo[k].utype)
        {
        case HKY:
                U = uniform();
                if (U > 0.5)
                    {
                    newkappa[1] = kappa[ci][lk] + (2.0*U-1.0)*kappawindowsize[lk];
                    if (newkappa[1] > kappamax[lk])
                        newkappa[1] = 2.0*kappamax[lk] - newkappa[1];
                    }
                else
                    {
                    newkappa[1] = kappa[ci][lk] - kappawindowsize[lk]*U*2.0;
                    if (newkappa[1] < 0)
                        newkappa[1] = - newkappa[1];
                    }
                newlike[1] = likelihoodHKY(ci, lk, Q[ci]->u[uk], newkappa[1], -1, -1, -1, -1);
                break;
        case INFINITESITES:
               newlike[1] = likelihoodIS(ci, lk, Q[ci]->u[uk]); 
               break;
        case STEPWISE :
              newlike[1] = likelihoodSW(ci, lk, ak, Q[ci]->u[uk]); 
              break;
        }
	if (paraminfo[k].utype == STEPWISE)
		weight += newlike[1] - L[ci][lk]->oldlike_a[ak]; 
	else 
		weight += newlike[1] - L[ci][lk]->oldlike; 

    weight = exp(beta[ci]*weight);
    U = uniform();
	if (weight >= 1.0 || weight > U)
        {
		if (paraminfo[j].utype == STEPWISE)
			L[ci][lj]->oldlike_a[aj] = newlike[0];
		else
			L[ci][lj]->oldlike = newlike[0];
		if (paraminfo[k].utype == STEPWISE)
				L[ci][lk]->oldlike_a[ak] = newlike[1];
			else
				L[ci][lk]->oldlike = newlike[1];
		if (paraminfo[j].utype ==HKY)
			{
			kappa[ci][lj]=newkappa[0];
			copyfraclike(ci,lj);
			storescalefactors(ci, lj);
			}
		if (paraminfo[k].utype==HKY)
			{
			kappa[ci][lk]=newkappa[1];
			copyfraclike(ci,lk);
			storescalefactors(ci, lk);
			}
		return 1;
		}
	else 
		{
		/* have to reset the dlikeA values in the trees for stepwise model */
		Q[ci]->u[uj] = olduj;
		Q[ci]->u[uk] = olduk;
		if (paraminfo[j].utype == STEPWISE)
			{
			aj = uj - (locusulookup[lj] + (L[0][lj]->model == JOINT_IS_SW));
			L[ci][lj]->oldlike_a[aj] = likelihoodSW(ci, lj, aj, Q[ci]->u[uj]); 
			}
		if (paraminfo[k].utype == STEPWISE)
			{
			ak = uk - (locusulookup[lk] + (L[0][lk]->model == JOINT_IS_SW));
			L[ci][lk]->oldlike_a[ak] = likelihoodSW(ci, lk, ak, Q[ci]->u[uk]); 
			}
		if (paraminfo[j].utype==HKY)
			restorescalefactors(ci, lj);
		if (paraminfo[k].utype==HKY)
			restorescalefactors(ci, lk);
		return 0;
		}
    }  /* changeu */

/* only use for HKY model with single locus data sets, otherwise kappa is updated in changeu */
int changekappa(int ci)
	{
	int li;
	double U, weight,newlike, newkappa;

	li = 0;
    U = uniform();
    if (U > 0.5)
        {
        newkappa = kappa[ci][li] + (2.0*U-1.0)*kappawindowsize[li];
        if (newkappa > kappamax[li])
            newkappa = 2.0*kappamax[li] - newkappa;
        }
    else
        {
        newkappa = kappa[ci][li] - kappawindowsize[li]*U*2.0;
        if (newkappa < 0)
            newkappa = - newkappa;
        }
    newlike = likelihoodHKY(ci, 0, Q[ci]->u[0], newkappa, -1, -1, -1, -1);
    weight = newlike -  L[ci][0]->oldlike; 
    weight = exp(beta[ci]*weight);
    U = uniform();
	if (weight >= 1.0 || weight > U)
		{
          L[ci][li]->oldlike = newlike;
          kappa[ci][li]=newkappa;
		  copyfraclike(ci,li);
		  storescalefactors(ci, li);
		return(1);
		}
	else
		{
	   restorescalefactors(ci, li);
	   return(0);
		}
	} /* changekappa */

/* works like changeu */
int changeh(int ci, int hi)
	{
    double U, newr, weight, oldhi, oldhj;
    double tpn[MAXLOCI];
    double d, r;
    int mi, hj;
    static int start = 0;
	static double windowsize, maxval;
    double m1, m2;

    /* windowsize and maxval are on log scales */
    if (start == 0)
        {
		maxval = 2*Qmax.h[0];
		windowsize = Qwin.h[0];
        start = 1;
        }
    if (nloci > 2)
        do {
            hj = (int) (uniform() * nloci);
            }
        while (hj == hi || hj < 0 || hj >=nloci);
    else 
        {
        myassert(hi==0);
        hj = 1;
        }

    oldhi = Q[ci]->h[hi];
    oldhj = Q[ci]->h[hj];
    r = log(oldhi/oldhj);

    U = uniform();
	if (U > 0.5)
		newr = r + (2.0*U-1.0)*windowsize;
	else
		newr = r - windowsize*U*2.0;
	if (newr > maxval)
		newr = 2.0*maxval - newr;
	else if (newr < -maxval)
		newr = 2.0*(-maxval) - newr; 
    d = exp((newr - r)/2);
    Q[ci]->h[hi] *= d;
    Q[ci]->h[hj] /= d;
    weight = 0;
    (progopts[LOCUSMIGRATION]) ? (mi=hi): (mi=0);
    m1 = Q[ci]->m1[mi];
    m2 = Q[ci]->m2[mi];
	//tpn[hi] = ptreeprob(Q[ci]->q1,Q[ci]->q2,Q[ci]->qA,m1,m2, Q[ci]->t,Q[ci]->h[hi], &L[ci][hi]->ecount, L[ci][hi]->elist, Q[ci]->s);
	tpn[hi] = ptreeprob(Q[ci]->q1,Q[ci]->q2,Q[ci]->qA,m1,m2, Q[ci]->t,Q[ci]->h[hi], &L[ci][hi]->ecount, L[ci][hi]->elist,L[ci][hi]->eindex, Q[ci]->s);
	weight += tpn[hi] -  L[ci][hi]->oldprob; 
    (progopts[LOCUSMIGRATION]) ? (mi=hj): (mi=0);
    m1 = Q[ci]->m1[mi];
    m2 = Q[ci]->m2[mi];
	//tpn[hj] = ptreeprob(Q[ci]->q1,Q[ci]->q2,Q[ci]->qA,m1,m2, Q[ci]->t,Q[ci]->h[hj], &L[ci][hj]->ecount, L[ci][hj]->elist, Q[ci]->s);
	tpn[hj] = ptreeprob(Q[ci]->q1,Q[ci]->q2,Q[ci]->qA,m1,m2, Q[ci]->t,Q[ci]->h[hj], &L[ci][hj]->ecount, L[ci][hj]->elist,L[ci][hj]->eindex, Q[ci]->s);
	weight += tpn[hj] -  L[ci][hj]->oldprob; 
	weight = exp(beta[ci]*weight);
    U = uniform();
	if (weight >= 1.0 || weight > U)
        {
		L[ci][hi]->oldprob = tpn[hi];
		L[ci][hj]->oldprob = tpn[hj];
		return 1;
        }
	else 
        {
        Q[ci]->h[hi] = oldhi;
        Q[ci]->h[hj] = oldhj;
        return 0;
        }
    }  /* changeh */

int changet(int ci, double *t, double tmax, double tmin, double twin)
	{
	double weight, newt, temp;
    double tpnew[MAXLOCI],likenew[MAXLOCI + MAXLINKEDSMM], likenewsum;
    double tr,tpw;
    int li, i,mi,j, ec;
    double m1, m2,U;
	int ai, ui;
	struct edge *tree;

    temp=uniform();
    newt = (*t - twin/2) + temp*twin;
    while ((newt > tmax) || (newt < tmin))
		{
        if (newt > tmax)
			newt = 2.0 * tmax - newt;
		else 
			if (newt < tmin)
				newt = 2.0 * tmin - newt;
		} 
    tr = newt/ *t;

    tpw = 0;
    weight = 1.0;
    ec = 0;
	likenewsum = 0;
    for (ui = 0, li=0;li < nloci;li++)
        {
		tree = L[ci][li]->tree;
        (progopts[LOCUSMIGRATION]) ? (mi=li): (mi=0);
        m1 = Q[ci]->m1[mi];
        m2 = Q[ci]->m2[mi];
        ec += L[ci][li]->numgenes-1;
        L[ci][li]->roottime *= tr;
        for (i=0; i< L[ci][li]->numlines; i++)
		    {
            if (tree[i].down != -1)
                {
		        j = 0;
                while (*(tree[i].mig + j) > -0.5)
                    {
                    *(tree[i].mig + j) *= tr;
                    j++;
                    ec++;
                    }
                tree[i].time *= tr;
                }
		    }
        for (j = 0; j < L[ci][li]->ecount; j++)
            {
            myassert((L[ci][li]->elist + j)->time >= 0);
            (L[ci][li]->elist + j)->time *= tr;
            }
        //tpnew[li] = ptreeprob(Q[ci]->q1,Q[ci]->q2,Q[ci]->qA,m1,m2, newt,Q[ci]->h[li], &L[ci][li]->ecount, L[ci][li]->elist, Q[ci]->s);
		tpnew[li] = ptreeprob(Q[ci]->q1,Q[ci]->q2,Q[ci]->qA,m1,m2, newt,Q[ci]->h[li], &L[ci][li]->ecount, L[ci][li]->elist, L[ci][li]->eindex,Q[ci]->s);
        tpw += tpnew[li] - L[ci][li]->oldprob;
        switch(L[ci][li]->model)
            {
            case HKY : likenew[ui] = likelihoodHKY(ci,li,Q[ci]->u[ui], kappa[ci][li], -1, -1, -1, -1); 
					likenewsum += likenew[ui] - L[ci][li]->oldlike;
					ui++;
					break;
            case INFINITESITES : 
                if (progopts[RETURNPRIOR]) 
                    likenew[ui] = 1;
                else
                    likenew[ui] = (1-tr) * Q[ci]->u[locusulookup[ui]] * L[ci][li]->length + log(tr)*L[ci][li]->numsites + L[ci][li]->oldlike;
				likenewsum += likenew[ui] - L[ci][li]->oldlike;
				ui++;
                //likenew[li] = likelihoodIS(ci, li,Q[ci]->u[li]); should not need to do this
                
                break;
            case STEPWISE : 
				for (ai = 0; ai < L[ci][li]->numsmm; ai++, ui++)
					{
					likenew[ui] =  likelihoodSW(ci,li, ai, Q[ci]->u[ui]); 
					likenewsum += likenew[ui] - L[ci][li]->oldlike_a[ai];
					}
				break;
            case JOINT_IS_SW : 
                if (progopts[RETURNPRIOR]) 
					{
                    likenew[ui] = 1;
					}
                else
					{
					likenew[ui] = (1-tr) * Q[ci]->u[ui] * L[ci][li]->length + log(tr)*L[ci][li]->numsites + L[ci][li]->oldlike;;
					}
				likenewsum += likenew[ui] - L[ci][li]->oldlike;
				ui++;
				for (ai = 0; ai < L[ci][li]->numsmm; ai++, ui++)
					{
					likenew[ui] =  likelihoodSW(ci,li, ai, Q[ci]->u[ui]); 
					likenewsum += likenew[ui] - L[ci][li]->oldlike_a[ai];
					}
                break;
            }
		if (L[ci][li]->roottime  > TIMEMAX) 
			err(ci,li,31);
        }
	tpw += likenewsum;
    weight = exp(beta[ci]*tpw + ec * log(tr));
    U=uniform();
	if (weight >= 1.0 || weight > U )  
        {
        for (ui = 0,li = 0;li <nloci;li++)
		    {
			tree = L[ci][li]->tree;
				L[ci][li]->oldprob = tpnew[li]; 
			switch(L[ci][li]->model)
				{
				case HKY :  L[ci][li]->oldlike = likenew[ui]; 
							ui++;
							storescalefactors(ci,li); 
							copyfraclike(ci,li);
							break;
				case INFINITESITES : 
					L[ci][li]->oldlike = likenew[ui]; ui++;break;
				case STEPWISE : 
					for (ai = 0; ai < L[ci][li]->numsmm; ai++, ui++)
						L[ci][li]->oldlike_a[ai] = likenew[ui];
					break;
				case JOINT_IS_SW : 
					L[ci][li]->oldlike = likenew[ui]; 
					ui++;
					for (ai = 0; ai < L[ci][li]->numsmm; ai++, ui++)
						L[ci][li]->oldlike_a[ai] = likenew[ui];
					break;
				}
            L[ci][li]->length *= tr;
			}
         *t = newt;
         return 1;
        }
     else 
        {
        for (li=0;li < nloci;li++)
            {
			tree = L[ci][li]->tree;
			L[ci][li]->roottime  /=  tr;  

            for (i=0; i< L[ci][li]->numlines; i++)
		        {
                if (tree[i].down != -1)
                    {
                    j=0;
                    while (*(tree[i].mig + j) > -0.5)
                        {
                        *(tree[i].mig + j) /= tr;
                        j++;
                        }
                    tree[i].time /= tr;
                    }
		        }
            for (ec = 0; ec < L[ci][li]->ecount; ec++)
                {
                (L[ci][li]->elist + ec)->time /= tr;
                }
            /* have to reset the dlikeA values in the trees for stepwise model */
			if (L[ci][li]->model == JOINT_IS_SW || L[ci][li]->model == STEPWISE)
				{
				for (ai = 0;ai < L[ci][li]->numsmm; ai++)
					{
					if (L[ci][li]->model == JOINT_IS_SW)
						ui = locusulookup[li]+ai +1;
					else
						ui = locusulookup[li]+ ai;
					L[ci][li]->oldlike_a[ai] = likelihoodSW(ci, li, ai, Q[ci]->u[ui]); 
					}
				}
			if (L[ci][li]->model == HKY) 
				restorescalefactors(ci, li);
            }
        return 0;
        }
    } /* changet */

#ifdef INCLUDESIZECHANGE

double changes(int ci, double olds, double smax, double smin, double windowsize)
	{
    double U, news, weight;
    double tpn[MAXLOCI], tpsum;
    int li, mi;

	U = uniform();
	if (U > 0.5)
		{
		news = olds + (2.0*U-1.0)*windowsize;
		if (news > smax)
			news = 2.0 * smax - news;
		}
	else
		{
		news = olds - windowsize*U*2.0;
        if (news < smin )
            news = 2.0 * smin - news; 
		}
    myassert(news >= smin && news <= smax);
    tpsum = 0.0;
    for (li = 0; li< nloci; li++)
        {
        (progopts[LOCUSMIGRATION]) ? (mi=li): (mi=0);
        tpsum -= L[ci][li]->oldprob; 
		//tpn[li] = ptreeprob(Q[ci]->q1,Q[ci]->q2,Q[ci]->qA,Q[ci]->m1[mi],Q[ci]->m2[mi], Q[ci]->t, Q[ci]->h[li], &L[ci][li]->ecount, L[ci][li]->elist,news);
		tpn[li] = ptreeprob(Q[ci]->q1,Q[ci]->q2,Q[ci]->qA,Q[ci]->m1[mi],Q[ci]->m2[mi], Q[ci]->t, Q[ci]->h[li], &L[ci][li]->ecount, L[ci][li]->elist,L[ci][li]->eindex,news);
        tpsum += tpn[li];
        }
    weight = exp(beta[ci]*tpsum);
    U = uniform();
	if (weight >= 1.0 || weight > U)
        {
        for (li = 0; li< nloci; li++)
            {
            L[ci][li]->oldprob = tpn[li];
            }
		return news;
        }
	else return olds;
	} /* changes*/
#endif
