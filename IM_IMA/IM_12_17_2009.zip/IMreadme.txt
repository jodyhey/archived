12/17/09  
This distribution includes materials for the IM and IMa computer programs 

The directory structure of this archive is as follows
+-base directory
	+--IMAsource
	+--IMsource
	+--papers
	+--spreadsheets


The base directory contains the following files:

Introduction_to_IM_and_IMa_3_5_2007.pdf - documentation that explains the 
	principles behind IM and IMa
Using_IMa_12_16_09.pdf  - documentation that explains how to use IMa
Using_IM_12_16_09.pdf  - documentation that explains how to use IM
IMreadme.txt  - this file
imtest_dos.u  - a tiny test data file with dos/windows end-of-line characters
intest_unix.u - a tiny test data file with unix/linux end-of-line characters
IMrun   small file to keep the program running, as needed (Read documentation for 
	details)
IM.exe  - WIN32 executable of IM (compiled for a maximum of 100 loci and 200
	Metropolis Coupled chains)
IMa.exe  - WIN32 executable of IMa (compiled for a maximum of 100 loci and 200
	Metropolis Coupled chains)


The contents of the subdirectories are as follows:

IMAsource - this directory contains the source code of the IMa program 
IMsource -  this directory contains the source code of the IM program 

The source files for these programs are copyrighted by Jody Hey and Rasmus 
Nielsen.  You may modify them  as needed to recompile for different computers, 
or with different runtime constants, as needed to analyze your data.  None of 
the source code may be incorporated into other programs without permission 
from the authors.  Users who modify the source code may not distribute the 
modified source code to others.      



papers - this directory contains pdf docuemnts of the following papers
	Hey, J. 2005. On the number of new world founders: a population genetic portrait of the peopling of the Americas. PLoS Biol 3:e193.
	Hey, J., and R. Nielsen. 2004. Multilocus methods for estimating population sizes, migration rates and divergence time, with applications to the divergence of Drosophila pseudoobscura and D. persimilis. GENETICS 167:747-760.
	Won, Y. J., and J. Hey. 2005. Divergence population genetics of chimpanzees. Mol Biol Evol 22:297-307.
	Hey J,  Nielsen R. 2007. Integration within the Felsenstein equation for improved Markov chain Monte Carlo methods in population genetics. PNAS 104:2785-2790.

spreadheets - this directory contains Microsoft Excel spreadsheets for 
	plotting marginal distributions. 