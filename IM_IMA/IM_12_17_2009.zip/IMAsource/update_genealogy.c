/* IMa   for IM_analytic    2007-2009  Jody Hey and Rasmus Nielsen*/ 
/* December 17, 2009 */


#undef GLOBVARS
#include "ima.h"


//int slidecount; // use for debugging slider() 

/*********** LOCAL STUFF **********/

struct edge *copyedge;
double *nnminus1; 
int holddownA[MAXLINKED];
int medgedrop, mrootdrop;
int rootmove;
double lmedgedrop, lmrootdrop;
double holdsisdlikeA[MAXLINKED]; 

/* prototype of local functions */
double integrate_coalescent_term(int ci, int cc, double fc, double max, int k);
double integrate_migration_term(int cm, double fm, double max);
void storeoldedges( int ci, int li, int edge, int sisedge, int downedge);
void restoreedges( int ci, int li, int edge, int sisedge, int downedge, int newsisedge);
void slider(int ci, int li, int slidingedge,int *sis, double *timepoint, double *slidedist);
void joinsisdown(int ci, int li,int slidingedge,int sis, int *tmrcachange);
void setedges(int ci, int li,int slidingedge, int down,int newsis);
void storetree(int ci, int li,int mode);
double addmigration(int ci, int li, int edge,  double oldedgetime, double *tlengthpart, int *mpart);

double integrate_coalescent_term(int ci, int cc, double fc, double max, int k)
    { /* note fc includes inheritance scalar - see treeweight 
	when the inheritance scalars vary the expressions are slightly different
    and require the values stored in hterms
    k = 0 for pop1, k=1 for pop2 and k=2 for ancestral pop*/
#define LOG2 0.69314718056 
    double p;
	if (!multipleh)
		{
		if (cc > 0 )  // there was a bug when all loci have the same h where h != 1. 
			//p = uppergamma((int) cc-1,2*fc/max) + log(2/C[0]->L[0].h.val) + (1-cc) * log(fc);
			p = uppergamma((int) cc-1,2*fc/max) + LOG2 - cc *log(C[0]->L[0].h.val) + (1-cc) * log(fc);
		else
			{
			if (2*fc/max >0) /* cc == 0 */
				p = log(max * exp(-2*fc/max) - 2*fc * exp(uppergamma(0,2*fc/(max))));
			else 
				p = log(max);
			}
		}
	else
		{
		if (cc > 0 )
			p = uppergamma((int) cc-1,2*fc/max) + LOG2 - C[ci]->hterms[k] + (1-cc) * log(fc);
		else
			{
            myassert(fabs(C[ci]->hterms[k]) < 1e-10);
			if (2*fc/max >0) /* cc == 0 */
				p = log(max * exp(-2*fc/max) - 2*fc * exp(uppergamma(0,2*fc/max)));
			else 
				p = log(max);
			}
		}
    return p;
    } /* integrate_coalescent_term */

double integrate_migration_term(int cm, double fm, double max)
    {
    double p;
    if (cm > 0)
        p = (-1-cm)*log(fm) + lowergamma((int) cm+1,fm*max);
    else
        {
        if (cm ==1)  
            p = log((1- exp(-fm * max)*(1+ fm * max))/(fm*fm)); /* don't get here, as written, but could use this  */
        else 
            {
            if (fm >0) /* cm == 0 */
                p = log((1- exp(-fm * max))/fm);
            else 
                p = log(max);
            }
        }
    return p;
    } /* integrate_migration_term */

/* info for edge goes in copyedge[0],
   info for sisedge goes in copyedge[1]
   info for downedge goes in copyedge[2] */

void storeoldedges( int ci, int li, int edge, int sisedge, int downedge)
	{
	int i,ai;
    double uptime;
	struct edge *tree = C[ci]->L[li].tree;

	copyedge[0].down = tree[edge].down;
	i = -1;
	do {
		i++;
		*(copyedge[0].mig + i) = *(tree[edge].mig +i);
		} 
    while (*(copyedge[0].mig + i) > -0.5 ); 
	copyedge[0].cmm = tree[edge].cmm;
    medgedrop = i;
	if (edge < C[ci]->L[li].numgenes)
		uptime = 0;
	else
        uptime = tree[tree[edge].up[0]].time;
    if (uptime < C[ci]->t.val)
        if (tree[edge].time < C[ci]->t.val)
            lmedgedrop = tree[edge].time - uptime;
        else
            lmedgedrop = C[ci]->t.val  -  uptime;
    else
        {
        lmedgedrop = 0;
        myassert(medgedrop == 0);
        }
	copyedge[0].time = tree[edge].time;
	copyedge[0].pop = tree[edge].pop;
	copyedge[1].down = tree[sisedge].down;
	i = -1;
	do {
		i++;
		*(copyedge[1].mig + i) = *(tree[sisedge].mig + i);
		} while (*(copyedge[1].mig + i) > -0.5 ); 
	copyedge[1].cmm = tree[sisedge].cmm;
	copyedge[1].time = tree[sisedge].time;
	copyedge[1].pop = tree[sisedge].pop;
	copyedge[2].down = tree[downedge].down;
	i = -1;
	do {
		i++;
		*(copyedge[2].mig + i) = *(tree[downedge].mig + i);
		} while (*(copyedge[2].mig +i) > -0.5 ); 
	copyedge[2].cmm = tree[downedge].cmm;
	copyedge[2].time = tree[downedge].time;
	copyedge[2].pop = tree[downedge].pop;
	copyedge[0].up[0] = tree[edge].up[0];
	copyedge[0].up[1] = tree[edge].up[1];	
    copyedge[1].up[0] = tree[sisedge].up[0];
	copyedge[1].up[1] = tree[sisedge].up[1];	
	copyedge[2].up[0] = tree[downedge].up[0];
	copyedge[2].up[1] = tree[downedge].up[1];	
    if (C[ci]->L[li].model == STEPWISE )
		for (ai = 0; ai < C[ci]->L[li].nlinked; ai++)
        {
        copyedge[0].A[ai] = tree[edge].A[ai];
        copyedge[0].dlikeA[ai] = tree[edge].dlikeA[ai];
        copyedge[1].A[ai] = tree[sisedge].A[ai];
        copyedge[1].dlikeA[ai] = tree[sisedge].dlikeA[ai];
        copyedge[2].A[ai] = tree[downedge].A[ai];
        if (copyedge[2].down != -1)
            {
            copyedge[2].dlikeA[ai] = tree[downedge].dlikeA[ai];
            holddownA[ai] = tree[copyedge[2].down].A[ai];	
            }
        else 
            {
            holddownA[ai] = -1;
            copyedge[2].dlikeA[ai] = 0;
            }
        }
    if (C[ci]->L[li].model == JOINT_IS_SW)
		for (ai = 1; ai < C[ci]->L[li].nlinked; ai++)
        {
        copyedge[0].A[ai] = tree[edge].A[ai];
        copyedge[0].dlikeA[ai] = tree[edge].dlikeA[ai];
        copyedge[1].A[ai] = tree[sisedge].A[ai];
        copyedge[1].dlikeA[ai] = tree[sisedge].dlikeA[ai];
        copyedge[2].A[ai] = tree[downedge].A[ai];
        if (copyedge[2].down != -1)
            {
            copyedge[2].dlikeA[ai] = tree[downedge].dlikeA[ai];
            holddownA[ai] = tree[copyedge[2].down].A[ai];	
            }
        else 
            {
            holddownA[ai] = -1;
            copyedge[2].dlikeA[ai] = 0;
            }
        }
    } /* storoldeges */

/* set the tree back to the way it was */ 
void restoreedges( int ci, int li, int edge, int sisedge, int downedge, int newsisedge)
/*all this can be optimized some*/
	{
	int i, j, ai, down;
	struct edge *tree = C[ci]->L[li].tree;

	if (newsisedge != sisedge)
		{
		down = tree[downedge].down;
		if (down != -1)
			{
			if (tree[down].up[0] == downedge)
				tree[down].up[0] = newsisedge;
			else tree[down].up[1] = newsisedge;
			}
		else 
			{
			C[ci]->L[li].root = newsisedge;
			C[ci]->L[li].roottime = tree[tree[newsisedge].up[0]].time;
            myassert(C[ci]->L[li].roottime <= TIMEMAX);
			}
		tree[newsisedge].down = down;
		if (down != -1)
			{
			i = 0;
			while (*(tree[newsisedge].mig + i) > -0.5 ) 
				i++;
			j = -1;
			do
				{
				j++;
				checkmig(i+j,&(tree[newsisedge].mig),&(tree[newsisedge].cmm));
				*(tree[newsisedge].mig + i + j) = *(tree[downedge].mig + j);
				}while (*(tree[downedge].mig + j) > -0.5 ); 
			}
		else 
            {
            *(tree[newsisedge].mig) = -1;
			if (C[ci]->L[li].model == STEPWISE)
				for (ai = 0; ai < C[ci]->L[li].nlinked; ai++)
					tree[newsisedge].dlikeA[ai] = 0;
			if (C[ci]->L[li].model == JOINT_IS_SW )
				for (ai = 1; ai < C[ci]->L[li].nlinked; ai++)
					tree[newsisedge].dlikeA[ai] = 0;
            }
		tree[newsisedge].time = tree[downedge].time;
		}	
	tree[edge].down = copyedge[0].down;
	i = -1;
	do {
		i++;
		checkmig(i,&(tree[edge].mig),&(tree[edge].cmm));
		*(tree[edge].mig + i) = *(copyedge[0].mig + i);
		} while (*(tree[edge].mig + i) > -0.5 ); 
	tree[edge].time = copyedge[0].time;
	tree[edge].pop = copyedge[0].pop;
	down = tree[sisedge].down;
	tree[sisedge].down = copyedge[1].down;
	if (down != -1)
		{
		if (tree[down].up[0] == sisedge)
			tree[down].up[0] = downedge;
		else tree[down].up[1] = downedge;
		}
	i = -1;
	do {
		i++;
		checkmig(i,&(tree[sisedge].mig),&(tree[sisedge].cmm));
		*(tree[sisedge].mig + i) = *(copyedge[1].mig + i);
		} while (*(tree[sisedge].mig + i) > -0.5 ); 
	tree[sisedge].time = copyedge[1].time;
	tree[sisedge].pop = copyedge[1].pop;
	tree[downedge].down = copyedge[2].down;
	i = -1;
	do {
		i++;
		checkmig(i,&(tree[downedge].mig),&(tree[downedge].cmm));
		*(tree[downedge].mig + i) = *(copyedge[2].mig + i);
		} while (*(tree[downedge].mig + i) > -0.5 ); 
	tree[downedge].time = copyedge[2].time;
	tree[downedge].pop = copyedge[2].pop;
	tree[downedge].up[0] = copyedge[2].up[0];
	tree[downedge].up[1] = copyedge[2].up[1];
	if (tree[downedge].down == -1)
		{
		C[ci]->L[li].roottime = tree[tree[downedge].up[0]].time;
        myassert(C[ci]->L[li].roottime <= TIMEMAX);
		C[ci]->L[li].root = downedge;
		}
    if (C[ci]->L[li].model == STEPWISE  )
		for (ai = 0; ai < C[ci]->L[li].nlinked; ai++)
        {
        tree[edge].A[ai] = copyedge[0].A[ai];
        tree[edge].dlikeA[ai] = copyedge[0].dlikeA[ai] ;
        tree[sisedge].A[ai] = copyedge[1].A[ai];
        tree[sisedge].dlikeA[ai] = copyedge[1].dlikeA[ai];
        tree[downedge].A[ai] = copyedge[2].A[ai];
        tree[downedge].dlikeA[ai] = copyedge[2].dlikeA[ai];
        if (holdsisdlikeA[ai] != 0)
            tree[newsisedge].dlikeA[ai] = holdsisdlikeA[ai];
        }
	  if (C[ci]->L[li].model == JOINT_IS_SW )
		for (ai = 1; ai < C[ci]->L[li].nlinked ; ai++)
        {
        tree[edge].A[ai] = copyedge[0].A[ai];
        tree[edge].dlikeA[ai] = copyedge[0].dlikeA[ai] ;
        tree[sisedge].A[ai] = copyedge[1].A[ai];
        tree[sisedge].dlikeA[ai] = copyedge[1].dlikeA[ai];
        tree[downedge].A[ai] = copyedge[2].A[ai];
        tree[downedge].dlikeA[ai] = copyedge[2].dlikeA[ai];
        if (holdsisdlikeA[ai] != 0)
            tree[newsisedge].dlikeA[ai] = holdsisdlikeA[ai];
        }
    } /* restoreedges  */


void slider(int ci, int li, int slidingedge,int *sis, double *timepoint, double *slidedist)
/* timepoint points at C[ci]->L[li].tree[*slidingedge].time and is the current position of the sliding point, 
slidedist is the distance it must move 
do not restructure the tree. just figure out when and on which branch timepoint ends up on, 
this will be the new sisterbranch
use recursion */
    {
    double uplimit;
	struct edge *tree = C[ci]->L[li].tree;

    if (*slidedist < 0)
        {
		//slidecount++;
        /* go up */
        *slidedist = - *slidedist; 
		if (slidingedge < C[ci]->L[li].numgenes)
			uplimit = 0;
		else
            uplimit = tree[tree[slidingedge].up[0]].time;
        if (iq[m1i].pr.max == 0 && tree[slidingedge].pop != tree[*sis].pop)
            {
            /* if there is no migration, then slidingedge cannot join a node that is in the other population and it must stay below C[ci]->t.val*/
            myassert(*timepoint > C[ci]->t.val);
            uplimit  = DMAX(C[ci]->t.val,uplimit);
            }
        myassert(*timepoint >= uplimit);
        /* if uplimit >= sis up time  - slidingedge cannot reach a node*/
        if (tree[*sis].up[0] == -1  || uplimit >= tree[tree[*sis].up[0]].time)
            {
            if (*slidedist < *timepoint - uplimit) 
                /* slide up and stop,  sis remains the same */
                {
                *timepoint -= *slidedist;
                *slidedist = 0;
                myassert(*timepoint > uplimit);
                return;
                }
            else
                {
                /* slide up and reflect, sis remains the same, leave slidedist positive so slidingedge goes down with next call to slider*/
                *slidedist -= *timepoint - uplimit;
                *timepoint = uplimit;
                myassert(*slidedist > 0);
                slider(ci, li,slidingedge, sis,timepoint,slidedist);
                return;
                }
            }
        else
            {
            /* uplimit is less than sis up time, and thus slidingedge can reach a node */
            if (*slidedist < *timepoint - tree[tree[*sis].up[0]].time) 
                /* slide up and stop,  sis remains the same */
                {
                *timepoint -= *slidedist;
                *slidedist = 0;
                myassert(*timepoint > tree[tree[*sis].up[0]].time);
                return;
                }
            else
                {
                /* slide up and reach a node, pick one side at random and recurse */
                *slidedist -= *timepoint - tree[tree[*sis].up[0]].time;
                *timepoint = tree[tree[*sis].up[0]].time;
                if (bitran() /*uniform() < 0.5*/)
                    {
                    *sis = tree[*sis].up[0];
                    }
                else
                    {
                    *sis = tree[*sis].up[1];
                    }
                /* reset slidedist to negative, so slidingedge continues up the tree in next call to slider */
                *slidedist =  - *slidedist; 
                myassert(*slidedist < 0);
                slider(ci, li,slidingedge,sis,timepoint,slidedist);
                return;
                }
            }
        }
    else
        {
		//slidecount++;
        /* go down */
        if (tree[*sis].down == -1 || *timepoint + *slidedist < tree[*sis].time)
            {
            /* if sis is the root, or distance is less than to next down node, just slide down */
            *timepoint += *slidedist;
			if (*timepoint >= TIMEMAX)
				*timepoint = TIMEMAX;
            *slidedist = 0;
            return;
            }
        else
            {
            /* a down node is reached */
            *slidedist -=  tree[*sis].time - *timepoint;
            *timepoint = tree[*sis].time;
            if (bitran())
                {
                /* begin to slide down the down node*/
                *sis = tree[*sis].down;
                slider(ci, li,slidingedge, sis, timepoint,slidedist);
                return;
                }
            else 
                {
                /* begin to slide up the sis  */
                if (tree[tree[*sis].down].up[0] == *sis)
                    {
                    *sis = tree[tree[*sis].down].up[1];
                    }
                else
                    {
                    *sis = tree[tree[*sis].down].up[0];
                    }
                *slidedist = - *slidedist;

                slider(ci, li,slidingedge, sis, timepoint,slidedist);
                return;
                }
            }
        }
    } /* slider */

void joinsisdown(int ci, int li,int slidingedge,int sis, int *tmrcachange)
    {
    /* extend sis, and free up down */	
    int i,j,ai,downdown, down;
	double uptime;
	struct edge *tree = C[ci]->L[li].tree;

    down = tree[sis].down;
    i = 0;
	while (*(tree[sis].mig + i) > -0.5 ) 
		i++;
	j = -1;
	do {
		j++;
		checkmig(i+1,&(tree[sis].mig), &(tree[sis].cmm));
		*(tree[sis].mig + i) = *(tree[down].mig + j);
		i++;
		} while (*(tree[down].mig + j) > -0.5); 
	tree[sis].time = tree[down].time;

	*(tree[slidingedge].mig) = -1;
    /* set the up to which sis now connects */
    tree[sis].down = tree[down].down;
	downdown = tree[sis].down;
	if (downdown != -1)
		{
        rootmove = 0;
		if (tree[downdown].up[0] == down)
			tree[downdown].up[0] = sis;
		else tree[downdown].up[1] = sis;
        mrootdrop = 0;
        lmrootdrop = 0;
		}
	else
		{
        rootmove = 1;
		*tmrcachange += 1;
/* figure out total time and number of migrants being dropped */
        i = -1;
    	do {
	    	i++;
            }
        while (*(tree[sis].mig + i) > -0.5);
        mrootdrop = i;
		if (sis < C[ci]->L[li]. numgenes)
			uptime = 0;
		else
            uptime = tree[tree[sis].up[0]].time;
        if (uptime < C[ci]->t.val )
            {
            if (C[ci]->L[li].roottime < C[ci]->t.val)
                lmrootdrop = C[ci]->L[li].roottime - uptime;
            else
                lmrootdrop = C[ci]->t.val  -  uptime;
	        }
        else
            lmrootdrop = 0;
		C[ci]->L[li].root = sis;
        tree[sis].down = -1;
		tree[sis].time = TIMEMAX;
		if ( C[ci]->L[li].model == STEPWISE)
			{
			for (ai = 0; ai < C[ci]->L[li].nlinked; ai++)
				tree[sis].dlikeA[ai] = 0;
			}
		if (C[ci]->L[li].model == JOINT_IS_SW)
			{
			for (ai = 1; ai < C[ci]->L[li].nlinked; ai++)
				tree[sis].dlikeA[ai] = 0;
			}
        *(tree[sis].mig) = -1;
        C[ci]->L[li].roottime = uptime;
		}
    } /* joinsisdown */

void setedges(int ci, int li,int slidingedge, int down,int newsis)
    {
    /* split newsis into two parts, and make a new down edge out of the lower part*/
    int i,j, downdown;
	double curt;
	struct edge *tree = C[ci]->L[li].tree;

    curt = tree[slidingedge].time;
	tree[down].time = tree[newsis].time;
	tree[newsis].time = curt;
    /* set the up  of the edge to which down now connects, depends on whether newsis is the root */
    downdown = tree[newsis].down;
	if (downdown != -1)
		{
		if (tree[downdown].up[0] == newsis)
			tree[downdown].up[0] = down;
		else tree[downdown].up[1] = down;
		}
	else
		{
		/* newsis is the current root so the root must move down */
		C[ci]->L[li].root = down;
		C[ci]->L[li].roottime = curt;
        if (C[ci]->L[li].roottime > TIMEMAX)
            err(ci, li, 72);
		*(tree[down].mig) = -1;
		}
	tree[down].down = downdown;
    /* divide the migration events along newsis into upper part for newsis and lower part for down */
    if (curt > C[ci]->t.val)
        {
        tree[down].pop = 0;
        j = 0;
        }
    else
        {
	    tree[down].pop = tree[newsis].pop;
	    i=0;
	    while (*(tree[newsis].mig + i) > -0.5 && *(tree[newsis].mig + i) < curt)
            {
            i++;
            tree[down].pop = 1 - tree[down].pop;
            }
	    j = 0;
	    if (downdown != -1)
		    {							
		    while (*(tree[newsis].mig + j + i) > -0.5) 
			    {
				checkmig(j,&(tree[down].mig), &(tree[down].cmm));
			    *(tree[down].mig + j) = *(tree[newsis].mig + j + i);
			    j++;
			    }
		    }
        *(tree[newsis].mig + i) = -1;
        }
	*(tree[down].mig + j) = -1;
	tree[newsis].down = tree[slidingedge].down = down;
	tree[down].up[0] = newsis;
	tree[down].up[1] = slidingedge;
    } /* setedges */


/* steps in picking a new genealogy 
- pick an edge, the bottom of which will slide
- save all info for that edge, sis and the down edge that will be freed up
- join the sis and down edges, freeing up an edge
	if down was the root, then sis becomes the root
-set aside the number for the down edge - this is the freed up edge and will get used again later
-do the sliding and pick a new sis and a location - but do not change the tree. 
-split the newsis edge into sis and down edges, and divide the migration events accordingly
-connect the original edge to the new spot
-add migration events to this edge
*/

void storetree(int ci, int li,int mode)
    {
    static double holdlength,holdtlength;
    static double holdroottime;
    static int holdroot;
    static int holdmig;

    if (mode == 0)
        {
        holdlength = C[ci]->L[li].length;
        holdtlength = C[ci]->L[li].tlength;
        holdroottime = C[ci]->L[li].roottime;
        holdroot = C[ci]->L[li].root;
        holdmig = C[ci]->L[li].mignum;
        }
    else
        {
		C[ci]->L[li].length = holdlength;
        C[ci]->L[li].tlength = holdtlength;
        C[ci]->L[li].mignum =holdmig;
        C[ci]->L[li].roottime = holdroottime;
        C[ci]->L[li].root = holdroot;
        }
    } /* storetree */

/* add migration to edge, and to its sister if edge connects to the root, return the log of the hastings ratio of 
    update probabilities */
    /* add migration events to edge that just slid.  Also if it slid down the root node, and moved the root, then migration 
    events may need to be added to the sister branch as well */
	/* tlengthpart is the length of the tree more recent than t */
	/* mpart is just the total number of migration events on the tree */

double addmigration(int ci, int li, int edge,  double oldedgetime, double *tlengthpart, int *mpart)
    {
    int newsis;
    double uptime1, uptime2;
    int m1_popstate, m2_popstate, mp,mp1, mp2, i, j,k;
    double mt1, mt2;
    double mlist[2*ABSMIGMAX];
    double weight;
    double mproposenum, mproposedenom, temp;
	double mparamf, mparamb;
	struct edge *tree = C[ci]->L[li].tree;
	double t;
	int root;

// possible constants to hold	mmax 

/* determine rate to use for update */
	t = C[ci]->t.val;
	root = C[ci]->L[li].root;
    myassert(*mpart >= 0 && *tlengthpart >= 0);
    if (*tlengthpart <= 0) /* should only be possible for samples of one or two sequences */
        {
        if (*mpart ==0)
            mparamf = DMIN(1,1/t);
        else
            mparamf = DMIN(1,*mpart/t);
        }
    else
        {
        if (*mpart ==0)
            mparamf = DMIN(1,1/ *tlengthpart);
        else
            mparamf = *mpart/ *tlengthpart;
        }
    if (mparamf > iq[m1i].pr.max)
        mparamf = iq[m1i].pr.max;

/* do update and calculate probability*/    
    mp1 = mp2 = 0;
	if (edge < C[ci]->L[li].numgenes)
		uptime1 = 0;
	else
        uptime1 = tree[tree[edge].up[0]].time;
    if (uptime1 < t)
        {
        if (tree[edge].time < t)
            {
            mt1 = tree[edge].time - uptime1;
            if (tree[edge].down == root)
                m1_popstate = -1;
            else
                m1_popstate = 1 - (tree[edge].pop == tree[tree[edge].down].pop);
            }
        else
            {
            mt1 = t  -  uptime1;
            m1_popstate = -1;
            }
        }
    else
        mt1 = 0;

    if (tree[edge].down == root)  /* simulate migration on the sister branch as well */
        {
        if (tree[tree[edge].down].up[0] == edge)
            newsis = tree[tree[edge].down].up[1];
        else
            newsis = tree[tree[edge].down].up[0];
		if (newsis < C[ci]->L[li].numgenes)
			uptime2 = 0;
		else
            uptime2 = tree[tree[newsis].up[0]].time;
        m2_popstate = -1;
        if (uptime2 < t)
            {
            if (tree[newsis].time < t)
                {
                mt2 = tree[newsis].time - uptime2;
                myassert(tree[newsis].down == root);
                }
            else
                mt2 = t  -  uptime2;
            }
		else
			mt2 = 0;
        }
    else
        mt2 = 0;

    if (mt1 > 0 && mt2 == 0)
        {
		mp1 = poisson(mparamf*mt1,m1_popstate);
		// could replace these next lines with dirichlet (broken stick), maybe save time
        for (i=0;i<mp1;i++)
            mlist[i] = uptime1 + uniform()*mt1;
        if (mp1 > 1)
			//hpsortreg(mlist-1, mp1);
			sort(mlist-1, mp1);
        for (i=0;i<mp1;i++)
			{
			checkmig(i,&(tree[edge].mig),&(tree[edge].cmm));
            *(tree[edge].mig + i) = mlist[i];
			}
        *(tree[edge].mig + mp1) = -1;
        if (tree[edge].down == root)
            {
            /* need to set the population of the new root */
            tree[root].pop = tree[edge].pop;
            i=0; 
			while (*(tree[edge].mig + i) > -0.5) i++;
			if (ODD(i))
                tree[root].pop = 1 - tree[root].pop;
            }
        switch (m1_popstate)
			 {
			case -1 : temp = mp1 * log(mparamf) - mparamf*mt1;  break;
			case 0  : temp = mp1 * log(mparamf) - mylogcosh(mparamf*mt1); break;
			case 1  : temp = mp1 * log(mparamf) - mylogsinh(mparamf*mt1); break;
			default : err(ci, li, 73);
			}
        }
    if (mt2 > 0 && mt1 == 0)  
        {
		mp2 = poisson(mparamf*mt2,m2_popstate);
        for (i=0;i<mp2;i++)
            mlist[i] = uptime2 + uniform()*mt2;
		if (mp2 > 1)
			//hpsortreg(mlist-1, mp2);
			sort(mlist-1, mp2);
        for (i=0;i<mp2;i++)
			{
			checkmig(i,&(tree[newsis].mig),&(tree[newsis].cmm));
            *(tree[newsis].mig + i) = mlist[i];
			}
        *(tree[newsis].mig + mp2) = -1;
        if (tree[newsis].down == root)
            {
            /* need to set the population of the new root */
            tree[root].pop = tree[newsis].pop;
            i=0;
	        while (*(tree[newsis].mig + i) > -0.5) i++;
			if (ODD(i))
                tree[root].pop = 1 - tree[root].pop;
            }
        myassert(m2_popstate==-1);
		switch (m2_popstate)
			 {
			case -1 : temp = mp2 * log(mparamf) - (mparamf * mt2); break;
			case 0  : temp = mp2 * log(mparamf) - mylogcosh(mparamf * mt2);	break;
			case 1  : temp = mp2 * log(mparamf) - mylogsinh(mparamf * mt2);	break;
			default : err(ci, li, 73);
			}
        }
    if (mt2 > 0 && mt1 > 0)
        {
        if (tree[edge].time > t)
            {
            myassert(tree[edge].time == tree[newsis].time);
			mp1 = poisson(mparamf*mt1,-1);
			mp2 = poisson(mparamf*mt2,-1);
			// move this down a bit temp = (mp1 + mp2) * log(mparamf) - (mparamf * (mt1+mt2));
			            
			for (i=0;i<mp1;i++)
				mlist[i] = uptime1 + uniform()*mt1;
			if (mp1 > 1)
				//hpsortreg(mlist-1, mp1);
				sort(mlist-1, mp1);
			for (i=0;i<mp1;i++)
				{
				checkmig(i,&(tree[edge].mig),&(tree[edge].cmm));
				*(tree[edge].mig + i) = mlist[i];
				}
			*(tree[edge].mig + mp1) = -1;
			if (tree[edge].down == root)
				{
				if (tree[edge].time < t)
					{
					/* need to set the population of the new root */
					tree[root].pop = tree[edge].pop;
					i=0;
					while (*(tree[edge].mig + i) > -0.5)	i++;
					if (ODD(i))
						tree[root].pop = 1 - tree[root].pop;
					}
				else
					tree[root].pop = 0; /* may not be necessary */
				}
			for (i=0;i<mp2;i++)
				mlist[i] = uptime2 + uniform()*mt2;
			if (mp2 > 1) 
				//hpsortreg(mlist-1, mp2);
				sort(mlist-1, mp2);
			for (i=0;i<mp2;i++)
				{
				checkmig(i,&(tree[newsis].mig),&(tree[newsis].cmm));
				*(tree[newsis].mig + i) = mlist[i];
				}
			*(tree[newsis].mig + mp2) = -1;
			temp = (mp1 + mp2) * log(mparamf) - (mparamf * (mt1+mt2));
            }
        else
            {
			i=0;
			mp = poisson(mparamf*(mt1+mt2), ODD(tree[edge].pop + tree[newsis].pop));
			/* move this down a bit
			if (ODD(mp))
				temp = mp * log(mparamf) - mylogsinh(mparamf * (mt1+mt2));
			else
				temp = mp * log(mparamf) - mylogcosh(mparamf * (mt1+mt2)); */
			for (i=0;i<mp;i++)
				{
				mlist[i] = uniform()*(mt1+mt2);
				}
			if (mp > 1)
				//hpsortreg(mlist-1, mp);
				sort(mlist-1, mp);
			i = 0;
			while (mlist[i] + uptime1 < tree[edge].time && i < mp)
				{
				checkmig(i,&(tree[edge].mig),&(tree[edge].cmm));
				*(tree[edge].mig + i) = mlist[i] + uptime1;
				myassert(*(tree[edge].mig + i) > uptime1 && *(tree[edge].mig + i) < t);
				myassert(*(tree[edge].mig + i) < tree[edge].time);
				myassert(i==0 || *(tree[edge].mig + i) > *(tree[edge].mig + i-1));
				i++;
				}
			*(tree[edge].mig + i) = -1; 
			mp1 = i;
			mp2 = mp - i;
			for (j=i, k=0;j < mp;j++, k++)
				{
				checkmig(k,&(tree[newsis].mig),&(tree[newsis].cmm));
				*(tree[newsis].mig + k) = uptime2 + mlist[j] -  (tree[edge].time - uptime1);
				myassert(*(tree[newsis].mig + k) > uptime2 && *(tree[newsis].mig + k) < t);
				myassert(*(tree[newsis].mig + k) < tree[newsis].time);
				myassert(k==0 || *(tree[newsis].mig + k) > *(tree[newsis].mig + k-1));
				}
			*(tree[newsis].mig + k) = -1; 
			myassert(mp2 == k);
			if (tree[edge].down == root)
				{
				tree[root].pop = tree[edge].pop;
				i=0;
				while (*(tree[edge].mig + i) > -0.5)	i++;
				if (ODD(i))
					tree[root].pop = 1 - tree[root].pop;
				}
			if (ODD(mp))
				temp = mp * log(mparamf) - mylogsinh(mparamf * (mt1+mt2));
			else
				temp = mp * log(mparamf) - mylogcosh(mparamf * (mt1+mt2));
			}
        }
    if (mt2 <= 0 && mt1 <= 0) // should not get here
        temp = 0;

/* calculate probability of reverse update    */
    mproposedenom = temp;
    *tlengthpart = *tlengthpart - lmedgedrop - lmrootdrop + mt1 + mt2;
    *mpart = *mpart - medgedrop - mrootdrop + mp1 + mp2;
    myassert(*mpart >= 0 && *tlengthpart >= 0);
    if (*tlengthpart <= 0) /* should only be possible with samples of one or two sequences */
        {
        if (*mpart ==0)
            mparamb = DMIN(1,1/t);
        else
            mparamb = DMIN(1,*mpart/t);
        }
    else
        {
        if (*mpart ==0)
            mparamb = DMIN(1,1/ *tlengthpart);
        else
            mparamb = *mpart/ *tlengthpart;
        }
    if (mparamb > iq[m1i].pr.max)
        mparamb = iq[m1i].pr.max;
    temp = 0;
    if (rootmove)
        {
        if (oldedgetime > t)
            {
            if (lmedgedrop <= 0 && lmrootdrop > 0)
                temp = mrootdrop * log(mparamb) - (mparamb * lmrootdrop);
            if (lmedgedrop > 0 && lmrootdrop <= 0)
                temp = medgedrop * log(mparamb) - (mparamb * lmedgedrop);
            if (lmedgedrop > 0 && lmrootdrop > 0)
                temp = (mrootdrop + medgedrop) * log(mparamb) - (mparamb *(lmrootdrop+lmedgedrop));
			if (lmedgedrop <= 0 && lmrootdrop <= 0)
                temp = 0;
            }
        else
            {
            myassert(lmedgedrop > 0 && lmrootdrop > 0);
            if (ODD(medgedrop + mrootdrop))
				 temp =  (mrootdrop + medgedrop) * log(mparamb) - mylogsinh(mparamb *(lmrootdrop+lmedgedrop));
            else 
				 temp =  (mrootdrop + medgedrop) * log(mparamb) - mylogcosh(mparamb *(lmrootdrop+lmedgedrop));
            }
        }
    else
        {
        myassert(lmrootdrop ==0 && mrootdrop==0);
        if (lmedgedrop > 0)
            {
            if (oldedgetime > t)
                temp = medgedrop * log(mparamb) - (mparamb * lmedgedrop);
            else
                {
                if (ODD(medgedrop))
					 temp = medgedrop * log(mparamb) - mylogsinh(mparamb * lmedgedrop);
                else 
					 temp = medgedrop * log(mparamb) - mylogcosh(mparamb * lmedgedrop);
                }
            }
        else
            temp = 0;
        }
    mproposenum = temp;
	weight  = mproposenum - mproposedenom;
    return weight;
    } /* addmigration */


/********** GLOBAL FUNCTIONS ***********/


void ginit(void) // initialize a couple things needed for genealogy calculations and updating
	{
	int i, li, hkyinc;
	int largestsamp;
	copyedge = malloc(3*(sizeof(struct edge)));
	for (i=0;i<3;i++)
		copyedge[i].mig = malloc(ABSMIGMAX * sizeof(double));
	if (somestepwise)
		for (i=0;i<3;i++)
			{
			copyedge[i].A = calloc(MAXLINKED, sizeof(int));
			copyedge[i].dlikeA = calloc(MAXLINKED, sizeof(double));
			}
	for (li = 0;li < nloci; li++)
		if (C[0]->L[li].model == HKY)
			{
			hkyinc = 1;
			}
	for (i = 0,li = 0; li < nloci; li++)
        if (i < C[0]->L[li].numgenes)  i = C[0]->L[li].numgenes;
	largestsamp = i;
	nnminus1 = malloc((largestsamp+1)*sizeof(double));
	nnminus1[0] = 0;
	for (i=1;i<=largestsamp;i++)
		{
		nnminus1[i] = (double) (i) * ((double) i - 1);
		}
	} /* ginit */


void treeweight(int ci, int li, double divt)
/* events are migrations, m = 1, or coalescent, c = 0 or population splitting, t = -1
e contains information for events. event i is contained in e+i and includes
the time till the next event, time
the event that happens at that time cmt (0 or 1 or -1)
the population in which the event happens 
if that event is migration, the pop is the one from which the migrant is leaving
the number of individuals in each population, just before the event happens.
*/
    {
//double treeinfo[fm2+1];
	
    int i,j,nowpop, n0, n1,n01,  ncount;
    double upt, ttemp, lasttime, sumtime=0;
    struct treeevent *e;
    int ec;
    double rh2;
	unsigned long *eci;
	struct locus *L = &(C[ci]->L[li]);
	struct edge *tree = L->tree;
	double *treeinfo = L->treeinfo;
	int ng = L->numgenes;

	myassert(divt >= 0);
	if (L->roottime > divt && divt > 0)
    //if (divt < L->roottime)
        ncount = ng;
    else
        ncount = ng-1;
    L->mignum = 0;
	for (i=0; i<2*ng-1; i++)
		{
		j = 0;
        while (*(tree[i].mig + j) > -0.5 ) j++;
        L->mignum += j;
		myassert(tree[i].up[0] >= -1 && tree[i].up[0] < 2*ng-1
			&& tree[i].up[1] >= -1 && tree[i].up[1] < 2*ng-1); 
		}
	ncount += L->mignum;
	e = malloc(ncount*sizeof(struct treeevent));
    ec = 0;
    for (i=0; i<2*ng-1; i++)
        {
		nowpop = tree[i].pop;
        if (i < ng)
			upt = 0;
		else
			{
			upt = tree[tree[i].up[0]].time;
            myassert(i>= ng); 
            (e + ec)->time = upt;
            (e + ec)->cmt = 0;
			if (upt >= divt) 
				(e + ec)->pop = 0;
			else  
				(e + ec)->pop = nowpop;
		    ec += 1;
            }
		j = 0;
        while (*(tree[i].mig + j) > -0.5 )
			{
            myassert(*(tree[i].mig + j) >= upt); 
			myassert(*(tree[i].mig + j) < divt);
			(e + ec)->time = *(tree[i].mig + j);
			(e + ec)->pop = nowpop;
            nowpop = 1-nowpop;
			(e + ec)->cmt = 1;
			ec += 1;	
			j++;
			}
        }
    if (L->roottime > divt && divt > 0)
        {
        (e + ec)->time = divt;
        (e + ec)->cmt = -1;
        ec += 1;
        }
    myassert(ncount==ec);
	eci = malloc(ncount*sizeof(unsigned long));
	indexx(ec,e-1,eci-1);  // sorts an index of locations in ec by time 
    n0=L->numpop1;
    n1=L->numpop2;
    lasttime = 0;
    treeinfo[cc1]=  treeinfo[cc2]=  treeinfo[cca]=  treeinfo[fc1]=  treeinfo[fc2]= 0;
    treeinfo[fca]=  treeinfo[fm1]=  treeinfo[fm2]=  treeinfo[cm1]=  treeinfo[cm2]= 0;
    L->length = L->tlength = 0;
    rh2 = 1/(2* L->h.val); 
    for (j=0;j<  ec;j++)
       {
		i = eci[j]-1;
        ttemp = (e +i)->time - lasttime;
        myassert(ttemp >= 0);
        myassert(n0 >= 0);
        myassert(n1 >= 0);
		n01 = n0+n1;
        L->length += n01 * ttemp;
        if (lasttime < divt)
            {
            if ((e+i)->time < divt)
                L->tlength += n01 * ttemp;
            else
                L->tlength += n01 * (divt - lasttime);
            }
        lasttime = (e +i)->time;
        if ((e +i)->cmt == -1)
            {
            myassert((e +i)->time == divt);
            sumtime = divt;
            }
        else
            sumtime += ttemp;
        
        if ((e +i)->cmt == -1 || sumtime <= divt)
            {
             treeinfo[fc1] += nnminus1[n0] * ttemp *rh2;
             treeinfo[fc2] += nnminus1[n1] * ttemp *rh2;
            if (iq[m1i].pr.max > 0)
                {
                 treeinfo[fm1] += n0 * ttemp;
                 treeinfo[fm2] += n1 * ttemp;
                }
            }
        else
             treeinfo[fca] += nnminus1[n0] * ttemp *rh2;

        switch ((e +i)->cmt)
            {
            case  0 :  if (sumtime > divt)
                             treeinfo[cca]++;
                        else
                            {
                            if ((e +i)->pop)
								 treeinfo[cc2]++;
							else
                                 treeinfo[cc1]++;
                            }
                        break;
            case  1 :   if ((e +i)->pop)
                             treeinfo[cm2]++;
                        else
                             treeinfo[cm1]++;
                        break;
            case  -1:  break;
            }
        if ((e +i)->cmt==0)
            {
            if ((e +i)->pop)
                n1--;
            else 
                n0--;
            }
        if ((e +i)->cmt ==1)
            {
			myassert(!((n0==0 && (e +i)->pop==0) ||(n1==0 && (e +i)->pop==1)));
            if ((e +i)->pop)
                {
				n1--;
                n0++;
				}
			else
				{
				n0--;
                n1++;
				}
            }
         if ((e +i)->cmt==-1)
            {
            n0 += n1;
			n1 = 0;
            }
        }
    if (modeloptions[ONEPOP])
        {
         treeinfo[cc1] +=  treeinfo[cca];
         treeinfo[fc1] +=  treeinfo[fca];
         treeinfo[cca] = treeinfo[fca]= 0;
        }
    free(e);
	free(eci);
    } /*treeweight */


/* integrate_tree_prob - determine integrated probability of the genealogy  */  
/* function does not know about loci,  all the information needed is contained in 
  *treeinfo,  regardless of whether it is for one locus (called from updategenealogy) or all loci (called
  from changet ) */
double integrate_tree_prob (int  ci, double *treeinfo)
	{
/*       0  1   2   3   4   5   6   7   8   9  10  11  12  13  14   15  16  17  18  19
enum {cc1,cc2,cca,cm1,cm2,fc1,fc2,fca,fm1,fm2,q1k,q2k,qak,m1k,m2k,pdg,prob,h1k,h2k,hak}; */

    double psum;
    int i;
        
    psum = 0;
    treeinfo[q1k] = integrate_coalescent_term(ci, (int) treeinfo[cc1],treeinfo[fc1],iq[q1i].pr.max,0);
    if (!modeloptions[ONEPOP])
        {
        treeinfo[q2k] = integrate_coalescent_term(ci, (int) treeinfo[cc2],treeinfo[fc2],iq[q2i].pr.max,1);
        if (!modeloptions[EQUILIBRIUMMIGRATION])
            treeinfo[qak] = integrate_coalescent_term(ci,  (int) treeinfo[cca],treeinfo[fca],iq[qai].pr.max,2);
        }
    else 
        treeinfo[q2k] =treeinfo[qak] = 0;
    if (iq[m1i].pr.max > 0)
        treeinfo[m1k] = integrate_migration_term( (int) treeinfo[cm1],treeinfo[fm1],iq[m1i].pr.max);
    else 
        treeinfo[m1k] = 0;
    if (iq[m2i].pr.max > 0)
        treeinfo[m2k] = integrate_migration_term( (int) treeinfo[cm2],treeinfo[fm2],iq[m2i].pr.max);
    else 
        treeinfo[m2k] = 0;
    for (psum = paramprior,i = q1k; i <= m2k; i++)
        psum += treeinfo[i];
    treeinfo[prob] = psum;
    myassert(psum > -1e200 && psum < 1e200);
    return(psum);
    } /* integrate_tree_prob */


void copyfraclike(int ci, int li)
    {
    int i,j,k;
	struct edge *tree = C[ci]->L[li].tree;
	int ng = C[ci]->L[li].numgenes;
    
	for (i=ng; i<2*ng-1; i++)
        {
        if (tree[i].hkyi.newfrac[0][0]!=-1)
            {
            for (j=0; j<C[ci]->L[li].numsites; j++)
                    for (k=0; k<4; k++)
                            tree[i].hkyi.frac[j][k]=tree[i].hkyi.newfrac[j][k];
            }
        }
    }


void storescalefactors(int ci, int li)
	{
	int i, k;
	struct edge *tree = C[ci]->L[li].tree;

	for(i=C[ci]->L[li].numgenes; i<2*C[ci]->L[li].numgenes-1; i++)
			for (k=0; k<C[ci]->L[li].numsites; k++)
					tree[i].hkyi.oldscalefactor[k]=tree[i].hkyi.scalefactor[k];
	}


/*  finishSWupdateA() returns the likelihood associated with the allele states on the parts of the tree that have changed
   it returns the difference in likelihoods associated with these parts.  thus the overall likelihood of data can just be
   updated by the value returned from this function. 

	when  finishSWupdate() is entered the tree is not complete, as the allele state of the new downedge is not known
    must pick an allele state for the new downedge:
    the new downedge has the same number as the old downedge, so it is just called downedge hereafter

    at the start the current allele value for downedge is oldA - this however comes from a different part 
       of the tree from the old downedge that was erased
   
    consider - the point at the base of edge is connected to 3 other nodes (2 up and 1 down) unless
    edge is the root in which case there are only 2 ups
    
    start w/ a old value of A at the top of downedge = oldA

    determine the mean (weighted by the length of the branch to the node) of the difference between the A values
    of the connecting nodes and oldA 
    Treat this mean value as the parameter of a geometric distribution.
    pick an rv that is in the necessary direction (+ or -) and add this to oldA  this becomes newA. 
    
    the allele value for downedge becomes newA. the new genealogy is now complete.
    
    now consider the reverse update from new to old A

    again, calculate the weighted mean difference (for the old genealogy) between adjacent allele states and newA. 
    pick a geometric rv 

    Consider the update as this - When the tree jumped from one genealogy to another, this caused oldA to be set to newA

        
    Aterm = log(Pr(oldstate in node | T* -> T)/Pr(new state in node | T -> T*)) is the ratio of two geometric probabilities. 
	Aterm is part of the Hastings term, the proposal ratio.
    This is passed to the calling function along with the new likelihood. */

double finishSWupdateA(int ci, int li, int ai, int edge, int downedge, int sisedge, int newsisedge, double u, double *Aterm)
    {
    int i, j, newA, oldA;
    int d,dA, e[3];
    double geotermnew,geotermold; 
    double upt, time[3];
	int wsumdiff;
    double oldlikeadj=0, likeadj=0;
	struct edge *tree = C[ci]->L[li].tree;
        
    oldA = tree[downedge].A[ai];
    if (newsisedge != sisedge)
        holdsisdlikeA[ai] = tree[newsisedge].dlikeA[ai]; 
    else 
        holdsisdlikeA[ai] = 0;
    oldlikeadj = copyedge[0].dlikeA[ai] + copyedge[1].dlikeA[ai] + copyedge[2].dlikeA[ai] + holdsisdlikeA[ai];
    e[0] = edge; 
    e[1] = newsisedge;
    e[2] = tree[e[0]].down;

    for (i=0;i<3;i++)
        {
        if (e[i] >= C[ci]->L[li].numgenes)
            {
            upt = tree[tree[e[i]].up[0]].time;
            myassert(upt== tree[tree[e[i]].up[1]].time);
            }
        else upt = 0;
        if (tree[e[i]].down != -1)
            {
            time[i] = tree[e[i]].time - upt;
            myassert(time[i] >=0.0);
            }
        }
    myassert(tree[e[0]].time==tree[e[1]].time);
    wsumdiff = 0;
    for (i=0, j=0;i<3;i++)
        {
        if (tree[e[i]].down != -1)
            {
            if (i < 2) 
                d = tree[e[i]].A[ai] - oldA;
            else 
                d = tree[tree[e[i]].down].A[ai] - oldA;
            wsumdiff += abs(d);
            j++;
            }
        }
    /* wsumdiff will be > 0 if oldA is too small */ 
	/*if (wsumdiff > 0)
		geotermnew = j/wsumdiff;
	else 
		geotermnew = 0.5;
    if (geotermnew <= 0 || geotermnew >= 1)
        geotermnew = 0.5; 
		*/
	geotermnew = j/((double) (wsumdiff + j));
	myassert(geotermnew > 0);
	if (geotermnew > 0.95)
        geotermnew = 0.95;

    dA = geometric(geotermnew)-1; 
    if (bitran() /*uniform() < 0.5 */)
        dA = -dA;
    if (dA >= 0)
        newA  = IMIN(C[ci]->L[li].maxA[ai],oldA+dA);
    else
        newA  = IMAX(C[ci]->L[li].minA[ai],oldA+dA);
    tree[downedge].A[ai] = newA;
    myassert(newA >= C[ci]->L[li].minA[ai]);
    dA = newA-oldA;/* difference between new value, and what it would be based simply on weighted mean */
    if (tree[sisedge].down != -1 && sisedge != newsisedge)
        {
        if (sisedge >= C[ci]->L[li].numgenes)
            {
            upt = tree[tree[sisedge].up[0]].time;
            }
        else upt = 0;

        /* set dlikeA for the old sisedge (which is now continuous with the old downedge */ 
        d = tree[sisedge].A[ai] - tree[tree[sisedge].down].A[ai];
        myassert(d<=C[ci]->L[li].maxA[ai]);
        tree[sisedge].dlikeA[ai] = -(tree[sisedge].time - upt)*u + log(bessi(d,(tree[sisedge].time - upt)*u));
        }
    else
        {
        tree[sisedge].dlikeA[ai] = 0; 
        }
    likeadj = tree[sisedge].dlikeA[ai];
    for (i=0, j=0;i<3;i++)
        {
        if (tree[e[i]].down != -1)
            {
            if (i < 2) 
                d = tree[e[i]].A[ai] - newA;
            else 
                d = tree[tree[e[i]].down].A[ai] - newA;
            tree[e[i]].dlikeA[ai] = -(time[i]*u) + log(bessi(d,time[i]*u));
            likeadj += tree[e[i]].dlikeA[ai];
            }
        }
    wsumdiff = 0;
    j = 0;
    for (i=0;i<2;i++)
        {
        d = copyedge[i].A[ai] - newA;
        wsumdiff += abs(d);
        j++;
        }
    if (copyedge[2].down != -1)
        {
        d = holddownA[ai] - newA;
        wsumdiff += abs(d);
        j++;
        }

		/*
	if (wsumdiff > 0)
		geotermold = j /wsumdiff;
	else
		geotermold = 0.5;
    if (geotermold <= 0 || geotermold >= 1)
        geotermold = 0.5;
	*/
	geotermold = j /((double) (wsumdiff + j));
    if (geotermold > 0.95)
        geotermold = 0.95;

    if (modeloptions[RETURNPRIOR]) 
        {
        *Aterm = 0;
        return 0;
        } 
    else 
        { 
        *Aterm = (abs(dA) * log(1-geotermold) + log(geotermold))- (abs(dA) * log(1-geotermnew) + log(geotermnew)); 
        return (likeadj - oldlikeadj);
        } 
    } /* finishSWupdateA*/

#define updateAfrac 0.3333   // inverse of updateAi  just a useful proportion,  don't need to do all of the nodes every step
#define updateAi  3

double updateA(int ci, int li, int ai, double u, int *count)
/* implements a geometric distribution based on the weighted mean difference in allele sizes surrounding the value in the 
node to be updated. branch lengths are used for the weighting */
/* would it be good to randomize the order in which nodes are updated ?  */
    {
    int i, upA[2], downA, newA, oldA;
    int d;
    int up[2],upup[2],down;
    double oldlike, like, dlikeup[2],dlikedown;
    double tup[2], tdown, weightsum, weight;
    double wsumdiff,geotermnew,geotermold, Aterm; 
	struct edge *tree = C[ci]->L[li].tree;
	int ng = C[ci]->L[li].numgenes;

    *count = 0;
    if (modeloptions[RETURNPRIOR]) 
        {
        *count = (int) (updateAfrac * (ng-1));  // don't do anything as it can have no effect 
        return 1;
        }
    for (i=ng;i<2*ng-1;i++)
        {
        /* don't bother with all nodes  just do uprop of them */
        if (uniform() < updateAfrac)
            {
            up[0] = tree[i].up[0];
            up[1] = tree[i].up[1];
            upup[0] = tree[up[0]].up[0];
            upup[1] = tree[up[1]].up[0];
            down = tree[i].down;
            if (upup[0] == -1)
                tup[0] = tree[up[0]].time;
            else 
                tup[0] = tree[up[0]].time - tree[upup[0]].time;
            if (upup[1] == -1)
                tup[1] = tree[up[1]].time;
            else 
                tup[1] = tree[up[1]].time - tree[upup[1]].time;
            oldA = tree[i].A[ai];
            upA[0] = tree[tree[i].up[0]].A[ai];
            upA[1] = tree[tree[i].up[1]].A[ai];
            oldlike = tree[tree[i].up[0]].dlikeA[ai] + tree[tree[i].up[1]].dlikeA[ai];
            wsumdiff = abs(oldA-upA[0])/tup[0]  + abs(oldA-upA[1])/tup[1] ; 
            weightsum = 1/tup[0] + 1/tup[1];
            if (down != -1)
                {
                tdown = tree[i].time - tree[up[0]].time;
                downA =  tree[tree[i].down].A[ai];
                wsumdiff += abs(oldA-downA)/tdown;
                weightsum += 1/tdown;
                oldlike += tree[i].dlikeA[ai];
                }
            else 
                {
                downA = -1;
                }
            /*
            if (wsumdiff > 0)
                geotermnew = weightsum/wsumdiff;
			else 
				geotermnew = 0.5;
            if (geotermnew < 0 || geotermnew >= 1 || wsumdiff <= 0)
                geotermnew = 0.5;
			*/
			geotermnew = weightsum/(wsumdiff + weightsum);
			myassert(geotermnew > 0);
            if (geotermnew > 0.95)
                geotermnew = 0.95;

            d = geometric(geotermnew)-1;
            myassert(d >= 0);
            if (bitran() /*uniform() < 0.5 */)
                newA  = IMAX(C[ci]->L[li].minA[ai],oldA-d);
            else
                newA  = IMIN(C[ci]->L[li].maxA[ai],oldA+d);
            if (newA != oldA)
                {
                wsumdiff = abs(newA-upA[0])/tup[0]  + abs(newA-upA[1])/tup[1] ; 
                if (down != -1)
                    {
                    wsumdiff += abs(newA-downA)/tdown;
                    }
				/*
                if (wsumdiff > 0)
                    geotermold = weightsum/wsumdiff;
				else
					geotermold = 0.5;
                if (geotermold < 0 || geotermold >= 1 || wsumdiff <= 0)
                    geotermold = 0.5;
				*/
				geotermold = weightsum/(wsumdiff + weightsum);
				myassert(geotermold > 0);
                if (geotermold > 0.95)
                    geotermold = 0.95;
                d = newA - upA[0];
                like = dlikeup[0] = -(tup[0]*u) + log(bessi(d,tup[0]*u));
                d =  newA - upA[1];
                like += dlikeup[1] = -(tup[1]*u) + log(bessi(d,tup[1]*u));
                if (down != -1)
                    {
                    d = newA - downA;
                    like += dlikedown = -(tdown*u) + log(bessi(d,tdown*u));
                    }
                Aterm = abs(newA-oldA) * log((1-geotermold)/(1- geotermnew)) + log(geotermold/geotermnew); 
                weight = exp(beta[ci]*(like - oldlike)+Aterm);
                if (weight >= 1.0 || weight > uniform())
                    {
                    tree[i].A[ai] = newA;
                    if (down != -1) 
                        tree[i].dlikeA[ai] = dlikedown;
                    tree[up[0]].dlikeA[ai] = dlikeup[0];
                    tree[up[1]].dlikeA[ai] = dlikeup[1];
                    //*count = *count + 1;
					*count = *count + 1;
                    }
                }
            }
        }
    like = 0;
    for (i=0;i<2*ng-1;i++)
        {
        if (tree[i].down != -1)
            {
            like += tree[i].dlikeA[ai];
            }
        }
    return like;
    } /*updateA */


void restorescalefactors(int ci, int li)
	{
	int i, k;
	struct edge *tree = C[ci]->L[li].tree;

	for(i=C[ci]->L[li].numgenes; i<2*C[ci]->L[li].numgenes-1; i++)
		{
		for (k=0; k<C[ci]->L[li].numsites; k++)
			{
			tree[i].hkyi.scalefactor[k]=tree[i].hkyi.oldscalefactor[k];
			}
		}
	}

#define SLIDESTDVMAX 20

int updategenealogy( int ci, int li, int *topolchange, int *tmrcachange)
	{
	int ui;
	int updateAcount;
	int edge, oldsis, newsis, freededge,accp;
	double like,like_a[MAXLINKED], oldlike;
    double migweight,weight, U;
    double tpw;
	double Aterm[MAXLINKED], Atermsum;
    double holdtreeinfo[fm2+1];
    double holdjointtreeinfo[prob+1];
	double holdhterms[3];
	double hlog;
    int i, ai;
    double slidedist;
    double originaledgetime;
    double tlengthpart;
    int mpart;
	double slideweight, edgel, upedgetime, newedgel, holdslidedist;
	double slidestdv;
	struct locus *L = &(C[ci]->L[li]);
	struct edge *tree = L->tree;
	int rejectIS;
    
/* make copies of things */	
    storetree(ci,li,0);
    for (i=0;i<=fm2;i++)
        holdtreeinfo[i] = L->treeinfo[i];
    for (i=0;i<=prob;i++)
        holdjointtreeinfo[i] = C[ci]->jointtreeinfo[i];
	if (multipleh)
		for (i=0;i<=2;i++)
			holdhterms[i] = C[ci]->hterms[i];
    tlengthpart = L->tlength;
    mpart = L->mignum;

/* initialize */
    migweight = 0;
    Atermsum = 0;
	*tmrcachange = 0;
	*topolchange = 0;
	slideweight = 0;

/* pick an edge */    
	do
		{
		edge = (int) floor(uniform() * L->numlines);
		} while (tree[edge].down  == -1); 
    freededge = tree[edge].down;
	//if (edge < 6)
	//	treeprint(0,0);
	if ((oldsis = tree[freededge].up[0]) == edge)
		oldsis = tree[freededge].up[1];
//	if (oldsis < 6)
//		treeprint(0,0);
	storeoldedges(ci, li, edge, oldsis, freededge);
    originaledgetime = tree[edge].time;
	if (edge < L->numgenes)
		upedgetime = 0;
	else
		upedgetime  = tree[tree[edge].up[0]].time;
	edgel = originaledgetime - upedgetime;
	myassert(edgel > 0);

/* slide edge */ 
	if (L->numgenes < 40)
		slidestdv = DMIN(SLIDESTDVMAX,L->roottime/3); 
	else 
		slidestdv = DMIN(SLIDESTDVMAX,10*originaledgetime); 
	holdslidedist = slidedist = normdev(0, slidestdv);
	slideweight -= log(normprob(0, slidestdv, holdslidedist));
    joinsisdown(ci, li,edge,oldsis, tmrcachange);
	newsis = oldsis; // only temporary, at the beginning of the slide
	//slidecount = 0;
    slider(ci, li, edge,&newsis,&(tree[edge].time), &slidedist); // resets newsis as needed by the slide
    setedges(ci, li, edge, freededge, newsis);
	newedgel = tree[edge].time - upedgetime;
	if (L->numgenes < 40)
		slidestdv = DMIN(SLIDESTDVMAX,L->roottime/3); 
	else 
		slidestdv = DMIN(SLIDESTDVMAX,10*tree[edge].time); 

/* calculate update weights */
	slideweight += log(normprob(0, slidestdv, holdslidedist));
	*topolchange += (oldsis != newsis);
    if (iq[m1i].pr.max > 0)
		migweight += addmigration(ci, li, edge, originaledgetime, &tlengthpart, &mpart);
    else
        migweight += 0;
    treeweight(ci, li, C[ci]->t.val);
	//if (edge < 6)
	//	treeprint(0,0);
//	if (oldsis < 6)
//		treeprint(0,0);
/* set tree terms */
    for (i=cc1;i<=fm2;i++)
        {
        C[ci]->jointtreeinfo[i] += L->treeinfo[i] - holdtreeinfo[i];
        if (C[ci]->jointtreeinfo[i] < 0)
            C[ci]->jointtreeinfo[i] = 0;
        } 
	if (multipleh)
		{
		hlog = log(L->h.val);
		C[ci]->hterms[0] += hlog*(L->treeinfo[cc1]-holdtreeinfo[cc1]);
		C[ci]->hterms[1] += hlog*(L->treeinfo[cc2]-holdtreeinfo[cc2]);
		C[ci]->hterms[2] += hlog*(L->treeinfo[cca]-holdtreeinfo[cca]);
		}   
    /*if (multipleh)  Should not need to do this, just here to check 
		{
        for (i=0;i<3;i++)
            C[ci]->hterms[i] = 0;
        for (i=0;i<nloci;i++)
            {
		    hlog = log(Q[ci]->h[i]);
            C[ci]->hterms[0] += hlog * L[ci][i]->treeinfo[cc1];
		    C[ci]->hterms[1] += hlog * L[ci][i]->treeinfo[cc2];
		    C[ci]->hterms[2] += hlog * L[ci][i]->treeinfo[cca];
            }
        } */

/* calculate P(D|G)  for new genealogy */
	rejectIS = 0; /* in case P(D|G) for IS model is zero */
    switch(L->model)
        {
        case HKY :	oldlike = L->oldlike[0];
					like = like_a[0] = likelihoodHKY(ci, li, L->u[0].mcinf.val, L->kappa.val, edge, freededge, oldsis, newsis); break;
        case INFINITESITES : oldlike = L->oldlike[0];
							like = like_a[0] = like = likelihoodIS(ci, li,L->u[0].mcinf.val); 
							rejectIS = (like == 0);
							break;
        case STEPWISE : 
            {
			for (ai = 0, like = 0, oldlike = 0; ai < L->nlinked; ai++)
				{
				like_a[ai] = L->oldlike[ai] + finishSWupdateA(ci, li, ai, edge, freededge, oldsis, newsis,L->u[ai].mcinf.val, &Aterm[ai]);
				like += like_a[ai];
				oldlike += L->oldlike[ai];
				Atermsum += Aterm[ai];
				}
//            checklikelihoodSW(ci, li,L->u[ai].mcinf.val);  
            break;
            }
        case JOINT_IS_SW : 
			like = like_a[0] = likelihoodIS(ci, li,L->u[0].mcinf.val);
			rejectIS = (like == 0);
			oldlike = L->oldlike[0];
			for (ai = 1; ai < L->nlinked; ai++)
				{
				like_a[ai] = L->oldlike[ai] + finishSWupdateA(ci, li, ai, edge, freededge, oldsis, newsis,L->u[ai].mcinf.val, &Aterm[ai]);
				like +=  like_a[ai];
				oldlike += L->oldlike[ai];
				Atermsum += Aterm[ai];
				}

            //checklikelihoodSW(ci, li,Q[ci]->us[li]);  
            break; 
        }
	accp = 0;

/* final weight calculation */
/* tpw is the ratio of new and old prior probability of the genealogies.  It is actually the ratio of the total across all loci,  but
since only locus li is being changed at the present time,  the ratio works out to just be the ratio for locus li */ 
    if (rejectIS == 0) 
        {
		tpw = -C[ci]->jointtreeinfo[prob];
        tpw += integrate_tree_prob(ci, &C[ci]->jointtreeinfo[0]);
		weight = tpw + like - oldlike;
        U = uniform();
        weight = exp(beta[ci]*weight + migweight + slideweight + Atermsum);
/* accept the update */
        if (weight > 1.0 || weight > U)
			{
			//if (ci==0 && li==0)
				//printf("up00\n");
			for (ai = 0; ai < L->nlinked; ai++)
				L->oldlike[ai] = like_a[ai];
			C[ci]->jointtreeinfo[pdg] += like - oldlike;
            if (L->model==HKY) 
				{
                copyfraclike(ci, li);
				storescalefactors(ci, li);
				}
			accp = 1;
			}
        }
/* reject the update */
	if (accp == 0)
        {
        restoreedges(ci, li, edge, oldsis, freededge, newsis);
        storetree(ci,li,1);
		if (L->model==HKY) 
			restorescalefactors(ci, li);
       	for (i=cc1;i<=fm2;i++)
            L->treeinfo[i] = holdtreeinfo[i];
        for (i=0;i<=prob;i++)
            C[ci]->jointtreeinfo[i]= holdjointtreeinfo[i];
		if (multipleh)
			for (i=0;i<=2;i++)
				C[ci]->hterms[i] = holdhterms[i];
		*topolchange = 0;
		*tmrcachange = 0;
        }
/* do updates at nodes for stepwise loci, regardless of whether slide update was accepted */
	 if (!modeloptions[RETURNPRIOR]) 
		if (L->model == STEPWISE || L->model == JOINT_IS_SW)
			for (ui= (L->model == JOINT_IS_SW);ui<L->nlinked;ui++) // ui starts at 1 if JOINT_IS_SW otherwise 0
				{
				updateAcount = 0;
				L->oldlike[ui] = updateA(ci,li,ui,L->u[ui].mcinf.val,&updateAcount);
				L->u[ui].Aupinf->accp += updateAcount* updateAi; /* approx adjust because only updateAfrac of ancestral states are updated each round  */
				L->u[ui].Aupinf->tries++;
				}  
	return accp;
    } /* updategenealogy */
