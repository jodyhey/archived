/* IMa   for IM_analytic    2007-2009  Jody Hey and Rasmus Nielsen*/ 
/* December 17, 2009 */

#undef GLOBVARS
#include "ima.h"

/*********** LOCAL STUFF **********/


//extern FILE  *catchbug; 
//extern char bugfilename[FNSIZE];


double calcautoc(struct autoc a);
void fillvec(void);//fills up the marginal distribution estimates

double calcautoc(struct autoc a)
	{
	return  (a.cov.s2 - (a.cov.s * a.cov.ss)/a.cov.n)/sqrt(  (a.var[0].s2 - SQR(a.var[0].s)/a.cov.n ) * (a.var[1].s2 - SQR(a.var[1].s)/a.cov.n )   );
	}

void fillvec(void)
   {
   int i;
   for (i=0; i<gridsize; i++)
      {
      iq[q1i].xy[i].y = margincalc(iq[q1i].xy[i].x,0,0,0 /*1 use this if values get too large*/);
      if (!modeloptions[ONEPOP])
         iq[q2i].xy[i].y = margincalc(iq[q2i].xy[i].x,0,1,0 /*1 use this if values get too large*/);
      if (!modeloptions[EQUILIBRIUMMIGRATION] && !modeloptions[ONEPOP])
         iq[qai].xy[i].y = margincalc(iq[qai].xy[i].x,0,2,0 /*1 use this if values get too large*/);
      if (iq[m1i].pr.max > 0)
         {
         iq[m1i].xy[i].y = margincalc(iq[m1i].xy[i].x,0,3,0 /*1 use this if values get too large*/);
         iq[m2i].xy[i].y = margincalc(iq[m2i].xy[i].x,0,4,0 /*1 use this if values get too large*/);
         }
      }
    } /* fillvec */

/********** global functions ********/

void closeopenout(FILE *outfile, char outfilename[])
	{
	fclose(outfile);
	if ((outfile = fopen(outfilename,"a+")) == NULL)
		{
		printf("Error opening text file for writing\n"); 
		err(-1,-1,7);
		} 
	}

void printrunbasics(FILE *outfile, int loadrun, char *fpstr, int burnsteps, int recordint, int recordstep, int savetreeint,
					time_t endtime,time_t starttime, double hilike, double hiprob)
	{
	double seconds; 
	int li; 

    
	if (loadrun == 1)
		{
		FP"IMa LOAD TREES MODE \n");
		FP"%s",fpstr);
		FP"\n\nMCMC INFORMATION\n");
		FP"===========================\n\n");
		
		}
	else
		{
		FP"%s",fpstr);
		FP"\n\nMCMC INFORMATION\n");
		FP"===========================\n\n");
		FP"Number of steps in chain following burnin: %10ld \n",(step-burnsteps));
		FP"Number of steps between recording : %d  Number of record steps: %ld \n",recordint,recordstep);
		FP"Number of steps between saving tree information: %d  Number of trees saved per locus: %ld \n",savetreeint,treessaved);
		
		time(&endtime);
		seconds = difftime(endtime,starttime);
		FP"\nTime Elapsed : %d hours, %d minutes, %d seconds \n\n", 
			(int) seconds / (int) 3600,
		   ((int) seconds / (int) 60) - ((int) 60 * ((int) seconds / (int) 3600)),
		   (int) seconds  - (int) 60* ((int) seconds / (int) 60)
		   );
		FP"Highest Sampled Joint P(G) (log) : %10.3f \n",hiprob); 
		FP"Highest Joint P(D|G) (log) : %10.3f \n\n", hilike);
		FP"Highest P(D|G, Params) (log) for each Locus \n");
		FP"\tLocus\tP(D|G, Params)\n");
		for (li = 0;li < nloci; li++)
			{
			FP"\t%d\t%.3f\n",li, C[0]->L[li].hilike);
			}  
		FP"\n");
		}
	} /* printrunbasics */

void checkhighs(int ci, int printint, double *hilike, double *hiprob, double *like)
	{
	int  li, i;
	double temp;
	#ifdef _DEBUG
	int cmmmax, cmmli, cmmi;
	#endif

/* fill hilocuslike, hilike and hiprob  */ 
	for (*like=0, li=0;li<nloci;li++)
        {
		temp = C[ci]->L[li].oldlike[0];
		if (C[0]->L[li].nlinked > 1)
			for (i = 1; i<C[0]->L[li].nlinked;i++)
				temp += C[ci]->L[li].oldlike[i];
		*like += temp;
        if (C[ci]->L[li].hilike < temp)
			C[ci]->L[li].hilike  =  temp;
        }
//	myassert(*like == C[ci]->jointtreeinfo[pdg]); should be close

    if (*hilike < C[ci]->jointtreeinfo[pdg]);
        *hilike = C[ci]->jointtreeinfo[pdg];
    if (*hiprob < C[ci]->jointtreeinfo[prob])
        *hiprob = C[ci]->jointtreeinfo[prob];
#ifdef _DEBUG
    if (( step/(int) printint)* (int) printint == step && step > 0)
		{
		for (cmmmax = 0,li = 0;li < nloci;li++)
			{
			for (i = 0;i<C[0]->L[li].numlines;i++)
				{
				if (cmmmax < C[0]->L[li].tree[i].cmm)
					{
					cmmmax = C[0]->L[li].tree[i].cmm;
					cmmli = li;
					cmmi = i;
					}
				}
			}
		printf("\n max cmm %d  tree %d  edge %d \n",cmmmax, cmmli,cmmi);
		}
#endif
	} /* checkhighs */

#define MAXLENX  200
#define MAXLENY  104
void asciitrend(FILE *outfile, double *y,char *qlabel, int xlen, int ylen, int logscale)
/*for logscale,  any integer not 0  makes the plot use a log scale */
/* structure of graph 
0 name
1 ytop    |
40 ybot   |
41         -------
42        xbot        xtop
*/
	{
	char  graph[MAXLENY][MAXLENX];
	char  tc[13];
	double yt,ymax = -1e200,ymin = 1e200;
	int  i,xspot,yspot, notplot = 0;

	if (xlen > MAXLENX) xlen = MAXLENX;
	if (ylen > MAXLENY) ylen = MAXLENY;
	
	for (i=0;i<TRENDDIM;i++)
		{
		yt = y[i];
		if (ymax < yt) ymax = yt;
		if (ymin > yt) ymin = yt;
		}
	if (logscale)
		{
		if (ymax > (double) logscale)
			ymax  = (double) logscale;
		if (ymin < 1/ (double) logscale)
			ymin = 1/ (double) logscale;
		}
	strcpy(graph[0],qlabel);
	strcat(graph[0]," trend");
	if (logscale)
        strcat(graph[0]," - log scale");
	sprintf(tc,"%8.4g",ymax);
	strcpy(graph[1],tc);
	while ((int) strlen(graph[1]) < xlen-1) strcat(graph[1]," ");

	sprintf(tc,"%8.4f",ymin);
	strcpy(graph[ylen-2],tc);
    while ((int) strlen(graph[ylen-2]) < xlen-1) strcat(graph[ylen-2]," ");
	strcpy(graph[ylen-1],"          ");
	while ((int) strlen(graph[ylen-1]) < xlen-1) strcat(graph[ylen-1],"-");
	for (i=2;i<ylen-2;i++)
		{
		graph[i][0] = '\0';
		while ((int) strlen(graph[i]) < xlen-1) strcat(graph[i]," ");
		}
	for (i=1;i<ylen-1;i++)
		graph[i][10] = '|';

	for (i=0;i<TRENDDIM;i++)
		{
		if (y[i] >= ymin  && y[i] <= ymax)
			if (logscale)
				yspot = (int) 1 + (ylen-2) - (int) ((ylen-2) * (log(y[i]) - log(ymin))/(log(ymax)-log(ymin)));
			else
				yspot = (int) 1 + (ylen-2) - (int) ((ylen-2) * (y[i] - ymin)/(ymax-ymin));
		else
			{
			yspot = -1;
			notplot = 1;
			}
        xspot = (int) 11 + (int) ((xlen - 12) * i/TRENDDIM);
		if (xspot < xlen  && yspot >= 1) graph[yspot][xspot] = '*';
		}
	for (i=0;i<ylen;i++)
		FP"%s \n",graph[i]);
	if (notplot)
		FP"    - not all values plotted, some exceed bounds: %5.4f - %5.0f \n",ymin, ymax);
	FP"\n");
    } /* asciitrend */

void asciicurve(FILE *outfile,struct plotpoint *a, char *qlabel, int logscale,int recordstep)
/*for logscale,  any integer not 0  makes the plot use a log scale */
/* does not set the correct scale for t */
/* structure of graph 
0 name
1 ytop    |
40 ybot   |
41         -------
42        xbot        xtop
*/
	{
	char  graph[44][70];
	char  tc[12];
	double yt,ymax = -100000,ymin = 100000;
	int  i, xspot,yspot;
	
	for (i=0;i<gridsize;i++)
		{
		yt = a[i].y;
		if (ymax < yt) 
			ymax = yt;
		if (ymin > yt) 
			ymin = yt;
		}
	ymax /= recordstep;
	ymin /= recordstep;
	strcpy(graph[0],qlabel);
	strcat(graph[0]," curve");
	sprintf(tc,"%8.4g",ymax);
	strcpy(graph[1],tc);
	strcat(graph[1],"                                                            ");
	sprintf(tc,"%8.4f",ymin);
	strcpy(graph[40],tc);
    while (strlen(graph[40]) < 69) strcat(graph[40]," ");
	strcpy(graph[41],"          --------------------------------------------------------");
	strcpy(graph[42],"          ");
	sprintf(tc,"%8.4f",a[0].x);
	strcat(graph[42],tc);
	if (logscale)
		strcat(graph[42],"           Log Scale                       ");
	else
		strcat(graph[42],"                                           ");
	sprintf(tc,"%8.4f",a[gridsize-1].x);
	strcat(graph[42],tc);
	for (i=2;i<40;i++)
		strcpy(graph[i],"                                                                   ");
	for (i=1;i<41;i++)
		graph[i][10] = '|';
	for (i=0;i<gridsize;i++)
		{
		yspot = (int) 1 + 40  - (int) (40.0* (a[i].y/recordstep - ymin)/(ymax-ymin));
        if (logscale)
            xspot = (int) 11 + (int) (54.0 * (log(a[i].x) - log(a[0].x))/(2*log( a[gridsize-1].x)));
        else
            xspot = (int) 11 + (int) (54.0 * (a[i].x-a[0].x)/  (a[gridsize-1].x - a[0].x));
		if (xspot < 70) graph[yspot][xspot] = '*';
		}
	for (i=0;i<43;i++)
		FP"%s \n",graph[i]);
	fprintf(outfile,"\n");
    } /* asciicurve */

#undef MAXLENX
#undef MAXLENY

void printacceptancerates(FILE *outto)
	{
	int li, ai;
	char c;
	int somehky;

	fprintf(outto,"Cumulative Update Acceptance Rates \n");
	fprintf(outto,"----------------------------------\n");
	fprintf(outto,"Splitting Time Parameter (t):  # Attempts:  %.2e  # Updates:  %.2e   %%:  %.2f\n",C[0]->t.upinf->tries,C[0]->t.upinf->accp,100* C[0]->t.upinf->accp/C[0]->t.upinf->tries);
	fprintf(outto,"\nGenealogy (G), Branch Topology (B), and Common Ancestor Time (T) Update Rates \n");
  	fprintf(outto,"Loc#\tAttempts\tG Updates\tG%%\tB Updates\tB%%\tT Updates\tT%%\n");
	for (li = 0;li < nloci; li++)
		{
		fprintf(outto,"%2i\t%.2e\t%.2e\t%.2f\t%.2e\t%.2f\t%.2e\t%.2f\n",li,
			(float) C[0]->L[li].gupdate->tries,
			(float) C[0]->L[li].gupdate->accp,
			100.0*(double)C[0]->L[li].gupdate->accp/(double) C[0]->L[li].gupdate->tries,
			(float) C[0]->L[li].topolupdate->accp,
			100.0*(double)C[0]->L[li].topolupdate->accp/(double) C[0]->L[li].gupdate->tries,
			(float) C[0]->L[li].tmrcaupdate->accp,
			100.0*(double)C[0]->L[li].tmrcaupdate->accp/(double) C[0]->L[li].gupdate->tries);
		}
	for (li = 0, somehky =0;li < nloci; li++)
		somehky = (somehky || C[0]->L[li].model == HKY);

	if (nurates > 1)
		{
		fprintf(outto,"\nMutation Model (M) and Update Rates for Mutation Rate (u)");
		if (somehky)
			fprintf(outto,", Kappa (K)");
		if (somestepwise)
			fprintf(outto," and Stepwise Allele Sizes (A)");
		fprintf(outto,"\nLoc#  M\tu Attempts\tu Updates\tu%%");
		if (somehky)
			fprintf(outto,"\tK%%");
		if (somestepwise)
			fprintf(outto,"\tA%%");
		fprintf(outto,"\n");
		for (li = 0;li < nloci; li++)
			{
			for (ai = 0 ; ai < C[0]->L[li].nlinked; ai++) 
				{
				switch (C[0]->L[li].u[ai].umodel)
					{
					case INFINITESITES :  c = 'I'; break;
					case HKY :  c = 'H'; break;
					case STEPWISE :  c = 'S'; break;
					}
				fprintf(outto,"%2d",li);
				if (C[0]->L[li].nlinked > 1)
					fprintf(outto,"_%-2d",ai);
				else
					fprintf(outto,"   ");
				fprintf(outto," %c",c);
				fprintf(outto,"\t%.2e\t%.2e\t%.2f",C[0]->L[li].u[ai].mcinf.upinf->tries,C[0]->L[li].u[ai].mcinf.upinf->accp,100.0*C[0]->L[li].u[ai].mcinf.upinf->accp/C[0]->L[li].u[ai].mcinf.upinf->tries);
				if (somehky)
					{
					if (C[0]->L[li].u[ai].umodel == HKY)
						fprintf(outto,"\t%.2f",100*C[0]->L[li].kappa.upinf->accp/((float) C[0]->L[li].kappa.upinf->tries));
					else
						fprintf(outto,"\t");
					}
				if (C[0]->L[li].u[ai].umodel == STEPWISE)
					fprintf(outto,"\t%.2f",100*C[0]->L[li].u[ai].Aupinf->accp/((float) (C[0]->L[li].numgenes-1) * C[0]->L[li].u[ai].Aupinf->tries));
				fprintf(outto,"\n");
				}
			}
		}
		
	if (modeloptions[UPDATEH])
		{
		fprintf(outto,"\nInheritance Scalar (h) Update Rates\n");
		fprintf(outto,"Loc#\th Attempts\th Updates\th%%\n");
		for (li = 0;li < nloci; li++)
			fprintf(outto,"%2d\t%.2e\t%.2e\t%.2f\n",li,C[0]->L[li].h.upinf->tries,C[0]->L[li].h.upinf->accp,100.0* C[0]->L[li].h.upinf->accp/C[0]->L[li].h.upinf->tries);
		}
	} /* printacceptancerates() */

void printcurrentvals()
	{
	int li, i;
    printf("\nCurrent Values and Likelihoods\n");
	printf("------------------------------\n");
    printf("Split time  t: %.3f\n",C[0]->t);  
    printf("Locus#    p(D|G)     u  ");
    if (modeloptions[UPDATEH]) printf("       h\n");
    else printf("\n");
	for (li = 0;li < nloci; li++)
        {
		
		for (i = 0; i < C[0]->L[li].nlinked; i++)
			{
			printf("%2i",li);
			if (C[0]->L[li].nlinked > 1)
				printf("_%-2d",i);
			else
				printf("   ");
			printf(" %9.3lg %9.4lg",C[0]->L[li].oldlike[i],C[0]->L[li].u[i].mcinf.val);
			if (modeloptions[UPDATEH] && i == 0) 
				printf("  %9.4lg", C[0]->L[li].h.val);
			printf("\n");
			}
        }
	} /* printcurrentvals */


void printautoc(FILE *outto, int checkstep[], struct autoc autoc_t[],struct autoc autoc_lpg[], struct autoc autoc_tmrca[][AUTOCTERMS])
	{
	int li,i;
	double ac_t[AUTOCTERMS],ac_lpg[AUTOCTERMS],ac_tmrca[MAXLOCI][AUTOCTERMS], ess,temp1,temp2;
	int stopsum;
	struct autoc ta;
	int locishow;

	if (outto == stdout)
		locishow = IMIN(nloci, 7);
	else
		locishow = nloci;

    fprintf(outto,"\nAutocorrelations and Effective Sample Size Estimates\n");
	fprintf(outto,"---------------------------------------\n");
    fprintf(outto,"   # Steps Between Values  and Autocorrelation Estmates \n");
    fprintf(outto,"\tSteps\t L[P]");
    if (!(modeloptions[ONEPOP] || modeloptions[EQUILIBRIUMMIGRATION]))
        fprintf(outto,"\t t");
    for (li=0;li<locishow;li++)
        fprintf(outto,"\t tmrca%d",li);
	if (locishow < nloci) 
		fprintf(outto," not all loci shown\n");
    else
		fprintf(outto,"\n");
	
	for (i=0;i<AUTOCTERMS;i++)
		{
        if (autoc_t[i].cov.n > AUTOCCUTOFF)
			{
            fprintf(outto,"\t%d",checkstep[i]);
			ta = autoc_lpg[i];
			ac_lpg[i] = calcautoc(ta);
			if (ac_lpg[i] > 1)
				ac_lpg[i] = 1;
			fprintf(outto,"\t% .4f",ac_lpg[i]);
            if (!(modeloptions[ONEPOP] || modeloptions[EQUILIBRIUMMIGRATION]))
                {
				ta = autoc_t[i];
				ac_t[i] = calcautoc(ta);
				if (ac_t[i] > 1)
					ac_t[i] = 1;
				fprintf(outto,"\t% .4f",ac_t[i]);
                }
            for (li=0;li<locishow;li++)
                {
				ta = autoc_tmrca[li][i];
				ac_tmrca[li][i] = calcautoc(ta);
				if (ac_tmrca[li][i] > 1)
					ac_tmrca[li][i] = 1;
				fprintf(outto,"\t% .4f",ac_tmrca[li][i]);
                }
            fprintf(outto,"\n"); 
			}
		}
    fprintf(outto,"\tESS");
/* integrate over autocorrelations values for values > 0.03 */
	ess = 0;
	stopsum = 0;
	for (i=1;i<AUTOCTERMS;i++)
		{
		if (autoc_lpg[i].cov.n > AUTOCCUTOFF)
			{
			if (ac_lpg[i] <0.03)
				temp1 = 0;
			else 
				temp1 = ac_lpg[i];
			if (ac_lpg[i-1] <0.03)
				temp2 = 0;
			else 
				temp2 = ac_lpg[i-1];
			if (stopsum==0)
				ess += (checkstep[i]-checkstep[i-1])* (temp1+temp2)/2;
			stopsum=  (stopsum || temp1==0);
			}
		}
    if (stopsum)
        fprintf(outto,"\t%.0f",step/(1+2*ess));
    else
        fprintf(outto,"\t< %.0f",step/(1+2*ess));
    if (!(modeloptions[ONEPOP] || modeloptions[EQUILIBRIUMMIGRATION]))
        {
		ess = 0;
		stopsum = 0;
		for (i=1;i<AUTOCTERMS;i++)
			{
			if (autoc_t[i].cov.n > AUTOCCUTOFF)
				{
				if (ac_t[i] <0.03)
					temp1 = 0;
				else 
					temp1 = ac_t[i];
				if (ac_t[i-1] <0.03)
					temp2 = 0;
				else 
					temp2 = ac_t[i-1];
				if (stopsum==0)
					ess += (checkstep[i]-checkstep[i-1])* (temp1+temp2)/2;
				stopsum=  (stopsum || temp1==0);
				}
			}
        if (stopsum)
            fprintf(outto,"\t%.0f",step/(1+2*ess));
        else
            fprintf(outto,"\t< %.0f",step/(1+2*ess));
        }
    for (li=0;li<locishow;li++)
        {
        stopsum = 0;
        ess = 0;
        for (i=1;i<AUTOCTERMS;i++)
			{
			if (autoc_tmrca[li][i].cov.n > AUTOCCUTOFF)
				{
				if (ac_tmrca[li][i] <0.03)
					temp1 = 0;
				else 
					temp1 = ac_tmrca[li][i];
				if (ac_tmrca[li][i-1] <0.03)
					temp2 = 0;
				else 
					temp2 = ac_tmrca[li][i-1];
				if (stopsum==0)
					ess += (checkstep[i]-checkstep[i-1])* (temp1+temp2)/2;
				stopsum=  (stopsum || temp1==0);
				}
			}
        if (stopsum)
            fprintf(outto,"\t%.0f",step/(1+2*ess));
        else
            fprintf(outto,"\t< %.0f",step/(1+2*ess));

        }
    fprintf(outto,"\n");
	} /* printautoc() */


void savetreefile(char treeinfosavefilename[], FILE *treeinfosavefile, int multipleh)
	{
	int j,i;
	static int lasttreesaved = 0;
    if ((treeinfosavefile = fopen(treeinfosavefilename,"a")) == NULL)
		       {
			    printf("Error opening treeinfosave file for writing\n"); 
                err(-1,-1,3);
		       }
    for (j=lasttreesaved+1;j<treessaved;j++)
        {
        for (i=0;i<= prob;i++)
			{
            if (i==cc1 || i==cc2 || i==cca || i==cm1 || i==cm2)
                fprintf(treeinfosavefile,"%d\t",(int) gsampinf[j][i]);
            else
                fprintf(treeinfosavefile,"%.6lf\t",gsampinf[j][i]);

            }
        for (i=prob+1;i<= hak;i++)
            {
            if (multipleh)
				fprintf(treeinfosavefile,"%.6lf\t",gsampinf[j][i]);
            else
                fprintf(treeinfosavefile,"0\t");
            }
		fprintf(treeinfosavefile,"%.6lf\t",gsampinf[j][tval]);
        fprintf(treeinfosavefile,"\n");
        }
    lasttreesaved = treessaved -1;
    f_close(treeinfosavefile);
	} /* savetreefile */


void printhist(FILE *outfile, int mode, long int recordstep, double uscaleinput, double generationtime)
    {
  	int i, j,k, ci, li,ui,pi,cui, numparamsh, imax;
	double maxval;
    double sum,smoothsum, smoothdenom, smoothterm, tempsum;
    int cellnum, smoothcellnum = 10;
    struct hlists hlist[gridsize];
    double hpdmax, hpdmin;
    double scaleu, timeu;
	int agi;
	struct plotpoint **histpointers;
	double *plotscalers;
	int firstu;
	static double  *uscaleml;
	
	char  **pstr;
	double *xysum;
	double *ysum;
	double *xsum;
	double *hpdlo, *hpdhi;
	double *densescale; 
	double *before, *after;
	char *hpdchar;

	if (mode == 0)
		fillvec();
	ci = 0; // only work on chain 0

	// count up how many parameters to list 
	pi = 0;
	for (i=0;i<BASICPARAMS;i++)	
		pi += iq[i].integrate;
	if (!modeloptions[ONEPOP] && !modeloptions[EQUILIBRIUMMIGRATION]) pi++;  //t
	firstu = pi;
	if (mode==0 && calcoptions[LOADRUN] == 0 /* && nurates > 1*/)
		{
		if (nurates > 1)
			for (li = 0;li<nloci;li++)
				{
				for (ui = 0; ui < C[ci]->L[li].nlinked; ui++)
					pi++;
				}
		for (li = 0;li<nloci;li++) pi += (C[ci]->L[li].u[0].umodel == HKY); // plot kappa 
		if (modeloptions[UPDATEH])  for (li = 0;li<nloci;li++) pi++;
		}

	numparamsh = pi;
	// record locations and necessary info on each of them 
	if (mode==0 && calcoptions[LOADRUN] == 0)
		uscaleml = malloc(nurates*sizeof(double));

	histpointers = malloc(numparamsh*sizeof(struct plotpoint *));
	plotscalers = calloc(numparamsh, sizeof(double));
	pstr = malloc(numparamsh*sizeof(*pstr));
//	for (i=0;i<numparamsh;i++)   this malloc unnecessary as it is just a list of strings.   was causing a crash 
//		pstr[i] = malloc(6*sizeof(char));
	xysum = calloc(numparamsh, sizeof(double));
	xsum = calloc(numparamsh, sizeof(double));
	ysum = calloc(numparamsh, sizeof(double));
	hpdlo = calloc(numparamsh, sizeof(double));
	hpdhi = calloc(numparamsh, sizeof(double));
	hpdchar = calloc(numparamsh+1, sizeof(char));
	densescale = calloc(numparamsh, sizeof(double));
	before = calloc(numparamsh, sizeof(double));
	after = calloc(numparamsh, sizeof(double));
	pi = 0;
	for (i=0;i<BASICPARAMS;i++)	
		if (iq[i].integrate)
			{
			histpointers[pi] = iq[i].xy;
			pstr[pi] = iq[i].str;
			densescale[pi] = 1;
			before[pi] = 0;
			after[pi] = 0;
			pi++;
			}
	if (!modeloptions[ONEPOP] && !modeloptions[EQUILIBRIUMMIGRATION])  //include t
		{
		histpointers[pi] = C[ci]->t.xy;
		pstr[pi] =C[ci]->t.str;
		strcpy(pstr[pi],C[ci]->t.str);
		// use full range,  assumming minimum t is zero,  for this purpose
		//densescale[pi] = (gridsize/(C[ci]->t.pr.max - C[ci]->t.pr.min) )/recordstep;
		densescale[pi] = (gridsize/(C[ci]->t.pr.max) )/recordstep;
		before[pi] = *C[ci]->t.beforemin;
		after[pi] = *C[ci]->t.aftermax;
		pi++;
		}

	if (mode==0 && calcoptions[LOADRUN] == 0)
		{
		if (nurates > 1)
			{
			for (li = 0;li<nloci;li++) 	
				for (ui = 0; ui < C[ci]->L[li].nlinked; ui++) 
					{
	//				myassert(pi < numparamsh);
					myassert(ui < C[ci]->L[li].nlinked);
					histpointers[pi] = C[ci]->L[li].u[ui].mcinf.xy;
					pstr[pi] = C[ci]->L[li].u[ui].mcinf.str;
					densescale[pi] = (gridsize/(exp(C[ci]->L[li].u[ui].mcinf.pr.max) - exp(C[ci]->L[li].u[ui].mcinf.pr.min)))/recordstep;
					before[pi] = *C[ci]->L[li].u[ui].mcinf.beforemin;
					after[pi] = *C[ci]->L[li].u[ui].mcinf.aftermax;
					pi++;
					}
			}
		for (li = 0;li<nloci;li++) // plot kappa 
			if (C[ci]->L[li].u[0].umodel == HKY)
				{
//				myassert(pi < numparamsh);
				histpointers[pi] = C[ci]->L[li].kappa.xy;
				pstr[pi] =C[ci]->L[li].kappa.str;
				densescale[pi] = (gridsize/(C[ci]->L[li].kappa.pr.max - C[ci]->L[li].kappa.pr.min) )/recordstep;
				before[pi] = *C[ci]->L[li].kappa.beforemin;
				after[pi] = *C[ci]->L[li].kappa.aftermax;
				pi++;   
				}
		if (modeloptions[UPDATEH])  
			for (li = 0;li<nloci;li++)
				{
//				myassert(pi < numparamsh);
				histpointers[pi] = C[ci]->L[li].h.xy;
				pstr[pi] =C[ci]->L[li].h.str;
				densescale[pi] = (gridsize/(exp(C[ci]->L[li].h.pr.max) - exp(C[ci]->L[li].h.pr.min)))/recordstep;
				before[pi] = *C[ci]->L[li].h.beforemin;
				after[pi] = *C[ci]->L[li].h.aftermax;
				pi++;
				}
		}
	// set the plotscalar depending on mode  (0 means regular, 1 means rescaled on the basis of mutation rates and generation times )
	if (mode == 0)
		{
		for (pi = 0; pi < numparamsh; pi++)
			plotscalers[pi] = 1;
		}
	else
		{
		scaleu = 0;
		if (calcoptions[LOADRUN])
			{
			if (uscaleinput <= 0)
				{
				FP"MUTATION RATE SCALAR NOT GIVEN AT RUNTIME - DEMOGRAPHIC SCALES CANNOT BE CALCULATED \n");
				return;
				}
			else
				{
				timeu=0;
				for (li=0,ui = 0, cui=0;li<nloci;li++)
					for (i = 0; i < C[ci]->L[li].nlinked; i++) 
					{
					if (C[ci]->L[li].u[i].uperyear.val > 0)
						{
						timeu += log(C[ci]->L[li].u[i].uperyear.val);
						cui++;
						}
					ui++;
					}
				}
			}
		else
			{
			timeu=0;
			for (li=0,ui = 0, cui=0;li<nloci;li++)
				for (i = 0; i < C[ci]->L[li].nlinked; i++) 
				{
				if (C[ci]->L[li].u[i].uperyear.val > 0)
					{
					timeu += log(C[ci]->L[li].u[i].uperyear.val);
					scaleu += log(uscaleml[ui]);
					cui++;
					}
				ui++;
				}
			}
        myassert(timeu != 0);
        timeu = exp(timeu/cui);
        FP"\tGeneration time in years specified at runtime: %lf \n",generationtime);
        FP"\tGeometric mean of mutation rates per year (based on rates specified in input file): %le\n",timeu);
        if (uscaleinput > 0)
            {
            scaleu = uscaleinput;
            FP"\tGeometric mean of ML estimates provided at runtime: %le\n",scaleu);
            }
        else
            {
            if (cui == nurates)
                {
                FP"\tMutation rates provided for all loci.\n");  
                FP"\tGeometric mean of ML estimates of mutation rate scalars: %le\n",exp(scaleu/cui));
                FP"\tBecause scalars for all loci are include, geometric mean of ML estimates set to 1.0 \n");
                scaleu = 1;
                }
            else
                {
				if (calcoptions[LOADRUN])
					{
					FP"\tGeometric mean of ML estimates of relevant mutation rate scalars not available  - set to 1.0 \n");
					scaleu = exp(scaleu/cui);
					}
				else
					{
					myassert(scaleu != 0);
					scaleu = exp(scaleu/cui);
					FP"\tGeometric mean of ML estimates of relevant mutation rate scalars: %le\n",scaleu);
					}
                }
            }
		for (i = 0,pi=0;i<BASICPARAMS;i++)
			if (iq[i].integrate)
				{
				if (i < 3)
					{
					plotscalers[pi]=  scaleu /(4 * timeu * generationtime);
					for (j=0;j<gridsize;j++)
						histpointers[pi][j].x *= plotscalers[pi];
					pi++;
					}
				else
					{
					plotscalers[pi]=  1000 * timeu * generationtime/scaleu;
					for (j=0;j<gridsize;j++)
						histpointers[pi][j].x *= plotscalers[pi];
					pi++;
					}
					
				}
		if (!modeloptions[EQUILIBRIUMMIGRATION])
			{
			plotscalers[pi] = scaleu/timeu;
			for (j=0;j<gridsize;j++)
				histpointers[pi][j].x *= plotscalers[pi];
			pi++;
			}
		}
	// print summary information 

    if (mode== 0)
        {
        FP"\n\nMARGINAL DISTRIBUTION VALUES AND HISTOGRAMS - curve height is an estimate of marginal posterior probability\n"); 
        }
    else  //mode == 1
    /* print out on demographic scales using mutation and generation time adjustments  do q1, q2, qa, m1, m2, t */
        {
        FP"\n\nMARGINAL DISTRIBUTION VALUES IN DEMOGRAPHIC UNITS\n"); 
        FP"\tCalculations use mutation rates (in years) and generation time (in years) input at runtime\n");
        FP"\t  - note, curve height has not been adjusted with the scale change. Integration does not equal 1 \n");
        FP"\tParameter\tMeaning\tUnits \n");
        FP"\tq1\tPop1 Ne\tIndividuals \n");
        FP"\tq2\tPop2 Ne\tIndividuals \n");
        FP"\tqa\tAncest.Pop Ne\tIndividuals \n");
        FP"\tt\tYears Div.\tYears\n");
        FP"\tm1\tPop1 Migr.\tAverage # of migrations per 1000 generations per gene copy\n");
        FP"\tm2\tPop1 Migr.\tAverage # of migrations per 1000 generations per gene copy\n");
        }
    FP"========================================\n");
    FP" Summaries\n\tValue  ");
    for (j=0;j<numparamsh;j++)
		{
        FP"\t %s",pstr[j]);
		}
    FP"\n\tMinbin ");
    for (j=0;j< numparamsh;j++)
		{
        i = 0;
        while (i< gridsize -1 && histpointers[j][i].y <= 0)
			{
			i++;
			}
        FP"\t%9.4f",histpointers[j][i].x);
        }
    FP"\n\tMaxbin");
	
    for (j=0;j< numparamsh;j++)
		{
        i = gridsize-1;
        while (i>0 && histpointers[j][i].y <= 0) 
			{
			i--;
			}
		FP"\t%9.4f",histpointers[j][i].x);
        }
    FP"\n\tHiPt  ");
	for (j=0;j< numparamsh;j++)
		{
		xysum[j] = 0;
		xsum[j] = 0;
		maxval = -1;
		for (i=0;i<gridsize;i++)
			{
			xysum[j] += histpointers[j][i].x * histpointers[j][i].y;
			xsum[j] += histpointers[j][i].x;
			ysum[j] += histpointers[j][i].y;
			if (maxval < histpointers[j][i].y)
				{
				maxval = histpointers[j][i].y;
				imax = i;
				}
			}
        FP"\t%9.4f",histpointers[j][imax].x);
        }
	FP"\n\tHiSmth");
	for (j=0;j< numparamsh;j++)
		{
		maxval = -1;
		if (j >= firstu && j <= firstu + nurates - 1) // awkward work arround for some unidentified bug  - for some reason mutation rate distributions that cross the boundary often get a spurious peak right at the boundary 
			{
			agi = gridsize -2;  /* don't include positions 0 and gridsize - 1 */
			i = 1;
			}
		else
			{
			agi = gridsize;
			i = 0;
			}
		for (;i<agi;i++)
			{
            cellnum = IMIN(smoothcellnum, 2*i);
            cellnum = IMIN(cellnum, 2*(agi-1 - i));
            k=IMAX(0,i-(cellnum/2));
			smoothdenom  = 0;
			smoothsum = 0;
            for (;k<=IMIN(agi-1,i+(cellnum/2));k++)
                {
				smoothterm = 1.0/(0.5 + abs(k-i));
				smoothsum += histpointers[j][k].y * smoothterm;
				smoothdenom  += smoothterm; 
                }
			smoothsum /= smoothdenom;
            if (maxval < smoothsum)
                {
                maxval = smoothsum;
                imax = i;
                }
			}
		if (j >= firstu && j <= firstu + nurates - 1)
			{
			imax++; // because we skipped position 0 when finding the smoothed peak for mutation rate scalars
			if (mode==0 && ci==0)
				{ /* save the mutation rate estimates */
				uscaleml[j - firstu] = histpointers[j][imax].x;
				}
			}
        FP"\t%9.4lf",histpointers[j][imax].x);
        }
    FP"\n\tMean  ");
	for (j=0;j< numparamsh;j++)
		{
        FP"\t%9.4f",xysum[j]/ysum[j]);  //xsum[j]
		}
/* print out 95% confidence points */	
	FP"\n\t95Lo  ");
	for (j=0;j< numparamsh;j++)
		{
        i=0;
        sum=0;
        while((sum + histpointers[j][i].y)/ ysum[j] <= 0.025 && i < gridsize)
            {
            sum += histpointers[j][i].y;
            i++;
            }
        FP"\t%9.4f",histpointers[j][i].x);
		}
    FP"\n\t95Hi  "); 
	for (j=0;j< numparamsh;j++)
		{
        i=gridsize-1;
        sum=0;
		while((sum + histpointers[j][i].y)/ ysum[j] <= 0.025 && i > 0)
            {
            sum += histpointers[j][i].y;
            i--;
            }
		FP"\t%9.4f",histpointers[j][i].x);
		}
/* print out 90% Highest Posterior Density intervals  - first, smooth the curve*/	
	smoothcellnum = 30;
	for (j=0;j< numparamsh;j++)
		{
		maxval = -1;
		if (j >= firstu && j <= firstu + nurates - 1) // awkward work arround for some unidentified bug  - for some reason mutation rate distributions that cross the boundary often get a spurious peak right at the boundary 
			{
			agi = gridsize -2;  /* don't include positions 0 and gridsize - 1 */
			i = 1;
			}
		else
			{
			agi = gridsize;
			i = 0;
			}
		tempsum = 0;
		for (;i<agi;i++)
			{
            cellnum = IMIN(smoothcellnum, 2*i);
            cellnum = IMIN(cellnum, 2*(agi-1 - i));
            k=IMAX(0,i-(cellnum/2));
			smoothdenom  = 0;
			smoothsum = 0;
            for (;k<=IMIN(agi-1,i+(cellnum/2));k++)
                {
				smoothterm = 1.0/(0.5 + abs(k-i));
				smoothsum += histpointers[j][k].y * smoothterm;
				smoothdenom  += smoothterm; 
                }
			hlist[i].v =  histpointers[j][i].x;
			smoothsum /= smoothdenom;
			tempsum += smoothsum;
			hlist[i].p = smoothsum;
			}
        shellhist(&(hlist[0]),gridsize); 
        sum = 0;
        hpdmax = -1;
        hpdmin = 1e10;
        i = gridsize-1;
        sum = hlist[i].p;
        while (i >= 0 && sum <= (0.90 * tempsum))
            {
            if (i>0 &&hlist[i].p < hlist[i-1].p)
                err(-1,0,999);
            if (hlist[i].v > hpdmax) 
                hpdmax = hlist[i].v;
            if (hlist[i].v < hpdmin) 
                hpdmin = hlist[i].v;
            i--;
            sum += hlist[i].p;
            }
        hpdlo[j] = hpdmin;
        hpdhi[j] = hpdmax;
        while (i > 0 && (hlist[i].v < hpdmin || hlist[i].v > hpdmax)) 
            i--;
        if (i> 0)
            hpdchar[j] = '?';
        else
            hpdchar[j] = ' ';
		}
    FP"\n\tHPD90Lo");
    for (j=0;j< numparamsh;j++)
		{
        FP"\t%8.4f%c",hpdlo[j],hpdchar[j]);
        }
    FP"\n\tHPD90Hi");
    for (j=0;j< numparamsh;j++)
		{
        FP"\t%8.4f%c",hpdhi[j],hpdchar[j]);
        }
	FP"\n\n");
    FP"\tParameter");
    for (j=0;j<numparamsh;j++)
        FP"\t%s\tL",pstr[j]);
	FP"\n\tHiPt");
	for (j=0;j< numparamsh;j++)
		{
		maxval = -1;
		for (i=0;i<gridsize;i++)
			{
			if (maxval < histpointers[j][i].y)
				{
				maxval = histpointers[j][i].y;
				imax = i;
				}
			}
		FP"\t%9.4f\t%8.5f ",histpointers[j][imax].x,densescale[j]*histpointers[j][imax].y);
        }
    FP"\n\n");
	for (i=0;i<gridsize;i++)
		{
        FP"\t%4d",i);
        for (j=0;j<numparamsh;j++)
			{
			if (histpointers[j][i].x < 0.005)
				{
				if (histpointers[j][i].x < 0.00005)
					FP"\t%9.8f\t%8.5f ",histpointers[j][i].x,densescale[j]*histpointers[j][i].y);
				else
					FP"\t%9.6f\t%8.5f ",histpointers[j][i].x,densescale[j]*histpointers[j][i].y);
				}
			else
				FP"\t%9.4f\t%8.5f ",histpointers[j][i].x,densescale[j]*histpointers[j][i].y);

			}
		FP"\n");
		}
	if (mode == 1)
		for (pi=0;pi<numparamsh;pi++)
			{
			for (j=0;j<gridsize;j++)
				histpointers[pi][j].x /= plotscalers[pi];
			}
    FP" Before\t");
    for (j=0;j<numparamsh;j++)
    	FP"\t\t%8.5f",before[j]*densescale[j]);
	FP"\n");
	FP" After\t");
    for (j=0;j<numparamsh;j++)
    	FP"\t\t%8.5f",after[j]*densescale[j]);
	FP"\n");
	free(histpointers);
	free(plotscalers); 
//	for (i=0;i<numparamsh;i++)   unncessary  was causing a crash 
//		free(pstr[i]);
	free(pstr); 
	free(xysum); 
	free(xsum); 
	free(ysum); 
	free(hpdlo); 
	free(hpdhi); 
	free(hpdchar); 
	free(densescale); 
	free(before); 
	free(after); 
    } /* printhist */

void printmigratehist(FILE *outfile, int recordstep)
	{
	int li, i;
	double summcount[MAXLOCI][2], summtime[MAXLOCI][2];
    FP"Migration Distributions \n");
    for (li=0;li<nloci;li++)
		{
        FP"\t-\tLocus_%-2d\t-\t-\t-\t-\t-\t-",li);
        }
    FP"\n");
    FP"\tpt");
    for (li=0;li<nloci;li++)
		{
		FP"\tm1#\tp\tm1time\tp\tm2#\tp\tm2time\tp");
		}
    FP"\n");
    if (printoptions[MIGRATEDIST])
		{
		for (li=0;li<nloci;li++)
			{
			summcount[li][0]=summcount[li][1]=0;
			summtime[li][0]=summtime[li][1]=0;
			}

		for (i=0;i<gridsize;i++)
			{
			FP"\t%4d",i);
			for (li=0;li<nloci;li++)
				{
				FP"\t%4d\t%8.5f\t%9.4f\t%8.5f\t%4d\t%8.5f\t%9.4f\t%8.5f",
					i,C[0]->L[li].migcountxy[0][i].y/recordstep,
    				C[0]->t.xy[i].x,C[0]->L[li].migtimexy[0][i].y/(recordstep - C[0]->L[li].migcountxy[0][0].y),
					i,C[0]->L[li].migcountxy[1][i].y/recordstep,
					C[0]->t.xy[i].x,C[0]->L[li].migtimexy[1][i].y/(recordstep - C[0]->L[li].migcountxy[1][0].y));
				summcount[li][0] += i* C[0]->L[li].migcountxy[0][i].y/recordstep;
				summcount[li][1] += i* C[0]->L[li].migcountxy[1][i].y/recordstep;
				summtime[li][0] += C[0]->t.xy[i].x * C[0]->L[li].migtimexy[0][i].y/(recordstep - C[0]->L[li].migcountxy[0][0].y);
				summtime[li][1] += C[0]->t.xy[i].x * C[0]->L[li].migtimexy[1][i].y/(recordstep - C[0]->L[li].migcountxy[1][0].y);
				}
			FP"\n");
			}
		for (li=0;li<nloci;li++)
			{
			FP"locus %d\tmean\t%8.5f\tmean\t%8.5f\tmean\t%8.5f\tmean\t%8.5f",li,summcount[li][0],summtime[li][0],summcount[li][1],summtime[li][1]);
			}
		FP"\n");
		}
    }

void printtmrcahist(FILE *outfile,int recordstep)
	{
	int i,k, li;
	int    maxi = -1;
	double maxval;
	double sum, smoothsum, smoothdenom,smoothterm;
	int cellnum, smoothcellnum = 8;

    FP"TMRCA distributions \n\n\t");
    FP"\t\t");
    for (li=0;li<nloci;li++)
		{
		FP"\tLocus%-2d",li);
		}
    FP"\n\tHiPt\t");
    for (li=0;li<nloci;li++)
		{
		maxval = -1;
		for (i=0;i<gridsize;i++)
            {
			if (maxval < C[0]->L[li].tmrcaxy[i].y)
				{
				maxval = C[0]->L[li].tmrcaxy[i].y;
				maxi = i;
				}
            }
        FP"\t%8.4f",C[0]->L[li].tmrcaxy[maxi].y);
        }
    FP"\n\tHiSmth\t");
    for (li=0;li<nloci;li++)
		{
	    maxval = -1;
		for (i=0;i<gridsize;i++)
			{
            cellnum = IMIN(smoothcellnum, 2*i);
            cellnum = IMIN(cellnum, 2*(gridsize-1 - i));
            k=IMAX(0,i-(cellnum/2));
			smoothdenom  = 0;
            smoothsum=0.0;
            for (;k<IMIN(gridsize,i+(cellnum/2));k++)
                {
				smoothterm = 1.0/(0.5 + abs(k-i));
                smoothsum += C[0]->L[li].tmrcaxy[k].y * smoothterm;
				smoothdenom += smoothterm;
                }
            smoothsum /= smoothdenom;
            if (maxval < smoothsum)
                {
                maxval = smoothsum;
                maxi = i;
                }
			}
        FP"\t%8.4f",C[0]->L[li].tmrcaxy[maxi].x);
        }
    FP"\n\tMean\t");
    for (li=0;li<nloci;li++)
		{
        sum=0;
        for (i=0;i<gridsize;i++)
            sum += C[0]->L[li].tmrcaxy[i].y * C[0]->L[li].tmrcaxy[i].x;
        sum /= recordstep ;
        FP"\t%8.4f",sum);
		}
    FP"\n\n");
    FP"\t\tTMRCA");
    for (li=0;li<nloci;li++)
		{
		FP"\tLike_%-2d",li);
		}
    FP"\n");
    for (i=0;i<gridsize;i++)
		{
        FP"\t\t%8.4f",C[0]->L[0].tmrcaxy[i].x);
        for (li=0;li<nloci;li++)
		    {
		    FP"\t%8.5f",C[0]->L[li].tmrcaxy[i].y/recordstep );
		    }
        FP"\n");
        }
    }

void printprofile1Dcurve(FILE *outfile,char  ***h)
    {
    int i,j,k;
    int maxi;
    double maxval;
    int cellnum, countsmooth,smoothcellnum = 1; /* dont use smoothing */
    double peakval[BASICPARAMS];
    int peakloc[BASICPARAMS];
    double interp, interpx, slope;
    double smoothsum, lastsmoothsum;

    FP"\nProfile Probability Curve Estimates (HiPt and 95%% confidence intervals estimated from curve estimate)\n\tValue");
    for (j=0;j<BASICPARAMS;j++) 
		if (iq[j].integrate)
			FP"\t%s",iq[j].str);    

    FP"\n\tHiPt");
	for (j=0;j<BASICPARAMS;j++)
		if (iq[j].integrate)
		{
		maxval = -1e200;
		for (i=0;i<profilegridsize+1;i++)
			{
			if (!isalpha(h[i][1+j*2][0]) && maxval < atof(h[i][1+j*2]))
				{
				maxval = atof(h[i][1+j*2]);
				maxi = i;
				}
			}
		if (maxi >= 0 && maxi < profilegridsize+1)
			{
			FP"\t%s",h[maxi][j*2]);
			peakval[j] = atof(h[maxi][j*2]);
			peakloc[j] = maxi;
			}
		else
			{
			FP"\t%s","na");
			peakval[j] = -1;
			peakloc[j] = 0;
			}
        }
	/* treat smoothed peak location as the peak, and then find points that are 2 logs on either side  - use linear interpretation between points */
	FP"\n\t95Lo");
	for (j=0;j<BASICPARAMS;j++)
		if (iq[j].integrate)
		{
        interp = atof(h[peakloc[j]][j*2+1])- 1.92;
        i=0;
        lastsmoothsum = 0;
        interpx = 0;
        do
            {
            cellnum = IMIN(smoothcellnum, 2*i);
            cellnum = IMIN(cellnum, 2*(profilegridsize - i));
            k=IMAX(0,i-(cellnum/2));
            countsmooth=0;
            smoothsum=0;
            for (;k<=IMIN(profilegridsize,i+(cellnum/2));k++)
                {
                if (!isalpha(h[k][1+j*2][0]))
                    {
                    smoothsum += atof(h[k][1+j*2]);
                    countsmooth++;
                    }
                }
            if (countsmooth)
                {
                smoothsum /= (double) countsmooth;
                if (smoothsum > interp && i>0)
                    {
                    slope = (smoothsum - lastsmoothsum)/(atof(h[i][j*2])-atof(h[i-1][j*2]));
                    interpx = (interp-lastsmoothsum)/slope + atof(h[i-1][j*2]);
                    }
                lastsmoothsum = smoothsum;
                }
            i++;
            }
        while (i <= peakloc[j] && interpx <= 0);
        if (interpx > 0 && interpx < peakval[j])
            FP"\t%9.4lf",interpx);
        else
            FP"\t na ");
        }
    FP"\n\t95Hi"); 
    for (j=0;j<BASICPARAMS;j++)
		if (iq[j].integrate)
		{
        interp = atof(h[peakloc[j]][j*2+1])- 1.92;
        i=peakloc[j];
        lastsmoothsum = 0;
        interpx = 0;
        do
            {
            cellnum = IMIN(smoothcellnum, 2*i);
            cellnum = IMIN(cellnum, 2*(profilegridsize - i));
            k=IMAX(0,i-(cellnum/2));
            countsmooth=0;
            smoothsum=0;
            for (;k<=IMIN(profilegridsize,i+(cellnum/2));k++)
                {
                 if (!isalpha(h[k][1+j*2][0]))
                    {
                    smoothsum += atof(h[k][1+j*2]);
                    countsmooth++;
                    }
                }
            if (countsmooth)
                {
                smoothsum /= (double) countsmooth;
                if (smoothsum < interp)
                    {
                    slope = (smoothsum - lastsmoothsum)/(atof(h[i][j*2])-atof(h[i-1][j*2]));
                    interpx = (interp-lastsmoothsum)/slope + atof(h[i-1][j*2]);
                    }
                lastsmoothsum = smoothsum;
                }
            i++;
            }
        while (i < profilegridsize+1 && interpx <= 0);
        if (interpx > 0 && interpx > peakval[j])
            FP"\t%9.4lf",interpx);
        else
            FP"\t na ");
        }
	
    FP"\nProfile Likelihood Surfaces \n");
    for (j=0;j<BASICPARAMS;j++) 
		if (iq[j].integrate)
			FP"\t%s\tL",iq[j].str);    
    FP"\n");
    
    for(i=0;i<profilegridsize+1;i++)
        {
        for (j=0;j<BASICPARAMS;j++)
			if (iq[j].integrate)
            {
            FP"\t%s\t%s",h[i][2*j],h[i][2*j+1]);
            }
        FP"\n");
        }
	
    } /* printprofile1Dcurve */


void profilelike1Dcurve(FILE *outfile, int ndim,double holdpeakloc[],double holdmlval, int imodel)
    {
    double fret;
	double p[BASICPARAMS+1];
	double mlval;
    char ***h;
    int i,j,k,ii,ix;
    float ftol, kinc, temp;
	int ndim1, kmax;
	double  dummy;
	
	ndim1 = ndim-1;
	optinf[0] = ndim1;
	optinf[1] = 1;
	if (ndim <= 1)
		return;
    h = calloc(sizeof(char*),profilegridsize+1);
    for (i=0;i< profilegridsize + 1;i++)
        {
        h[i] = calloc(sizeof(char*),2*BASICPARAMS);
        for (j=0;j<2*BASICPARAMS;j++)
            h[i][j] = calloc(sizeof(char),NUMSTRL);
        }
    ftol = (float) 1e-7;
	nestedmodel = imodel;
	for (i=0;i<BASICPARAMS;i++)
		optconst[i] = -1;
	printf("write profile likelihood curves, parameter: ");
	for (ii=0;ii< BASICPARAMS;ii++)
		if (iq[ii].integrate)
			{
			printf("\n%d",ii);
			kinc = (float) (maxvals_for_surface_calls[ii]-MINPARAMVAL)/(profilegridsize - 1);
			temp = (float)  MINPARAMVAL;
			kmax = 0;
			while (temp + kinc < holdpeakloc[ii])
				{
				temp += kinc;
				kmax++;
				}

			for (j=0,k=0;k<profilegridsize;k++,j++)
				{
				optconst[ii] = (float) (MINPARAMVAL + k*(maxvals_for_surface_calls[ii]-MINPARAMVAL)/(profilegridsize - 1));
				//optconst[ii] = (float) ((( ((double) k) + 0.5) * maxvals_for_surface_calls[ii]) / (double) profilegridsize);
				myassert(optconst[ii] > 0);
				if (k==0)
					{
					for (i=0,ix=1;i<BASICPARAMS;i++)
						{
						if (iq[i].integrate )
							{
							p[ix] = holdpeakloc[i];//MINPARAMVAL;
							ix++;
							}
						}
					}
				annealjointopt(outfile,&fret, &p[1],ndim1,30, ii, &dummy);
				if (optconst[ii] < 0.001)
					sprintf(h[j][ii*2],"%9.6f",optconst[ii]);
				else
					sprintf(h[j][ii*2],"%9.4f",optconst[ii]);
				if (fret < 0)
					sprintf(h[j][ii*2+1],"na");
				else
					{
					mlval = log(fret);
					sprintf(h[j][ii*2+1],"%9.4lf",mlval);
					}
				printf("%d   %9.4lf    %9.4lf \n",j, optconst[ii], mlval);
				if (k==kmax) /* include the peak as a point in the list */
					{
					j++;
					if (holdpeakloc[ii] < 0.001)
						sprintf(h[j][ii*2],"%9.6f",holdpeakloc[ii]);
					else
						sprintf(h[j][ii*2],"%9.4f",holdpeakloc[ii]);
					sprintf(h[j][ii*2+1],"%9.4lf",log(holdmlval));
					printf("%d   %9.4lf    %9.4lf \n",j, holdpeakloc[ii], log(holdmlval));
					}
				optconst[ii] = -1;
				}
		}
    printprofile1Dcurve(outfile,h);
    for (j=0;j<profilegridsize;j++)
        for (i=0;i< 2*BASICPARAMS;i++)
            free(h[j][i]);
    for (j=0;j<profilegridsize;j++)
        free(h[j]);
    } /* profilelike1Dcurve */

void twodmarginallistplot(char margin2dfilename[],char outfilename[])
	{
	int i, j,k,  ki, kj, plotk; 
	char p1[5],p2[5],plottab[margin2dgridsize*margin2dgridsize*20];
	double lval,xi,xj;
	char temps[FNSIZE];
	FILE *margin2dfile;
	
	if ((margin2dfile = fopen(margin2dfilename,"w")) == NULL)
	   {
		printf("Error opening profile2d file for writing\n"); 
        err(-1,-1,3);
	   }  
	printf("writing 2D marginal likelihood contours: \n");
	for (i=0;i<BASICPARAMS-1;i++)
		for (j=i+1;j<BASICPARAMS;j++)
			if (iq[i].integrate && iq[j].integrate)
				{
				printf("   parameter pair#: %s  %s \n",iq[i].str,iq[j].str);
				plottab[0]='\0';
				plotk = 0;
				k = 0;
				p1[0] = '\0';
				do
					{
					if (iq[i].str[k] != ' ')
						{
						strncat(p1,&iq[i].str[k],1);
						p1[strlen(p1)] = '\0';
						}
					k++;
					}
				while (iq[i].str[k] != '\0');
				p2[0] = '\0';
				k=0;
				do
					{
					if (iq[j].str[k] != ' ')
						{
						strncat(p2,&iq[j].str[k],1);
						p2[strlen(p2)] = '\0';
						}
					k++;
					}
				while (iq[j].str[k] != '\0');
				strcpy(temps,outfilename);
				strtrunc(temps,'.');
				strtrunc(temps,'-');
				strtrunc(temps,'_');
				plotk += sprintf(&plottab[plotk],"%s$%s%s={",temps,p1,p2);
				for (ki=0;ki<margin2dgridsize;ki++)
					{
					xi =  (float) ((( ((double) ki) + 0.5) * maxvals_for_surface_calls[i]) / (double) margin2dgridsize);
					myassert(xi > 0);
					plotk += sprintf(&plottab[plotk],"{");
					for (kj=0;kj<margin2dgridsize;kj++)
						{
						xj = (float) ((( ((double) kj) +0.5) * maxvals_for_surface_calls[j]) / (double) margin2dgridsize);
						lval = twodmargincalc(xi,xj,i,j, 1 , 0);

						if (lval <=  -10000)
							{
							plotk += sprintf(&plottab[plotk],"-10000.0");
							if (kj<margin2dgridsize-1) 
								plotk += sprintf(&plottab[plotk],",");
							}
						else
							{
							plotk += sprintf(&plottab[plotk],"%8.3lf",lval);
							if (kj<margin2dgridsize-1) 
								plotk += sprintf(&plottab[plotk],",");
							}
						}
					plotk += sprintf(&plottab[plotk],"}");
					if (ki<margin2dgridsize-1) 
						plotk += sprintf(&plottab[plotk],",");
					}
				plotk += sprintf(&plottab[plotk],"};");
				fprintf(margin2dfile,"%s\n",plottab);
				k = 2*margin2dgridsize;
				fprintf(margin2dfile,"ListContourPlot[%s$%s%s,MeshRange->{{0.0,%8.3lf},{0.0,%8.3lf}},Contours->%d, FrameLabel->{\"%s\",\"%s\"},Axes->True , ImageSize -> {600, 600}]\n",
					temps,p1,p2,maxvals_for_surface_calls[j],maxvals_for_surface_calls[i],k,p2,p1);
				}
	f_close(margin2dfile);
	} /*twodmarginallistplot */


void printprofile95(FILE *outfile,double holdpeakloc[], double hold95lo[],double hold95hi[])
    {
    int j;

    FP"\nProfile Likelihood Confidence Intervals (non-focal parameters optimized) \n\tFocal");
    for (j=0;j<BASICPARAMS;j++) 
		if (iq[j].integrate)
			FP"\t%s",iq[j].str);    

    FP"\n\tHiPt");
	for (j=0;j<BASICPARAMS;j++)
		if (iq[j].integrate)
			{
			if (holdpeakloc[j] < 0.001)
				FP"\t%9.6lf",holdpeakloc[j]);
			else
				FP"\t%9.4lf",holdpeakloc[j]);
			}
	FP"\n\t95%%Lo");
	for (j=0;j<BASICPARAMS;j++)
		if (iq[j].integrate)
			{
			if (hold95lo[j] <= MINPARAMVAL)
				FP"\t<min");
			else
				{
				if (hold95lo[j] >= DBL_MAX)
					FP"\na");
				else
					{
					if (hold95lo[j] < 0.001)
						FP"\t%9.6lf",hold95lo[j]);
					else
						FP"\t%9.4lf",hold95lo[j]);
					}
				}
			}
	FP"\n\t95%%Hi");
	for (j=0;j<BASICPARAMS;j++)
		if (iq[j].integrate)
			{
			if (hold95hi[j] >= maxvals_for_surface_calls[j])
				FP"\t>max");
			else
				{
				if (hold95hi[j] >= DBL_MAX)
					FP"\tna");
				else
					FP"\t%9.4lf",hold95hi[j]);
				}
			}
	FP"\n");
    } /* printprofile95 */


