/* IMa   for IM_analytic    2007-2009  Jody Hey and Rasmus Nielsen*/ 
/* December 17, 2009 */

/* April, 2008 fix some bugs that caused crashes upon output and when fitting nested models */ 
 
/* summary of files by types of functions
//i standtest1.u -o ima_standtest1_a_reload_debug.out  -r ima_standtest1_a.out   -l10 -c012  -q11 -m11 -m21 -t1 -s123 -p 45

ima_main.c
main run/update loop  
autocorrelations
recording values
call data entry and initialization functions
call printing functions

get_data_initialize.c
read in data
call genealogy building
initialize parameter structures
setup chains

build_genealogy.c
build the starting genealogies

update_genealogy.c
updating genealogies
do analytic integration over parameter priors

update_mc_params.c
update other parameters 

calc_prob_data.c
calculate p(Data|G) under various mutation models

surface_call_functions.c
calculation of joint and marginal function values
functions that set up for and call optimization functions

surface_search_functions.c
optimization routins - mostly from numerical recipes

output.c
printing functions

utilities.c
utilities of diverse sorts

swapchains.c
chain swapping 

msdirent.c
maps dirent calls onto microsoft findfirst and findnext - use only w/ microsoft compilers

treeprint.c
prints out genealogy information - use only for debugging

*/

/* things that still need to be specified when using the loadrun options 
 -i  the data needs to be same as in the original run for the locus specific mutation rates, and for calculation of theta priors. 
 -o  if the -r option is not used to specify load filenames, then the output file is used and so this nees the same basename as the .ti file to be loaded
 all -j options
 -q1 -q2 - qa -m1 -m2 -t -w -u : all same as in the original run

  will also need a random number seed  -s
 */

#define GLOBVARS
#include "ima.h"
//#include <mcheck.h>

FILE  *outfile;
char outfilename[FNSIZE];
char loadfilebase[FNSIZE] = "\0";
time_t   starttime, endtime, totaltime, burntime, chainstarttime,  timer, lasttime;
long  burnduration, chainduration;  
int burndone;
long int  burnsteps;
int bdurationmode,cdurationmode, runmode, updatemode;
int treestosave;
int savetreeint;
int recordint;
int printint;
double generationtime;
double uscaleinput;
int swaptries;
int heatmode;
char fpstr[50000];
int fpstri;
int imodel; 
int basics;
struct autoc autoc_t[AUTOCTERMS];
struct autoc autoc_lpg[AUTOCTERMS];
struct autoc autoc_tmrca[MAXLOCI][AUTOCTERMS];
char oldoutfilename[FNSIZE];
double hilocuslike[MAXLOCI];
char margin2dfilename[FNSIZE];
int autoc_checkstep[AUTOCTERMS] = {1,10,50,100,500,1000,5000,10000,50000,100000,500000,1000000};
int numtreefiles;
FILE *treeinfosavefile;
char treeinfosavefilename[FNSIZE];
long int recordstep;
double  hilike = -1e20, hiprob = -1e20;
int adaptcheck = 1000;
double lpgtrend[TRENDDIM];
FILE *checkdonefile;
double hval1, hval2;
time_t checktimer, checklasttime;
char dckfilename[FNSIZE];
long checkduration; 
int initialize_autocorrelations = 0;
FILE *loadparamfile;
char paramfilename[FNSIZE] = "paramfile";


#define CHECKINTERVALSTEPS 1000

/*Local function prototypes  */
void start(int argc, char *argv[]);
void fillautoc(struct autoc *a, int n, double v);
//updated checkautoc on 4/21/08
//void checkautoc(void);
void checkautoc(int initialize_autocorrelations);
void Qupdate(void);
int run(void);
void savetreeinfo(void);
void inctrend(int m, int t, double trendarray[], double v);
void record(void);
void loadtreevalues(void);
void intervaloutput(int burnsteps);
void printoutput(void);

void start(int argc, char *argv[])
	{
	static int i,j,k, li,ci;
	static char  ch,ch1, *chpt;
	static char  pstr[256],templine[50];
    int Ap,Bp,Cp,Dp, Ep,Fp,G1p,G2p,Hp,Ip,Jp,Lp,Kp,m1p,m2p,Np,Op,Pp,Q1p,Q2p,QAp,Rp,Sp,Tp,Up,Vp,Wp,Yp,Zp;
    double tempf;
	char textline[301];
	char  command_line[201];
	char infilename[FNSIZE];
	//FILE *infile;
	long seed_for_ran1;
	struct mc_param ttemp;

	q1i = 0; q2i = 1; qai = 2; m1i = 3; m2i = 4;
    time(&starttime);
	Ap = 0; /* # of steps between recording */ 
    Bp = 0; /* duration of burnin */
    Cp = 0; /* calculation options*/
	Dp = 0; /* number of steps in between tree saves */
	Ep = 0;  /* filename to start from checkpoint */
    Fp = 0; /* heat mode term */
    G1p = 0; /* heat term */
    G2p = 0; /* heat term */
    Hp = 0; /* set inheritance scalar as parameter option */
    Ip = 0; /*input file */
    Jp = 0; /* used for programmer options */
    Kp = 0; /* number of swap attempts per step */
    Lp = 0; /* duration of chain */
	m1p = 0; /* migration rate 1 max */
	m2p = 0; /* migration rate 2 max */
    Np = 0; /* # of chains */
	Op = 0; /* output file */
	Pp = 0; /* output options */
    Q1p = 0; /* Theta1 max scalar*/
    Q2p = 0; /* Theta1 max scalar*/
    QAp = 0; /* Theta1 max scalar*/
	Rp = 0; /* tree load file name base */
	Sp = 0; /* random number seed */
	Tp = 0; /* Time maximum */
    Up = 0;  /* generation time in years */
    Wp = 0; /* Time minimum */
    Vp = 0;  /* time window scalar  - set window (Tmax-Tmin)/(10 + nloci * scalar) */
    Yp = 0; /* mutation rate scalar for loci with mutation rates given in input file - for use with LOADRUN mode  */
    Zp = 0; /* screen printout frequency */

/*
-e  and -d   using checkpoint files 
to save a complete dump of all values and data structures  use the '-e' flag
the 'e' must be followed by a number that represents the number of hours in between  saving the checkpoint file.
The file is also saved immediately after the burnin,  and at the end of the run
e.g. -e1  will save files after the burn,  and then every hour until the run is done, and then at the end of the run
-e0 saves after the burn and at the end of the run (assuming it finishes normally), and not inbetween.
each successive checkpoint file save overwrites the previous file  
the name of the checkpoint file is the fullname of the regular output file,  with '.dck' added to the end of it 

to restart from a saved checkpoint file, start a run with only the -d flag
the 'd' is followed by the full name of the checkpoint file. 
This will start up a new run, where the previous one stopped, and will use all the same parameters as the old run.
Immediately after starting, an output file is produced that shows where everthing was at when that file was saved. 
that output file will have the same name as (and will over write) the file that was used in the run that generated the checkpoint file,

To restart a run, and treat it as if the burn had just been completed, add -e0 to the command line along with the -d flag. This 
should reset everything to the point of not having any record of the previous run,  however the state of the chain will be where it was at the 
end of the previous run.  This option could be used as a way to burn along to the point where you know it is mixing well. 
*/
    printf("executing program ...\n");
	strcpy(command_line,"");
    if ((argc == 2 && (char) toupper(argv[1][1]) ==  'H') || argc == 1)
        {
		printf("IMa Program - copyright 2009 by Jody Hey and Rasmus Nielsen\n");
		printf("This program is run through a command line interface\n");  
		printf("The program file and the data file should be in the same directory \n");
		printf("To execute the program, type the program name followed by the necessary command line flags and instructions \n");
		printf(" -- this program cannot be sensibly used without an understanding of the method and the options (see documentation)\n");
		printf("Command line usage: - upper or lower case letters can be used\n");
		printf("-a  steps between recording parameter values from MCMC (default: 10)\n");
        printf("-b  duration of burn  (MCMC mode only)\n");
        printf("    - if integer, the number of burnin steps \n");
        printf("    - if floating point, the time in hours of burnin period\n");
		printf("-c  calculation options: \n");
		printf("    0 LOAD-TREE Mode - load trees from previous run(s); also requires -r \n");
		printf("    1 find the joint surface peak (default is not to find it)\n");
		printf("    2 examine nested models  - also turns on 'find the joint surface peak'\n");
		printf("    3 show details of joint optimization results \n");
		/* don't show these options 
		printf("    4 calc profile likelihood curves for single parameters\n");  
		printf("    5 calc profile likelihood 95%% confidence intervals for single parameters\n");   */
		printf("-d  number of steps between tree saving -MCMC mode only (default 100)\n");
		
		//printf("-e  time (hours) between save of checkpoint file. -e0 for saving only after burn, or from retarting after burn\n");
        printf("-f  heat mode: l linear (default); t twostep; a adaptive twostep; g geometric\n");
		//printf("-jh  jh personal options \n");
		//printf("      0  alt data format for SW data -  one data line for each allele in each pop,  1st # is allele length, 2nd is # copies \n");
        printf("-g1 first heating parameter, effect depends on heating mode (default 0.05) \n");
        printf("-g2 second heating parameter, effect depends on heating mode  \n");
        printf("-h  comment for output file (no spaces) \n");
        printf("-i  input file name (no spaces) \n");
        printf("-j  run options: \n");
		printf("    0  likelihood() functions return 1 - posterior should equal prior \n");
		printf("    1  for 4Nu priors (q1,q2,qa) use command-line values as priors\n");
		printf("         default: priors = product of command-line values and data estimates\n");
		printf("    2  treat inheritance scalars as parameters.(default= input file value or 1)\n");
		printf("    3  include ranges on mutation rates as priors on mutation rate scalars\n");
        printf("    4  set t to a very large value, mimics two population island model\n"); 
        printf("    5  set t = 0 to mimic one large panmictic population of size 4NAu\n");
		printf("-k  with multiple chains (-n) the number of chain swap attempts per step \n");
        printf("-l  duration of run / number of trees \n");
        printf("  - if in MCMC mode (not loading trees from a previous run) \n");
		printf("     - if integer, the number of trees to save. Use with -d. \n");
        printf("	 - if floating point, the time in hours between outputs. Use with -d \n");
		printf("         run continues until file ""IMrun"" is no longer present\n");
        printf("         in the directory, or if present, does not begin with 'y'\n");
		printf("  - if in load-tree mode (using -c0 to load trees from previous run)\n");
		printf("     - integer indicates number of trees to load \n");
        printf("-m1 maximum migration rate from population 1 to population 2 \n");
        printf("-m2 maximum migration rate from population 2 to population 1 \n");
        printf("-n  number of chains (MCMC mode only) \n");
        printf("-o  output file name (no spaces) default is 'outfile.txt' \n");
        printf("-p  output options: \n");
        printf("    0 do not save genealogies to a file (default saves sampled genealogies) \n");
        printf("    1 print TMRCA histogram for each locus (MCMC mode only)\n");
        printf("    2 print histogram of parameters on demographic scales \n");
        printf("    3 print histograms of # migration events and times (MCMC mode only)\n"); 
		printf("    4 print ASCII-based plots of parameter trends in outfile (MCMC mode only)\n");
		printf("    5 print ASCII-based marginal curves in outfile \n");
		printf("    6 print file with listplots of 2D marginal distributions\n");
        printf("-q1 scalar for 4N1u maximum \n");
		printf("-q2 scalar for 4N2u maximum (default =  scalar for 4N1u maximum)\n");
		printf("-qA scalar for 4NAu maximum (default =  scalar for 4N1u maximum)\n");
		printf("-r  base name (no extension) of files with tree data, requires use of -c0 \n");
        printf("-s  random number seed (default is taken from current time)\n");
        printf("-t  maximum time of population splitting \n");
        printf("-w  minimum time of population splitting \n"); 
        printf("-u  generation time in years  (default is 1) \n");
        printf("-v  window width adjust for t updating (MCMC mode only)\n");
        printf("-y  mutation rate scalar for relevant loci - for use with -p2 \n");
		//printf("-x '*.dck' file name for starting from a previous run \n");
        printf("-z  number of steps between screen output (default 10000) (MCMC mode only)\n");
        exit(0);
        }
    else
        {
		for (i = 1; i < argc; i++) 
		    {
            strcpy(pstr, argv[i]);
		    if ((strlen(pstr)==2) || ( (strlen(pstr)==3) && (
                (toupper(pstr[1])=='G') ||
                (toupper(pstr[1])=='M') ||
                (toupper(pstr[1])=='Q') 
                ) ) )
                {
                strcat(command_line," ");
                strcat(command_line,pstr);
                ch = toupper(pstr[1]);
				if (strlen(pstr) > 2)
					ch1 = toupper(pstr[2]);
				else
					ch1 = ' ';
				i++;
				strcat(command_line," ");
				strcpy(pstr, argv[i]);
				strcat(command_line,pstr);
                }
            else
                {
                strcat(command_line," ");
                strcat(command_line,pstr);
                ch = toupper(pstr[1]);
                ch1 = toupper(pstr[2]);
                if ((ch=='G') || (ch=='M') || (ch=='Q'))
                    strdelete(pstr,1,3);
                else
                    strdelete(pstr,1,2);
                }
		    switch ((char) toupper(ch)) 
			    {
				case 'A' : 
					recordint = atoi(&pstr[0]); 
					Ap = 1;
					break;
				case 'B' :
					tempf =  atof(&pstr[0]);
					/* check to see if the value is floating point, in which case treat it as being in fractions of an hour  and convert to seconds*/
					if (strchr(pstr,'.'))
						{
						burnduration = (int) (3600 * tempf);
						bdurationmode = TIMEINF;
						time(&lasttime);
						}
					else
						{
						burnduration = (int) tempf;
						bdurationmode = TIMESTEPS;
						}
				    Bp = 1;
				    break;
				case 'C' :
                    j= (int) strlen(pstr)-1;
                    while (j>=0)
                        {
                        calcoptions[atoi(&pstr[j])] = 1;
                        pstr[j] = '\0';
                        j--;
                        }
                    break;
				/*case 'X' :
					printoptions[CHECKPOINTFILEREAD] = 1;
					printoptions[CHECKPOINTFILEWRITE] = 1;
  				    strcpy(dckfilename,pstr);
					if (strstr(dckfilename,".dck") == NULL)
						strcat(dckfilename,".dck");
					strcpy(olddckfilename,dckfilename);
					strcat(olddckfilename,".old");
					Xp = 1;
					break;
				case 'E' :
					printoptions[CHECKPOINTFILEWRITE] = 1;
                    tempf =  atof(&pstr[0]);
					if (tempf <= 0)
						{
						checkduration = LONG_MAX;
						printoptions[RESTARTBURN] = 1;
						}
					else
						checkduration = (int) (3600 * tempf);
				    Ep = 1;
				    break;*/
				case 'F' :
                    Fp = 1;
                    switch ((char) toupper(pstr[0]))
                        {
                        case 'T'    : heatmode = HTWOSTEP;break;
                        case 'A'    : heatmode = HADAPT; break;
                        case 'G'	: heatmode = HGEOMETRIC; break;
                        default : heatmode  = HLINEAR;
                        }
                    break; 
                case 'G' :
                    if (ch1=='1')
					    j=1;
				    else 
					    j=0;
				    //strdelete(pstr,1,1);
				    if (j==1)
					    {
					    hval1 = atof(&pstr[0]);
					    G1p = 1;
					    }
				    else 
					    {
					    hval2 = atof(&pstr[0]);
					    G2p = 1;
					    }	
				    break;
				case 'H':
			      sprintf(textline, "%s", pstr);
                  if (strlen(textline) > 0)
                      {
                      Hp = 1;
                      }
                  else Hp = 0;
			      break;
			    case 'I':
			      strcpy(infilename,pstr);
			      /*if ((infile = fopen(infilename,"r")) == NULL)
				      {
					    printf("Error opening text file for reading\n"); 
                        err(-1,-1,1);
				      } */
			      Ip = 1;
			      break;
				case 'J' :
                    if (!(toupper(ch1)=='H'))
                        {
						j= (int) strlen(pstr)-1;
						while (j>=0)
							{
							modeloptions[atoi(&pstr[j])] = 1;
							pstr[j] = '\0';
							j--;
							}
                        }
                    else
                        {
						j= (int) strlen(pstr);
						for (k=0;k < j; k++)
							pstr[k] = pstr[k+1];
						j=  (int) strlen(pstr)-1;
						while (j>=0)
							{
							jheyoptions[atoi(&pstr[j])] = 1;
							pstr[j] = '\0';
							j--;
							}
                        };
				    break;
				case 'K' : swaptries = atoi(&pstr[0]); Kp = 1; break;
			    case 'L' :
                    tempf =  atof(&pstr[0]);
                    /* check to see if the value is floating point, in which case treat it as being in fractions of an hour  and convert to seconds*/
                    if ( strchr(pstr,'.'))
                        {
                        chainduration = (int) (3600 * tempf);
                        cdurationmode = TIMEINF;
                        treestosave = -1;
                        }
                    else
                        {
                        treestosave = (int) tempf;
                        cdurationmode = TIMESTEPS;
                        }
				    Lp = 1;
				    break;
				case 'M' :
				    if (ch1=='1')
					    j=1;
				    else 
					    j=0;
				    if (j==1)
					    {
						iq[m1i].pr.max = (double) atof(&pstr[0]);
					    m1p = 1;
					    }
				    else 
					    {
						iq[m2i].pr.max = (double) atof(&pstr[0]);
					    m2p = 1;
					    }	
				    break;
                case 'N' : numchains = atoi(&pstr[0]); Np = 1; break;
			    case 'O': strcpy(outfilename,pstr); Op = 1; break;
#define  maxdashpval 7
				case 'P' :
                    j= (int) strlen(pstr)-1;
                    while (j>=0 && j <= maxdashpval)
                        {
						k = atoi(&pstr[j]);
                        printoptions[k] = 1;
                        pstr[j] = '\0';
                        j--;
                        }
                    break;
#undef maxdaskpval 
                case 'Q' :
                    switch (ch1)
                        {
                        case '1'   : iq[q1i].pr.max = (double) atof(&pstr[0]); 
									 if (iq[q1i].pr.max)  Q1p = 1;
									 break;
                        case '2'   : iq[q2i].pr.max = (double) atof(&pstr[0]); 
							         if (iq[q2i].pr.max) Q2p = 1;
									 break;
                        case 'A'   : iq[qai].pr.max = (double) atof(&pstr[0]); 
							         if(iq[qai].pr.max) QAp = 1;
									 break;
                        }
                    break; 
				case 'R': strcpy(loadfilebase,pstr); Rp = 1;break;
                case 'S' :
			        seed_for_ran1 = atoi(&pstr[0]);
			        if (!seed_for_ran1) seed_for_ran1 = 1;
			        Sp = 1;
				    break;
			    case 'T' : ttemp.pr.max =  atof(&pstr[0]);  Tp = 1;  break;
                case 'U' : generationtime =  atof(&pstr[0]); Up = 1; break;
                case 'Y' : 
						uscaleinput =  atof(&pstr[0]); 
						Yp = 1;
						break;
                case 'V' : ttemp.win = atof(&pstr[0]);Vp = 1; break;
				case 'W' : ttemp.pr.min =  atof(&pstr[0]); Wp = 1; break;
                case 'D' : savetreeint = atoi(&pstr[0]); Dp = 1; break;
                case 'Z' : printint = atoi(&pstr[0]); Zp = 1; break;
				}
		    }
        }
	
	if (!Ip) 
		{
		printf("No data file given\n"); 
        err(-1,-1,1);
		}
	if (Ep)
		{
		strcpy(dckfilename,outfilename);
		strcat(dckfilename,".dck");
		if (checkduration > chainduration)
			checkduration = LONG_MAX;
		}
	if (!Op)  strcpy(outfilename,"outfile.txt");
    if (!Np || calcoptions[LOADRUN])
        {
        numchains = DEFCHAINS; /* default value */
        }
    else
        {
        if ((heatmode==HGEOMETRIC  && numchains < 4) || (heatmode==HTWOSTEP  && numchains < 3) || (heatmode==HADAPT  && numchains < 3))
            {
            err(-1,-1,12);
            }
        if (!Fp)
            {
            heatmode = HLINEAR;
            if (!G1p)
                hval1 = 0.05; /* default value */
            }
        else 
            {
            if (heatmode > HLINEAR)
                {
                if (heatmode == HTWOSTEP )
                    {
                    if (!G1p) hval1 = 0.05;
                    if (!G2p) hval2 = 2;
                    }
                if (heatmode == HADAPT)
                    {
                    if (!G1p) hval1 = 0.05;
                    if (!G2p) hval2 = 1;
                    }
                if (heatmode == HGEOMETRIC)
                    {
                    if (!G1p) hval1 = 0.9;
                    if (!G2p) hval2 = 0.8;
                    }
                }
            else
                if (!G1p)
                    hval1 = 0.05; /* default value */
            }
        }
	if (modeloptions[ONEPOP])
		imodel = QONEPOP;
	if (modeloptions[EQUILIBRIUMMIGRATION])
		imodel = EFULL;
	else
		{
		if (iq[m1i].pr.max <= 0)
			imodel = ABC00;
		else
			imodel = FULL;
		}

	if (!Ap) recordint = RECORDINTDEFAULT;
    if (!Up) generationtime = 1;
    if (!Dp) savetreeint = SAVETREEINTDEFAULT;
    if (!Zp) printint = PRINTINTDEFAULT;
	if (calcoptions[NESTEDMODELS])
		calcoptions[FINDJOINTPEAK] = 1;
	if (!Bp && !calcoptions[LOADRUN])
		{
        printf(" No information provided for burn-in duration '-B'\n"); 
        err(-1,-1,9);
		}
	if (!m1p && !modeloptions[ONEPOP])
		{
        printf(" No information provided for maximum value for m1 '-m1'\n"); 
        err(-1,-1,9);
		}
	if (!m2p && !modeloptions[ONEPOP])
		{
		printf(" No information provided for maximum value for m2 '-m2'\n"); 
		err(-1,-1,9);
		}
	if (!Tp && !modeloptions[EQUILIBRIUMMIGRATION] && !modeloptions[ONEPOP])
		{
        printf(" No information provided for maximum separation time '-t'\n"); 
        err(-1,-1,9);
		}
    if (!Wp) 
		ttemp.pr.min = 0.0; 
    if (!Kp)  swaptries = 1;
    else
        {
        if (numchains > 1 && swaptries > numchains*(numchains-1)/2)
            swaptries = numchains*(numchains-1)/2;
        } 
    
	if (!Q1p)
		{
		printf(" No information provided for maximum value of theta1, use -q1 or -c5\n"); 
		err(-1,-1,9);
		}
    
    if (!Q2p) iq[q2i].pr.max = iq[q1i].pr.max;
    if (!QAp) iq[qai].pr.max = iq[q1i].pr.max;
	if (modeloptions[ONEPOP])
        {
		iq[m2i].pr.max = iq[m1i].pr.max= 0;
        if (QAp)
            {
            Q1p=Q2p=QAp;
			iq[q1i].pr.max = iq[q2i].pr.max =  iq[qai].pr.max;
            }
        if (Q1p && !QAp)
            {
            QAp=Q2p=Q1p;
			iq[q2i].pr.max = iq[qai].pr.max =  iq[q1i].pr.max;
            }
        if (Q2p && !QAp)
            {
            QAp=Q1p=Q2p;
			iq[qai].pr.max = iq[q1i].pr.max =  iq[q2i].pr.max;
            }
        if (!QAp)
            {
			printf(" No information provided for maximum value of thetaA '-q1'\n"); 
			err(-1,-1,9);
            }
        }
    if (!Sp) seed_for_ran1 = (long) time(NULL);
    if (!Vp)  ttemp.win = 0;
	if (strcmp(infilename,outfilename)==0)
        {
        printf("input and output file names are identical\n");
        err(-1,-1,8);
        }
    if (cdurationmode == TIMESTEPS)
        {
        chainduration = treestosave * savetreeint;
        }
	
    SP"IMa - Isolation with Migration [analytic] Output  -  IMa source code copyright Jody Hey, Rasmus Nielsen  2007-2008");
    SP"  -  code date: December 17, 2009 \n\n");
    SP"\nINPUT AND STARTING INFORMATION \n");
    SP"================================\n");
    SP"\nCommand line string : %s \n",command_line);
	if (Cp)
        SP"Comment at runtime : %s\n",textline);
	SP"Input filename : %s \n",infilename);
	SP"Output filename: %s \n",outfilename);
	SP"Random number seed : %li \n",seed_for_ran1);
    if (modeloptions[RETURNPRIOR])
        SP"**DEBUGGING MODE - no data ** \n");
    SP"IM Model:\n");
    basics = 2 + BASICPARAMS-1;
    if (modeloptions[ONEPOP])
        SP"     - Single population model, divergence time fixed at 0 \n");
    if (modeloptions[EQUILIBRIUMMIGRATION])
        SP"\nEquilibrium Migration Model, divergence time fixed at %.0f \n\n",TIMEMAX);
	if (modeloptions[UPDATEH])
        SP"     - Inheritance Scalars are treated as parameters to be estimated \n");
    else
        SP"     - Inheritance Scalars are treated as constants, as given in input file\n");
    SP"- Run Duration - \n");
    if (!calcoptions[LOADRUN])
        {
        switch (bdurationmode)
            {
	        case TIMESTEPS:SP"     Burn period, # steps: %li \n",burnduration); break;
            case TIMEINF:SP"     Burn period, # seconds: %li \n",burnduration);break;
               };
        switch (cdurationmode)
            {
             case TIMESTEPS: SP"     Record period, #saves: %d  #steps each: %d   total #steps: %li \n",treestosave, chainduration/treestosave, chainduration); break;
             case TIMEINF: SP"      Record period, # seconds per interval: %ld \n",chainduration);break;
            };
        }
    SP"- Metropolis Coupling -\n");
    if (numchains > 1) 
        {
        SP"     Metropolis Coupling implemented using %d chains \n",numchains);
        switch (heatmode)
            {
            case HLINEAR:  SP"     Linear Increment Model   term: %.3f\n", hval1);break;
            case HTWOSTEP: SP"     Twostep Increment Model   term1: %.3f  term2: %.3f\n", hval1, hval2);break;
            case HADAPT:   SP"     Twostep Adaptive Model  starting term1: %.3f  starting term2: %.3f\n", hval1, hval2);break;
            case HGEOMETRIC: SP"     Geometric Increment Model   term1: %.3f  term2: %.3f\n", hval1, hval2);break;
            }
        }
    else
        SP"     None \n");

	setseeds(seed_for_ran1);
    setlogfact();
	setupchains(infilename,fpstri, fpstr,ttemp);
	setheat(hval1,hval2, heatmode);
    // updated checkautoc on 4/21/08
    checkautoc(1);
    SP"\n");
	SP"- Maximum Values for Integrated Parameters -\n");
	if (modeloptions[ONEPOP])
		SP"     Max for q1 : %.2f \n",iq[q1i].pr.max);
	else
		{
		SP"     Max for q1 : %.2f \n",iq[q1i].pr.max);
		SP"     Max for q2 : %.2f \n",iq[q2i].pr.max);
		if (!modeloptions[EQUILIBRIUMMIGRATION])
			SP"     Max for qa : %.2f \n",iq[qai].pr.max);
		SP"     Max for m1 : %.2f \n",iq[m1i].pr.max);
		SP"     Max for m2 : %.2f \n",iq[m2i].pr.max);
		if (!modeloptions[EQUILIBRIUMMIGRATION])
			{
			SP"     Max for t  : %.2f \n",ttemp.pr.max);
			if (Wp)
				SP"     Min for t  : %.2f \n",ttemp.pr.min); 
			}
		}
	if (modeloptions[POPSIZEPRIORSETMODE])
        SP"   - upper bounds on q terms set directly from command line \n");    
    SP"\n");
	//if (infile) f_close(infile);  should already be closed
    /*
	for (i=0;i< AUTOCTERMS;i++)
		{
		iautoc(&autoc_t[i]);
		iautoc(&autoc_lpg[i]);
		for (li=0;li<nloci;li++)
			autoc_tmrca[li][i];
		} */
	if (!printoptions[DONTSAVETREES]) SP"All tree information used for surface estimation printed to file");
    if (printoptions[PRINTTMRCA]) SP"TMRCA  histograms printed at end of this file\n");
    if (cdurationmode == TIMEINF) 
        {
        strcpy(oldoutfilename,outfilename);
        strcat(oldoutfilename,".old");
        }
    for (i=0;i<MAXLOCI;i++) 
        hilocuslike[i] = -1e20;
    if (Up)
        SP"Generation time specified (in years): %.2lf\n",generationtime);
	if (printoptions[PRINT2DMARGINALS])
		{
		strcpy(margin2dfilename,outfilename);
		strcat(margin2dfilename,".m2d");
	   }
    } /* start*/  

void fillautoc(struct autoc *a, int n, double v)
	{
	a->cov.n++;
	a->cov.s += a->vals[n];
    a->cov.ss += v;
	a->cov.s2 += (a->vals[n] * v);
    a->var[0].s += a->vals[n];
    a->var[1].s += v;
    a->var[0].s2 += SQR(a->vals[n]);
    a->var[1].s2 += SQR(v);
	}

/* in ima.h
#define AUTOCTERMS 12  // the number of lag values for which autocorrelations are recorded
#define CHECKAUTOCWAIT 10000  // number of steps before recording autocorrelation values
#define AUTOCINT 1000         // interval between measurements for autocorrelations when there is 1 chain - can't change w/out changing values in AUTOCNEXTARRAYLENGTH
#define AUTOCNEXTARRAYLENGTH 1000  // largest value in autoc_checkstep[] divided by AUTOCINT 
#define AUTOCCUTOFF 100  // minimum number of measurements to have for autocorrelation before printing results 
int autoc_checkstep[AUTOCTERMS] = {1,10,50,100,500,1000,5000,10000,50000,100000,500000,1000000};
*/


/*updated the way checkautoc() initializes on 4/21/08 */
//called with initialize_autocorrelations == 1 at beginning and after burn 

//void checkautoc(void)
void checkautoc(int initialize_autocorrelations)
    {
    int i,li;
    //static int initialize_autocorrelations = 0;
    static int  nextstepsave[AUTOCTERMS], nextstepcalc[AUTOCTERMS],nextpossave[AUTOCTERMS],nextposcalc[AUTOCTERMS], maxpos[AUTOCTERMS];
	static int autocintuse;

	if (initialize_autocorrelations==1)
		{
		for (i=0;i< AUTOCTERMS;i++)
			{
			iautoc(&autoc_t[i]);
			iautoc(&autoc_lpg[i]);
			for (li=0;li<nloci;li++)
				autoc_tmrca[li][i];
			} 
		/* tries adjusting the rate at which measurements are made by the number of chains  - forgot, stuck by AUTOCINT*/
		autocintuse = AUTOCINT;
		for (i=0;i<AUTOCTERMS;i++)
			{
			nextstepsave[i] = CHECKAUTOCWAIT+AUTOCINT;
			nextstepcalc[i] = CHECKAUTOCWAIT+AUTOCINT + autoc_checkstep[i] + (burndone * burnsteps);
			nextpossave[i]= 0;
			nextposcalc[i] = 0;
			if (autoc_checkstep[i] <= AUTOCINT)
				maxpos[i] = 0;
			else
				maxpos[i] = (autoc_checkstep[i]/ AUTOCINT)-1;
			}
		// updated on 4/21/08
        //initialize_autocorrelations = 1;
		}
	else
		{
		for (i=0;i<AUTOCTERMS;i++)
			{
			if (step== nextstepcalc[i])
				{
				fillautoc(&(autoc_t[i]),nextposcalc[i],C[0]->t.val);
				//fillautoc(&(autoc_lpg[i]),nextposcalc[i],C[0]->jointtreeinfo[prob]);  was not using the pdg part ? ?
				fillautoc(&(autoc_lpg[i]),nextposcalc[i],C[0]->jointtreeinfo[prob] + C[0]->jointtreeinfo[pdg]);
                for (li = 0; li < nloci; li++)
                    {
					fillautoc(&(autoc_tmrca[li][i]),nextposcalc[i],C[0]->L[li].roottime);
                    }
				nextposcalc[i]++;
				if (nextposcalc[i] > maxpos[i])
					nextposcalc[i] = 0;
				nextstepcalc[i] += AUTOCINT;
				}
			}
		if ((long) AUTOCINT * (long)(step/AUTOCINT) == step)
			{
			for (i=0;i<AUTOCTERMS;i++)
				{
                if (!(modeloptions[ONEPOP] || modeloptions[EQUILIBRIUMMIGRATION]))
                    {
				    autoc_t[i].vals[nextpossave[i]] = C[0]->t.val;
                    }
				//autoc_lpg[i].vals[nextpossave[i]] = C[0]->jointtreeinfo[prob]; was not using the pdg part ?? 
				autoc_lpg[i].vals[nextpossave[i]] = C[0]->jointtreeinfo[prob] + C[0]->jointtreeinfo[pdg];
                for (li = 0; li < nloci; li++)
                    {
                    autoc_tmrca[li][i].vals[nextpossave[i]] = C[0]->L[li].roottime;
                    }
				nextpossave[i]++;
				if (nextpossave[i] > maxpos[i])
					nextpossave[i] = 0;
				}
			}
		}
    } /*checkautoc */

#define TUPDATEINC  5
#define UUPDATEINC  9
void Qupdate(void)
    {
    int j,k,li,ci, ui;
    int changed;
    int static ppick = 0;
    static  int lc = -1;
    int qswapped = 0;
    int topolchange, tmrcachange;
	static int tswitch = 0;
	double told;
	static int tui = 0;
	static int uui = 0;

    /* update genealogies */
	for (ci=0;ci<numchains;ci++)
		for (li=0;li<nloci;li++)
			{   
			if (ci==0) 
				C[ci]->L[li].gupdate->tries++;
			if (updategenealogy(ci,li,&topolchange, &tmrcachange))
			   {
			   if (ci==0) 
				   {
					C[ci]->L[li].gupdate->accp++;
					C[ci]->L[li].topolupdate->accp +=(topolchange > 0);
					C[ci]->L[li].tmrcaupdate->accp +=(tmrcachange > 0);
				   }
			   myassert(C[ci]->L[li].topolupdate->accp <= C[ci]->L[li].gupdate->accp);
			   } 
			}
	if (tui == TUPDATEINC)
		{
		for (ci=0;ci<numchains;ci++)
			{
			if (!(modeloptions[EQUILIBRIUMMIGRATION] ||modeloptions[ONEPOP]))
				{
				/* alternate between two types of t updating just to get better mixing*/
				told = C[0]->t.val;

				if (tswitch)
					//changed = changet(ci);
					changed = changet2(ci);
				else
					changed = changet2(ci);
				if (changed)
					C[ci]->jointtreeinfo[tval] = C[ci]->t.val;
				if (ci==0)
					{
					li = 0;
					while (li< nloci && C[ci]->L[li].roottime < C[ci]->t.val  && C[ci]->L[li].roottime < told )
						{
						li++;
						} 
					if (li!=nloci && changed)
						C[ci]->t.upinf->accp++;
					C[ci]->t.upinf->tries++;
					}
				}
			}
		tswitch = 1 - tswitch;
		tui = 0;
		}
	else 
		tui++;
        
	if (uui == UUPDATEINC)
		{
        if (nurates > 1)
            for (ci=0;ci<numchains;ci++)
			{
            for (j = 0;j < (nurates - (nurates==2));j++)
                {
				ui = changeu(ci, j, &k); 
                if (ci==0)
					{
					C[ci]->L[ul[j].l].u[ul[j].u].mcinf.upinf->tries++;
					C[ci]->L[ul[k].l].u[ul[k].u].mcinf.upinf->tries++;
					if (ui==1)
						{
						C[ci]->L[ul[j].l].u[ul[j].u].mcinf.upinf->accp++;
						C[ci]->L[ul[k].l].u[ul[k].u].mcinf.upinf->accp++;
						}
					if (ui==-1)
						{
						C[ci]->L[ul[j].l].u[ul[j].u].uprior_failedupdate++;
						C[ci]->L[ul[k].l].u[ul[k].u].uprior_failedupdate++;
						}
					}
                }
			if (modeloptions[UPDATEH])
				{
				for (li=0; li < nloci; li++)
					{
					changed = changeh(ci, li);
					if (ci==0) 
						{
						if (changed)
							C[ci]->L[li].h.upinf->accp++;
						C[ci]->L[li].h.upinf->tries++;
						}
					}
				}
            }
		else
			{
			if (nloci==1 && C[0]->L[0].model == HKY)  /* if there is just one HKY locus kappa needs updating on its own*/
				for (ci=0;ci<numchains;ci++)
					changekappa(ci);
			}
		uui = 0;
        }
	else
		uui++;
	
    if (numchains > 1)
        qswapped =  swapchains(swaptries,heatmode,adaptcheck,hval1,hval2);
    intervaloutput(burnsteps);
    if (step >= CHECKAUTOCWAIT)
        //updated 4/21/08
		checkautoc(0);
	} /* Qupdate */

void savetreeinfo(void)
    {
    int ci,i,j, k;

	j = tval + 1;
    if (treessaved==0)
	    {
        if (cdurationmode==TIMESTEPS)
            {
		    gsampinf = malloc(treestosave * sizeof(double *));
		    for (i=0;i<treestosave;i++)
				gsampinf[i] = malloc(j * sizeof(double));
		    }
        else /* cdurationmode == TIMEINF */
            {
			k = (MAXTREESTOSAVE + (CHECKINTERVALSTEPS / savetreeint) + 1); // need a bit more than MAXTREESTOSAVE to allow for time between checking to printoutput() 
		    gsampinf = malloc( k * sizeof(double *));
            for (i=0;i<k;i++)
			    gsampinf[i] = malloc(j * sizeof(double));
            }
        }
    if (treessaved >= MAXTREESTOSAVE -1 && cdurationmode==TIMEINF)
        {
        if (maxedouttreesave == 0)
			{
			SP"\n MAXIMUM POSSIBLE TREES SAVED - PROGRAM HALTED \n");
			maxedouttreesave = 1;
			}
        }
    ci=0;
	for (i=0;i<= prob;i++)
		gsampinf[treessaved][i]=C[ci]->jointtreeinfo[i];
	if (multipleh)
		for (j=0,i=prob+1;i<= hak;i++,j++)
			gsampinf[treessaved][i]=C[ci]->hterms[j];
	j = tval;
	gsampinf[treessaved][j] = C[ci]->t.val;
    } /* savetreeinfo */



int run(void)
    {
    static int checkinterval = 0;
    int li, ui;
    char ch;

    if (burndone)
        {
		if (printoptions[CHECKPOINTFILEWRITE])
			{
			if (checkinterval < CHECKINTERVALSTEPS)
                {
                checkinterval++;
                }
            else
                {
                checkinterval=0;
                time(&checktimer);
                if ((checktimer - checklasttime) > checkduration)
                    {
                    checklasttime = checktimer;
				//	writedck(dckfilename);
                    }
                }
			}
        switch (cdurationmode)
            {
	        case TIMESTEPS: return(step < (chainduration+burnsteps)); break;
            case TIMEINF:   
                if (checkinterval < CHECKINTERVALSTEPS)
                        {
                        checkinterval++;
                        return(1);
                        }
                    else
                        {
                        checkinterval=0;
                        if (maxedouttreesave)
                            return(0);
                        time(&timer);
                        if ((timer - lasttime) > chainduration)
                            {
                            if ((checkdonefile = fopen("IMrun","r"))==NULL)
                                {
                                return(0);
                                }
                            else 
                                {
                                ch = (char) getc(checkdonefile);
                                f_close(checkdonefile);
                                if ((char) toupper(ch) !='Y')
                                    {
                                    return(0);
                                    }
								else
                                    {
                                    printoutput();
									time(&lasttime);// start the clock again 
									if (printoptions[CHECKPOINTFILEWRITE])
										{
										checkinterval=0;
										checklasttime = checktimer;
										time(&checktimer);
										//writedck(dckfilename);
										}
                                    }
                                }
                            }
                        return(1);
                        }
                        break;
            default : return(0); break;
            }
        }
    else
        {
        switch (bdurationmode)
            {
            case TIMESTEPS: burndone = (step > burnduration); break;
			case TIMEINF:   
                if (checkinterval < CHECKINTERVALSTEPS)
                        {
                        checkinterval++;
                        return(1);
                        }
                    else
                        {
                        checkinterval=0;
                        time(&timer);
						burndone = (timer - lasttime) > burnduration;
						}
                 break;
            default : return(0); break;
            }
        if (burndone)
            {
            time(&chainstarttime);
            burnsteps = step-1;
			if (cdurationmode == TIMEINF)
				{
                time(&lasttime);
				time(&timer);
				}
			if (printoptions[CHECKPOINTFILEWRITE])
				{
				time(&checklasttime);
				checkinterval=0;
				//writedck(dckfilename);
				}
			C[0]->t.upinf->accp = C[0]->t.upinf->tries = 0;
            for (li=0;li<nloci;li++) 
		        {
                C[0]->L[li].gupdate->accp = C[0]->L[li].gupdate->tries = 0;
				C[0]->L[li].topolupdate->accp = C[0]->L[li].topolupdate->tries = 0;
				C[0]->L[li].tmrcaupdate->accp = C[0]->L[li].tmrcaupdate->tries = 0;
				for (ui = 0; ui < C[0]->L[li].nlinked; ui++)
					{
					C[0]->L[li].u[ui].mcinf.upinf->accp = C[0]->L[li].u[ui].mcinf.upinf->tries = 0;
					}
				if (modeloptions[UPDATEH])
					C[0]->L[li].h.upinf->accp = C[0]->L[li].h.upinf->tries = 0;
				if (C[0]->L[li].model == HKY)
					C[0]->L[li].kappa.upinf->accp = C[0]->L[li].kappa.upinf->tries = 0;
		        }
            //updated 4/21/08  reinitialize the autocorrelations 
            checkautoc(1);
            adaptcheck = 10000;
            if (!printoptions[DONTSAVETREES])
                {
                strcpy(treeinfosavefilename,outfilename);
                strcat(treeinfosavefilename,".ti");
                if ((treeinfosavefile = fopen(treeinfosavefilename,"w")) == NULL)
		           {
			        printf("Error opening treeinfosave file for writing\n"); 
                    err(-1,-1,3);
		           }
                //fprintf(treeinfosavefile,"HEADER INFORMATION FROM FIRST TREE FILE\n\n");
                fprintf(treeinfosavefile,"-------------------------------------------\n\n");
				fprintf(treeinfosavefile,"Header for tree file:  %s\n\n",treeinfosavefilename);
				fprintf(treeinfosavefile,"-------------------------------------------\n\n");
                fprintf(treeinfosavefile,"%s\n",fpstr);
				fprintf(treeinfosavefile,"-------------------------------------------\n\n");
				fprintf(treeinfosavefile,"End of deader for tree file:  %s\n\n",treeinfosavefilename);
                fprintf(treeinfosavefile,"-------------------------------------------\n\n");
                fprintf(treeinfosavefile,"cc1\tcc2\tcca\tcm1\tcm2\tfc1\tfc2\tfca\tfm1\tfm2\tq1k\tq2k\tqak\tm1k\tm2k\tpdg\tprob\th1k\th2k\thak\ttval\n");
                f_close(treeinfosavefile);
                }
			initialize_autocorrelations = 0;
            }
        return(1);
        }
    } /* run */

void inctrend(int m, int t, double trendarray[], double v)
	{
	int j;
	for (j= m; j < TRENDDIM - 1; j++)
		trendarray[j] = trendarray[j+1];
	trendarray[t] = v;
	}

/* should probably substitute revised version of trend maintenance that is in ima_main.c  of IMamp - seems to fix a bug  */
void record(void)
	{
	int i,k, li, ci, ui;
    int nowpop,mc, mcount[2];
    double mtime[2];   
	static int trendspot = 0, recordtrendinc = 1, recordinc = 0, movespot = TRENDDIM - 1;
	struct locus *L;

    ci=0;
	if (printoptions[PRINTTMRCA])
		for (li = 0; li< nloci; li++)
			{
			k = IMIN(gridsize, (int) (gridsize * C[ci]->L[li].roottime /(C[ci]->t.pr.max + 10)));
			if (k >= 0 && k < gridsize) 
				C[0]->L[li].tmrcaxy[k].y++;
			}
    if (printoptions[MIGRATEDIST])
        for (li = 0; li< nloci; li++)
		{
/* 12/17/09  stopped using mean times,  put in this revised code to record all times */
          for (i=0; i<2*C[ci]->L[li].numgenes-1; i++)
            if (C[ci]->L[li].tree[i].down > -1)
            {
              nowpop =  C[ci]->L[li].tree[i].pop;
              mc = 0;
              while (*(C[ci]->L[li].tree[i].mig+mc) > -0.5 && *(C[ci]->L[li].tree[i].mig + mc) < C[ci]->t.val) 
              {
	          // use full range of t,  evin if Qmin.t is not zero
	          //k = (int) (gridsize * (L[ci][li]->tree[i].mig[mc] - Qmin.t)/(Qmax.t-Qmin.t));
	            k = (int) (gridsize * (*(C[ci]->L[li].tree[i].mig +mc) )/C[ci]->t.pr.max);
                if (k >= 0 && k < gridsize)
                {
			      C[ci]->L[li].migtimexy[nowpop][k].y++;
                }
                mc++;
                nowpop = 1-nowpop;
              }
            }
                
        }


/* 12/17/09  stopped using mean times 
            mcount[0] = mcount[1] = 0;
            mtime[0] = mtime[1] = 0;
            for (i=0; i<2*C[ci]->L[li].numgenes-1; i++)
                if (C[ci]->L[li].tree[i].down > -1)
                    {
                    nowpop =  C[ci]->L[li].tree[i].pop;
                    mc = 0;
                    while (*(C[ci]->L[li].tree[i].mig+mc) > -0.5 && *(C[ci]->L[li].tree[i].mig + mc) < C[ci]->t.val) 
				        {
                        mcount[nowpop]++;
                        mtime[nowpop] += *(C[ci]->L[li].tree[i].mig +mc);
				        myassert(*(C[ci]->L[li].tree[i].mig +mc)>=0.0 && *(C[ci]->L[li].tree[i].mig+mc) < C[ci]->t.val);
				        mc++;
                        nowpop = 1-nowpop;
				        }
                    }
			for (i=0;i<=1;i++)
				{
				if (mcount[i] >= 0 && mcount[i] < gridsize)
					{
					C[ci]->L[li].migcountxy[i][mcount[i]].y++;
					}
				if (mcount[i])
					{
					mtime[i] /= mcount[i];
					// use full time scale regardless of whether there is a minimum in the prior
					//k = (int) (gridsize * (mtime[i] - C[ci]->t.pr.min)/(C[ci]->t.pr.max-C[ci]->t.pr.min));
					k = (int) (gridsize * (mtime[i])/(C[ci]->t.pr.max));
					if (k >= 0 && k < gridsize)
						C[ci]->L[li].migtimexy[i][k].y++;
					}
				}
            } */
    ci = 0;
	for (li = 0; li< nloci; li++)
		{
		L = &(C[ci]->L[li]);
		for (ui = 0; ui < L->nlinked; ui++)
			{
			k = (int) (gridsize * ( log(L->u[ui].mcinf.val) + L->u[ui].mcinf.pr.max)/(2* L->u[ui].mcinf.pr.max));
			if (k < 0)
				*L->u[ui].mcinf.beforemin = *L->u[ui].mcinf.beforemin + 1;
			else
				{
				if (k >= gridsize)
					*L->u[ui].mcinf.aftermax = *L->u[ui].mcinf.aftermax + 1;
				else
					L->u[ui].mcinf.xy[k].y++;
				}	
			}
		if (L->model == HKY)
			{
			k = (int) (gridsize * (L->kappa.val - L->kappa.pr.min)/(L->kappa.pr.max - L->kappa.pr.min));
			if (k < 0)
				*L->kappa.beforemin = *L->kappa.beforemin + 1;
			else
				{
				if (k >= gridsize)
					*L->kappa.aftermax = *L->kappa.aftermax + 1;
				else
					L->kappa.xy[k].y++;
				}	
			}
	    if (modeloptions[UPDATEH])
            {
			k = (int) (gridsize * ( log(L->h.val) + L->h.pr.max)/(2* L->h.pr.max));
			if (k < 0)
				*L->h.beforemin = *L->h.beforemin + 1;
			else
				{
				if (k >= gridsize)
					*L->h.aftermax = *L->h.aftermax + 1;
				else
					L->h.xy[k].y++;
				}	
            } 
		}
    if (!modeloptions[EQUILIBRIUMMIGRATION] && !modeloptions[ONEPOP])
        {
		// use full time scale,
	    //k = (int) (gridsize * (C[ci]->t.val - C[ci]->t.pr.min)/(C[ci]->t.pr.max-C[ci]->t.pr.min));
		k = (int) (gridsize * (C[ci]->t.val)/(C[ci]->t.pr.max));
        if (k < 0 || C[ci]->t.val < C[ci]->t.pr.min)
			*C[ci]->t.beforemin = *C[ci]->t.beforemin +1;
        else 
			{
			if (k >= gridsize)
				*C[ci]->t.aftermax = *C[ci]->t.aftermax + 1;
			else
	            C[ci]->t.xy[k].y++;
            } 
        }
	/* explanation for how trendline data are accumulated:
	movespot is the point at which values are deleted from the array, 
	by shifting all values from above that point down one,to make room for new values added at the end of the array (i.e. at trendspot)
	values are added more slowly as the run proceeds.  Each time the replacement point (movespot) reaches the end of the array the time period between additions doubles 
	Because the time period doubles when movespot reaches the end the points to the left of movespot have half the density (in time) of those to the right 
	*/
	if (printoptions[PRINTASCIITREND])
		{
		recordinc++;
		if (recordinc == recordtrendinc)
			{
			if (movespot == TRENDDIM -1 && trendspot == TRENDDIM-1)
				{
				movespot = 0;
				recordtrendinc *= 2;
				}
			inctrend(movespot, trendspot,lpgtrend,C[0]->jointtreeinfo[prob] + C[0]->jointtreeinfo[pdg]); 
			inctrend(movespot, trendspot,C[0]->t.trend,C[0]->jointtreeinfo[tval]); 
			for (li=0;li<nloci;li++)
				{
				for (ui = 0 ; ui < C[0]->L[li].nlinked; ui++)
					inctrend(movespot, trendspot, C[0]->L[li].u[ui].mcinf.trend,C[0]->L[li].u[ui].mcinf.val); 
				if (C[0]->L[li].model == HKY)
					inctrend(movespot, trendspot, C[0]->L[li].kappa.trend,C[0]->L[li].kappa.val); 
				if (modeloptions[UPDATEH])
					inctrend(movespot, trendspot, C[0]->L[li].h.trend,C[0]->L[li].h.val); 
				}
			if (movespot < TRENDDIM - 1)
				movespot++;
			trendspot += (trendspot < TRENDDIM - 1);
			recordinc = 0;
			}
		}
	} /* record */

void loadtreevalues(void)
    {
    char filenamewildcard[FNSIZE];
    char  *ctp, templine[301];
    FILE *sfile;
    int j,k,numtrees, totalnumtrees;
	int filefound, nofile;
	char defaultdir[2] = ".";
	struct dirent *dir_entry;
	DIR  *dp;
	int numfiles = 0;
	int numtoload, nottoload, loadall, loaded, notloaded;
	float load_notload_ratio; 

	if (strlen(loadfilebase))
		strcpy(filenamewildcard,loadfilebase);
	else
		{
		strcpy(filenamewildcard,outfilename);
		strtrunc(filenamewildcard,'.');
		strtrunc(filenamewildcard,'-');
		}
    strcat(filenamewildcard,"*.ti");
	SP"Base filename for loading files with sampled genealogies: %s\n",filenamewildcard);
	SP"Files loaded with sampled genealogies:\n");
    numtreefiles = 0;
    ctp = &templine[0];
    numtrees=totalnumtrees=0;
	if((dp = opendir(defaultdir)) == NULL) 
		{
        fprintf(stderr,"cannot open directory: %s\n", defaultdir);
        err(-1,-1,43);
		}
// first run through files to see how many trees there are in them 
	do {
		do
			{
			nofile = ((dir_entry = readdir(dp)) == NULL);
			if (!nofile)
				filefound = IsWildcardMatch (filenamewildcard, dir_entry->d_name,0);
			else
				filefound = 0;
			numfiles += filefound != 0;
			}
		while (!nofile && !filefound);
		if (numfiles == 0 && nofile == 1)
			err(-1, -1, 3);
		if (!nofile)
			{
			SP"   %s\n",dir_entry->d_name);
			numtreefiles++;
			if ( (sfile = fopen(dir_entry->d_name,"r")) == NULL)
				{
				printf("\nError opening text file for reading\n"); 
				exit(-2);
				} 
			while (fgets(templine,300, sfile) && strstr(templine,"cc1")== NULL && strstr(templine,"hak") == NULL && !feof(sfile));
			numtrees=0;
			while (fgets(templine,300, sfile) && !feof(sfile))
				numtrees++;
			if (numtrees < 1)
				err(-1,-1,92);
			else
				printf("loaded tree file %d \n",numtreefiles);
			//fclose(sfile);
			totalnumtrees += numtrees;
			}
        }while (!nofile);

	if (treestosave > 0)
		numtoload = IMIN(totalnumtrees, treestosave);
	else
		numtoload = totalnumtrees;
	numtoload = IMIN(numtoload,MAXTREESTOSAVE);
	gsampinf = malloc(numtoload * sizeof(double *));
	loadall = numtoload >= totalnumtrees;
	nottoload = totalnumtrees - numtoload;
	load_notload_ratio = (float) numtoload / (float) nottoload; 
	loaded = 0; notloaded = 0;
	SP"\nHEADER INFORMATION FROM FIRST TREE FILE\n");
	SP"========================================\n\n");
	

// now go through again and save the trees
	if((dp = opendir(defaultdir)) == NULL) 
		{
        fprintf(stderr,"cannot open directory: %s\n", defaultdir);
        err(-1,-1,43);
		}
	numfiles = 0;
    do {
		do
			{
			nofile = ((dir_entry = readdir(dp)) == NULL);
			if (!nofile)
				filefound = IsWildcardMatch (filenamewildcard, dir_entry->d_name,0);
			else
				filefound = 0;
			numfiles += filefound != 0;
			}
		while (!nofile && !filefound);
		if (numfiles == 0 && nofile == 1)
			err(-1, -1, 3);
		if (!nofile)
			{
			if ( (sfile = fopen(dir_entry->d_name,"r")) == NULL)
				{
				printf("\nError opening text file for reading\n"); 
				exit(-2);
				} 
			while (fgets(templine,300, sfile) && strstr(templine,"cc1")== NULL && strstr(templine,"hak") == NULL && !feof(sfile))
				if (numfiles == 1) 
					{
					SP"%s",templine);
					}
			while (fgets(templine,300, sfile) && !feof(sfile))
				{
				if (loadall || (loaded==0) ||  ((float) loaded/ (float) notloaded) <= load_notload_ratio) 
					{
					gsampinf[loaded] = malloc((tval+1) * sizeof(double));
					sscanf(templine,"%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf",
							&gsampinf[loaded][cc1],&gsampinf[loaded][cc2],&gsampinf[loaded][cca],&gsampinf[loaded][cm1],&gsampinf[loaded][cm2],&gsampinf[loaded][fc1],&gsampinf[loaded][fc2],&gsampinf[loaded][fca],
							&gsampinf[loaded][fm1],&gsampinf[loaded][fm2],&gsampinf[loaded][q1k],&gsampinf[loaded][q2k],&gsampinf[loaded][qak],&gsampinf[loaded][m1k],&gsampinf[loaded][m2k],&gsampinf[loaded][pdg],
							&gsampinf[loaded][prob],&gsampinf[loaded][h1k],&gsampinf[loaded][h2k],&gsampinf[loaded][hak],&gsampinf[loaded][tval]); 
					loaded++;
					}
				else
					{
					notloaded++;
					}
				}
			fclose(sfile);
			}
        }while (!nofile);
	SP"\n==============================================\n");
	SP"END OF HEADER INFORMATION FROM FIRST TREE FILE\n\n");
	SP"   # of files: %d    total number of loaded genealogies: %d out of a total of: %d \n",numtreefiles,loaded, totalnumtrees);
	if (numtrees < 1)
		err(-1,-1,92);
	closedir(dp);
    treessaved = loaded;
	if (!modeloptions[EQUILIBRIUMMIGRATION] && !modeloptions[ONEPOP])
		for (j=0; j< treessaved; j++)
			{
			// use full range of t, ignore t.pr.min > 0
			//k = (int) (gridsize * (gsampinf[j][tval] - C[0]->t.pr.min)/(C[0]->t.pr.max - C[0]->t.pr.min));
			k = (int) (gridsize * (gsampinf[j][tval])/(C[0]->t.pr.max));
			if (k < 0 || gsampinf[j][tval] < C[0]->t.pr.min) 
				*C[0]->t.beforemin = *C[0]->t.beforemin + 1;
			else 
				{
				if (k >  gridsize-1) 
					*C[0]->t.aftermax = *C[0]->t.aftermax + 1;
				else 
					C[0]->t.xy[k].y++;
				}
			}
    } /* loadtreevalues */

void printoutput(void)  // mostly calls functions in output.c
	{
	int i,li,ci, ui;
    double seconds; 
    
	int ndim;
	double holdpeakloc[BASICPARAMS];
	double holdmlval;
	double hold95lo[BASICPARAMS];
	double hold95hi[BASICPARAMS];
	
	
	if (calcoptions[LOADRUN] == 0)
		{
		/* save tree info in *.ti file */
		if (!printoptions[DONTSAVETREES] && treessaved > 0)
			savetreefile(treeinfosavefilename,treeinfosavefile,multipleh);
		if (cdurationmode == TIMEINF) 
			{
			remove(oldoutfilename);
			rename(outfilename, oldoutfilename);
			}
		}
	if ((outfile = fopen(outfilename,"w")) == NULL)
        {
        printf("Error opening text file for writing\n"); 
        err(-1,-1,7);
        } 
	printrunbasics(outfile,calcoptions[LOADRUN],fpstr,burnsteps,recordint,recordstep,savetreeint,endtime,starttime,hilike,hiprob);
	
	if (calcoptions[LOADRUN] == 0)
		{
		FP"Mean Time of Most Recent Common Ancestor \n"); // use some of the values recorded for autocorrelation measurements
		FP"\tLocus\tMean Time\tVariance \n");
		for (li=0;li<nloci;li++)
			if (autoc_tmrca[li][0].cov.n > 1)
				FP"\t%d\t%10.3f\t%10.3f\n",li,autoc_tmrca[li][0].cov.ss/autoc_tmrca[li][0].cov.n,(autoc_tmrca[li][0].var[1].s2 - (autoc_tmrca[li][0].cov.ss/autoc_tmrca[li][0].cov.n))/(autoc_tmrca[li][0].cov.n-1));
		FP"\n");  
		printacceptancerates(outfile);
		if(modeloptions[MUTATIONPRIORRANGE] && countuprior > 1)
			{
			FP"\nFailed Mutation Updates Because of Prior Ranges");
			FP"\nLocus#\tu#\toutof#\tu%%\n");
			for (ui = 0; ui < nurates; ui++)
				{
				FP"\t%d\t%d\t%6d\t%.2e\t%.3f\n",ul[ui].l,ul[ui].u,C[0]->L[ul[ui].l].u[ul[ui].u].uprior_failedupdate,C[0]->L[ul[ui].l].u[ul[ui].u].mcinf.upinf->tries,(100.0*C[0]->L[ul[ui].l].u[ul[ui].u].uprior_failedupdate)/C[0]->L[ul[ui].l].u[ul[ui].u].mcinf.upinf->tries);
				}
			FP"\n");
			}
		if (autoc_t[0].cov.n > AUTOCCUTOFF)
			printautoc(outfile,autoc_checkstep,autoc_t,autoc_lpg,autoc_tmrca);
		if (numchains > 1)
			printchaininfo(outfile, heatmode, hval1, hval2);
		}
	if (!modeloptions[RETURNPRIOR])
		{
		printf("surface calculations . . .\n");
		ndim = findpeaks(outfile,imodel,outfilename,&holdmlval,holdpeakloc);
		if (calcoptions[PROFILE95CONF])
			{
			printf("finding confidence intervals, parameter: ");
			profile95(outfile,ndim,holdmlval,holdpeakloc,hold95lo,hold95hi); 
			printf("\n");
			printprofile95(outfile,holdpeakloc,hold95lo,hold95hi); 
			closeopenout(outfile,outfilename);
			}
		}
	if (ndim > 1 && calcoptions[PROFILECURVE])
		{
        profilelike1Dcurve(outfile,ndim,holdpeakloc, holdmlval,imodel); 
		closeopenout(outfile,outfilename);
		}
	printhist(outfile,0,recordstep, uscaleinput, generationtime);
    if (printoptions[DEMOGHIST])
		printhist(outfile,1,recordstep,uscaleinput, generationtime);
    ci = 0;
	if (printoptions[PRINTASCIICURVE])
		{
		FP"\n\nASCII Curves - Approximate Posterior Densities \n");
		FP"===================================================\n");
		for (i=0;i< BASICPARAMS;i++)
			if (iq[i].integrate)
				asciicurve(outfile, &iq[i].xy[0],iq[i].str,0,1);
		if (!modeloptions[ONEPOP] && !modeloptions[EQUILIBRIUMMIGRATION]) 
			asciicurve(outfile, &C[0]->t.xy[0],C[0]->t.str,0,recordstep);
		if (calcoptions[LOADRUN] == 0)
			{
			if (nurates > 1)
				{
				for (li = 0;li<nloci;li++) 	
					for (ui = 0; ui < C[ci]->L[li].nlinked; ui++) 
					{
					asciicurve(outfile, &C[0]->L[li].u[ui].mcinf.xy[0],C[0]->L[li].u[ui].mcinf.str,1,recordstep);
					}
				}	
			if (modeloptions[UPDATEH])
				for (li=0;li<nloci;li++)
					asciicurve(outfile, &C[0]->L[li].h.xy[0],C[0]->L[li].h.str,1,recordstep);
			for (li=0;li<nloci;li++)
				if (C[0]->L[li].model == HKY)
					asciicurve(outfile, &C[0]->L[li].kappa.xy[0],C[0]->L[li].kappa.str,0,recordstep);
			}
		}
	if (calcoptions[LOADRUN] == 0 && printoptions[PRINTASCIITREND])
		{
        ci = 0;
		FP"\n\nASCII Plots of Parameter Trends \n");
		FP"===================================================\n");
		asciitrend(outfile, &lpgtrend[0],"Log[P(G)+P(D|G)]", 100, 30,0);
		if (!modeloptions[ONEPOP] && !modeloptions[EQUILIBRIUMMIGRATION]) 
			asciitrend(outfile, C[0]->t.trend,C[0]->t.str,100,30,0);
		if (nurates >  1)
			{
			for (li=0;li<nloci;li++)
				for (ui = 0 ; ui < C[0]->L[li].nlinked; ui++)
					asciitrend(outfile, C[0]->L[li].u[ui].mcinf.trend,C[0]->L[li].u[ui].mcinf.str,100,30,UMAX);
			if (modeloptions[UPDATEH])
				for (li=0;li<nloci;li++)
					asciitrend(outfile, C[0]->L[li].h.trend,C[0]->L[li].h.str,100,30,HMAX);
			}
		for (li=0;li<nloci;li++)
			if (C[0]->L[li].model == HKY)
				asciitrend(outfile, C[0]->L[li].kappa.trend,C[0]->L[li].kappa.str,100,30,0);
		}
	if (printoptions[PRINT2DMARGINALS])
		twodmarginallistplot(margin2dfilename,outfilename);
	if (calcoptions[LOADRUN] == 0 && printoptions[PRINTTMRCA])
		printtmrcahist(outfile,recordstep);
    if (calcoptions[LOADRUN] == 0 && printoptions[MIGRATEDIST])
		printmigratehist(outfile,recordstep);
	time(&endtime);
    seconds = difftime(endtime,starttime);
    FP"Time Elapsed : %d hours, %d minutes, %d seconds \n\n", 
        (int) seconds / (int) 3600,
       ((int) seconds / (int) 60) - ((int) 60 * ((int) seconds / (int) 3600)),
	   (int) seconds  - (int) 60* ((int) seconds / (int) 60)
	   );
    FP"\nEND OF OUTPUT\n");
	f_close(outfile);
	} /* printoutput*/


void intervaloutput(int burnsteps)
	{
	double like;
	int ci;

	ci = 0;
	checkhighs(0, printint,  &hilike, &hiprob, &like);
	if (( step/(int) printint)* (int) printint == step && step > 0)
		{
		if (!burndone)
            {
            printf("=BURNIN-PERIOD===============================\n");
            printf("STEP # %li  p(D|G): %.1lf p(G): %.1lf\n",step,like,C[ci]->jointtreeinfo[prob]);
            }
        else 
            {
            printf("=============================================\n");
            if (treessaved > 0)
                printf("STEP # %li # Genealogies Saved: %d p(D|G): %.1lf p(G): %.1f\n",step - burnsteps,treessaved,like,C[ci]->jointtreeinfo[prob]);
            else
                printf("STEP # %li  p(D|G): %.1lf p(G): %.1lf\n",step - burnsteps,like,C[ci]->jointtreeinfo[prob]);
            }
		printacceptancerates(stdout);
		printcurrentvals();
		if (autoc_t[0].cov.n > AUTOCCUTOFF)
			printautoc(stdout,autoc_checkstep,autoc_t,autoc_lpg,autoc_tmrca);
		if (numchains > 1)
			printchaininfo(stdout, heatmode,hval1,hval2);
		}
	} /* intervaloutput */


int main(int argc, char *argv[]) 
	{
    int i,j;
	int oldrecordint;
//	mtrace();
// Get current flag
// Turn on leak-checking bit. tmpFlag |= _CRTDBG_LEAK_CHECK_DF;
// Turn off CRT block checking bit. tmpFlag &= ~_CRTDBG_CHECK_CRT_DF;
//tmpFlag &= ~_CRTDBG_CHECK_CRT_DF;
// Set flag to the new value

/* */
#ifdef HPDBG
tmpFlag = _CrtSetDbgFlag( _CRTDBG_REPORT_FLAG );
//tmpFlag |= _CRTDBG_LEAK_CHECK_DF;
tmpFlag &= ~_CRTDBG_LEAK_CHECK_DF;
//tmpFlag |= _CRTDBG_CHECK_CRT_DF;
tmpFlag &= ~_CRTDBG_CHECK_CRT_DF;
tmpFlag |= _CRTDBG_CHECK_ALWAYS_DF; 
_CrtSetDbgFlag( tmpFlag );
#endif

	start(argc, argv);
	if (calcoptions[LOADRUN])
        {
        loadtreevalues();
        recordstep = treessaved;
        printoutput();
		return 0;
        }
#if 0   //checkpoint stuff not included
	else
		{
		if (printoptions[CHECKPOINTFILEREAD]) 
			{
			readdck();
			if (printoptions[RESTARTBURN])
				reinitialize();
			else
				printoutput();
			goto restart;
			}
		}
#endif 

	printf("Starting Markov chain.\n");
    step = 0;
	recordstep = 0;
	i = recordint;
    j = savetreeint;
	oldrecordint = recordint;
//restart:
    while (run())
        {
/* not sure why this is here
if (step==1000)
{
      writemcmc(0, 1);
} */

        Qupdate();
		if (burndone)
            {
			if (i== recordint)
				{
				record();
				recordstep++;
				i=1;
				}
			else
				i++;
            if (j== savetreeint)
				{
				savetreeinfo();
                treessaved++;
				j=1;
				}
			else
				j++;
            }
        step++;
		//treeprint(0,0);
    }
    printoutput();
#ifdef HPDBG
	_CrtDumpMemoryLeaks ();
#endif
	return 0;
	} /* main */

