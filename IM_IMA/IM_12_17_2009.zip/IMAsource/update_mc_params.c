/* IMa   for IM_analytic    2007-2009  Jody Hey and Rasmus Nielsen*/ 
/* December 17, 2009 */


#undef GLOBVARS
#include "ima.h"

/*** LOCAL STUFF *****/

int urri[2*MAXLOCI][2*MAXLOCI]; // double it - some loci might have multiple rates
double urrlow[2*MAXLOCI][2*MAXLOCI], urrhi[2*MAXLOCI][2*MAXLOCI];

/*** GLOBAL FUNCTIONS ***/

#define MAXPRIORSCALETRY 10000000  // max number of times to try getting starting mutation rates compatible with priors
void setuinfo(double summut)
	{
	int i, li, ui, uj, k; 
	int  numuprior=0;
	double priorscaletry = 0;
	double  U,r; 
	int doneu, rcheck, numupair, *upriorpairlist1, *upriorpairlist2;
	double prodcheck, maxr, newr, d;
/*  ul contains a list of locations by locus and within locus of all mutation rate scalars
    uii is the position in that list
	in setinitialQ() the priors on mutation rate scalars are set to standard pos (max) and neg (min) values (they are on a log scale)
	   and are stored in the mcinf.pr   (e.g. C[0]->L[0].u[0].mcinf.pr)
	if the input file has prior ranges on mutation yets,  these are read into uperyear.pr  (e.g. C[ci]->L[li].u[ui].uperyear.pr)
	The ratios of these uperyear values among loci must be taken to reset the values of mcinf.pr   
*/
	for (i = 0,li = 0; li < nloci; li++)
		for (ui = 0;ui < C[0]->L[li].nlinked; ui++)
			{
			ul[i].l = li;
			ul[i].u = ui;
			C[0]->L[li].u[ui].uii = i;
			i++;
			}
	for (prodcheck = 1, ui = 0; ui < nurates; ui++)
		{
		C[0]->L[ul[ui].l].u[ul[ui].u].mcinf.val = exp(C[0]->L[ul[ui].l].u[ul[ui].u].mcinf.val - summut/nurates);
		prodcheck *= C[0]->L[ul[ui].l].u[ul[ui].u].mcinf.val;
		}
	if (fabs(log(prodcheck)) > 1e-5)
		err(0,li,76);
	for (ui = 0; ui < nurates; ui++)
		{
		if (C[0]->L[ul[ui].l].u[ul[ui].u].uperyear.pr.min != 0) numuprior++;
		}
	if (modeloptions[MUTATIONPRIORRANGE])
		{
		myassert(numuprior > 1);
		numupair = numuprior * (numuprior-1)/2;
		upriorpairlist1 = calloc (numupair,sizeof(int));
		upriorpairlist2 = calloc (numupair,sizeof(int));
		k = 0;
		for (ui = 0; ui < nurates-1; ui++)
			{
			for (uj = ui+1; uj < nurates; uj++)
				if (C[0]->L[ul[ui].l].u[ul[ui].u].uperyear.pr.min != 0 && C[0]->L[ul[uj].l].u[ul[uj].u].uperyear.pr.min != 0)
					{
					upriorpairlist1[k] = ui;
					upriorpairlist2[k] = uj;
					k++;
					}
			}
		/* urri[i][j] has a 0 if neither i nor j has a prior. 1 if i has a prior and j does not,  -1 if i does not have a pior and j does  */
		for (ui = 0; ui < nurates; ui++)
			for (uj = 0; uj < nurates; uj++)
				{
				urri[ui][uj] = 0;
				if (ui != uj && C[0]->L[ul[ui].l].u[ul[ui].u].uperyear.pr.min != 0 && C[0]->L[ul[uj].l].u[ul[uj].u].uperyear.pr.min != 0)
					{
					urrlow[ui][uj] = log(C[0]->L[ul[ui].l].u[ul[ui].u].uperyear.pr.min/ C[0]->L[ul[uj].l].u[ul[uj].u].uperyear.pr.max);
					urrhi[ui][uj] = log(C[0]->L[ul[ui].l].u[ul[ui].u].uperyear.pr.max/C[0]->L[ul[uj].l].u[ul[uj].u].uperyear.pr.min);
					urri[ui][uj] = urri[uj][ui] = 2;
					}
				else
					{
					if (ui != uj && C[0]->L[ul[ui].l].u[ul[ui].u].uperyear.pr.min != 0 && C[0]->L[ul[uj].l].u[ul[uj].u].uperyear.pr.min == 0)
						urri[ui][uj] = 1;
					if (ui != uj && C[0]->L[ul[uj].l].u[ul[uj].u].uperyear.pr.min != 0 && C[0]->L[ul[ui].l].u[ul[ui].u].uperyear.pr.min == 0)
						urri[ui][uj] = -1;
					}
				}
		/* need to set all of the uscalers so that their ratios are in the ranges defined by the priors */
		/* it is possible that suiteable sets of scalars will not be able to be found */
		maxr = 3*C[0]->L[0].u[0].mcinf.pr.max;	
		do	{
			doneu = 1;
			for (i=0;i< numupair;i++)
				{
				ui = upriorpairlist1[i];
				uj = upriorpairlist2[i];
				r = log(C[0]->L[ul[ui].l].u[ul[ui].u].mcinf.val/C[0]->L[ul[uj].l].u[ul[uj].u].mcinf.val);
				rcheck = (r >= urrlow[ui][uj] && r <= urrhi[ui][uj]);
				doneu = doneu && rcheck;
				if (!rcheck)
					{
					do
						{
						U = uniform();
						if (U > 0.5)
							newr = r + maxr*(2.0*U-1.0);
						else
							newr = r - maxr*U*2.0;
						if (newr > maxr)
							newr = 2.0*maxr - newr;
						else if (newr < -maxr)
							newr = 2.0*(-maxr) - newr; 
						d = exp((newr - r)/2);
						}
					while ((newr <= urrlow[ui][uj] || newr >= urrhi[ui][uj]));
					C[0]->L[ul[ui].l].u[ul[ui].u].mcinf.val *= d;
					C[0]->L[ul[uj].l].u[ul[uj].u].mcinf.val /= d;
					}
				}
			priorscaletry++;
			}
		while (!doneu && priorscaletry < MAXPRIORSCALETRY);
		if (priorscaletry >= MAXPRIORSCALETRY)
			err(0,li,78);
		for (prodcheck = 1,ui = 0; ui < nurates; ui++) 
			//prodcheck *= C[0]->L[ul[ui].l].u[ul[ui].u].uperyear.val;
			prodcheck *= C[0]->L[ul[ui].l].u[ul[ui].u].mcinf.val;
		if (fabs(log(prodcheck)) > 1e-5)
			{
			err(0,li,77);
			}
		free(upriorpairlist1);
		free(upriorpairlist2);
		}
	} /* setuinfo */

int changet(int ci) // change all times by a scalar
	{
	double weight, newt, temp;
    //double tpnew,tpold,likenew[MAXLOCI],like_anew[MAXLOCI];
	double tpold,tpnew,likenew[MAXLOCI + MAXLINKED], likenewsum;
    double tr,tpw;
    int li, i,j, ec;
    double U;
    double holdjointtreeinfo[prob+1];
	struct edge *tree;
	struct locus *L;
	int ai, ui;


    temp=uniform();
    newt = (C[ci]->t.val - C[ci]->t.win/2) + temp*C[ci]->t.win;
    while ((newt > C[ci]->t.pr.max) || (newt < C[ci]->t.pr.min))
		{
        if (newt > C[ci]->t.pr.max)
			newt = 2.0 * C[ci]->t.pr.max - newt;
		else 
			if (newt < C[ci]->t.pr.min)
				newt = 2.0 * C[ci]->t.pr.min - newt;
		} 
    tr = newt/ C[ci]->t.val;
    tpw = 0;
    for (i=0;i<=prob;i++)
        {
        holdjointtreeinfo[i] = C[ci]->jointtreeinfo[i];
        }
    tpold = C[ci]->jointtreeinfo[prob];
    for (i=fc1;i<=fm2;i++)
        C[ci]->jointtreeinfo[i] *= tr;
// count # of events that have their time changed 
    ec=0;        
	likenewsum = 0;
    for (li=0;li < nloci;li++)
        {
		L = &(C[ci]->L[li]);
		//tree = C[ci]->L[li].tree;
		tree = L->tree;
        ec += L->numgenes-1;
        for (i=0; i<2*L->numgenes-1; i++)
		    {
            if (tree[i].down != -1)
                {
		        j = 0;
                while (*(tree[i].mig + j) > -0.5)
                    {
					myassert(*(tree[i].mig + j)*tr <newt);
                    j++;
                    }
				ec += j;
                }
		    }
		ai = 0;
		ui = L->u[ai].uii;
        switch(L->model)
            {
            case HKY :
				/* need to reset the node times in the genealogy for this mutation model */
					L->roottime *= tr;
					L->length *= tr;
					L->tlength *= tr;
					for (i=0; i<2*L->numgenes-1; i++)
						{
						if (tree[i].down != -1)
							{
							tree[i].time *= tr;
							}
						}
					likenew[ui] = likelihoodHKY(ci, li,L->u[0].mcinf.val, L->kappa.val, -1, -1, -1, -1); 
					likenewsum += likenew[ui] - L->oldlike[0];
					break;
            case INFINITESITES : 
                if (modeloptions[RETURNPRIOR]) 
                    likenew[ui] = 1;
                else   // under IS model P(D|G) scales by the length, which scales by tr 
                    likenew[ui] = (1-tr) * L->u[0].mcinf.val * L->length + log(tr)*L->numsites + L->oldlike[0];
				likenewsum += likenew[ui] - L->oldlike[0];
                break;
            case STEPWISE : 
				for (; ai < L->nlinked; ai++)
					{
					ui = L->u[ai].uii;
					likenew[ui] =  likelihoodSW(ci,li, ai,L->u[ai].mcinf.val,tr); 
					likenewsum += likenew[ui] - L->oldlike[ai];
					}
                break;
            case JOINT_IS_SW : 
                if (modeloptions[RETURNPRIOR]) 
                    likenew[ui] = 1;
                else
                    likenew[ui] = (1-tr) * L->u[0].mcinf.val * L->length + log(tr)*L->numsites + L->oldlike[0];
				likenewsum += likenew[ui] - L->oldlike[0];
				for (ai = 1; ai < L->nlinked; ai++)
					{
					ui = L->u[ai].uii;
					likenew[ui] =  likelihoodSW(ci,li, ai,L->u[ai].mcinf.val,tr); 
					likenewsum += likenew[ui] - L->oldlike[ai];
					}
                break; 
            }
        }
	tpw += likenewsum;
    tpnew = integrate_tree_prob(ci, &C[ci]->jointtreeinfo[0]);
    tpw += tpnew - tpold;
    weight = exp(beta[ci]*tpw + ec*log(tr));
    U=uniform();
	if (weight >= 1.0 || weight > U )  
        {
        for (li = 0;li <nloci;li++)
		    {
			L = &(C[ci]->L[li]);
			tree = L->tree;
			for (i=fc1;i<=fm2;i++)
					L->treeinfo[i] *= tr;
			for (ai = 0; ai < L->nlinked; ai++)
				{
				L->oldlike[ai] = likenew[L->u[ai].uii];
				}
			if (L->model == HKY)
				{
				/* have already set node times in this case,  so just need to set migration times */
				for (i=0; i<2*L->numgenes-1; i++)
					{
					if (tree[i].down != -1)
						{
						j = 0;
						while (*(tree[i].mig + j) > -0.5)
							{
							*(tree[i].mig + j) *= tr;
							j++;
							}
						}
					}
				storescalefactors(ci,li); 
				copyfraclike(ci,li);
				}
			else
				/* need to reset everything in the tree*/
				{
				tree = L->tree;
				L->roottime *= tr;
				L->length *= tr;
				L->tlength *= tr;
				for (i=0; i<2*L->numgenes-1; i++)
					{
					if (tree[i].down != -1)
						{
						j = 0;
						while (*(tree[i].mig + j) > -0.5)
							{
							*(tree[i].mig + j) *= tr;
							j++;
							}
						tree[i].time *= tr;
						}
					}
	    		}
            }
		 
		  C[ci]->jointtreeinfo[pdg] += likenewsum;
         C[ci]->t.val = newt;
         return 1;
        }
     else 
        {
        for (i=0;i<=prob;i++)
            {
            C[ci]->jointtreeinfo[i] =holdjointtreeinfo[i];
            }
        for (li=0;li<nloci;li++)
            {
			L = &(C[ci]->L[li]);
			tree = L->tree;
			if (L->model == HKY) 
				{
				/* need to put times in the genealogy back to what they were */
				L->roottime /= tr;
				L->length /= tr;
				L->tlength /= tr;
				for (i=0; i<2*L->numgenes-1; i++)
					{
					if (tree[i].down != -1)
						{
						tree[i].time /= tr;
						}
					}
				restorescalefactors(ci, li);
				}
            if (L->model == STEPWISE) 
				for (ai = 0; ai < L->nlinked; ai++)
					likelihoodSW(ci,li, ai,L->u[ai].mcinf.val,1); 
			if (L->model == JOINT_IS_SW) 
				for (ai = 1; ai < L->nlinked; ai++)
                likelihoodSW(ci, li, ai,L->u[ai].mcinf.val,1); 
            }
        return 0;
        }
    } /* changet */

/* 
changet2

t updating of Rannala and Yang (2003)   
In their usage there is an upper bound (species split time above the node in consideration), which for us is 0.  
There is also a lower bound which is the species split time below the nod in consideration,  which for us is a large number intended to approximate Infinity.  

Consider an update from t to tnew, then for events in the tree that are more recent than tnew  the update is 
 tau* = tau * tnew /t

Let there be m events of this type. 
For  events where tau < t (which only affects coalescent events, not migration events),  the update is simply
tau* = tau +tnew - t
In other words,  the times are shifted by a constant amount. 

the hastings term is just
(tnew/t)^m

1/8/06  - seems to work?? 
  */

int changet2(int ci)
	{
	double weight, newt, temp;
    double tpnew,tpold,likenew[MAXLOCI+MAXLINKED],likenewsum;
    double tr,tpw;
    int li, i,j, ecu, ecd,emu, ai,ui;
    double U;
    double holdjointtreeinfo[prob+1];
	double holdtreeinfo[MAXLOCI][fm2+1];
	double holdroot[MAXLOCI], holdlength[MAXLOCI],holdtlength[MAXLOCI];
	struct locus *L;
	struct edge *tree;

    temp=uniform();
    newt = (C[ci]->t.val - C[ci]->t.win/2) + temp*C[ci]->t.win;
    while ((newt > C[ci]->t.pr.max) || (newt < C[ci]->t.pr.min))
		{
        if (newt > C[ci]->t.pr.max)
			newt = 2.0 * C[ci]->t.pr.max - newt;
		else 
			if (newt < C[ci]->t.pr.min)
				newt = 2.0 * C[ci]->t.pr.min - newt;
		}
    tr = newt/ C[ci]->t.val;
	tpold = C[ci]->jointtreeinfo[prob];
    for (i=0;i<=prob;i++)
        {
        holdjointtreeinfo[i] = C[ci]->jointtreeinfo[i];
		C[ci]->jointtreeinfo[i] = 0;
        }
	ecu = ecd = emu =0;        
	temp = 0;
	likenewsum = 0;
	for (li=0;li < nloci;li++)
        {
		L = &(C[ci]->L[li]);
		tree = L->tree;
		holdroot[li] = L->roottime;
		holdlength[li] =  L->length;
		holdtlength[li] =  L->tlength;
		for (i=0;i<=fm2;i++)
			holdtreeinfo[li][i] = L->treeinfo[i];
		for (i=0; i<2*L->numgenes-1; i++)
			{
			if (tree[i].down != -1)
				{
				if (tree[i].time < C[ci]->t.val)
					{
					tree[i].time *= tr;
					ecu++;
					}
				else
					{
					tree[i].time += newt - C[ci]->t.val; 
					ecd++;
					}
				j = 0;
				while (*(tree[i].mig + j) > -0.5)
					{
					myassert(*(tree[i].mig + j) < C[ci]->t.val);
					if (*(tree[i].mig + j) < C[ci]->t.val)
						*(tree[i].mig + j) *= tr;
					j++;
					}
				emu += j;
				}
			}
		if (L->roottime < C[ci]->t.val)
			L->roottime *= tr;
		else
			L->roottime += newt - C[ci]->t.val; 
		treeweight(ci,li,newt);
		for (i=cc1;i<=fm2;i++)
			{
			C[ci]->jointtreeinfo[i] += L->treeinfo[i];
			myassert(C[ci]->jointtreeinfo[i] >= 0);
			}
		ai = 0;
		ui = L->u[ai].uii;
        switch(L->model)
            {
            case HKY :
				/* need to reset the node times in the genealogy for this mutation model */
					likenew[ui] = likelihoodHKY(ci, li,L->u[0].mcinf.val, L->kappa.val, -1, -1, -1, -1); 
					likenewsum += likenew[ui] - L->oldlike[0];
					break;
            case INFINITESITES : 
                if (modeloptions[RETURNPRIOR]) 
                    likenew[ui] = 1;
                else
					likenew[li] = likelihoodIS(ci, li,L->u[0].mcinf.val);
				likenewsum += likenew[ui] - L->oldlike[0];
                break;
            case STEPWISE : 
				for (; ai < L->nlinked; ai++)
					{
					ui = L->u[ai].uii;
					likenew[ui] =  likelihoodSW(ci,li, ai,L->u[ai].mcinf.val,1); 
					likenewsum += likenew[ui] - L->oldlike[ai];
					}
                break;
            case JOINT_IS_SW : 
                if (modeloptions[RETURNPRIOR]) 
                    likenew[ui] = 1;
                else
					likenew[ui] = likelihoodIS(ci, li,L->u[0].mcinf.val);
				likenewsum += likenew[ui] - L->oldlike[0];
				for (ai = 1; ai < L->nlinked; ai++)
					{
					ui = L->u[ai].uii;
					likenew[ui] =  likelihoodSW(ci,li, ai,L->u[ai].mcinf.val,1); 
					likenewsum += likenew[ui] - L->oldlike[ai];
					}
                break; 
            }
        }
	tpw = likenewsum;
    ecu /= 2 ;
	tpnew = integrate_tree_prob(ci, &C[ci]->jointtreeinfo[0]);
    tpw += tpnew - tpold;
    weight = exp(beta[ci]*tpw + (ecu+emu) *log(tr));
    U=uniform();
	if (weight >= 1.0 || weight > U )  
        {
        for (li = 0;li <nloci;li++)
			{
			for (ai = 0; ai < C[ci]->L[li].nlinked; ai++)
				{
				C[ci]->L[li].oldlike[ai] = likenew[C[ci]->L[li].u[ai].uii];
				}
			if (C[ci]->L[li].model == HKY) 
				{
				storescalefactors(ci, li); 
				copyfraclike(ci,li);
	    		}
            }
         C[ci]->t.val = newt;
		 C[ci]->jointtreeinfo[pdg] = holdjointtreeinfo[pdg] + likenewsum;
         return 1;
        }
     else 
        {
        for (i=0;i<=prob;i++)
            {
            C[ci]->jointtreeinfo[i] =holdjointtreeinfo[i];
            }
		for (li=0;li < nloci;li++)
			{
			L = &(C[ci]->L[li]);
			tree = L->tree;
			L->roottime = holdroot[li];
			L->length = holdlength[li];
			L->tlength = holdtlength[li];
	       	for (i=cc1;i<=fm2;i++)
	            {
		        L->treeinfo[i] = holdtreeinfo[li][i];
			    } 
			for (i=0; i<2*L->numgenes-1; i++)
				{
				if (tree[i].down != -1)
					{
					if (tree[i].time < newt)
						{
						tree[i].time /= tr;
						}
					else
						{
						tree[i].time += C[ci]->t.val - newt; 
						}
					j = 0;
					while (*(tree[i].mig + j) > -0.5)
						{
						myassert(*(tree[i].mig + j) < newt);
						if (*(tree[i].mig + j) < newt)
							{
							*(tree[i].mig + j) /= tr;
							}
						j++;
						}
					}
				}
			
			}
        for (li=0;li<nloci;li++)
            {
			if (C[ci]->L[li].model == HKY) 
				restorescalefactors(ci, li);
			if (C[ci]->L[li].model == STEPWISE) 
				for (ai = 0; ai < C[ci]->L[li].nlinked; ai++)
					likelihoodSW(ci,li, ai,C[ci]->L[li].u[ai].mcinf.val,1); 
			if (C[ci]->L[li].model == JOINT_IS_SW) 
				for (ai = 1; ai < C[ci]->L[li].nlinked; ai++)
                likelihoodSW(ci, li, ai,C[ci]->L[li].u[ai].mcinf.val,1); 
		//	treeprint(ci,li);
            }
		
        return 0;
        }
    } /* changet2 */ 

#define MAXURCHECK 100  /* not sure how difficult it will be to find random ratios that fit the priors */

/* changeu picks new values on a log scale over a very wide range
the recorded range is set in IMn1.c to be 1/1000 -1000  (i.e. over a
1,000,000 fold range.  However the actual range is set to be much greater
This effectively sets the range to be infinite, and causes mutation rates to be picked without a prior.
By setting the actual range to be very wide, the prior probability within the range of 1/1000 -1000 becomes flat */

int changeu(int ci, int j, int *k)
	{
    /* update the ratio between two mutation rate scalars .  The upate is drawn from a uniform log scale between 1/maxratio and maxratio 
	maxratio is set to be 3 times the maximum value of the individual scalars*/
    double U, newr, weight, olduj,olduk;
    double newlike[2], newkappa[2], likenewsum;
    double d, r;
    int i, li,lj, lk, ai, aj,ak;
    static int start = 0;
	static double windowsize, maxratio;
	double tempr;
	int urcheck, counturcheck, uindex;
#ifdef _DEBUG
	double prodcheck;
#endif 
    /* windowsize and maxratio are on log scales 
	 all mutation rate scalars have the same priors and windowsize */

     if (start == 0) 
		{
		maxratio = 3*C[0]->L[0].u[0].mcinf.pr.max;
		if (modeloptions[MUTATIONPRIORRANGE])
			windowsize = C[0]->L[0].u[0].mcinf.pr.max;
		else
			windowsize = C[0]->L[0].u[0].mcinf.win;
        start = 1;
        }

#ifdef _DEBUG
	for (prodcheck = 1, ai = 0; ai < nurates; ai++)
		{
		prodcheck *= C[ci]->L[ul[ai].l].u[ul[ai].u].mcinf.val;
		}
	myassert(prodcheck < 1.00001 && prodcheck > 0.99999);
#endif
    if (nurates > 2)
        do {
            *k = (int) (uniform() * nurates);
            }
        while (*k == j || *k < 0 || *k >=nurates);
    else 
        {
        myassert(j==0);
        *k = 1;
        }
    lj = ul[j].l;
	aj = ul[j].u;
	lk = ul[*k].l;
	ak = ul[*k].u;
    myassert(*k != j);
	olduj = C[ci]->L[lj].u[aj].mcinf.val;
	olduk = C[ci]->L[lk].u[ak].mcinf.val;
    r = log(olduj/olduk);
	if (modeloptions[MUTATIONPRIORRANGE])
		{
		counturcheck = 0;
		do
			{
			if (counturcheck >= MAXURCHECK)
				return -1;
			U = uniform();
			if (U > 0.5)
				newr = r + (2.0*U-1.0)*windowsize;
			else
				newr = r - windowsize*U*2.0;
			if (newr > maxratio)
				newr = 2.0*maxratio - newr;
			else if (newr < -maxratio)
				newr = 2.0*(-maxratio) - newr; 
			d = exp((newr - r)/2);

			/* urri[i][j] has a 0 if neither i nor j has a prior. 1 if i has a prior and j does not,  -1 if i does not have a pior and j does  */
			/* must check if the new rates will cause the ratios among scalars to fall outside of the allowed ranges of ratios  */
			/* if they do, then they are rejected */
			urcheck = 0;
			counturcheck++;
			if (urri[j][*k] == 2)  // both scalars have priors 
				{
				urcheck = (newr <= urrlow[j][*k] || newr >= urrhi[j][*k]);
				for (uindex = 0; uindex < nurates; uindex++)
					{
					if (urri[j][uindex] == 2 && uindex != *k)
						{
						tempr = log(d*C[ci]->L[lj].u[aj].mcinf.val / C[ci]->L[ul[uindex].l].u[ul[uindex].u].mcinf.val);
						urcheck = urcheck || (tempr <= urrlow[j][uindex] || tempr >= urrhi[j][uindex]);
						}
					if (urcheck)
						break;
					}
				for (uindex = 0; uindex < nurates; uindex++)
						{
						if (urri[uindex][*k] == 2 && uindex != j)
							{
							tempr = log(C[ci]->L[ul[uindex].l].u[ul[uindex].u].mcinf.val / (C[ci]->L[lk].u[ak].mcinf.val/d));
							urcheck = urcheck || (tempr <= urrlow[uindex][*k] || tempr >= urrhi[uindex][*k]);
							}
						if (urcheck)
							break;
						}
				}
			else
				{
				if (urri[j][*k] == 1)  // the uj scalar has a prior, but not the uk scalar
					{
					for (uindex = 0; uindex < nurates; uindex++)
						{
						if (urri[j][uindex] == 2)
							{
							tempr = log(d*C[ci]->L[lj].u[aj].mcinf.val / C[ci]->L[ul[uindex].l].u[ul[uindex].u].mcinf.val);
							urcheck = urcheck || (tempr <= urrlow[j][uindex] || tempr >= urrhi[j][uindex]);
							}
						if (urcheck)
							break;
						}
					}
				if (urri[j][*k] == -1) // the uk scalar has a prior, but not the uj scalar
					{
					for (uindex = 0; uindex < nurates; uindex++)
						{
						if (urri[uindex][*k] == 2)
							{
							tempr = log(C[ci]->L[ul[uindex].l].u[ul[uindex].u].mcinf.val / (C[ci]->L[lk].u[ak].mcinf.val/d));
							urcheck = urcheck || (tempr <= urrlow[uindex][*k] || tempr >= urrhi[uindex][*k]);
							}
						if (urcheck)
							break;
						}
					}
				}
			}
		while (urcheck);
		}
	else
		{
		U = uniform();
		if (U > 0.5)
			newr = r + (2.0*U-1.0)*windowsize;
		else
			newr = r - windowsize*U*2.0;
		if (newr > maxratio)
			newr = 2.0*maxratio - newr;
		else if (newr < -maxratio)
			newr = 2.0*(-maxratio) - newr; 
		d = exp((newr - r)/2);
		}
    
	C[ci]->L[lj].u[aj].mcinf.val *= d;
	C[ci]->L[lk].u[ak].mcinf.val /= d;

	likenewsum = 0;
	for (i=0;i<2;i++)
		{
		if (i==0)
			{
			li = lj; ai = aj;
			}
		else
			{
			li = lk; ai = ak;
			}
        switch(C[ci]->L[li].u[ai].umodel)
            {
            case HKY:
                    U = uniform();
                    if (U > 0.5)
                        {
                        newkappa[i] = C[ci]->L[li].kappa.val + (2.0*U-1.0)* C[ci]->L[li].kappa.win;
                        if (newkappa[i] > C[ci]->L[li].kappa.pr.max)
                            newkappa[i] = 2.0 * C[ci]->L[li].kappa.pr.max - newkappa[i];
                        }
                    else
                        {
                        newkappa[i] = C[ci]->L[li].kappa.val - C[ci]->L[li].kappa.win *U*2.0;
                        if (newkappa[i] < 0)
                            newkappa[i] = - newkappa[i];
                        }
					if (ci==0)
						C[ci]->L[li].kappa.upinf->tries++;
                    newlike[i] = likelihoodHKY(ci, li, C[ci]->L[li].u[ai].mcinf.val, newkappa[i], -1, -1, -1, -1);
                    break;
            case INFINITESITES:
                   newlike[i] = likelihoodIS(ci, li, C[ci]->L[li].u[ai].mcinf.val); 
                   break;
            case STEPWISE :
					newlike[i] = likelihoodSW(ci, li, ai,C[ci]->L[li].u[ai].mcinf.val,1); 
                  break;
            }
		likenewsum += newlike[i] -  C[ci]->L[li].oldlike[ai]; 
		}
    weight = exp(beta[ci]*likenewsum);
    U = uniform();
	if (weight >= 1.0 || weight > U)
        {
		for (i=0;i<2;i++)
			{
			if (i==0)
				{
				li = lj; ai = aj;
				}
			else
				{
				li = lk; ai = ak;
				}
			C[ci]->L[li].oldlike[ai] = newlike[i];
			if (C[ci]->L[li].u[ai].umodel==HKY)
                {
				myassert(ai == 0);
                C[ci]->L[li].kappa.val = newkappa[i];
				if (ci==0)
					C[ci]->L[li].kappa.upinf->accp++;
                copyfraclike(ci, li);
				storescalefactors(ci, li);
                }
			}
		C[ci]->jointtreeinfo[pdg] += likenewsum;
#ifdef _DEBUG
		for (prodcheck = 1, ai = 0; ai < nurates; ai++)
			{
			prodcheck *= C[ci]->L[ul[ai].l].u[ul[ai].u].mcinf.val;
			}
		myassert(prodcheck < 1.00001 && prodcheck > 0.99999);
#endif
		return 1;
        }
	else 
        {
		C[ci]->L[lj].u[aj].mcinf.val = olduj;
		C[ci]->L[lk].u[ak].mcinf.val = olduk;
		if (C[ci]->L[lj].u[aj].umodel==HKY)
			restorescalefactors(ci, lj);
		if (C[ci]->L[lk].u[ak].umodel==HKY)
			restorescalefactors(ci, lk);
        if (C[ci]->L[lj].u[aj].umodel==STEPWISE)
			C[ci]->L[lj].oldlike[aj] = likelihoodSW(ci,lj, aj,olduj,1);
		if (C[ci]->L[lk].u[ak].umodel==STEPWISE)
			C[ci]->L[lk].oldlike[ak] = likelihoodSW(ci,lk, ak,olduk,1);
#ifdef _DEBUG
		for (prodcheck = 1, ai = 0; ai < nurates; ai++)
			{
			prodcheck *= C[ci]->L[ul[ai].l].u[ul[ai].u].mcinf.val;
			}

		myassert(prodcheck < 1.00001 && prodcheck > 0.99999);
#endif
        return 0;
        }
    }  /* changeu */


/* only use for HKY model with single locus data sets, otherwise kappa is updated in changeu */
int changekappa(int ci)
	{
	int li;
	double U, weight,newlike, newkappa;

	li = 0;
    U = uniform();
	C[ci]->L[li].kappa.upinf->tries++;
    if (U > 0.5)
        {
        newkappa = C[ci]->L[li].kappa.val + (2.0*U-1.0)* C[ci]->L[li].kappa.win;
        if (newkappa > C[ci]->L[li].kappa.pr.max)
            newkappa = 2.0 * C[ci]->L[li].kappa.pr.max - newkappa;
        }
    else
        {
        newkappa = C[ci]->L[li].kappa.val - C[ci]->L[li].kappa.win *U*2.0;
        if (newkappa < 0)
            newkappa = - newkappa;
        }
    newlike = likelihoodHKY(ci, li, C[ci]->L[li].u[0].mcinf.val, newkappa, -1, -1, -1, -1);

	weight = newlike -  C[ci]->L[li].oldlike[0]; 
    weight = exp(beta[ci]*weight);
    U = uniform();
	if (weight >= 1.0 || weight > U)
		{
		C[ci]->L[li].oldlike[0] = newlike;
		C[ci]->L[li].kappa.val=newkappa;
		C[ci]->L[li].kappa.upinf->accp++;
		copyfraclike(ci,li);
		storescalefactors(ci, li);
		return(1);
		}
	else
		{
	   restorescalefactors(ci, li);
	   return(0);
		}
	} /* changekappa */

/* works like changeu */
int changeh(int ci, int li)
	{
    double U, newr, weight, oldhi, oldhj;
    double oldprob, tpw;
    double d, r, logoldh, lognewh;
    int i,j, lj;
    static int start = 0;
	static double windowsize, maxratio;
	double holdintegrateterms[5];
#ifdef _DEBUG
	double prodcheck;
#endif 

    if (start == 0)
        {
		maxratio = 2* C[0]->L[0].h.pr.max;
		windowsize = C[0]->L[0].h.win;
        start = 1;
        }
    if (nloci > 2)
        do {
            lj = (int) (uniform() * nloci);
            }
        while (lj == li || lj < 0 || lj >=nloci);
    else 
        {
        myassert(li==0);
        lj = 1;
        }

    oldhi = C[ci]->L[li].h.val;
    oldhj = C[ci]->L[lj].h.val;
    r = log(oldhi/oldhj);

    U = uniform();
	if (U > 0.5)
		newr = r + (2.0*U-1.0)*windowsize;
	else
		newr = r - windowsize*U*2.0;
	if (newr > maxratio)
		newr = 2.0*maxratio - newr;
	else if (newr < -maxratio)
		newr = 2.0*(-maxratio) - newr; 
    d = exp((newr - r)/2);
    C[ci]->L[li].h.val *= d;
    C[ci]->L[lj].h.val /= d;
	lognewh = log(C[ci]->L[li].h.val);
	logoldh = log(oldhi);
	for (i = 0; i<= 2; i++)
		C[ci]->hterms[i] += C[ci]->L[li].treeinfo[i]* (lognewh - logoldh);
	lognewh = log(C[ci]->L[lj].h.val);
	logoldh = log(oldhj);
	for (i = 0; i<= 2; i++)
		C[ci]->hterms[i] += C[ci]->L[lj].treeinfo[i]* (lognewh - logoldh);
	for (i = fc1; i<= fca; i++)
		{
		C[ci]->jointtreeinfo[i] += C[ci]->L[li].treeinfo[i]*(oldhi/C[ci]->L[li].h.val  - 1.0);
		myassert(C[ci]->jointtreeinfo[i] >= 0);
		C[ci]->jointtreeinfo[i] += C[ci]->L[lj].treeinfo[i]*(oldhj/C[ci]->L[lj].h.val  - 1.0);
		myassert(C[ci]->jointtreeinfo[i] >= 0);
		}
	for (i = q1k, j=0; i<= m2k; i++, j++)
		holdintegrateterms[j] = C[ci]->jointtreeinfo[i];
	oldprob =  C[ci]->jointtreeinfo[prob];
	tpw = - oldprob;
    tpw += integrate_tree_prob(ci, &C[ci]->jointtreeinfo[0]);

	/*  update criterion is the product of new genealogy probilites divided by the product of old genealogy probabilities */
	weight = exp(beta[ci]*tpw);
    U = uniform();
	if (weight >= 1.0 || weight > U)
        {
		for (i = fc1; i<= fca; i++)
			{
			C[ci]->L[li].treeinfo[i] *= oldhi/C[ci]->L[li].h.val;
			C[ci]->L[lj].treeinfo[i] *= oldhj/C[ci]->L[lj].h.val;
			}
#ifdef _DEBUG
	for (prodcheck = 1, lj = 0; lj < nloci; lj++)
		{
		prodcheck *= C[ci]->L[lj].h.val;
		}
	myassert(prodcheck < 1.00001 && prodcheck > 0.99999);
#endif
		return 1;
        }
	else 
        {
		for (i = fc1; i<= fca; i++)
			{
			C[ci]->jointtreeinfo[i] += C[ci]->L[li].treeinfo[i]*(1.0 - oldhi/C[ci]->L[li].h.val);
			myassert(C[ci]->jointtreeinfo[i] >= 0);
			C[ci]->jointtreeinfo[i] += C[ci]->L[lj].treeinfo[i]*(1.0 - oldhj/C[ci]->L[lj].h.val);
			myassert(C[ci]->jointtreeinfo[i] >= 0);
			}
		lognewh = log(C[ci]->L[li].h.val);
		logoldh = log(oldhi);
		for (i = 0; i<= 2; i++)
			C[ci]->hterms[i] += C[ci]->L[li].treeinfo[i]* (logoldh - lognewh);
		lognewh = log(C[ci]->L[lj].h.val);
		logoldh = log(oldhj);
		for (i = 0; i<= 2; i++)
			C[ci]->hterms[i] += C[ci]->L[lj].treeinfo[i]* (logoldh - lognewh);
		C[ci]->jointtreeinfo[prob] = oldprob;
		for (i = q1k, j=0; i<= m2k; i++, j++)
			C[ci]->jointtreeinfo[i] = holdintegrateterms[j];
		C[ci]->L[li].h.val = oldhi;
		C[ci]->L[lj].h.val = oldhj;

        return 0;
        }
    }  /* changeh */

