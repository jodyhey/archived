/* IMa   for IM_analytic    2007-2009  Jody Hey and Rasmus Nielsen*/ 
/* December 17, 2009 */


#undef GLOBVARS
#include "ima.h"


/* read in the data */

/*** LOCAL STUFF *****/

int infilelines; //* could be passed to readseq funcs

/* prototypes of local functions*/
int numvar(int ci, int li);
int findsegsites(FILE *infile, int ci, int li, int numbases, int initseg[], int *pop1seg, int *pop2seg, int MODEL);
void elimfrom(int ci,int li, int site);
int seqid(int ci, int li, int i, int j);
void sortseq(int ci,int li);
void eliminategaps(int ci,int li);
void readseqHKY(FILE *infile, int ci,  int li);
void readseqIS(FILE *infile, int ci, int li, int MODEL);
void readseqSW(FILE *infile, int ci, int li);
void readdata(FILE *infile,int fpstri, char fpstr[]);
void setinitialQ(void);
void initmcparam(int ci, struct mc_param *mcp0, struct mc_param *mcp);
void initupdate(int ci, struct update_rate_calc  **upd0, struct update_rate_calc  **upd);
void initxy(int ci, struct plotpoint **xy0, struct plotpoint  **xy);

int numvar(int ci, int li)
    {
    int i, j, tot=0;

    for (i=0; i<C[ci]->L[li].numsites; i++)
        {
        j=1;
        while (j<C[ci]->L[li].numgenes && C[ci]->L[li].seq[0][i]==C[ci]->L[li].seq[j][i])
            j++;
        if (j<C[ci]->L[li].numgenes)
            tot++;
        }
    return tot;
    }


int findsegsites(FILE *infile,  int ci, int li, int numbases, int initseg[], int *pop1seg, int *pop2seg, int MODEL)
/* jh modified this to find sites that cannot be used 
  suitable base values are A,a,C,c,G,g,T,t  other things cause the site to be ignored 
 also  added counting of sites for both populations */
    {
    char c, *zeroc, *altc, *zeroc1, *zeroc2, *altc1, *altc2;
    int i, j, k, v, ai,totseg = 0, A;
	int *initseg1, *initseg2;
	
    zeroc = malloc(numbases*(sizeof(char)));
    altc = malloc(numbases*(sizeof(char)));
	zeroc1 = malloc(numbases*(sizeof(char)));
    altc1 = malloc(numbases*(sizeof(char)));
	zeroc2 = malloc(numbases*(sizeof(char)));
    altc2 = malloc(numbases*(sizeof(char)));
	initseg1 = malloc(numbases*(sizeof(int)));
	initseg2 = malloc(numbases*(sizeof(int)));
	*pop1seg = 0;
	*pop2seg = 0;
	for (k=0; k< C[ci]->L[li].numbases; k++)
	    {
	    C[ci]->L[li].badsite[k] = 0;
	    initseg[k] = initseg1[k] = initseg2[k]  = 0;

	    }
    for (i=0; i<C[ci]->L[li].numgenes; i++)
  	    {
	    for (v=0; v<10; v++)
		    { /*assumes that the first sequence of 10 characters that does not contain a carriage return is the species name*/
		    if ((char)  fgetc(infile) == '\n')
			    v = 0;
		    }
        if (MODEL==JOINT_IS_SW) // just read through these
        //    {
          //  fscanf(infile,"%d",&A);  this can't handle more than 1 STR
            //}  
        	for (ai =1; ai < C[ci]->L[li].nlinked; ai++)
			  {
			  fscanf(infile,"%d",&A);
			  }
	    j=0;
		while ((c= (char) tolower(( fgetc(infile))))!='\n' && j < C[ci]->L[li].numbases)
		    {
		    if (c != ' ')
			    {
    	        if (i==0)
				    {
				    zeroc[j] = c;
				    altc[j] = ' ';
				    if ((c != 'a' && c != 'c') && (c != 't' && c != 'g'))
					    C[ci]->L[li].badsite[j] = 1;
				    }
			    else 
				    {
				    if ((c != 'a' && c != 'c') && (c != 't' && c != 'g'))
					    C[ci]->L[li].badsite[j] = 1;
				    if (C[ci]->L[li].badsite[j]==0 && c != zeroc[j] )
					    {
					    if (altc[j] == ' ')
						    altc[j] = c;
					    else
						    {
						    if (c != altc[j])
							    C[ci]->L[li].badsite[j]=1;
						    }
    	        	    initseg[j] = 1;
					    }
				    }
				if (i==0)
				    {
				    zeroc1[j] = c;
				    altc1[j] = ' ';
				    }
			    if (i > 0 && i < C[ci]->L[li].numpop1)
				    {
				    if (C[ci]->L[li].badsite[j]==0 && c != zeroc1[j] )
					    {
					    if (altc1[j] == ' ')
						    altc1[j] = c;
    	        	    initseg1[j] = 1;
					    }
				    }
				if (i==C[ci]->L[li].numpop1)
				    {
				    zeroc2[j] = c;
				    altc2[j] = ' ';
				    }
			    if (i > C[ci]->L[li].numpop1 && i < C[ci]->L[li].numgenes)
				    {
				    if (C[ci]->L[li].badsite[j]==0 && c != zeroc2[j] )
					    {
					    if (altc2[j] == ' ')
						    altc2[j] = c;
    	        	    initseg2[j] = 1;
					    }
				    }
    	        j++;
			    }
  		    }
  	    }
     for (i=0; i<numbases; i++)
 	    {
	    if (C[ci]->L[li].badsite[i] ==1)
			{
			initseg[i] = 0;
			initseg1[i] = 0;
			initseg2[i] = 0;
			}
 	    if (initseg[i] == 1)
 		    totseg++;
		if (initseg1[i] == 1)
 		    *pop1seg = *pop1seg + 1;
		if (initseg2[i] == 1)
 		    *pop2seg = *pop2seg + 1;
 	    }
    //f_close(infile);
    free(zeroc);
    free(altc);
	free(zeroc1);
    free(altc1);
	free(zeroc2);
    free(altc2);
	free(initseg1);
    free(initseg2);
    return totseg;
    } /* findsegsites */


void elimfrom( int ci, int li, int site)
    {
    int i, j;

    for (i=0; i<C[ci]->L[li].numgenes; i++)
            {
            for (j=site; j<C[ci]->L[li].numsites-1; j++)
                    C[ci]->L[li].seq[i][j] = C[ci]->L[li].seq[i][j+1];
            }
    }

int seqid( int ci, int li, int i, int j)
    {
    int n;
    for (n=0; n<C[ci]->L[li].numgenes; n++)
            {
            if (C[ci]->L[li].seq[n][i] != C[ci]->L[li].seq[n][j])
                    return 0;
            }
    return 1;
    }

void sortseq(int ci,  int li)
	{
	int i, j;

	C[ci]->L[li].mult = malloc((C[ci]->L[li].numsites)*(sizeof(int)));
	for (i=0; i<C[ci]->L[li].numsites; i++)
		C[ci]->L[li].mult[i] = 1;
	for (i=0; i<C[ci]->L[li].numsites; i++)
		{
		for (j=i+1; j<C[ci]->L[li].numsites; j++)
			{
			/*printf("compares codon %i and %i\n",i+1,j+1);*/
			if (seqid(ci, li,i,j) == 1)
				{
			/*	printf("eliminates codon %i\n",j+1);*/
				elimfrom(ci, li,j);
				j--;
				C[ci]->L[li].numsites--;
				C[ci]->L[li].mult[i]++;
				}
			}
		}
	}

void eliminategaps(int ci,  int li)
    {
    int i, j;

    for (i=0; i<C[ci]->L[li].numsites; i++){
           for (j=0; j<C[ci]->L[li].numgenes; j++){
                    if (C[ci]->L[li].seq[j][i]==-1){
                            elimfrom(ci, li,i);
                            i--;
                            C[ci]->L[li].numsites--;
                            }
                    }
           }
	if (ci == 0)
		printf("Locus %i: HKY  model %i sites after elimination of gaps \n",li,C[ci]->L[li].numsites);
    }


void readseqHKY(FILE *infile, int ci,  int li)
    {
	int i,j,v,k=0;
	char c;
	double PIstandard;

	C[ci]->L[li].u[0].umodel = HKY;
    C[ci]->L[li].numsites = C[ci]->L[li].numbases;
	C[ci]->L[li].seq = malloc(C[ci]->L[li].numgenes*(sizeof(int *)));
	for (i=0; i<C[ci]->L[li].numgenes; i++)
                C[ci]->L[li].seq[i]=malloc(C[ci]->L[li].numsites*(sizeof(int)));
        for (i=0; i<4; i++)
                C[ci]->L[li].pi[i]=0.0;
	do
		{
		for (i=0; i<C[ci]->L[li].numgenes; i++){
			for (v=0; v<10; v++)
				{ /*assumes that the first sequence of 10 characters that does not contain a carriage return is the species name*/
				if ((c=(char)  fgetc(infile)) == '\n')
					v = 0;
				}
		   j=k;
		   while ((c= (char) fgetc(infile))!='\n')
				{
				if ((c!=' ')&&(c!='\t'))
					{
					if (i>=C[ci]->L[li].numgenes||j>=C[ci]->L[li].numsites)
						{
						/*ERROR READING DATA */ 
						err(ci, li,41);
						}
					if (c=='a' || c=='A')
						{
						C[ci]->L[li].seq[i][j] = 0;
						C[ci]->L[li].pi[0]++;
						}
					else 
						if (c=='c'||c=='C')
							{
 							C[ci]->L[li].seq[i][j] = 1;
							C[ci]->L[li].pi[1]++;
							}
						else 
							if (c=='g'||c=='G')
								{
 								C[ci]->L[li].seq[i][j] = 2;
								C[ci]->L[li].pi[2]++;;
								}
							else 
								if (c=='t' || c=='u' || c=='T' || c== 'U')
									{
									C[ci]->L[li].seq[i][j] = 3;
									C[ci]->L[li].pi[3]++;
									}
								else 
									if (c=='n' || c=='-' || c=='N' || c=='.')
										C[ci]->L[li].seq[i][j] = -1;
									else
										{ 
										printf("\nBAD BASE in species %i base %i: %c",i+1,j+1,c);       
										scanf("%i",&i);
										err(ci, li,42);
										}
					j++;
					if (i==(C[ci]->L[li].numgenes-1)) k++;
					}
				}
		   }
		}
	while (k<C[ci]->L[li].numsites);
        if (C[ci]->L[li].numpop1+C[ci]->L[li].numpop2 != C[ci]->L[li].numgenes)
	        err(ci, li,84);
    eliminategaps(ci, li);
    C[ci]->L[li].totsites=C[ci]->L[li].numsites;
	sortseq(ci, li);
    C[ci]->L[li].numlines = 2*C[ci]->L[li].numgenes-1;
	PIstandard = 0.0;
    for (i=0; i<4; i++)
        PIstandard+=C[ci]->L[li].pi[i];
    for (i=0; i<4; i++)
        {
        C[ci]->L[li].pi[i]=C[ci]->L[li].pi[i]/PIstandard;
        /*C[ci]->L[li].pi[i]=0.25; JC only*/
        }
    infilelines += C[ci]->L[li].numgenes;
    } /* readseqHKY */

void readseqIS(FILE *infile, int ci, int li, int MODEL)
    {
    int i, j, ai, v, k, sitek, sitej;
    int  *initseg;
    char c, *refseq;
    int numinvar;

	C[ci]->L[li].u[0].umodel = INFINITESITES;
    initseg = malloc(C[ci]->L[li].numbases*(sizeof(int)));
    C[ci]->L[li].badsite = malloc(C[ci]->L[li].numbases*(sizeof(int)));
    for (i=0; i<C[ci]->L[li].numbases; i++)
	    initseg[i] = 0;
    if (C[ci]->L[li].numbases > 0)
	    {
	    C[ci]->L[li].numsites = findsegsites(infile, ci, li,C[ci]->L[li].numbases, initseg, &C[ci]->L[li].pop1sites,&C[ci]->L[li].pop2sites,MODEL);
        if (C[ci]->L[li].model == INFINITESITES && ci == 0)
	        printf("Locus %i : Infinite Sites model, %i sites are segregating\n",li,C[ci]->L[li].numsites);
        if (C[ci]->L[li].model == JOINT_IS_SW && ci == 0)
	        printf("Locus %i : Joint Infinite Sites/Stepwise model, %i sites are segregating\n",li,C[ci]->L[li].numsites);
		rewind(infile);
	    /*if (NULL==(infile=fopen(infilename,"r")))
            {
  	        err(ci,-1,1);
            } */
	    for (i=0;i< infilelines;i++)
		    while ((c=((char)  fgetc(infile)))!='\n' );
  	    }

    else C[ci]->L[li].numsites = 0;
    numinvar = C[ci]->L[li].numbases - C[ci]->L[li].numsites;
    C[ci]->L[li].numlines = 2*C[ci]->L[li].numgenes-1;
    refseq = malloc(C[ci]->L[li].numbases*(sizeof(char)));
    C[ci]->L[li].seq=malloc(C[ci]->L[li].numgenes*(sizeof(int *))); 
    for (i=0; i<C[ci]->L[li].numgenes; i++)
	    C[ci]->L[li].seq[i]=malloc((C[ci]->L[li].numsites)*(sizeof(int)));
	if (MODEL==JOINT_IS_SW)
		for (ai =1; ai < C[ci]->L[li].nlinked; ai++)
			{
			if (ci == 0)
				C[ci]->L[li].u[ai].Aupinf = calloc(1, sizeof(struct update_rate_calc));
			else
				C[ci]->L[li].u[ai].Aupinf = C[0]->L[li].u[ai].Aupinf;
			}

    if (C[ci]->L[li].numbases > 0)
        {
        k = 0;
        sitek = 0;
        do{
	        for (i=0; i<C[ci]->L[li].numgenes; i++)
  		        {
		        for (v=0; v<10; v++)
			        { /*assumes that the first sequence of 10 characters that does not contain a carriage return is the species name*/
			        if ((c = (char)  fgetc(infile)) == '\n')
				        v = 0;
			        }
                if (MODEL==JOINT_IS_SW)
                    {
					C[ci]->L[li].tree[i].A = calloc(C[ci]->L[li].nlinked, sizeof(int));
					C[ci]->L[li].tree[i].dlikeA = calloc(C[ci]->L[li].nlinked, sizeof(double));
					for (ai =1; ai < C[ci]->L[li].nlinked; ai++)
						{
						C[ci]->L[li].u[ai].umodel = STEPWISE;
						fscanf(infile,"%d",&C[ci]->L[li].tree[i].A[ai]);
						}
                    }
		        j = k;
		        sitej = sitek;
		        while ((c= (char) tolower(( fgetc(infile))))!='\n'  && j < C[ci]->L[li].numbases)
			        {
                    if (isdigit(c))
                        err(ci, li,80);
			        if (c != ' ')
    	      	        {
    	      	        if (initseg[j] == 1)
					        {
					        if (i==0)
    		       		        {
    		       		        refseq[j] = c;
    		       		        C[ci]->L[li].seq[0][sitej] = 0;
    		           	        }
    		                else if (c == refseq[j])
    		        	        {
						        C[ci]->L[li].seq[i][sitej] = 0;
						        }
    		                else
    		        	        {
    		        	         C[ci]->L[li].seq[i][sitej] = 1;
    		        	         }
    		                sitej++;
    		   		        if (i==(C[ci]->L[li].numgenes-1)) sitek++;
    		                }
    		            j++;
    		   	        if (i==(C[ci]->L[li].numgenes-1)) k++;
				        }
  			        }
  		        }
          } while (k<C[ci]->L[li].numbases);
         }
    infilelines += C[ci]->L[li].numgenes;
    if (C[ci]->L[li].numpop1+C[ci]->L[li].numpop2 != C[ci]->L[li].numgenes)
	    err(ci, li,84);
    free(initseg);
    free(refseq);
    } /* readseqIS */

/* read in the allele sizes for a data set under the STEPWISE model */

void readseqSW(FILE *infile, int ci, int li)
    {
    int i, j, tempA,numA;
    char tempname[10], *c;
	char textline[301];

	for (i=0; i<C[ci]->L[li].numgenes; i++)
  		{
		c = &textline[0];
		fgets(c,300,infile);
		if (jheyoptions[SWINPUTOPTION])  // alernat input option  only works if there is only one SW portion
			{
			C[ci]->L[li].u[0].umodel = STEPWISE;
			myassert(C[ci]->L[li].nlinked == 1);
			if (ci == 0)
				C[ci]->L[li].u[0].Aupinf = calloc(1, sizeof(struct update_rate_calc));
			else
				C[ci]->L[li].u[0].Aupinf = C[0]->L[li].u[0].Aupinf;
			sscanf(c,"%s ",&tempname[0]);
			c = nextwhite(c);
			sscanf(c,"%d %d",&tempA,&numA);
			
			for (j=0; j<numA; j++)
				{
				C[ci]->L[li].tree[i+j].A = calloc(C[ci]->L[li].nlinked, sizeof(int));
				C[ci]->L[li].tree[i+j].dlikeA = calloc(C[ci]->L[li].nlinked, sizeof(double));
				C[ci]->L[li].tree[i+j].A[0] = tempA;
				}
			i += j-1;
			infilelines++;
			}
		else
			{
			C[ci]->L[li].tree[i].A = calloc(C[ci]->L[li].nlinked, sizeof(int));
			C[ci]->L[li].tree[i].dlikeA = calloc(C[ci]->L[li].nlinked, sizeof(double));
			sscanf(textline,"%s ",&tempname[0]);
			c = nextwhite(c);
			for (j =0 ;j < C[ci]->L[li].nlinked; j++)
				{
				if (ci == 0)
					C[ci]->L[li].u[j].Aupinf = calloc(1, sizeof(struct update_rate_calc));
				else
					C[ci]->L[li].u[j].Aupinf = C[0]->L[li].u[j].Aupinf;
				}
			for (j=0; j< C[ci]->L[li].nlinked; j++)
				{
				C[ci]->L[li].u[j].umodel = STEPWISE;
				sscanf(c,"%d",&(C[ci]->L[li].tree[i].A[j]));
				c = nextwhite(c);
				}
			infilelines++;;
			}
		}
	if (ci == 0)
		printf("Locus %i : Stepwise Mutation Model\n",li);
    } /* readseqSW */

void readdata(FILE *infile, int fpstri, char fpstr[])
	{
	/* reads through the data file nloci  times */
	/* first line is a comment*/
	/* any number of additional comments,  each line begins with '#' */
	/* names of two species,  species1 first, followed by species 2 */
	/* number of loci */
	/* for each locus */
	/* name, number of sequences in pop1, number of sequences in pop2, length of sequences , 
     H for HKY model 
     I for  infinite sites
     S  for stepwise model
     J  for joint infinite sites and stepwise
    inheritance scalar (1 or 0.75 or 0.25)*/
	char ch;
	int li, i,ci, uinext, ui;
    char c,*cc;
    int holdinfilelines;
	char textline[301];
	char popnames[2][NAMELENGTH];

	fgets(textline,300,infile);
	infilelines++;
	SP"\nText from input file: %s",textline);
    ch= (char)  getc(infile);
	while (ch =='#')
		{
		infilelines++;
		fgets(textline, 300, infile);
        SP"\nText from input file: %s",textline);
		ch= (char)  getc(infile);
		}
    ungetc(ch,infile);
	fscanf(infile,"%s %s \n",popnames[0],popnames[1]);
	fscanf(infile,"%d \n",&nloci);
    if (nloci < 1)
        {
        err(-1,-1,21);
        }
	infilelines+=2;
    SP"\n");
    SP"- Population Names - \n");
    SP"Population 1 : %s \n",popnames[0]);
    SP"Population 2 : %s \n",popnames[1]);
    SP"\n");
    SP"- Locus Information -\n");
    if (nloci==1) 
        modeloptions[UPDATEH]=0;
    if (modeloptions[UPDATEH])
        SP"Locus#\tLocusname\tsamplesize1\tsamplesize2\tModel\tMutationRatesPerYear\n");
    else
        SP"Locus#\tLocusname\tsamplesize1\tsamplesize2\tModel\tInheritanceScalar\tMutationRatesPerYear\n");
    holdinfilelines = infilelines;
    //f_close(infile);
    //infile = NULL;
	nurates = 0;
	countuprior = 0;
    for (ci=0;ci< numchains;ci++)
		C[ci]->L = calloc(nloci,sizeof(struct locus));
    for (ci=0;ci< numchains;ci++)
        {
        infilelines = holdinfilelines;
        //if (NULL==(infile=fopen(infilename,"r")))  err(ci,-1,1);
		rewind(infile);
	    for (i=0;i< infilelines;i++)   while ((c=((char)  fgetc(infile)))!='\n'); 
        if (numchains > 1)  printf("Loading Chain %i \n",ci);
		for (uinext = 0,li=0;li<nloci;li++)
		    {
            fgets(textline,300,infile);
			while  (( textline[strlen(textline)-1] == '\n')|| (textline[strlen(textline)-1] == ' ')) 
				textline[strlen(textline)-1] = '\0';
			cc = textline;
/* read in information from infile,  for chains > 0 only read data  */
			if (ci==0)
				{ 
				ui = uinext;
				C[ci]->L[li].nlinked = 0;
				sscanf(cc,"%s",C[ci]->L[li].name);
				cc = nextnonspace(cc);
				sscanf(cc,"%d",&C[ci]->L[li].numpop1);
				cc = nextnonspace(cc);
				sscanf(cc,"%d",&C[ci]->L[li].numpop2);
				cc = nextnonspace(cc);
				C[ci]->L[li].numgenes = C[ci]->L[li].numpop1 + C[ci]->L[li].numpop2;
				if (modeloptions[ONEPOP])
					{
					C[ci]->L[li].numpop1 += C[ci]->L[li].numpop2;
					C[ci]->L[li].numpop2 = 0;
					}
				C[ci]->L[li].numlines = 2*C[ci]->L[li].numgenes - 1;
				SP"%d\t%s\t%3d\t%3d",li,C[ci]->L[li].name,C[ci]->L[li].numpop1,C[ci]->L[li].numpop2);
				sscanf(cc,"%d",&C[ci]->L[li].numbases);
				cc = nextnonspace(cc);
				C[ci]->L[li].nlinked = 1;
				switch (toupper(cc[0])) 
					{
					case 'I' :C[ci]->L[li].model=INFINITESITES; SP"\tIS"); uinext = ui+1;  break;
					case 'H' :C[ci]->L[li].model=HKY; SP"\tHKY"); uinext = ui+1; break;
					case 'S' :C[ci]->L[li].model=STEPWISE;
								if (isdigit(cc[1]))
									{
									C[ci]->L[li].nlinked += atoi(&cc[1]) - 1;
									SP"\tSW_M");
									}
								else
									SP"\tSW");
								uinext = ui + C[ci]->L[li].nlinked;
								break;
					case 'J' :C[ci]->L[li].model=JOINT_IS_SW;
								if (isdigit(cc[1]))
									{
									C[ci]->L[li].nlinked += atoi(&cc[1]);
									SP"\tIS+SW_M");
									}
								else 
									{
									C[ci]->L[li].nlinked++;
									SP"\tIS+SW");
									}
								uinext = ui + C[ci]->L[li].nlinked;
								break;
					default: C[ci]->L[li].model=INFINITESITES;SP"\tIS");
					}
				C[ci]->L[li].u = calloc(C[ci]->L[li].nlinked, sizeof(struct u_mc_param));
				C[ci]->L[li].oldlike = calloc(C[ci]->L[li].nlinked, sizeof(double));
				cc = nextnonspace(cc);
				ui = 0;
				if (cc) // get mutation rate info from data line
					{
					sscanf(cc,"%lf",&(C[ci]->L[li].h.val));
					SP"\t%lf",C[ci]->L[li].h.val);
					cc = nextnonspace(cc);
					while (cc)
						{
						sscanf(cc,"%lf",&C[ci]->L[li].u[ui].uperyear.val);
						SP"\t%lg",C[ci]->L[li].u[ui].uperyear.val);
						cc = nextnonspace(cc);
						if (cc &&  cc[0] == '(') /* look for a mutation rate range in parentheses e.g. (0.03,0.05)  */
							{
							cc++;
							sscanf(cc,"%lf",&(C[ci]->L[li].u[ui].uperyear.pr.min));
							while (cc[0] != ',') cc++;
							cc++;
							sscanf(cc,"%lf",&(C[ci]->L[li].u[ui].uperyear.pr.max));
							while (cc[0] != ')') cc++;
							while (!isdigit(cc[0]) && cc[0] != '\0') cc++;
							if (cc[0] == '\0') 
								cc = NULL;
							if ( C[ci]->L[li].u[ui].uperyear.pr.min > C[ci]->L[li].u[ui].uperyear.pr.max || C[ci]->L[li].u[ui].uperyear.pr.min > C[ci]->L[li].u[ui].uperyear.val || C[ci]->L[li].u[ui].uperyear.pr.max < C[ci]->L[li].u[ui].uperyear.val)
								err(ci,li,79);
							SP"\t(%lg - %lg)",C[ci]->L[li].u[ui].uperyear.pr.min,C[ci]->L[li].u[ui].uperyear.pr.max);
							countuprior++;
							}
						ui++;
						}
					}
				else 
					{
					C[ci]->L[li].h.val = 1;
					SP"\t%lf",C[ci]->L[li].h.val);
					}
				SP"\n");
				nurates += C[ci]->L[li].nlinked;
                }
			else
				{
				C[ci]->L[li].model = C[0]->L[li].model;
				C[ci]->L[li].nlinked = C[0]->L[li].nlinked;
				strcpy(C[ci]->L[li].name,C[0]->L[li].name);
				C[ci]->L[li].numpop1 = C[0]->L[li].numpop1;
				C[ci]->L[li].numpop2 = C[0]->L[li].numpop2;
				C[ci]->L[li].numbases = C[0]->L[li].numbases;
				C[ci]->L[li].numgenes = C[0]->L[li].numgenes;
				C[ci]->L[li].numlines = C[0]->L[li].numlines;
				C[ci]->L[li].h.val = C[0]->L[li].h.val;
				C[ci]->L[li].u = calloc(C[ci]->L[li].nlinked, sizeof(struct u_mc_param));
				C[ci]->L[li].oldlike = calloc(C[ci]->L[li].nlinked, sizeof(double));
				for (ui = 0; ui < C[ci]->L[li].nlinked; ui++)
					C[ci]->L[li].u[ui] = C[0]->L[li].u[ui];
				} 
		    infilelines++;
			/* build genealogy */
			C[ci]->L[li].tree = calloc(C[ci]->L[li].numlines,(sizeof(struct edge)));
			for (i = 0; i < C[ci]->L[li].numlines; i++)
				{
				C[ci]->L[li].tree[i].mig = malloc(MIGINC * sizeof(double));
				C[ci]->L[li].tree[i].mig[0] = -1;
				C[ci]->L[li].tree[i].cmm = MIGINC;
				C[ci]->L[li].tree[i].up[0] = C[ci]->L[li].tree[i].up[0] = C[ci]->L[li].tree[i].down = -1;
				C[ci]->L[li].tree[i].time = 0;
				C[ci]->L[li].tree[i].mut = -1;
				C[ci]->L[li].tree[i].pop = -1;
				}
            switch(C[ci]->L[li].model) 
                {
                case INFINITESITES:readseqIS(infile,ci,li, INFINITESITES);break;
                case HKY: readseqHKY(infile,ci,li); break;
                case STEPWISE: readseqSW(infile,ci,li);break;
                case JOINT_IS_SW: readseqIS(infile,ci,li,JOINT_IS_SW);break;
		        }
			}
		if(ci==0 && modeloptions[MUTATIONPRIORRANGE])
			{
			SP" Use prior ranges on mutation rates specified in input file \n");
			if (countuprior <= 1)
				{
				SP" Less than 2 prior ranges given in input file,  mutation rate priors not used \n");
				modeloptions[MUTATIONPRIORRANGE] = 0;
				}
			}
		//f_close(infile);
        //infile = NULL;
		}
	} /* readdata */


void setinitialQ(void)
	{
	int i, j, li,ci, ui;
	double w, w2;
	double  sumq1, sumq2, temp, tempq1, tempq2;
    double uscale, hscale;
    /* some max values are from command line
    for Thetas, the range is set to watterson's estimate based on the entire data set
     initial parameter values are picked from a uniform distribution between the max and the min */
    /*if HKY model, then it is not known what would be a good theta value,  so a large scalar is used */
    /* for mutatation rates, max values also depend on the amount of variation that is found */

	/* set mutation rate scalars */
    tempq1 = 0;
    tempq2 = 0;
    sumq1 = sumq2 = 0;
	temp = 0;
	if (nurates == 1)  // only one single part locus 
		{
		li = 0;
		if (C[0]->L[li].u[0].umodel == INFINITESITES) 
			{
			for(j=1,w=0.0;j<C[0]->L[li].numpop1;j++)
				w += 1/(double) j;
			if (w==0) w = 1;
			sumq1 += tempq1 = (C[0]->L[li].pop1sites + 1) / w; 
			for(j=1,w=0.0;j<C[0]->L[li].numpop2;j++)
				w += 1/(double) j;
			if (w==0) w = 1;
			sumq2 += tempq2 = (C[0]->L[li].pop2sites + 1) / w; 
			}
		if (C[0]->L[0].u[0].umodel == HKY) 
			{
			for(j=1,w=0.0;j<C[0]->L[li].numgenes;j++)
				w += 1/(double) j;
			if (w==0) w = 1;
			sumq1 += tempq1 = numvar(0,li)/w;
			sumq2 += tempq2 = numvar(0,li)/w;
			}
		if (C[0]->L[0].u[0].umodel == STEPWISE) 
			{
			somestepwise=1;
			for(j=0,w=0,w2=0;j<C[0]->L[li].numpop1;j++)
				{
				w  += C[0]->L[li].tree[j].A[0];
				w2 += SQR( (double) C[0]->L[li].tree[j].A[0]);
				}
			tempq1 = (double) 2*(w2 - SQR(w)/C[0]->L[li].numpop1)/(C[0]->L[li].numpop1);
			if (tempq1 ==0) tempq1 = 10;
			sumq1  += tempq1;
			for(w=0,w2=0;j<C[0]->L[li].numgenes;j++)
				{
				w  += C[0]->L[li].tree[j].A[0];
				w2 += SQR((double) C[0]->L[li].tree[j].A[0]);
				}
			tempq2 =  2*(w2 - SQR(w)/C[0]->L[li].numpop2)/(C[0]->L[li].numpop2);
			if (tempq2 ==0) tempq2 = 10;
			sumq2 += tempq2;
			}
		}
	else
		{
		for (li = 0; li < nloci; li++)
			{
			if (C[0]->L[li].model == INFINITESITES || C[0]->L[li].model == JOINT_IS_SW) 
				{
				for(j=1,w=0.0;j<C[0]->L[li].numpop1;j++)
					w += 1/(double) j;
				if (w==0) w = 1;
				sumq1 += tempq1 = (C[0]->L[li].pop1sites + 1) / w; 
				for(j=1,w=0.0;j<C[0]->L[li].numpop2;j++)
					w += 1/(double) j;
				if (w==0) w = 1;
				sumq2 += tempq2 = (C[0]->L[li].pop2sites + 1) / w; 
				C[0]->L[li].u[0].mcinf.val = log(DMAX(0.0001,tempq1 + tempq2)); // avoid a zero
				temp += C[0]->L[li].u[0].mcinf.val ;
				}
			if (C[0]->L[li].model == HKY) 
				{
				for(j=1,w=0.0;j<C[0]->L[li].numgenes;j++)
					w += 1/(double) j;
				if (w==0) w = 1;
				sumq1 += tempq1 = numvar(0,li)/w;
				sumq2 += tempq2 = numvar(0,li)/w;
				C[0]->L[li].u[0].mcinf.val = log(DMAX(0.0001,tempq1 + tempq2)); // avoid a zero
				temp += C[0]->L[li].u[0].mcinf.val ;
				}
			if (C[0]->L[li].model == STEPWISE || C[0]->L[li].model == JOINT_IS_SW)
				{
				if (C[0]->L[li].model == JOINT_IS_SW) 
					ui = 1;
				else ui = 0;
				for (;ui < C[0]->L[li].nlinked; ui++)
					{
					somestepwise=1;
					for(j=0,w=0,w2=0;j<C[0]->L[li].numpop1;j++)
						{
						w  += C[0]->L[li].tree[j].A[ui];
						w2 += SQR((double) C[0]->L[li].tree[j].A[ui]);
						}
					tempq1 = 2*(w2 - SQR(w)/C[0]->L[li].numpop1)/(C[0]->L[li].numpop1);
					if (tempq1 ==0) tempq1 = 10;
					sumq1  += tempq1;
					for(w=0,w2=0;j<C[0]->L[li].numgenes;j++)
						{
						w  += C[0]->L[li].tree[j].A[ui];
						w2 += SQR( (double) C[0]->L[li].tree[j].A[ui]);
						}
					tempq2 = 2*(w2 - SQR(w)/C[0]->L[li].numpop2)/(C[0]->L[li].numpop2);
					if (tempq2 ==0) tempq2 = 10;
					sumq2 += tempq2;
					C[0]->L[li].u[ui].mcinf.val = log(DMAX(0.0001,tempq1 + tempq2)); // avoid a zero
					temp += C[0]->L[li].u[ui].mcinf.val;
					}
				}
			}
		}

	/*  setting iq  values */
    /* could remove this section and just have Qmax for thetas be set by the user  */
	if (!modeloptions[RETURNPRIOR] && modeloptions[POPSIZEPRIORSETMODE] ==0)
        {
        if (sumq2 > 0)
			iq[q2i].pr.max *=  sumq2/nurates;
        if (sumq1 > 0)
			iq[q1i].pr.max *=  sumq1/nurates;
        if (sumq1 > sumq2)
			iq[qai].pr.max *= sumq1/nurates;
        else 
			iq[qai].pr.max *=  sumq2/nurates;
        }
     
    if (modeloptions[EQUILIBRIUMMIGRATION])
        {
		iq[qai].pr.max = 1;
		if (iq[m1i].pr.max == 0 || iq[m2i].pr.max == 0)
            err(-1,-1,11);
        }
    if (modeloptions[ONEPOP])
        {
		iq[qai].pr.max = iq[q2i].pr.max = iq[q1i].pr.max;
        }
    if (modeloptions[ONEPOP])
		{
        paramprior = iq[qai].pr.max;
		calcoptions[FINDJOINTPEAK] = 0;
		}
    else
        {
        
        if (modeloptions[EQUILIBRIUMMIGRATION])
            paramprior = iq[q1i].pr.max* iq[q2i].pr.max;
        else
            paramprior = iq[q1i].pr.max * iq[q2i].pr.max * iq[qai].pr.max;
        if (iq[m1i].pr.max > 0)
           paramprior *= iq[m1i].pr.max * iq[m2i].pr.max ;
        }
    paramprior =  -log(paramprior);
	for (i=0; i<BASICPARAMS; i++)
		iq[i].integrate = 1;
	if (modeloptions[ONEPOP])
        iq[q2i].integrate  = iq[qai].integrate  =  iq[m1i].integrate  = iq[m2i].integrate  =  0;
    if (modeloptions[EQUILIBRIUMMIGRATION])
		iq[qai].integrate  =  0;
    if (iq[m1i].pr.max <= 0)
		iq[m1i].integrate  = iq[m2i].integrate  =  0;
	if (nurates > 1)
		{
		for (i = 0,li = 0; li < nloci; li++)
			for (ui = 0;ui < C[0]->L[li].nlinked; ui++)
			{
			C[0]->L[li].u[ui].mcinf.pr.max =  log(UMAX); // 10000
			C[0]->L[li].u[ui].mcinf.pr.min = -C[0]->L[li].u[ui].mcinf.pr.max;
			C[0]->L[li].u[ui].mcinf.win  = C[0]->L[li].u[ui].mcinf.pr.max/nloci;
			}
		setuinfo(temp);
		}
	else 
		C[0]->L[0].u[0].mcinf.val = 1.0;

	for (li=0;li<nloci;li++) 
		if (C[0]->L[li].model == HKY)
			{
			C[0]->L[li].kappa.val = 2.0;
			C[0]->L[li].kappa.pr.max = 100.0;
			C[0]->L[li].kappa.win = 2.0;
			}
	//C[0]->t.win = (C[0]->t.pr.max - C[0]->t.pr.min)/(5 + C[0]->t.win * nloci);
	C[0]->t.win = (C[0]->t.pr.max - C[0]->t.pr.min)/10.0;

	if (modeloptions[UPDATEH])
		{
		for (li=0;li<nloci;li++)
	        {
		    C[0]->L[li].h.pr.max = log(HMAX);
            C[0]->L[li].h.pr.min = -C[0]->L[li].h.pr.max;
		    C[0]->L[li].h.val =1; 
		    C[0]->L[li].h.win= C[0]->L[li].h.pr.max/5;
			multipleh = 1;
		    }
		}
	
    if (modeloptions[EQUILIBRIUMMIGRATION])
        {
		C[0]->t.val = TIMEMAX;
        }
	else  
		{
		if (modeloptions[ONEPOP])
			{
			C[0]->t.val = 0;
			}
		else  //* start t on the low side
			C[0]->t.val =  C[0]->t.pr.min + uniform()*(C[0]->t.pr.max - C[0]->t.pr.min)/2.0; 
		}
   
	/* copy stuff for the mc parameters from chain 0 to the other chains */
	for (ci=1; ci<numchains; ci++)
		{
		memcpy(&C[ci]->t,&C[0]->t,sizeof(struct mc_param));
		for (li=0;li<nloci;li++)
			{
			memcpy(C[ci]->L[li].u,C[0]->L[li].u,C[0]->L[li].nlinked * sizeof(struct u_mc_param));
			memcpy(&C[ci]->L[li].h,&C[0]->L[li].h,sizeof(struct mc_param));
			memcpy(&C[ci]->L[li].kappa,&C[0]->L[li].kappa,sizeof(struct mc_param));
			}
		}
    if (!modeloptions[ONEPOP] && !modeloptions[EQUILIBRIUMMIGRATION])
		for (ci=1; ci<numchains; ci++)
			C[ci]->t.val = uniform()*(C[ci]->t.pr.max - C[ci]->t.pr.min)/5.0 + C[ci]->t.pr.min; 

    /* these vectors are bins to contain counts of parameter values in each range 
    the vec vectors are the counts, the grid vectors are the boundaries of the bins*/
    /* one scale should be ok for all loci, because all have same max values of u and h */
	for (i = 0; i <= M2 ; i++)
		{
		iq[i].xy = calloc(gridsize, sizeof(struct plotpoint));
		}
	if (nurates > 1)
		uscale = (C[0]->L[0].u[0].mcinf.pr.max  - C[0]->L[0].u[0].mcinf.pr.min)/gridsize;
    if (modeloptions[UPDATEH])
		hscale = (C[0]->L[0].h.pr.max - C[0]->L[0].h.pr.min)/gridsize;
	
    for (i=0; i<gridsize; i++)
	    {
        if (nurates > 1)
            {
			temp = exp(C[0]->L[0].u[0].mcinf.pr.min + (i+0.5) * uscale);   // the same scale is used for all mutation rate scalars 
		    for (li=0;li<nloci;li++) 
				for (ui = 0;ui < C[0]->L[li].nlinked; ui++)
					{
					C[0]->L[li].u[ui].mcinf.xy[i].x = temp;
					}				
            if (modeloptions[UPDATEH])
				{
				hscale = (C[0]->L[0].h.pr.max - C[0]->L[0].h.pr.min)/gridsize;
				temp = exp(C[0]->L[0].h.pr.min + (i+0.5) * hscale);   // the same scale is used for all inheritance scalars
                for (li=0;li<nloci;li++) 
			        {
					C[0]->L[li].h.xy[i].x = temp;
			        }
				}
            }
	   for (li=0;li<nloci;li++) 
			if (C[0]->L[li].model == HKY)
				C[0]->L[li].kappa.xy[i].x =	C[0]->L[li].kappa.pr.min + ((i+0.5) * (	C[0]->L[li].kappa.pr.max - 	C[0]->L[li].kappa.pr.min)) / gridsize; 
		for (j = 0; j <= M2 ; j++)
			iq[j].xy[i].x = iq[j].pr.min + ((i+0.5) * (iq[j].pr.max - iq[j].pr.min)) / gridsize; 

		temp = C[0]->t.pr.min + ((i+0.5) * (C[0]->t.pr.max - C[0]->t.pr.min)) / gridsize;
		C[0]->t.xy[i].x = temp;
        if (printoptions[PRINTTMRCA])
            {
            for (li=0;li<nloci;li++) 
			    {
				C[0]->L[li].tmrcaxy[i].x = (i+0.5) * (10 + C[0]->t.pr.max )/gridsize ;
                }
            }
		if (printoptions[MIGRATEDIST])
            {
            /* set up histograms for number of migration events in each direction for each locus. Also the mean time of an event
            given that there was one or migration. For the mean time use the same time scale as t, so don't need a grid for this.
            For the # of events, just the index serves as the count so  don't need a grid for this*/
            for (li=0;li<nloci;li++) 
			    {
				C[0]->L[li].migtimexy[0][i].x = C[0]->L[li].migtimexy[1][i].x = temp;
				C[0]->L[li].migcountxy[0][i].x  = C[0]->L[li].migcountxy[1][i].x = i;
                }
            }
	    }	
	} /*setinitialQ */

void initmcparam(int ci, struct mc_param *mcp0, struct mc_param *mcp)
	{
	if (ci == 0)
		{
		mcp0->upinf  = calloc(1, sizeof(struct update_rate_calc));
		mcp0->xy = calloc(gridsize, sizeof(struct plotpoint));
		mcp0->trend = calloc(TRENDDIM, sizeof(double));
		mcp0->beforemin = calloc(1, sizeof(double));
		mcp0->aftermax = calloc(1, sizeof(double));
		}
	else
		{
		mcp->upinf = mcp0->upinf;
		mcp->xy = mcp0->xy;
		mcp->trend = mcp0->trend;
		mcp->beforemin = mcp0->beforemin; 
		mcp->aftermax = mcp0->aftermax;
		}
	}

void initupdate(int ci, struct update_rate_calc  **upd0, struct update_rate_calc  **upd)
	{
	if (ci == 0)
		*upd0 = calloc(1, sizeof(struct update_rate_calc));
	else
		*upd = *upd0;
	}

void initxy(int ci, struct plotpoint **xy0, struct plotpoint  **xy)
	{
	if (ci == 0)
		*xy0 = calloc(gridsize, sizeof(struct plotpoint));
	else
		*xy = *xy0;;
	}

/********** GLOBAL FUNCTIONS ***********/
#define log1000  6.9077553


void setupchains(char infilename[],int fpstri, char fpstr[], struct mc_param ttemp)
	{
	int ci, li, ui, i, ai;
	//double  tempprobg; 

//int *topolchange, *tmrcachange;  //debug

	FILE *infile;
	C = calloc(numchains,sizeof(struct chain *));  //points to an array of chains 
	for (ci = 0; ci< numchains;ci++)
		C[ci] = calloc(1,sizeof(struct chain));
	C[0]->t = ttemp;
	if ((infile = fopen(infilename,"r")) == NULL)
		{
		printf("Error opening text file for reading\n"); 
        err(-1,-1,1);
		} 
	readdata(infile, fpstri, fpstr);
	for (ci=0;ci< numchains;ci++) // allocate for recording values from mcmc 
        {
		initmcparam(ci,&(C[0]->t),&(C[ci]->t));
		strcpy(C[ci]->t.str,"t   ");
		for (li=0;li<nloci;li++)
			{
			initupdate(ci, &C[0]->L[li].gupdate,&C[ci]->L[li].gupdate);
			initupdate(ci, &C[0]->L[li].topolupdate,&C[ci]->L[li].topolupdate);
			initupdate(ci, &C[0]->L[li].tmrcaupdate,&C[ci]->L[li].tmrcaupdate);
			if (printoptions[MIGRATEDIST])
				{
				initxy(ci,&C[0]->L[li].migcountxy[0],&C[ci]->L[li].migcountxy[0]);
				initxy(ci,&C[0]->L[li].migcountxy[1],&C[ci]->L[li].migcountxy[1]);
				initxy(ci,&C[0]->L[li].migtimexy[0],&C[ci]->L[li].migtimexy[0]);
				initxy(ci,&C[0]->L[li].migtimexy[1],&C[ci]->L[li].migtimexy[1]);
				}
			if (printoptions[PRINTTMRCA])
				{
				initxy(ci,&C[0]->L[li].tmrcaxy,&C[ci]->L[li].tmrcaxy);
				}
			for (ui = 0; ui < C[ci]->L[li].nlinked; ui++)
				initmcparam(ci,&C[0]->L[li].u[ui].mcinf,&C[ci]->L[li].u[ui].mcinf);
			if (modeloptions[UPDATEH])
				initmcparam(ci,&C[0]->L[li].h,&C[ci]->L[li].h);
			if (C[ci]->L[li].model == HKY)
				initmcparam(ci,&C[0]->L[li].kappa,&C[ci]->L[li].kappa);
			}
		}
	strcpy(iq[q1i].str,"q1  ");
	strcpy(iq[q2i].str,"q2  ");
	strcpy(iq[qai].str,"qa  ");
	strcpy(iq[m1i].str,"m1  ");
	strcpy(iq[m2i].str,"m2  ");
	for (li = 0;li < nloci;li++)
		{
		if (C[0]->L[li].model == STEPWISE)
			for (ai = 0;ai < C[0]->L[li].nlinked; ai++)
				sprintf(C[0]->L[li].u[ai].mcinf.str,"%dSW%d",li,ai);
		else
			sprintf(C[0]->L[li].u[0].mcinf.str,"%du ",li);

		if (C[0]->L[li].model == JOINT_IS_SW)
			for (ai = 1;ai < C[0]->L[li].nlinked; ai++)
				sprintf(C[0]->L[li].u[ai].mcinf.str,"%dSW%d",li,ai);
		if (C[0]->L[li].model == HKY)
			sprintf(C[0]->L[li].kappa.str,"%d_Ka",li);
		if (modeloptions[UPDATEH])
			sprintf(C[0]->L[li].h.str,"%dh   ",li);
		}
	setinitialQ();
	ginit();
    for (ci = 0; ci < numchains; ci++)
        {
		for (i=0;i<tval;i++)
			C[ci]->jointtreeinfo[i] = 0;
	    for (li=0;li<nloci;li++) 
		    {
			C[ci]->L[li].oldlike = calloc(C[ci]->L[li].nlinked, sizeof(double));
            switch(C[ci]->L[li].model)
                {
                case INFINITESITES :
					/*resetseeds(123);
					C[ci]->t.val = 1;
                    makeIStreetemp(ci, li); 
					treeweight(ci, li, C[ci]->t.val);
					for (i=cc1;i<=fm2;i++)
						C[ci]->jointtreeinfo[i] += C[ci]->L[li].treeinfo[i];
					tempprobg = integrate_tree_prob(ci, &C[ci]->jointtreeinfo[0]);
					changet2(ci); 
					for (i=0;i<10;i++)
						{
						updategenealogy(ci,li,&topolchange, &tmrcachange);
						}  */


					makeIStree(ci,li);
					treeweight(ci, li, C[ci]->t.val);
                    C[ci]->L[li].oldlike[0] = likelihoodIS(ci, li, C[ci]->L[li].u[0].mcinf.val); 
					C[ci]->jointtreeinfo[pdg] += C[ci]->L[li].oldlike[0];
                    break;
                case HKY :
 			        makeHKYtree(ci, li);
					treeweight(ci, li, C[ci]->t.val);
			        C[ci]->L[li].oldlike[0] = likelihoodHKY(ci, li,C[ci]->L[li].u[0].mcinf.val, C[ci]->L[li].kappa.val, -1, -1, -1, -1);
					C[ci]->jointtreeinfo[pdg] += C[ci]->L[li].oldlike[0];
			        copyfraclike(ci,li);
					storescalefactors(ci,li);
                    break;
				case STEPWISE : 
					makeSWtree(ci,li); 
					treeweight(ci, li, C[ci]->t.val);
					for (ai = 0; ai < C[ci]->L[li].nlinked; ai++)
						{
						C[ci]->L[li].oldlike[ai] = likelihoodSW(ci,li, ai,C[ci]->L[li].u[ai].mcinf.val,1); 
						C[ci]->jointtreeinfo[pdg] += C[ci]->L[li].oldlike[ai];
						}
					break;
                case JOINT_IS_SW:
					//makeIStree(ci, li); 
					makeJOINT_IS_SWtree(ci, li); 
					treeweight(ci, li, C[ci]->t.val);
					C[ci]->L[li].oldlike[0] = likelihoodIS(ci, li, C[ci]->L[li].u[0].mcinf.val); 
					C[ci]->jointtreeinfo[pdg] += C[ci]->L[li].oldlike[0];
					for (ai = 1; ai < C[ci]->L[li].nlinked; ai++)
						{
						C[ci]->L[li].oldlike[ai] = likelihoodSW(ci,li, ai,C[ci]->L[li].u[ai].mcinf.val,1); 
						C[ci]->jointtreeinfo[pdg] += C[ci]->L[li].oldlike[ai];
						}
                    break; 
                }
			//treeweight(ci, li, C[ci]->t.val);
            for (i=cc1;i<=fm2;i++)
                C[ci]->jointtreeinfo[i] += C[ci]->L[li].treeinfo[i];
			if (multipleh)
				{
				C[ci]->hterms[0] += C[ci]->L[li].treeinfo[cc1]* log(C[0]->L[li].h.val);
				C[ci]->hterms[1] += C[ci]->L[li].treeinfo[cc2]* log(C[0]->L[li].h.val);
				C[ci]->hterms[2] += C[ci]->L[li].treeinfo[cca]* log(C[0]->L[li].h.val);
				}
		    }
        C[ci]->jointtreeinfo[prob] = integrate_tree_prob(ci, &C[ci]->jointtreeinfo[0]);
        }
	f_close(infile);
	} /* setupchains */

