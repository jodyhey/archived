/* IMa   for IM_analytic    2007-2009  Jody Hey and Rasmus Nielsen*/ 
/* December 17, 2009 */

#undef GLOBVARS
#include "ima.h" 

/*********** LOCAL FUNCTIONS **********/

double logfact[100*ABSMIGMAX+1];
unsigned long *iseed;


/* function prototype */

int *ivector(long nl, long nh);
void free_ivector(int *v, long nl, long nh);
unsigned long *lvector(long nl,long nh);
void free_lvector(unsigned long *v, long nl, long nh);
double bessi0(double x);
double bessi1(double x);

// stuff called by indexx() - sorting an index,  from NR 
#define NRANSI
#define NR_END 1l
#define FREE_ARG char*

int *ivector(long nl, long nh)
/* allocate an int vector with subscript range v[nl..nh] */
{
   int *v;

   v=(int *)malloc((size_t) ((nh-nl+1+NR_END)*sizeof(int)));
   if (!v) nrerror("allocation failure in ivector()");
   return v-nl+NR_END;
}

void free_ivector(int *v, long nl, long nh)
/* free an int vector allocated with ivector() */
{
   free((FREE_ARG) (v+nl-NR_END));
}

unsigned long *lvector(long nl,long nh)
//long nh,nl;
/* allocate an unsigned long vector with subscript range v[nl..nh] */
{
   unsigned long *v;

   v=(unsigned long *)malloc((unsigned int) ((nh-nl+1+NR_END)*sizeof(long)));
   if (!v) nrerror("allocation failure in lvector()");
   return v-nl+NR_END;
}

void free_lvector(unsigned long *v, long nl, long nh)
/* free an unsigned long vector allocated with lvector() */
{
   free((FREE_ARG) (v+nl-NR_END));
}

double bessi0(double x)
    {
    double ax,ans;
    double y;

    if ((ax=fabs(x)) < 3.75) {
        y=x/3.75;
        y*=y;
        ans=1.0+y*(3.5156229+y*(3.0899424+y*(1.2067492
            +y*(0.2659732+y*(0.360768e-1+y*0.45813e-2)))));
    } else {
        y=3.75/ax;
        ans=(exp(ax)/sqrt(ax))*(0.39894228+y*(0.1328592e-1
            +y*(0.225319e-2+y*(-0.157565e-2+y*(0.916281e-2
            +y*(-0.2057706e-1+y*(0.2635537e-1+y*(-0.1647633e-1
            +y*0.392377e-2))))))));
    }
    return ans;
    }

double bessi1(double x)
    {
    double ax,ans;
    double y;

    if ((ax=fabs(x)) < 3.75) {
        y=x/3.75;
        y*=y;
        ans=ax*(0.5+y*(0.87890594+y*(0.51498869+y*(0.15084934
            +y*(0.2658733e-1+y*(0.301532e-2+y*0.32411e-3))))));
    } else {
        y=3.75/ax;
        ans=0.2282967e-1+y*(-0.2895312e-1+y*(0.1787654e-1
            -y*0.420059e-2));
        ans=0.39894228+y*(-0.3988024e-1+y*(-0.362018e-2
            +y*(0.163801e-2+y*(-0.1031555e-1+y*ans))));
        ans *= (exp(ax)/sqrt(ax));
        }
    return x < 0.0 ? -ans : ans;
    }



/********** GLOBAL FUNCTIONS ***********/

#ifdef USE_MYASSERT
void myassert(int isit)
	{
	if (!isit)
		{
        /*if (outfile != NULL) can't do this unless outfile is global
            f_close(outfile); */
exit(-9);
		}
	}
#endif

void errr(int ci, int li, int i, double val1, double val2)
	{
	printf("Error # %i  ",i);
    if (li >= 0)
        printf(" chain %d locus %d ",ci,li);
    printf(" step %ld  val1 %lf   val2 %lf\n",step, val1, val2);
	exit(i);                                                                
	}

/*
miscellaneous errors
1  cannot open data file
2  cannot create file to hold parameter values, printed at intervals
3  no matching .ti file found as called for using -c0 and -r  flags
4  malloc failed in multidimensional array allocation 
5  cannot create file 
6  cannot create treefile
7 cannot create output file
8  input and output file names are identical
11 equilibrium migration model, but migration set to 0
12  too few chains for heating model 
21 problem w/ number of loci indicated in data file
22 cannot open data file

30 - to much migration called for - reduce maximum value of migration parameter
41 error reading data
42 error in data
51 model not recognized in changeq
71 - problem in updating tree
72 - problem with root 
73 - problem in updating migration 
74  - problem in treeweight,  n0 vals don't add up 
75  - problem in treeweight,  n1 vals don't add up 
76  -  product of mutation scalars not equal to 1
78  -  mutation range priors to constraining - not able to set starting values
79 - no updating of tmrca
80 - formatting of input file causes wrong lines to be read as data
81  data not compatible with infinite sites model
82  data not compatible with infinite sites model
83  data not compatible with infinite sites model
84 - sample sizes do not have add up for one locus
91  likelihoods do not add up for stepwise model
92 - no trees loaded
101 - error in gamma functions "a too large, ITMAX too small in gcf"
102 - error in gamma functions "x less than 0 in routine gser"
103 - error in gamma functions "a too large, ITMAX too small in routine gser"
104 - error in gammaq functions "Invalid arguments in routine gammp"
105 "bad arguments in expint"
106 "series failed in expint"
107 "continued fraction failed in expint"
108 - error in gammap functions "Invalid arguments in routine gammp"
111 - error in NR functions
*/


void nrerror(char error_text[])
/* Numerical Recipes standard error handler */
{
	fprintf(stderr,"Numerical Recipes run-time error...\n");
	fprintf(stderr,"%s\n",error_text);
	fprintf(stderr,"...now exiting to system...\n");
	err(-1,-1,111);
}


/* for a large value x,  cosh[x] = sinh[x] 
also (cosh[x] + sinh[x] = exp[x]  so cosh[x] = sinh[x] = Exp[x]/2
so rather than return floating error,  for the log of a cosh of a large number  just return x - log[2]  */
#define LOG2  0.69314718055994531
double mylogcosh(double x)
	{
	if (x < 100)
		return log(cosh(x));
	else
		return x - LOG2;
	}

double mylogsinh(double x)
	{
	if (x < 100)
		return log(sinh(x));
	else
		return x - LOG2;
	}
#undef LOG2

/***********************************/
/* RANDOM NUMBER RELATED FUNCTIONS */
/***********************************/

static int z_rndu=137;
//move this back into uniform
static int x_rndu=11, y_rndu=23;

void resetseeds(int seed)
	{
	z_rndu=137;
	x_rndu=11;
	y_rndu=23;

    z_rndu = 170*(seed%178) + 137;
	iseed = malloc(sizeof(unsigned long));
	*iseed = ULONG_MAX / 2  + (unsigned long) seed; // just set it so that iseed points to a large number - probably not necessary
    }


void setseeds(int seed)
    {
    z_rndu = 170*(seed%178) + 137;
	iseed = malloc(sizeof(unsigned long));
	*iseed = ULONG_MAX / 2  + (unsigned long) seed; // just set it so that iseed points to a large number - probably not necessary
    }

double uniform()
{
/* Rasmus Note:
	U(0,1): AS 183: Appl. Stat. 31:188-190
   Wichmann BA & Hill ID.  1982.  An efficient and portable
   pseudo-random number generator.  Appl. Stat. 31:188-190

   x, y, z are any numbers in the range 1-30000.  Integer operation up
   to 30323 required.

   Suggested to me by Z. Yang who also provided me with
   the source code used here.
*/
/* different compilers were giving slightly diffferent numbers unless there are float casts */
   // turn this back on  static int x_rndu=11, y_rndu=23;
   double r;
   
   x_rndu = 171*(x_rndu%177) -  2*(x_rndu/177);
   y_rndu = 172*(y_rndu%176) - 35*(y_rndu/176);
   z_rndu = 170*(z_rndu%178) - 63*(z_rndu/178);
   if (x_rndu<0) x_rndu+=30269;
   if (y_rndu<0) y_rndu+=30307;
   if (z_rndu<0) z_rndu+=30323;
   r = x_rndu/30269.0 +  y_rndu/30307.0 +  z_rndu/30323.0;
   return  (r-(long) r);
}

double expo(double c)
    {
	/*float temp;
	temp = log(uniform());
	temp = (1.0/(float) c) * temp;
    return (double) - temp; */
	return - log(uniform())/c;
    }
    

/* for binary random numbers  -	quick - based on Press et al irbit2() */
#define IB1 1
//#define IB2 2
//#define IB5 16
#define IB18 131072
//#define MASK (IB1+IB2+IB5)
#define MASK 19
__forceinline int bitran(void)    
	{
	if (*iseed & IB18) 
		{
		*iseed=((*iseed ^ MASK) << 1) | IB1;
		return 1;
		} 
	else 
		{
		*iseed <<= 1;
		return 0;
		} 
	}
#undef MASK
#undef IB18
//#undef IB5
//#undef IB2
#undef IB1 


#define ONEOVERSQRT2PI  0.3989422803
double normprob(double mean, double stdev, double val)
	{
	return ONEOVERSQRT2PI * exp( - SQR((val-mean)/stdev)/2)/stdev;
	}
#undef ONEOVERSQRT2PI


double normdev(double mean, double stdev)
    {
    static int iset=0;
    static double  gset;
    double fac,rsq,v1,v2;
    double rescale;

    if  (iset == 0) 
        {
        do 
            {
            v1=2.0*uniform()-1.0;
            v2=2.0*uniform()-1.0;
            rsq=v1*v1+v2*v2;
            } while (rsq >= 1.0 || rsq == 0.0);
        fac=sqrt(-2.0*log(rsq)/rsq);
        gset=v1*fac;
        iset=1;
		rescale = ((v2*fac*  stdev) +  mean);
        return rescale;
        } 
    else 
        {
        iset=0;
		rescale =  ((gset *  stdev) +  mean);
        return rescale;
        }
    } /* normdev */

/* gets a poisson random variable.  check it out with simulations 
if condition is 0, pick an even number
if condition is 1, pick an odd number
if condition is -1 pick any number 
If param > MINPP the normal distribution is used as an approximation

Also stuck in some stuff to deal with the case when condition is 1 and param << 1
*/

#define MINPP  25.0
int poisson(double param, int condition)
    {
    long double randnum, raised, rcheck;
    int   i;
    if (condition == 1 && param < 0.25) /* i.e. need an odd number and the parameter is a small value */ 
        {
        randnum = uniform();
        rcheck = param / sinh(param);
        if (randnum < rcheck) /* param / sinh(param) is prob of # being 1, given it must be odd */ 
            i = 1;
        else 
			/* if p=0.25 then  probability of the value being greater than 5 is about 10^-8, small enough to ignore*/
            {
            rcheck = param * (6 + param * param)/(6* sinh(param));
            if (randnum < rcheck)
                i = 3;
            else
                i = 5;
            }
        }
    else
		{
        do
            {
            if (param >= MINPP)
                {
                 i = (int) DMAX(0,ROUND(normdev(param,sqrt(param)))); //use normal distribution as approximation
                }
            else 
                {
                raised = exp(-param);
                randnum =  uniform() ;
                for (i=0; randnum > raised; i++)
                    randnum *= uniform() ;
                }
            }
         while (condition != -1  && condition != ODD(i));
		}
	if (i > ADDMIGMAX)  /* trap numbers that get too large to handle (and that don't make sense) */
		{
		if (condition != -1 )
			i = ADDMIGMAX - condition;
		else
			i = ADDMIGMAX;
		}
    return(i);
	} /* pickpoisson */
#undef MINPP

int geometric(double p)
/* returns a geometrically distributed random integer variable >= 0 */
/* this distribution is given by prob(k) = p*(1-p)^(k-1)  where k = 1,2,...  which has a mode of 1 and an expectation of 1/p */
/* it is a bit different from prob(k) = p*(1-p)^k   where k  = 0,1, 2... , which has a mode of 0 and an expectation of (1-p)/p */
/* the variance of these two different versions is the same, i.e. (1-p)/p^2 */
/* checked this in various ways - seems ok */
    {
    return (int) ceil(log(uniform()) / log(1.0 - p));
    }


/***********************************/
/* SORTING FUNCTIONS */
/***********************************/

/* heap sort is slightly faster than shell sort */
void hpsort(struct treeevent *lptr,int  n)
    {
    unsigned long i,ir,j,l;
    struct treeevent t;
    if (n < 2) return;
    l=(n >> 1)+1;
    ir=n;
    for (;;) 
        {
        if (l > 1) 
            {
            t= *(lptr + --l);
            } 
        else 
            {
            t = *(lptr+ir);
            *(lptr + ir) = *(lptr+1);
            if (--ir == 1) 
                {
                *(lptr + 1)=t;
                break;
                }
            }
        i=l;
        j=l+l;
        while (j <= ir) 
            {
            if (j < ir && (lptr+j)->time < (lptr+(j+1))->time) j++;
            if (t.time < (lptr+j)->time) 
                {
                *(lptr+i) = *(lptr+j);
                i=j;
                j <<= 1;
                } 
            else j=ir+1;
            }
        *(lptr+i)=t;
        }
    }  /*hpsort */

/* heap sort is slightly faster than shell sort */
void hpsortreg(double list[],int  n)
    {
    unsigned long i,ir,j,l;
    double t;
    if (n < 2) return;
    l=(n >> 1)+1;
    ir=n;
    for (;;) 
        {
        if (l > 1)   
            {
            t= list[--l];
            } 
        else 
            {
            t = list[ir];
            list[ir] = list[1];
            if (--ir == 1) 
                {
                list[1]=t;
                break;
                }
            }
        i=l;
        j=l+l;
        while (j <= ir) 
            {
            if (j < ir &&  list[j] < list[j+1]) j++;
            if (t < list[j]) 
                {
                list[i] = list[j];
                i=j;
                j <<= 1;
                } 
            else j=ir+1;
            }
        list[i] = t;
        }
    }  /*hpsort */

void shellhist(struct hlists *hptr, int length)
    {
    double aln = 1.442695022, tiny = 1.0e-5;
    struct hlists h;
    static   int nn,m,lognb2,i,j,k,l;
    lognb2 = (int) floor(log(length)*aln + tiny);
    m = length;
    for (nn=1; nn<= lognb2; nn++)
        {
        m = m /2;
        k = length - m;
        for (j = 0; j <= k-1; j++)
            {
            i = j;
            reloop:
            l = i+m;
            if (((hptr+l)->p < (hptr+i)->p) || (((hptr+l)->p == (hptr+i)->p) && (((hptr+l)->v < (hptr+i)->v)) ) )
                {
                 h = *(hptr+i);
                 *(hptr+i) = *(hptr+l);
                 *(hptr+l) = h;
                 i = i - m;
                 if (i>= 0) goto reloop;
                 }
            }
        }
    } /* shellhist */


/* quicksort of an index of locations */
#define SWAP(a,b) itemp=(a);(a)=(b);(b)=itemp;
#define M 7
#define NSTACK 50

void indexx(unsigned long n, struct treeevent *arr, unsigned long *indx)
{
	unsigned long i,indxt,ir=n,itemp,j,k,l=1;
	int jstack=0,*istack;
	double a;

	istack=ivector(1,NSTACK);
	for (j=1;j<=n;j++) indx[j]=j;
	for (;;) {
		if (ir-l < M) {
			for (j=l+1;j<=ir;j++) {
				indxt=indx[j];
				a=arr[indxt].time;
				for (i=j-1;i>=l;i--) {
					if (arr[indx[i]].time <= a) break;
					indx[i+1]=indx[i];
				}
				indx[i+1]=indxt;
			}
			if (jstack == 0) break;
			ir=istack[jstack--];
			l=istack[jstack--];
		} else {
			k=(l+ir) >> 1;
			SWAP(indx[k],indx[l+1]);
			if (arr[indx[l]].time > arr[indx[ir]].time) {
				SWAP(indx[l],indx[ir])
			}
			if (arr[indx[l+1]].time > arr[indx[ir]].time) {
				SWAP(indx[l+1],indx[ir])
			}
			if (arr[indx[l]].time > arr[indx[l+1]].time) {
				SWAP(indx[l],indx[l+1])
			}
			i=l+1;
			j=ir;
			indxt=indx[l+1];
			a=arr[indxt].time;
			for (;;) {
				do i++; while (arr[indx[i]].time < a);
				do j--; while (arr[indx[j]].time > a);
				if (j < i) break;
				SWAP(indx[i],indx[j])
			}
			indx[l+1]=indx[j];
			indx[j]=indxt;
			jstack += 2;
			if (jstack > NSTACK) nrerror("NSTACK too small in indexx.");
			if (ir-i+1 >= j-l) {
				istack[jstack]=ir;
				istack[jstack-1]=i;
				ir=j-1;
			} else {
				istack[jstack]=j-1;
				istack[jstack-1]=l;
				l=i;
			}
		}
	}
	free_ivector(istack,1,NSTACK);
}


#undef SWAP

#define SWAP(a,b) temp=(a);(a)=(b);(b)=temp;
//regular quicksort
//void sort(unsigned long n, float arr[]) line from nr  
// slightly modified,  works on array of doubles 
void sort(double arr[], unsigned long n)
{
   unsigned long i,ir=n,j,k,l=1,*istack;
   int jstack=0;
   double a,temp;

   istack=lvector(1,NSTACK);
   for (;;) {
      if (ir-l < M) {
         for (j=l+1;j<=ir;j++) {
            a=arr[j];
            for (i=j-1;i>=l;i--) {
               if (arr[i] <= a) break;
               arr[i+1]=arr[i];
            }
            arr[i+1]=a;
         }
         if (jstack == 0) break;
         ir=istack[jstack--];
         l=istack[jstack--];
      } else {
         k=(l+ir) >> 1;
         SWAP(arr[k],arr[l+1])
         if (arr[l] > arr[ir]) {
            SWAP(arr[l],arr[ir])
         }
         if (arr[l+1] > arr[ir]) {
            SWAP(arr[l+1],arr[ir])
         }
         if (arr[l] > arr[l+1]) {
            SWAP(arr[l],arr[l+1])
         }
         i=l+1;
         j=ir;
         a=arr[l+1];
         for (;;) {
            do i++; while (arr[i] < a);
            do j--; while (arr[j] > a);
            if (j < i) break;
            SWAP(arr[i],arr[j]);
         }
         arr[l+1]=arr[j];
         arr[j]=a;
         jstack += 2;
         if (jstack > NSTACK) nrerror("NSTACK too small in sort.");
         if (ir-i+1 >= j-l) {
            istack[jstack]=ir;
            istack[jstack-1]=i;
            ir=j-1;
         } else {
            istack[jstack]=j-1;
            istack[jstack-1]=l;
            l=i;
         }
      }
   }
   free_lvector(istack,1,NSTACK);
}

#undef SWAP
#undef M
#undef NSTACK
#undef SWAP

/***********************************/
/* GAMMA DISTRIBUTION FUNCTIONS */
/***********************************/

double gammln(double xx)
{
 double x,y,tmp,ser;
 static double cof[6]={76.18009172947146,-86.50532032941677,
  24.01409824083091,-1.231739572450155,
  0.1208650973866179e-2,-0.5395239384953e-5};
 int j;

 y=x=xx;
 tmp=x+5.5;
 tmp -= (x+0.5)*log(tmp);
 ser=1.000000000190015;
 for (j=0;j<=5;j++) ser += cof[j]/++y;
 return -tmp+log(2.5066282746310005*ser/x);
}
/* (C) Copr. 1986-92 Numerical Recipes Software '$&'3$. */


#define ITMAX 1000
#define EPS 3.0e-7
#define FPMIN 1.0e-30

void gcf(double *gammcf, double a, double x, double *gln)
{
 int i;
 double an,b,c,d,del,h;

 *gln=logfact[(int) a - 1];
 b=x+1.0-a;
 c=1.0/FPMIN;
 d=1.0/b;
 h=d;
 for (i=1;i<=ITMAX;i++) {
  an = -i*(i-a);
  b += 2.0;
  d=an*d+b;
  if (fabs(d) < FPMIN) d=FPMIN;
  c=b+an/c;
  if (fabs(c) < FPMIN) c=FPMIN;
  d=1.0/d;
  del=d*c;
  h *= del;
  if (fabs(del-1.0) < EPS) break;
 }
 if (i > ITMAX) 
     err(-1,-1,101);
 // had to change this for floating point reasons
 //*gammcf=exp(-x+a*log(x)-(*gln))*h;
 *gammcf = -x+a*log(x)-(*gln) + log(h);
}
#undef FPMIN


/* (C) Copr. 1986-92 Numerical Recipes Software '$&'3$. */

void gser(double *gamser, int a, double x, double *gln)
{
 int n;
 double sum,del,ap;
 //double temp1, temp2;

 *gln=logfact[ a - 1];
 if (x <= 0.0) {
  if (x < 0.0) 
      err(-1,-1,102);
  *gamser=0.0;
  return;
 } else {
  ap=a;
  del=sum=1.0/a;
  for (n=1;n<=ITMAX;n++) {
   ++ap;
   del *= x/ap;
   sum += del;
   if (fabs(del) < fabs(sum)*EPS) 
       {
	   //had to change this for floating point reasons
       //*gamser = sum*exp(-x+a*log(x)-(*gln));
	   *gamser =  -x+a*log(x)-(*gln) + log(sum);
        return;
        }
  }
  err(-1,-1, 103);
  
  return;
 }
}
#undef ITMAX
/* (C) Copr. 1986-92 Numerical Recipes Software '$&'3$. */


#define MAXIT 100
#define EULER 0.5772156649
#define FPMIN 1.0e-30

double expint(int n, double x)
{
 int i,ii,nm1;
 double a,b,c,d,del,fact,h,psi,ans;

 nm1=n-1;
 if (n < 0 || x < 0.0 || (x==0.0 && (n==0 || n==1)))
     err(-1,-1,105);
 else {
  if (n == 0) ans=exp(-x)/x;
  else {
   if (x == 0.0) ans=1.0/nm1;

   else {
    if (x > 1.0) {
     b=x+n;
     c=1.0/FPMIN;
     d=1.0/b;
     h=d;
     for (i=1;i<=MAXIT;i++) {
      a = -i*(nm1+i);
      b += 2.0;
      d=1.0/(a*d+b);
      c=b+a/c;
      del=c*d;
      h *= del;
      if (fabs(del-1.0) < EPS) {
       ans=h*exp(-x);
       return ans;
      }
     }
     err(-1,-1,107);
     
    } else {
     ans = (nm1!=0 ? 1.0/nm1 : -log(x)-EULER);
     fact=1.0;
     for (i=1;i<=MAXIT;i++) {
      fact *= -x/i;
      if (i != nm1) del = -fact/(i-nm1);
      else {
       psi = -EULER;
       for (ii=1;ii<=nm1;ii++) psi += 1.0/ii;
       del=fact*(-log(x)+psi);
      }
      ans += del;
      if (fabs(del) < fabs(ans)*EPS) return ans;
     }
     err(-1,-1,106);
     
    }
   }
  }
 }
 return ans;
}
#undef MAXIT
#undef EPS
#undef FPMIN
#undef EULER
/* (C) Copr. 1986-92 Numerical Recipes Software '$&'3$. */


double uppergamma(int a, double x)
/*  Returns the log of what Mathematica calls the incomplete gamma function.   */
{
 double gamser,gammcf,gln,p;

 if (x < 0.0 || a < 0.0) 
     errr(-1,-1, 104,x,a);
 if (a == 0)
     {
	 p = log(expint(1,x));  
     }
 else
	 {
	 if (x < (a+1.0)) 
		{
		gser(&gamser,a,x,&gln);
		//p = gln + log(1.0 - gamser);
		p = gln + log(1.0 - exp(gamser));
		} 
	 else 
		{
		gcf(&gammcf,a,x,&gln);
		// p = gln + log(gammcf);
		p = gln + gammcf;
		}
	 }
  if (p<-1e100) 
    p=-1e100;
  return p;
}


double lowergamma(int a, double x)
/*  modified numrec functions to return the log of  what mathematica would call the complement of 
 the incomplete gamma function.  */
{
 double gamser,gammcf,gln,p;

 if (x < 0.0 || a < 0.0) 
     errr(-1,-1,108,x,a);
 if (a == 0)
     {
     errr(-1,-1,108,x,a);
     }
 if (x < (a+1.0)) 
    {
    gser(&gamser,a,x,&gln);
    //p = gln + log(gamser);
	p = gln + gamser;
    } 
 else 
    {
    gcf(&gammcf,a,x,&gln);
	//p = gln + log(1-gammcf);
    p = gln + log(1-exp(gammcf));
    }
 if (p<-1e100) 
    p=-1e100;
 return p;

}

/* (C) Copr. 1986-92 Numerical Recipes Software '$&'3$. */


/***********************************/
/* TEXT, CHARACTER RELATED FUNCTIONS */
/***********************************/

/* Delete the substring of length "len" at index "pos" from "s". Delete less if out-of-range. */
void strdelete(char *s,int pos,int len)
	{
    int slen;
    if (--pos < 0) return;
    slen = (int) strlen(s) - pos;
    if (slen <= 0) return;
    s += pos;
    if (slen <= len)
		{
        *s = 0;
        return;
		}
    while ((*s = s[len])) s++;
	}

/* remove all characters, c, from a string */ 
void strremove(char *s, char c)
	{
	char *cspot;

	while ((cspot = strchr(s,c)) != NULL)
		{
		*cspot = '\0';
		strcat(s,cspot+1);
		}
	}
/* truncate a string at the first instance of c */
void strtrunc(char *s, char c)
	{
	char *cspot;
	if (strchr(s,c))
		{
		cspot = strchr(s,c);
		*cspot = '\0';
		}
	}

/* find next whitespace, after next non-whitespace */
char *nextwhite(char *c)
   {
   int nonw;
   nonw = !isspace(*c);
   while (*c != '\0')
      {
      while ((nonw==1 && !isspace(*c))  || (nonw==0 && isspace(*c)))
         {
         c++;
         if (nonw==0 && !isspace(*c))
            nonw = 1;
         }
      return c;
      }
   return  c;
   } /* nextwhite */

char *nextnonspace(char *textline)
/* finds the next non-space character after the next space */
	{
	char *cc;
	if (textline == NULL)
		return NULL;
	cc = textline;
	while (*cc != ' ' && *cc != '\0')
		cc++;
	while (*cc == ' ')
		cc++;
	if (*cc == '\0')
		return NULL;
	else
		return cc;
	}

/**********************************************************************
 * wildcard.c
 *
 * written by Julian Robichaux, http://www.nsftools.com
 **********************************************************************/

#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE !FALSE
#endif

/*  See if a string matches a wildcard specification that uses * or ?
    (like "*.txt"), and return TRUE or FALSE, depending on the result.
    There's also a TRUE/FALSE parameter you use to indicate whether
    the match should be case-sensitive or not.  */
int IsWildcardMatch (char *wildcardString, char *stringToCheck, int caseSensitive)
{
	char wcChar;
	char strChar;
	// use the starMatchesZero variable to determine whether an asterisk
	// matches zero or more characters (TRUE) or one or more characters
	// (FALSE)
	int starMatchesZero = TRUE;
	while ((strChar = *stringToCheck) && (wcChar = *wildcardString))
	{
		// we only want to advance the pointers if we successfully assigned
		// both of our char variables, so we'll do it here rather than in the
		// loop condition itself
		*stringToCheck++;
		*wildcardString++;

		// if this isn't a case-sensitive match, make both chars uppercase
		// (thanks to David John Fielder (Konan) at http://innuendo.ev.ca
		// for pointing out an error here in the original code)
		if (!caseSensitive)
		{
			wcChar = (char) toupper(wcChar);
			strChar = (char) toupper(strChar);
		}
		// check the wcChar against our wildcard list
		switch (wcChar)
		{
			// an asterisk matches zero or more characters
			case '*' :
				// do a recursive call against the rest of the string,
				// until we've either found a match or the string has
				// ended
				if (starMatchesZero)
					*stringToCheck--;

				while (*stringToCheck)
				{
					if (IsWildcardMatch(wildcardString, stringToCheck++, caseSensitive))
						return TRUE;
				}

				break;

			// a question mark matches any single character
			case '?' :
				break;

			// if we fell through, we want an exact match
			default :
				if (wcChar != strChar)
					return FALSE;
				break;
		}

	}

	// if we have any asterisks left at the end of the wildcard string, we can
	// advance past them if starMatchesZero is TRUE (so "blah*" will match "blah")
	while ((*wildcardString) && (starMatchesZero))
	{
		if (*wildcardString == '*')
			wildcardString++;
		else
			break;
	}
	
	// if we got to the end but there's still stuff left in either of our strings,
	// return false; otherwise, we have a match
	if ((*stringToCheck) || (*wildcardString))
		return FALSE;
	else
		return TRUE;

}
#undef TRUE
#undef FALSE


/* realloc memory for migration arrays, as needed */
__forceinline void checkmig(int i, double **mig, int *nmig/*, int source */)
	{
	myassert(*nmig >= MIGINC);
	if (i+2 > *nmig)
		{
		*nmig += MIGINC;
		if (*nmig > ABSMIGMAX)
			{
//			printf("\nsource %d  i %d    nmig %d\n",source, i, *nmig);
			err(-1,-1,30);
			}
		*mig = realloc(*mig, *nmig * sizeof(double));
		}
	}
/************************/
/* Other Misc Functions */
/************************/

/* logfact is absuredly large, but this is because it must be usable for all of the migration events in a
data set, which might be very large for a large data set with large upper bounds on migration rates */
void setlogfact(void)
    {
    int i;
    logfact[0] = 0;
    for (i=1;i<=100*ABSMIGMAX;i++)
        logfact[i] = ( (double) logfact[i-1]) + log(i);
    }

void ieevent(struct eevent *a) // initialize structure
   {
   a->n = 0;
   a->s = 0;
   a->ss = 0;
   a->s2 = 0;
   }

void iautoc(struct autoc *a) // initialize structure
	{
	ieevent(&(a->cov));
	ieevent(&(a->var[0]));
	ieevent(&(a->var[1]));
	}

double  rnd(double x, int n)
/* sort of rounds  - quite crude*/
/* only use for values in which x*10^n  does not exceed a long int */
	{
	int i, k;
	long  xi; 
	k = 0;
	while (fabs(x) < 1)
		{
		x *= 10;
		k++;
		}
	while (fabs(x) >= 10)
		{
		x /= 10;
		k--;
		}
	for (i=0;i<n;i++)
		x *= 10;
	xi = (long) ((x)+0.5);
	x = (double) xi;
	if (k < 0)
		{
		for (i=0;i > k;i--)
			x *= 10;
		}
	if (k > 0)
		{
		for (i=0;i < k;i++)
			x /= 10;
		}
	for (i=0;i<n;i++)
		x /= 10;
	return x;
	}


#define ACC 40.0
#define BIGNO 1.0e10
#define BIGNI 1.0e-10

double bessi(int n, double x)
    {
    int j;
    double bi,bim,bip,tox,ans;

    myassert(x>=0);
    n = abs(n);
    if (x > 700)
        return (MYDBL_MAX); 
    if (n==0)
        return bessi0(x);
    if (n==1)
        return bessi1(x);
    if (x == 0.0)
        return 0.0;
    else {
        tox=2.0/fabs(x);
        bip=ans=0.0;
        bi=1.0;
        for (j=2*(n+(int) sqrt(ACC*n));j>0;j--) {
            bim=bip+j*tox*bi;
            bip=bi;
            bi=bim;
            if (fabs(bi) > BIGNO) {
                ans *= BIGNI;
                bi *= BIGNI;
                bip *= BIGNI;
            }
            if (j == n) ans=bip;
        }
        ans *= bessi0(x)/bi;
        return x < 0.0 && (n & 1) ? -ans : ans;
    }
    }
#undef ACC
#undef BIGNO
#undef BIGNI

double ****alloc4Ddouble (int d1, int d2, int d3, int d4)
{
  double ****a;
  int i, j, k;

  if ((a = (double ****) malloc (d1 * sizeof (double ***))) == NULL)
    err (-1, -1, 4);
  for (i = 0; i < d1; i++)
    {
      if ((a[i] = (double ***) malloc (d2 * sizeof (double **))) == NULL)
        err (-1, -1, 4);
      for (j = 0; j < d2; j++)
        {
          if ((a[i][j] = (double **) malloc (d3 * sizeof (double *))) == NULL)
            err (-1, -1, 4);
          for (k = 0; k < d3; k++)
            if ((a[i][j][k] =
                 (double *) malloc (d4 * sizeof (double))) == NULL)
              err (-1, -1, 4);
        }
    }
  return a;
}

int ****alloc4Dint (int d1, int d2, int d3, int d4)
{
  int ****a;
  int i, j, k;

  if ((a = (int ****) malloc (d1 * sizeof (int ***))) == NULL)
    err (-1, -1, 4);
  for (i = 0; i < d1; i++)
    {
      if ((a[i] = (int ***) malloc (d2 * sizeof (int **))) == NULL)
        err (-1, -1, 4);
      for (j = 0; j < d2; j++)
        {
          if ((a[i][j] = (int **) malloc (d3 * sizeof (int *))) == NULL)
            err (-1, -1, 4);
          for (k = 0; k < d3; k++)
            if ((a[i][j][k] = (int *) malloc (d4 * sizeof (int))) == NULL)
              err (-1, -1, 4);
        }
    }
  return a;
}

void free4D (void ****a, int d1, int d2, int d3)
{
  int i, j, k;
  for (i = 0; i < d1; i++)
    {
      for (j = 0; j < d2; j++)
        {
          for (k = 0; k < d3; k++)
            {
              free (a[i][j][k]);
              a[i][j][k] = NULL;
            }
          free (a[i][j]);
          a[i][j] = NULL;
        }
      free (a[i]);
      a[i] = NULL;
    }
  free (a);
  a = NULL;
}

double ***alloc3Ddouble (int layers, int rows, int cols)
{
  double ***a;
  int i, j;

  if ((a = (double ***) malloc (layers * sizeof (double **))) == NULL)
    err (-1, -1, 4);
  for (i = 0; i < layers; i++)
    {
      if ((a[i] = (double **) malloc (rows * sizeof (double *))) == NULL)
        err (-1, -1, 4);
      for (j = 0; j < rows; j++)
        if ((a[i][j] = (double *) malloc (cols * sizeof (double))) == NULL)
          err (-1, -1, 4);
    }
  return a;
}

int ***alloc3Dint (int layers, int rows, int cols)
{
  int ***a;
  int i, j;

  if ((a = (int ***) malloc (layers * sizeof (int **))) == NULL)
    err (-1, -1, 4);
  for (i = 0; i < layers; i++)
    {
      if ((a[i] = (int **) malloc (rows * sizeof (int *))) == NULL)
        err (-1, -1, 4);
      for (j = 0; j < rows; j++)
        if ((a[i][j] = (int *) malloc (cols * sizeof (int))) == NULL)
          err (-1, -1, 4);
    }
  return a;
}

void free3D (void ***a, int layers, int rows)
{
  int i, j;
  for (i = 0; i < layers; i++)
    {
      for (j = 0; j < rows; j++)
        {
          free (a[i][j]);
          a[i][j] = NULL;
        }
      free (a[i]);
      a[i] = NULL;
    }
  free (a);
  a = NULL;
}

int **alloc2Dint (int rows, int cols)
{
  int **a = NULL;
  int i;

  if ((a = (int **) malloc (rows * sizeof (int *))) == NULL)
    err (-1, -1, 4);
  for (i = 0; i < rows; i++)
    if ((a[i] = (int *) malloc (cols * sizeof (int))) == NULL)
      err (-1, -1, 4);
  return a;
}

double **alloc2Ddouble (int rows, int cols)
{
  double **a = NULL;
  int i;

  if ((a = (double **) malloc (rows * sizeof (double *))) == NULL)
    err (-1, -1, 4);
  for (i = 0; i < rows; i++)
    if ((a[i] = (double *) malloc (cols * sizeof (double))) == NULL)
      err (-1, -1, 4);
  return a;
}

void free2D (void **a, int rows)
{
  int i;
  for (i = 0; i < rows; i++)
    {
      free (a[i]);
      a[i] = NULL;
    }
  free (a);
  a = NULL;
}

