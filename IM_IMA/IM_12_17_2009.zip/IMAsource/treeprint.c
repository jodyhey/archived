/* IMa   for IM_analytic    2007-2009  Jody Hey and Rasmus Nielsen*/ 
/* December 17, 2009 */

/* used only when debugging  and when the treeprint(ci, li) is called 
generates a file called treeprint.out - can be very large - careful */

#undef GLOBVARS
#include "ima.h" 

/*********** LOCAL FUNCTIONS **********/

struct treevals  *savetree[MAXLOCI];
FILE *treeprintfile;

/* function prototypes */
void shelltreevals(struct treevals *lptr, int length);


void shelltreevals(struct treevals *lptr, int length)
    {
    double aln = 1.442695022, tiny = 1.0e-5;
    struct treevals t;
    static   int nn,m,lognb2,i,j,k,l;
    lognb2 = (int) floor(log(length)*aln + tiny);
    m = length;
    for (nn=1; nn<= lognb2; nn++)
        {
        m = m /2;
        k = length - m;
        for (j = 0; j <= k-1; j++)
            {
            i = j;
            reloop:
            l = i+m;
            if ((lptr+l)->time < (lptr+i)->time)
                {
                t = *(lptr+i);
                *(lptr+i) = *(lptr+l);
                *(lptr+l) = t;
                i = i - m;
                if (i>= 0) goto reloop;
                }
            }
        }
    } /* shellfithet */


/********** GLOBAL FUNCTIONS ***********/


void treeprint(int ci, int li)
/* use this in debugging mode to see what a genealogy looks like for a particular parameter set */
    {
    int i,j, site, node, up1, up2;
    double upt;
    struct treevals *tvptr;
    tvptr = malloc((2*C[ci]->L[li].numgenes-1)*(sizeof(struct treevals)));
    for (i=0; i<2*C[ci]->L[li].numgenes-1; i++)
        tvptr[i].mut = 0;
    for (site=0; site < C[ci]->L[li].numsites; site++)
		{
        for (j=0; j<C[ci]->L[li].numgenes; j++)
		    C[ci]->L[li].tree[j].mut = C[ci]->L[li].seq[j][site];
	    for (j=C[ci]->L[li].numgenes; j<C[ci]->L[li].numlines; j++)
		    C[ci]->L[li].tree[j].mut = -1;
        for (j=0; j<C[ci]->L[li].numgenes; j++)
			labeltree(ci, li, j);
        for (node=C[ci]->L[li].numgenes; node<C[ci]->L[li].numlines; node++)
            {
			i = node - C[ci]->L[li].numgenes;
			up1 = C[ci]->L[li].tree[node].up[0];
			up2 = C[ci]->L[li].tree[node].up[1];
			if ((C[ci]->L[li].tree[up1].mut == 0 && C[ci]->L[li].tree[up2].mut == 1) || (C[ci]->L[li].tree[up1].mut== 1 && C[ci]->L[li].tree[up2].mut == 0))
				{
				if (C[ci]->L[li].tree[node].down == -1) /* root - not clear where mutation is , put it on left */
					{
                    tvptr[up1].mut++;
					}
				else
					{
					if (C[ci]->L[li].tree[C[ci]->L[li].tree[node].down].mut == C[ci]->L[li].tree[up1].mut)
						{						
                        tvptr[up2].mut++;
						}
					else
						{
                        tvptr[up1].mut++;
						}
					}
				}
				}
			}
    for (i=0; i<2*C[ci]->L[li].numgenes-1; i++)
        {
        tvptr[i].nodenum = i;
        j=0;
        while (C[ci]->L[li].tree[i].mig[j] > -1) j++;
        tvptr[i].up1 = C[ci]->L[li].tree[i].up[0];
        tvptr[i].up2 = C[ci]->L[li].tree[i].up[1];
        tvptr[i].down = C[ci]->L[li].tree[i].down;
        tvptr[i].time = C[ci]->L[li].tree[i].time;
        if (i >= C[ci]->L[li].numgenes)
            upt = C[ci]->L[li].tree[C[ci]->L[li].tree[i].up[0]].time;
        else upt = 0;
        tvptr[i].timei = C[ci]->L[li].tree[i].time - upt;
        tvptr[i].migcount = j;
        tvptr[i].pop = C[ci]->L[li].tree[i].pop;
		//only prints stepwise stuff for one locus,  need to update code for multiple linked STRs
        if (C[ci]->L[li].model == STEPWISE)
            {
            tvptr[i].A[0] = C[ci]->L[li].tree[i].A[0];
            tvptr[i].dlikeA[0] = C[ci]->L[li].tree[i].dlikeA[0];
            }
		if (C[ci]->L[li].model == JOINT_IS_SW)
            {
            tvptr[i].A[0] = C[ci]->L[li].tree[i].A[1];
            tvptr[i].dlikeA[0] = C[ci]->L[li].tree[i].dlikeA[1];
            }
        }
    shelltreevals(tvptr,C[ci]->L[li].numgenes);
    shelltreevals(tvptr + C[ci]->L[li].numgenes,C[ci]->L[li].numgenes-1);
   if ((treeprintfile = fopen("treeprint.out","a")) == NULL)
        {
		printf("Error opening text file for writing\n"); 
        err(ci,li,6);
	    }
    fprintf(treeprintfile,"Locus: %d  Step: %li\n",li,step);
	fprintf(treeprintfile,"   split time  %8.4f",C[ci]->t.val);
    
    fprintf(treeprintfile,"\n");
    fprintf(treeprintfile,"  current likelihood: %.5f\n",C[ci]->L[li].oldlike);
    fprintf(treeprintfile,"\tNode#\tup1\tup2\tdown\ttime\ttimei\t#mig\tpop\tmut");
    if (C[ci]->L[li].model == STEPWISE || C[ci]->L[li].model == JOINT_IS_SW)
        fprintf(treeprintfile,"\tA\tld\n");
    else fprintf(treeprintfile,"\n");
    for (i=0; i<2*C[ci]->L[li].numgenes-1; i++)
        {
        fprintf(treeprintfile,"\t%3d\t%3d\t%3d\t%3d\t%7.4f\t%7.4f\t%3d\t%3d\t%d",
            tvptr[i].nodenum,
            tvptr[i].up1,
            tvptr[i].up2,
            tvptr[i].down,
            tvptr[i].time,
            tvptr[i].timei,
            tvptr[i].migcount,
            tvptr[i].pop,
            tvptr[i].mut);
        if (C[ci]->L[li].model == STEPWISE || C[ci]->L[li].model == JOINT_IS_SW)
            fprintf(treeprintfile,"\t%3d\t%7.5f\n",tvptr[i].A[0],tvptr[i].dlikeA[0]);
        else fprintf(treeprintfile,"\n");
        }
    f_close(treeprintfile);
    treeprintfile = NULL;
    free(tvptr);
    } /* treeprint */

