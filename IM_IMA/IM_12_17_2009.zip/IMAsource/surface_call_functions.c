/* IMa   for IM_analytic    2007-2009  Jody Hey and Rasmus Nielsen*/ 
/* December 17, 2009 */


/* funccall.c   functions associated w/ the surface, and that make calls optimization routines */
#undef GLOBVARS
#include "ima.h" 



#define NUMSTRL  11
#define LOWVAL 1e-200
#define LOG2  0.69314718055994531

/*********** LOCAL STUFF **********/
double nestmaxvals[BASICPARAMS];
float *xjoint;  // used by a couple functions - declared for this file saves on mallocs 

struct nest  nestmodinfo[QONEPOP+1] = {
		{"Full ",5,"12345",0},{"ABCDD",4,"12344",0},{"ABCD0",4,"12340",1},{"ABC0D",4,"12304",1},{"ABC00",3,"12300",1},{"AACDE",4,"11234",0},
		{"AAADE",3,"11123",0},{"AACDD",3,"11233",0},{"AAC00",2,"11200",1},{"AAADD",2,"11122",0},{"AAA00",1,"11100",1},{"ABADE",4,"12134",0},
		{"ABADD",3,"12133",0},{"ABA00",2,"12100",1},{"ABBDE",4,"12234",0},{"ABBDD",3,"12233",0},{"ABB00",2,"12200",1},{"EFull",4,"12034",0},
		{"AB_DD",3,"12033",0},{"AA_DE",3,"11023",0},{"AA_DD",2,"11022",0},{"1pop ",1,"10000",0}};

/* function prototypes */

/* setx and resetx are used when evaluated nested models for placing the correct values that are optimized in the right places in the array that gets passed
to the function that gets optimized*/
void  setx(int pset[],int  *nm);
void  resetx(float x[]);
double marginp(int param, int firsttree, int lasttree, double x); //calculate marginal probability
double marginbis(double (*func)(double, double, int, int), double x1, double x2, double yadust, int pi); // find a value associated w/ a certain marginal probability

/*pset[i] is the position in the full list of parameters (5 elements) of the ith element of the optimized parameter list in the nested model */
void  setx(int pset[],int  *nm)
	{
	switch (nestedmodel) 
        {
 		case ABCDD : pset[0] = 0;pset[1] = 1;pset[2] = 2;pset[3] = 3;pset[4] = -1;*nm = 4; break;
		case ABCD0 : pset[0] = 0;pset[1] = 1;pset[2] = 2;pset[3] = 3;pset[4] = -1;*nm = 4; break;
		case ABC0D : pset[0] = 0;pset[1] = 1;pset[2] = 2;pset[3] = -1;pset[4] = 4;*nm = 4; break;
		case ABC00 : pset[0] = 0;pset[1] = 1;pset[2] = 2;pset[3] = -1;pset[4] = -1;*nm = 3; break;
		case AACDE : pset[0] = 0;pset[1] = 2;pset[2] = 3;pset[3] = 4;pset[4] = -1;*nm = 4;  break;
		case AAADE : pset[0] = 0;pset[1] = 3;pset[2] = 4;pset[3] = -1;pset[4] = -1;*nm = 3;  break;
		case AACDD : pset[0] = 0;pset[1] = 2;pset[2] = 3;pset[3] = -1;pset[4] = -1;*nm = 3;  break;
		case AAC00 : pset[0] = 0;pset[1] = 2;pset[2] = -1;pset[3] = -1;pset[4] = -1;*nm = 2;  break;
		case AAADD : pset[0] = 0;pset[1] = 3;pset[2] = -1;pset[3] = -1;pset[4] = -1;*nm = 2;  break;
		case AAA00 : pset[0] = 0;pset[1] = -1;pset[2] = -1;pset[3] = -1;pset[4] = -1;*nm = 1;  break;
		case ABADE : pset[0] = 0;pset[1] = 1;pset[2] = 3;pset[3] = 4;pset[4] = -1;*nm = 4;  break;
		case ABADD : pset[0] = 0;pset[1] = 1;pset[2] = 3;pset[3] = -1;pset[4] = -1;*nm = 3;  break;
		case ABA00 : pset[0] = 0;pset[1] = 1;pset[2] = -1;pset[3] = -1;pset[4] = -1;*nm = 2;  break;
		case ABBDE : pset[0] = 0;pset[1] = 1;pset[2] = 3;pset[3] = 4;pset[4] = -1;*nm = 4;  break;
		case ABBDD : pset[0] = 0;pset[1] = 1;pset[2] = 3;pset[3] = -1;pset[4] = -1;*nm = 3;  break;
		case ABB00 : pset[0] = 0;pset[1] = 1;pset[2] = -1;pset[3] = -1;pset[4] = -1;*nm = 2;  break;
		case AB_DD : pset[0] = 0;pset[1] = 1;pset[2] = 3;pset[3] = -1;pset[4] = -1;*nm = 3;  break;
		case AA_DE : pset[0] = 0;pset[1] = 3;pset[2] = 4;pset[3] = -1;pset[4] = -1;*nm = 3;  break;
		case AA_DD : pset[0] = 0;pset[1] = 3;pset[2] = -1;pset[3] = -1;pset[4] = -1;*nm = 2;  break;
		}
	};

void  resetx(float x[])
	{
	switch (nestedmodel) 
            {
		    case ABCDD : x[5] = x[4];break;
			case ABCD0 : x[5] = (float) MINPARAMVAL; break;
			case ABC0D : x[5] = x[4]; x[4] = (float) MINPARAMVAL; break;
		    case ABC00 : x[5] = (float) MINPARAMVAL; x[4] = (float) MINPARAMVAL; break;
		    case AACDE : x[5] = x[4];x[4] = x[3]; x[3] = x[2];x[2] = x[1];break;
		    case AAADE : x[5] = x[3];x[4] = x[2]; x[3] = x[1];x[2] = x[1];break;
		    case AACDD : x[5] = x[3];x[4] = x[3]; x[3] = x[2];x[2] = x[1];break;
		    case AAC00 : x[5] = (float) MINPARAMVAL; x[4] = (float) MINPARAMVAL; x[3] = x[2];x[2] = x[1];break;
		    case AAADD : x[5] = x[2];x[4] = x[2]; x[3] = x[1];x[2] = x[1];break;
		    case AAA00 : x[5] = (float) MINPARAMVAL; x[4] = (float) MINPARAMVAL; x[3] = x[1];x[2] = x[1];break;
		    case ABADE : x[5] = x[4];x[4] = x[3]; x[3] = x[1];break;
		    case ABADD : x[5] = x[3];x[4] = x[3]; x[3] = x[1];break;
		    case ABA00 : x[5] = (float) MINPARAMVAL; x[4] = (float) MINPARAMVAL; x[3] = x[1];break;
		    case ABBDE : x[5] = x[4];x[4] = x[3]; x[3] = x[2];break;
		    case ABBDD : x[5] = x[3];x[4] = x[3]; x[3] = x[2];break;
		    case ABB00 : x[5] = (float) MINPARAMVAL; x[4] = (float) MINPARAMVAL; x[3] = x[2];break;
		    case AB_DD : x[4] = x[3]; break;
		    case AA_DE : x[4] = x[3]; x[3] = x[2];x[2] = x[1];break;
		    case AA_DD : x[4] = x[2]; x[3] = x[2];x[2] = x[1];break;
			}
	};

double marginp(int param, int firsttree, int lasttree, double x)
    {
    int gi, ci;
    double hval,sum, p, temp;
/*       0  1    2   3   4   5   6   7   8   9  10  11  12  13  14   15  16  17  18 19  20*/
//enum {cc1,cc2,cca,cm1,cm2,fc1,fc2,fca,fm1,fm2,q1k,q2k,qak,m1k,m2k,pdg,prob,h1k,h2k,hak,tval};
    ci = 0;
    sum = 0;
    if (x < 0 || x > maxvals_for_surface_calls[param]) 
        return 0;
    for (gi=firsttree;gi< lasttree;gi++)
        {
	    switch (param) 
            {
            case 0:if (multipleh) 
                       hval = gsampinf[gi][h1k];
                    else
					   hval = gsampinf[gi][cc1] * log(C[0]->L[0].h.val);
                    
					//else
					//	hval = gsampinf[gi][cc1];
					//hval *= log(C[0]->L[0].h.val);

					temp = - gsampinf[gi][q1k] + gsampinf[gi][cc1] * (LOG2 - log(x)) - hval - 2*gsampinf[gi][fc1]/x;
					sum += exp(temp);
                    //sum += exp(- gsampinf[gi][q1k] + gsampinf[gi][cc1] * log(2/x) - hval - 2*gsampinf[gi][fc1]/x);
                    break;
            case 1:if (multipleh) 
                       hval = gsampinf[gi][h2k];
                    else
                       hval = gsampinf[gi][cc2]* log(C[0]->L[0].h.val);
					temp = - gsampinf[gi][q2k] + gsampinf[gi][cc2] * (LOG2 - log(x)) - hval - 2*gsampinf[gi][fc2]/x;
                    sum += exp(temp);
                    break;
		    case 2:if (multipleh) 
                       hval = gsampinf[gi][hak];
                    else
                       hval = gsampinf[gi][cca]* log(C[0]->L[0].h.val);
					temp = - gsampinf[gi][qak] + gsampinf[gi][cca] * (LOG2 - log(x)) - hval - 2*gsampinf[gi][fca]/x;
                    sum += exp(temp);
                    break;
            case 3: sum += exp(- gsampinf[gi][m1k] + gsampinf[gi][cm1] * log(x) - gsampinf[gi][fm1]*x);
                    break;
            case 4: sum += exp(- gsampinf[gi][m2k] + gsampinf[gi][cm2] * log(x) - gsampinf[gi][fm2]*x);
                    break;
            }
        }
    p = sum/(lasttree - firsttree + (firsttree==0));
    return -p;  /* negative because a minimization routine is used */
    } /* marginp */

#define JMAX 40
#define BISTOL  1e-4
double marginbis(double (*func)(double, double, int, int), double x1, double x2, double yadust, int pi)
{
   int j;
   double dx,f,fmid,xmid,rtb;
   
   f=(*func)(x1, yadust, pi,1);
   fmid=(*func)(x2, yadust, pi,1);
   if (f*fmid >= 0.0) 
	   return DBL_MIN;  /* not found does not appear to be a point corresponding to 95% limit*/ 
   rtb = f < 0.0 ? (dx=x2-x1,x1) : (dx=x1-x2,x2);
   for (j=1;j<=JMAX;j++) {
      fmid=(*func)(xmid=rtb+(dx *= 0.5), yadust, pi,1);
      if (fmid <= 0.0) rtb=xmid;
      if (fabs(dx) < BISTOL || fmid == 0.0) 
		  return rtb;
   }
   return DBL_MAX;  /* Too many bisections in marginbis - cannot find root */ 
}
#undef JMAX
#undef BISTOL


/********** GLOBAL FUNCTIONS ***********/


/* original version of jointp - no smoothing */
/* this calculates the function value
	works for calls in which some parameters are set to a constant value - these calls use optconst[]
	works for calls in which a reduced parameter set is used as the main model
	should also work for calls in which a reduced parameter set is used in a nested model, by calling resetx()
*/
float jointp(float x1[], int code)
/* calculate the joint likelihhood function  */
/* the point at which to calculate the value of the function is in x1[] and optconst[]
   the parameters with values in x1[] are the ones that may vary in the functions that call jointp()
   the parameters with values in optconst[] are not varying
   these two sets of values need to get copied into x[] in the proper order  */
    {

//#define PSCALE -100
    int gi, i, ci, j, ix;
    double sum,p, q;
    double *hval, hhold[3];
	//double hval[3];
    float *x;
    int firsttree, lasttree;
	double *cp, *fp;
	double *maxv;
	//double sumscale, pmax;
	//int allneg;
	double tempp;

	if (nestedmodel == FULL || nestedmodel == EFULL  || nestedmodel == QONEPOP)
		maxv = &maxvals_for_surface_calls[0];
	else
		maxv = &nestmaxvals[0];

    ci = 0;
    sum = 0;
    firsttree = optinf[2];
    lasttree = optinf[3];
	j=0;
    if (optinf[1] > 0) /* this means the function is called as part of profile likelihood surface estimation */
		/* need to correctly order the parameter values, including those that are constants (in optconst) and those that are not (in x1).
		  a bit tricky because the quantities in x1 are not ordered the same way*/
        {
        //x = malloc((1+BASICPARAMS)*sizeof(double));
		x = xjoint;
        for(i=0,j=1, ix=1;i<BASICPARAMS;i++)
			if (iq[i].integrate)
				{
				if (optconst[i] > 0)
					{
					x[ix] = optconst[i];
					}
				else 
					{
					x[ix] = x1[j];
					j++;
					}
				ix++;
				}
        }
    else
		{
		if (nestedmodel != FULL && nestedmodel != EFULL  && nestedmodel != QONEPOP)
			{
			//x = malloc((1+BASICPARAMS)*sizeof(double));
			x = xjoint;
			for (i = 1; i<=BASICPARAMS;i++)
				x[i] = x1[i];
			resetx(x);
			}
		else
			{
			x = &(x1[0]); /* regular joint surface calculation */
			}
		}
    for(i=0, ix=1;i< BASICPARAMS;i++)
        if (iq[i].integrate)
			{
			if (x[ix] < (float) MINPARAMVAL || x[ix] > (float) maxv[i]) 
				{
				//if (optinf[1] > 0 || (nestedmodel != FULL && nestedmodel != EFULL  && nestedmodel != QONEPOP)) 
				  // free(x);
				return (float) 1e20; /* set far from peak - need a large positive value because minimization routine is used 
										exp of the negative of this will be zero*/
				}
			ix++;
			}
//enum {cc1,cc2,cca,cm1,cm2,fc1,fc2,fca,fm1,fm2,q1k,q2k,qak,m1k,m2k,pdg,prob,h1k,h2k,hak,tval};
	//FP"i\tp\tq1\tq2\tqa\tm1\tm2\n");
    for (gi=firsttree;gi< lasttree;gi++)
        {
//if (code) {printf("5 %d \n",gi);}
		if (multipleh)
			{
			hval = &gsampinf[gi][h1k];
			/*hval[0] = gsampinf[gi][h1k];
			hval[1] = gsampinf[gi][h2k];
			hval[2] = gsampinf[gi][hak];  */
			}
		else
			{
			hhold[0] = gsampinf[gi][cc1]* log(C[0]->L[0].h.val);
			hhold[1] = gsampinf[gi][cc2]* log(C[0]->L[0].h.val);
			hhold[2] = gsampinf[gi][cca]* log(C[0]->L[0].h.val); 
			hval = &hhold[0]; 
			/*hval[0] = gsampinf[gi][cc1]* log(C[0]->L[0].h.val);
			hval[1] = gsampinf[gi][cc2]* log(C[0]->L[0].h.val);
			hval[2] = gsampinf[gi][cca]* log(C[0]->L[0].h.val);  */
			}
        p = paramprior - gsampinf[gi][prob];
		myassert(gsampinf[gi][prob] != 0);
		fp = &gsampinf[gi][fc1];
		cp = &gsampinf[gi][cc1];
		for (i=0, ix=1;i<3;i++)
			{
			if (iq[i].integrate)
				{
				myassert(x[ix] > 0);
				myassert(p != 0);
				p += *cp * (LOG2 - log(x[ix])) - hval[i] - 2* *fp/x[ix];
				ix++;
				}
			fp++;
			cp++;
			}
		for (i=3;i<BASICPARAMS;i++)
			{
			if (iq[i].integrate)
				{
				myassert(*fp > 0);
				myassert(x[ix] > 0);
				p +=  *cp  * log(x[ix]) - *fp * x[ix]; 
				ix++;
				}
			fp++;
			cp++;
			}
    /* code from Rasmus to deal with taking the logarithm of a sum of exponentials of very small values which often leads to underflow - works well but may not be needed*/
	/*	if (gi == firsttree)
			{
			pmax = p;
			allneg = (p<0);
			sumscale = 1;
			}
		else
			{
			if (allneg)
				{
				allneg = allneg && (p<0);
				if (p> pmax)
					{
					if (pmax - p > PSCALE)
						sumscale = sumscale * exp(pmax-p) + 1;
					else
						sumscale = 1; 
					pmax = p;
					}
				else
					{
					if (p - pmax > PSCALE)
						sumscale = sumscale+exp(p-pmax);
					}
				}
			}*/
		tempp = exp(p);
		if (tempp < LOWVAL)
			tempp = LOWVAL;
		sum += tempp;
        }
	/*if (allneg)
		q = -((log(sumscale) + pmax) - log((double) (lasttree-firsttree)));
	else
		{ */
if (code) {printf("7 sum %lf  lasttree - firsttree %d \n", sum,lasttree - firsttree);}
		q = sum/ (double) (lasttree-firsttree);
		q = - log(q); /* negative because a minimization routine is used */ 
		//}
    //if (optinf[1] > 0 || (nestedmodel != FULL && nestedmodel != EFULL  && nestedmodel != QONEPOP)) 
      //  free(x);
if (code) {printf("8 q %f \n", (float) q);}
    return (float) q;  /* float because the NR routines use floats */
    } /* jointp */

/* this is very similar to jointp but does smoothing over NP points scattered around x, with distance set by DISMAX and exponential weighting set by SF */
/* also calculates the value of t associated with the point by taking the average of all t values,  weighted by the probabilities associated with this point */
/* use this after optimization.  Optimization finds the very highest point, but then smooth around it to avoid having an estimate of the likelihood
that is too high due to the variance of the surface */
#define NP  30
#define DISMAX 0.05
#define SF   0.0005
float jointpsmoothed(float x1[], double *t)
    {
    int gi, i, ci, j, ix, k;
    double sum,p, q, phold;
    double hval[3];
    float *x;
    int firsttree, lasttree;
	double *cp, *fp;
	double *maxv;
	double pp[NP];
	double dp[NP];
	static double  dtp[NP][BASICPARAMS+1];
	static double logdtp[NP][BASICPARAMS+1];
	static int check = 0;
	double tempnum, tempdenom;
	double fptemp, logtemp, tempp;
	double dt, w,m=1, sumt, pr;

	if (check==0)  // pick a set of NP points that are set off from the peak by small distances added or subtracted at each parameter position from the peak location
				// save these distances- they can be used repeatedly
		{
		for (i=0,k=1;i<NP;i++)
			{
			for(j=0, ix=1; j< BASICPARAMS;j++)
				if (iq[j].integrate) // nasty bug here - this was iq[i]  which makes no sense
					{
					if (m)
						dt = 1 +  DISMAX *  k/ (double) (5*NP);
					else
						dt = 1 -  DISMAX * k/ (double) (5*NP);
					m = 1-m;
					k++;
					dtp[i][ix] = dt;
					logdtp[i][ix] = log(dt);
					ix++;
					}
			}
		check = 1;
		}

	if (nestedmodel == FULL || nestedmodel == EFULL  || nestedmodel == QONEPOP)
		maxv = &maxvals_for_surface_calls[0];
	else
		maxv = &nestmaxvals[0];

    ci = 0;
    sum = 0;
    firsttree = optinf[2];
    lasttree = optinf[3];
	j=0;
    if (optinf[1] > 0) /* this means the function is called as part of profile likelihood surface estimation */
		/* need to correctly order the parameter values, including those that are constants (in optconst) and those that are not (in x1).
		  a bit tricky because the quantities in x1 are not ordered the same way*/
        {
        //x = malloc((1+BASICPARAMS)*sizeof(double));
		x = xjoint;
        for(i=0,j=1, ix=1;i<BASICPARAMS;i++)
			if (iq[i].integrate)
				{
				if (optconst[i] > 0)
					{
					x[ix] = optconst[i];
					}
				else 
					{
					x[ix] = x1[j];
					j++;
					}
				ix++;
				}
        }
    else
		{
		if (nestedmodel != FULL && nestedmodel != EFULL  && nestedmodel != QONEPOP)
			{
			x = xjoint;
			//x = malloc((1+BASICPARAMS)*sizeof(double));
			for (i = 1; i<=BASICPARAMS;i++)
				x[i] = x1[i];
			resetx(x);
			}
		else
			{
			x = &(x1[0]); /* regular joint surface calculation */
			}
		}

    for(i=0, ix=1;i< BASICPARAMS;i++)  // this is checking to see if the point is out of bounds - should not be able to get here I don't think
		{
        if (iq[i].integrate)
			{
			if (x[ix] < (float) MINPARAMVAL || x[ix] > (float) maxv[i]) 
				{
				if (optinf[1] > 0 || (nestedmodel != FULL && nestedmodel != EFULL  && nestedmodel != QONEPOP)) 
				   free(x);
				return (float) 1e20; /* set far from peak - need a large positive value because minimization routine is used 
										exp of the negative of this will be zero*/
				}
			ix++;
			}
		}
	sumt=0;
    for (gi=firsttree;gi< lasttree;gi++)
        {
		if (multipleh)
			{
			hval[0] = gsampinf[gi][h1k];
			hval[1] = gsampinf[gi][h2k];
			hval[2] = gsampinf[gi][hak];
			}
		else
			{
			hval[0] = gsampinf[gi][cc1]* log(C[0]->L[0].h.val);
			hval[1] = gsampinf[gi][cc2]* log(C[0]->L[0].h.val);
			hval[2] = gsampinf[gi][cca]* log(C[0]->L[0].h.val);
			}
        p = paramprior - gsampinf[gi][prob];
	 // pp holds the probability calculation,  dp holds the distance
		for (i=0;i<NP;i++)
			{
			pp[i] = p;
			dp[i]= 0;
			}

		myassert(gsampinf[gi][prob] != 0);

		fp = &gsampinf[gi][fc1];
		cp = &gsampinf[gi][cc1];
		for (i=0, ix=1;i<3;i++)
			{
			if (iq[i].integrate)
				{
				myassert(x[ix] > 0);
				myassert(p != 0);
				fptemp = 2* *fp/x[ix];
				logtemp = LOG2 - log(x[ix]);
				phold = *cp * logtemp - hval[i] - fptemp;
				p += phold;
				for (j=0;j<NP;j++)
					{
					if (optinf[1] > 0 && optconst[i] > 0) // profiling - keep value constant for profiled parameter during smoothing
						{
						pp[j] += phold;
						dp[j] += 0;
						}
					else
						{
						pp[j] += *cp * (logtemp - logdtp[j][ix]) - hval[i] - fptemp/dtp[j][ix];
						dp[j] += SQR(x[ix]* (1- dtp[j][ix]));
						}
					}
				ix++;
				}
			fp++;
			cp++;
			}
		for (i=3;i<BASICPARAMS;i++)
			{
			if (iq[i].integrate)
				{
				myassert(*fp > 0);
				myassert(x[ix] > 0);
				fptemp =  *fp * x[ix];
				logtemp = log(x[ix]);
				phold =  *cp  * logtemp - fptemp; 
				p += phold;
				for (j=0;j<NP;j++)
					{
					if (optinf[1] > 0 && optconst[i] > 0) // profiling - keep value constant for profiled parameter during smoothing
						{
						pp[j] += phold;
						dp[j] += 0;
						}
					else
						{
						pp[j] += *cp  * (logtemp + logdtp[j][ix]) - fptemp * dtp[j][ix]; 
						dp[j] += SQR(x[ix]* (1- dtp[j][ix]));
						}
					}
				ix++;
				}
			fp++;
			cp++;
			}
		tempnum = exp(p); // count the probability at the actual point the most 
		if (tempnum < LOWVAL)
			tempnum = LOWVAL;
		tempdenom = 1;
		for (j=0;j<NP;j++)
			{
			w =   1/exp(dp[j]/SF);
			tempp = exp(pp[j]);
			if (tempp < LOWVAL)
				tempp = LOWVAL;
			tempnum +=  tempp*w;
			tempdenom += w;
			}
		pr = tempnum/tempdenom;
		sum += pr;
		sumt += gsampinf[gi][tval] * pr;
        }
	*t = sumt / sum;
    q = sum/ (double) (lasttree-firsttree);
    q = - log(q); /* negative because a minimization routine is used */
  //  if (optinf[1] > 0 || (nestedmodel != FULL && nestedmodel != EFULL  && nestedmodel != QONEPOP)) 
  //      free(x);
    return (float) q;  /* float because the NR routines use floats */
    } /*jointpsmoothed */

/* profile95 call annealjointopt   
Need to find the root with respect to one parameter at a time (while optimizing the others) for both the upper and lower confidence intervals */ 

#define JMAX 40
#define  DOWN95  1.92
#define PROFILE95TOL  0.001

void profile95(FILE *outfile,int ndim,double holdmlval, double holdpeakloc[], double hold95lo[],double hold95hi[])
    {
	double p[BASICPARAMS+1], fret;
    int i,j,ii,ix;
	int ndim1;
	int UL;
	double temp, yadjust;
	double dx,f,fmid,xmid,rtb;
	float x1, x2;
	int numints;
	double dummy;

	ndim1 = ndim-1;
	optinf[0] = ndim1;
	optinf[1] = 1;
	yadjust = log(holdmlval) - DOWN95;
	for (ii= 0 ;ii< BASICPARAMS;ii++)
		if (iq[ii].integrate)
			{
			printf("\n%d",ii);
			for (i=0;i<BASICPARAMS;i++)
				optconst[i] = -1;
			for (UL = 0; UL <= 1; UL++)
				{
				/* simple bisection routine  
				/* start at joint optimum found previously */
				x1 = (float) holdpeakloc[ii];
				optconst[ii] = x1;
				f = DOWN95;
				//if ( (UL ==0 && x1 <  1.0)  || ((UL ==1) && x1 > 0.9 *  *(&iq[q1i].pr.max+ iq[ii].listpos)))
				if ( (UL ==0 && x1 <  1.0)  || ((UL ==1) && x1 > 0.9 * iq[ii].pr.max))
					numints = 1;
				else 
					numints = 4;
				j = 0;
				do  // walk down in increments until the root is bracketed
					{
					j++;
					if (UL==0)
						x2 = (float) (holdpeakloc[ii] -  j * (holdpeakloc[ii] - MINPARAMVAL)/numints);
					else
						//x2 = (float) (holdpeakloc[ii] +  j * (*(&iq[q1i].pr.max+ iq[ii].listpos) - holdpeakloc[ii])/numints);
						x2 = (float) (holdpeakloc[ii] +  j * (  iq[ii].pr.max  - holdpeakloc[ii])/numints);
					optconst[ii] = x2;
					for (i=0,ix=1;i<BASICPARAMS;i++)
						if (iq[i].integrate)
							{
							p[ix] = holdpeakloc[i];
							ix++;
							}
					annealjointopt(outfile,&fret,&p[1],ndim1,15, ii, &dummy);
					fmid=   log(fret) -yadjust;
					if (f*fmid >= 0)
						{
						x1 = x2;
						f = fmid;
						}
					}
				while (f*fmid >= 0.0 && j < numints);
				if (f*fmid >= 0.0) 
					temp = DBL_MIN;/* not found does not appear to be a point corresponding to 95% limit*/ 
				else   /* do bisection */
					{
					rtb = f < 0.0 ? (dx=x2-x1,x1) : (dx=x1-x2,x2);
					for (j=1;j<=JMAX;j++) 
						{
						xmid = rtb+(dx *= 0.5);
						optconst[ii] = (float) xmid;
						for (i=0,ix=1;i<BASICPARAMS;i++)
							if (iq[i].integrate)
								{
								p[ix] = holdpeakloc[i];
								ix++;
								}
						annealjointopt(outfile,&fret,&p[1],ndim1,5, ii, &dummy);
						fmid=  log(fret) - yadjust;
						if (fmid <= 0.0) 
							rtb=xmid;
						if (fabs(dx) < PROFILE95TOL || fmid == 0.0) 
							{
							temp = rtb;
							break;
							}
						}
					}
				if (j >= JMAX)
					temp = DBL_MAX; /* Too many bisections  - cannot find root */ 
				if (UL==0)
					hold95lo[ii] = temp;
				else 
					hold95hi[ii] = temp;
				}
			}
    } /* profile95 */

#undef PROFILE95TOL
#undef JMAX

/*us simulated annealing simplex method from NR*/
/*Calls to this come from findpeaks(),  both for using the main model and nested models 
   also from profile95() and from profile1Dcurve()
  These present different problems in ordering the parameters
  jointp() knows how to unpack the parameters so that they are used correctly for calculating the function value
  This function needs to know how to pack them, so that a model in which only n parameters are varying is 
  properly represented in a call to amebsa() with the proper n and xx[][] 
  
  peakloc[] can come in with a useful location for the simplex.  
  use this value at the first virtex
  if constval >= 0  then a value is held constant for the purpose of profiling and the call comes from profile95()*/ 


#define MAXANNEALTRY 50
void annealjointopt(FILE *outfile,double *mlval, double peakloc[], int ndim, int atry, int constval, double *t)
    {
    float **xx;
    float yb, temptr, minyb;
    int i,ix,j,jx,iter, iiter, nit, jiter;
    int code = 0;
    float (*jointpfunc) (float x1[], int code);
    float ftol = (float) 1e-7;
	float temptrmin;
	double *maxv;
	float temptrstep;
	int k, jstep;
	int pset[BASICPARAMS];
    float pb[BASICPARAMS + 1];
    float y[BASICPARAMS + 2];
    float x[BASICPARAMS + 1];
	float vx[MAXANNEALTRY][BASICPARAMS];
    
    if (nestedmodel == FULL || nestedmodel == EFULL  || nestedmodel == QONEPOP)
		maxv = &maxvals_for_surface_calls[0];
	else
		{
		maxv = &nestmaxvals[0];
		setx(pset, &ndim);
		}
	jointpfunc =jointp;
	xx = calloc(ndim+2,sizeof(float *));
    for (i=0;i< ndim+2;i++)
        xx[i] = calloc(ndim+2,sizeof(float));
	minyb = (float) 1e30;
	yb= (float) 1.0e30;
	atry = IMIN(MAXANNEALTRY,atry);
	printf(".");
	for (k=0;k<atry;k++)
		{
#ifdef HPDBG
// Clear the debug-heap flag, check memory 
CLEAR_CRT_DEBUG_FIELD( _CRTDBG_DELAY_FREE_MEM_DF );
_CrtCheckMemory( );
#endif

		/* start with vertices as suggested in NR, but then start using found solutions as corners of the simplex */
		if (nestedmodel == FULL || nestedmodel == EFULL  || nestedmodel == QONEPOP)
			{
			for (i=0,ix=1;i<=BASICPARAMS;i++)
				{
				if ((iq[i].integrate || i == BASICPARAMS) && (i != constval))
					{
					for (j=0,jx=1;j<BASICPARAMS;j++)
						{
						if (iq[j].integrate && j!= constval)
							{
                            myassert(jx <= ndim);
                            myassert(ix <= ndim+1);
							if (i < k)
								//x[jx] = xx[ix][jx] = vx[IMAX(i,k-5 + i)][j];
								/* after some trial and error this bit of jiggling seems to be best */
								x[jx] = xx[ix][jx] = (float) (vx[IMAX(i,k-5 + i)][j] * (1+ 0.1*(uniform() - 0.5)));
							else
								{
								if (ix==jx + 1)
									x[jx] = xx[ix][jx] = (float) maxv[j];
								else
									{
									if (k==0 && ix == 1)
										x[jx] = xx[ix][jx] = (float) peakloc[j]; 
									else
										x[jx] = xx[ix][jx] = (float) MINPARAMVAL; 
									}
								}
							jx++;
							}
						}
                    myassert(ix <= ndim+1);
					y[ix] = jointp(x, code);
					ix++;
					}
				}
			}
		else /* for nested models */
			{
			for (i=0,ix=1;i<=BASICPARAMS;i++)
				{
				if (pset[i] >= 0 || i==BASICPARAMS)
					{
					for (j=0,jx=1;j<BASICPARAMS;j++)
						{
						if (pset[j] >= 0)
							{
                            myassert(jx <= ndim);
                            myassert(ix <= ndim+1);
							if (i < k )  // this causes x[jx] and xx[ix][j] to be based on pertubations of values found previously, 
                                        //but why for i (param #) < k ??
								//x[jx] = xx[ix][jx] = vx[IMAX(i,k-5 + i)][j];
								x[jx] = xx[ix][jx] = (float) (vx[IMAX(i,k-5 + i)][j] * (1+ 0.1*(uniform() - 0.5)));
							else
								{
								if (ix==jx + 1)
									x[jx] = xx[ix][jx] = (float) maxv[pset[j]];
								else
									{
									if (k==0 && ix == 1)
										x[jx] = xx[ix][jx] = (float) DMIN(maxv[pset[j]],peakloc[pset[j]]); 
									else
										x[jx] = xx[ix][jx] = (float) MINPARAMVAL; 
									}
								}
							jx++;
							}
						}
                    myassert(ix <= ndim+1);
					y[ix] = jointp(x, code);
					ix++;
					}
				}
			}
/* set conditions that seem to work  - don't understand role of iter*/
/* different search parameters - in order of stringency and amount of time taken */
		/*
		temptrmin = 0.5;
		temptr = 20;
		jstep = 5;
		temptrstep =  0.9;  */


		
		temptrmin = (float) 0.2;
		temptr = (float) 20;
		jstep = 5;
		temptrstep =  (float) 0.92; 
		/*
		temptrmin = 0.1;
		temptr = 20;
		jstep = 5;
		temptrstep =  0.95;

		temptrmin = 0.1;  
		temptr = 25;
		jstep = 10;2
		temptrstep = 0.95;
		*/

		iiter = 100;
		iter = -1;
		nit = 0;
		jiter = 1;
		while (temptr > temptrmin && iter <0 )
			{
			iter=iiter;
			if (jiter ==  (jstep * (int) (jiter/jstep)))
				{
				temptr *= temptrstep;
				jiter = 1;
				} 
			//printf("%d\n",k);

/*if (nestedmodel > AAA00) 
    {
    //printf("model %d  temptr %lf iiter  %d  iter %d  nit %d jiter %d\n",nestedmodel, temptr, iiter, iter, nit, jiter);
    if (fabs(temptr - 0.187564) < 0.0001 && nit==22744 && jiter==1)
        code = 1;
    else
        code = 0;
    }*/
			amebsa(xx,y,ndim,pb,&yb,ftol,jointpfunc,&iter,temptr, code);
			nit += iiter-iter;
			if (iter > 0) break;
			jiter++;
			}
		//printf("k  %d \n",k);
		if (calcoptions[PRINTPEAKFINDDETAILS] && constval < 0)
			{
			FP"    %2d           ",k);
			FP" %8.4lf ",(double) -yb);
			} 
		/* save lastest solutions as simplex corner */
		for (i=0,ix=1;i<BASICPARAMS;i++) 
			{
			if (iq[i].integrate && i != constval)
				{
				if (calcoptions[PRINTPEAKFINDDETAILS] && constval < 0)
					FP" %8.4f ",pb[ix]);
                myassert(k<MAXANNEALTRY);
                myassert(ix-1 < BASICPARAMS);
				vx[k][ix-1] = pb[ix];
                ix++;
				}
			}
		if (calcoptions[PRINTPEAKFINDDETAILS] && constval < 0)
			{
			FP" %6d  %9.6f",nit, temptr);
			FP"\n");
			} 
		if (yb < minyb)
			{
			minyb = yb;
			for (i=0,ix=1;i<BASICPARAMS;i++) 
				if (iq[i].integrate && i != constval)
					{
					peakloc[i] = pb[ix];
                    ix++;
					}
			}
		}
	for (i=0,ix=1;i<BASICPARAMS;i++) 
		{
		if (iq[i].integrate && i != constval)
			{
            myassert(ix < BASICPARAMS + 1);
			y[ix] = (float) peakloc[i];
            ix++;
			}
		}
	*mlval = exp((double) -jointpsmoothed(y,t));
    for (i=0;i<=ndim+1;i++)
        free(xx[i]);
	free(xx);
    } /*annealjointopt  */


/* margincalc does the same thing as marginp, but gets called by different functions
uses all trees 
can be used for direct calculation
also can be used for root finding. 
also by using a nonzero value of jadust can be used to find the value of x that is
associated with a particular value of y (i.e. the likelihood) 
if logi==1  return the logarithm 
 */
double margincalc(double x, double yadust, int pi, int logi)
	{
	int gi,ci;
	double hval, sum;

    ci=0;
	sum = 0;

	for (gi=0;gi<treessaved;gi++)
		{
		if (pi == Q1)
			{
			if (multipleh)
				hval = gsampinf[gi][h1k];
			else
				hval = gsampinf[gi][cc1]* log(C[0]->L[0].h.val);
			sum += exp(- gsampinf[gi][q1k] + gsampinf[gi][cc1] * (LOG2 - log(x)) - hval - 2*gsampinf[gi][fc1]/x);
			}
		if (pi == Q2)
			{
			if (multipleh)
				hval = gsampinf[gi][h2k];
			else
				hval = gsampinf[gi][cc2]* log(C[0]->L[0].h.val);
			sum += exp(- gsampinf[gi][q2k] + gsampinf[gi][cc2] * (LOG2 - log(x)) - hval - 2*gsampinf[gi][fc2]/x);
			}
		if (pi == QA)
			{
			if (multipleh)
				hval = gsampinf[gi][hak];
			else
				hval = gsampinf[gi][cca]* log(C[0]->L[0].h.val);
			sum += exp(- gsampinf[gi][qak] + gsampinf[gi][cca] * (LOG2 - log(x)) - hval - 2*gsampinf[gi][fca]/x);
			}
		if (pi == M1)
			{
			sum += exp(- gsampinf[gi][m1k] + gsampinf[gi][cm1] * log(x) - gsampinf[gi][fm1]*x);
			}
		if (pi == M2)
			{
			sum += exp(- gsampinf[gi][m2k] + gsampinf[gi][cm2] * log(x) - gsampinf[gi][fm2]*x);
			}
		}
	sum /= treessaved;
	if (logi)
		{
		if (sum <= 0)
			sum = -LOWVAL;
		else
			sum = log(sum);
		}
	sum -= yadust; 
	return sum;
	} /* marginalcalc */


void marginalopt(int firsttree, int lasttree, double mlval[], double peakloc[])
    {
    int i;
    double ftol, ax,bx, cx, fa, fb, fc, xmax, ml;
    double (*func) (int, int, int, double);
    ftol = 1e-7;
    func = marginp;
    for (i=0;i< BASICPARAMS;i++)
        {
        if (iq[i].integrate )
            {
            switch (i)
                {
                case 0: bx = iq[q1i].pr.max/4;break;
                case 1: bx = iq[q2i].pr.max/4;break;
                case 2: bx = iq[qai].pr.max/4;break;
                case 3: bx = iq[m1i].pr.max/4; break;
                case 4: bx = iq[m2i].pr.max/4;break;
                }
            ax = MINPARAMVAL;
            mnbrakmod(i, firsttree, lasttree, &ax, &bx, &cx, &fa, &fb, &fc, func);
            ml = -goldenmod(i, firsttree, lasttree, ax, bx, cx, ftol, &xmax, func);
            mlval[i] = ml;
            peakloc[i] = xmax;
            }
        }
    } /* marginalopt */


double margin95(double mlval[], double peakloc[], int pi, int UL)
    {
	double x1, x2, x, yadjust;
    double (*func) (double, double, int, int);
    func = margincalc;
	if (UL == 0)  // lower
		{
		x1 = MINPARAMVAL;
		x2 = peakloc[pi];
		}
	else		// upper
		{
		x1 = peakloc[pi];
		//x2 = *(&iq[q1i].pr.max+ paraminfo[pi].listpos);
		x2 = iq[pi].pr.max;
		}
	yadjust = log(mlval[pi]) - DOWN95;
	x = marginbis(margincalc, x1,x2,yadjust, pi);
	return x;
    } /* margin95 */


double twodmargincalc(double xi, double xj, int pi, int pj, int logi, double yadjust)
	{
	int gi,ci, p, i;
	double x;
	double hval, sum, tempsum;

    ci=0;
	sum = 0;
	for (gi=0;gi<treessaved;gi++)
		{
		tempsum = 0;
		for (i=0;i<2; i++)
			{
			if (i==0)
				{
				x=xi;
				p = pi;
				}
			else
				{
				x=xj;
				p = pj;
				}
			if (p == Q1)
				{
				if (multipleh)
					hval = gsampinf[gi][h1k];
				else
					hval = gsampinf[gi][cc1]* log(C[0]->L[0].h.val);
				tempsum +=  (- gsampinf[gi][q1k] + gsampinf[gi][cc1] * (LOG2 - log(x)) - hval - 2*gsampinf[gi][fc1]/x);
				}
			if (p == Q2)
				{
				if (multipleh)
					hval = gsampinf[gi][h2k];
				else
					hval = gsampinf[gi][cc2]* log(C[0]->L[0].h.val);
				tempsum +=  (- gsampinf[gi][q2k] + gsampinf[gi][cc2] * (LOG2 - log(x)) - hval - 2*gsampinf[gi][fc2]/x);
				}
			if (p == QA)
				{
				if (multipleh)
					hval = gsampinf[gi][hak];
				else
					hval = gsampinf[gi][cca]* log(C[0]->L[0].h.val);
				tempsum +=  (- gsampinf[gi][qak] + gsampinf[gi][cca] * (LOG2 - log(x)) - hval - 2*gsampinf[gi][fca]/x);
				}
			if (p == M1)
				{
				tempsum +=  (- gsampinf[gi][m1k] + gsampinf[gi][cm1] * log(x) - gsampinf[gi][fm1]*x);
				}
			if (p == M2)
				{
				tempsum +=  (- gsampinf[gi][m2k] + gsampinf[gi][cm2] * log(x) - gsampinf[gi][fm2]*x);
				}
			}
		sum += exp(tempsum);
		}
	sum /= treessaved;
	if (logi)
		{
		if (sum <= 0)
			sum = -LOWVAL;
		else
			sum = log(sum);
		}
	sum -= yadjust; 
	return sum;
	} /* twodmarginalcalc */


#define NUMTREEINT 2  // consider NUMTREEINT batches of trees for finding peaks,  one way to check for convergence

	/*
	optinf[0]  # parameters in the model that are not constants
	optinf[1]  # parameters in the model that are constants
    optinf[2]  the number of the first tree to include
    optinf[3]  the number of the last tree to include
    */

/*	struct nest  nestmodinfo[QONEPOP+1] = {
		{"Full ",5,"12345"},{"ABCDD",4,"12344"},{"ABC00",3,"12300"},{"AACDE",4,"11234"},{"AAADE",3,"11123"},{"AACDD",3,"11233"},
		{"AAC00",2,"11200"},{"AAADD",2,"11122"},{"AAA00",1,"11100"},{"ABADE",4,"12134"},{"ABADD",3,"12133"},{"ABA00",2,"12100"},
		{"ABBDE",4,"12234"},{"ABBDD",3,"12233"},{"ABB00",2,"12200"},{"EFull",4,"12034"},{"AB_DD",3,"12033"},{"AA_DE",3,"11023"},
		{"AA_DD",2,"11022"},{"1pop ",1,"10000"}}; */

//enum {Full, ABCDD, ABC00, AACDE, AAADE, AACDE, AAC00, AAADD, AAA00, ABADE, ABADD, ABA00, ABBDE, ABBDD, ABB00, EFull, AB_DD, AA_DE, AA_DD, QONEPOP}

/* findpeaks()  finds several types of information about the surface and prints the results
	1) find marginal peaks for the main model  - save points in peakloc
	2) find 95% confidence limits on marginal peak locations 
		these calls ultimately go to the function marginp() which determines the marginal function value
	all other functino calls in findpeaks() ultimately go to jointp()  which calculates a value of the function for a joint parameter value  
	3) finds the joint optimimum  using simulated annealing 

  the profiling of the joint surface is done by profile95()
*/

int findpeaks(FILE *outfile,int imodel, char outfilename[], double *holdmlval, double holdpeakloc[])
    {
    int i, j, ndim;
    double temp;
	double  mlval[BASICPARAMS], peakloc[BASICPARAMS], temppeakloc[BASICPARAMS];
	int firsttree,lasttree;
	double minq, minm;
	char ts[2];
	int used[BASICPARAMS];
	double t;
	
	xjoint = malloc((1+BASICPARAMS)*sizeof(double));	// used by jointp and jointpsmoothed
	nestedmodel = imodel;
	for (i=0;i<BASICPARAMS;i++)
		{
        if (iq[i].integrate)
            {
			switch (i)
                {
                case 0: maxvals_for_surface_calls[i] = minq = iq[q1i].pr.max;break;
                case 1: maxvals_for_surface_calls[i] = iq[q2i].pr.max; minq = DMIN(minq,iq[q2i].pr.max);break;
                case 2: maxvals_for_surface_calls[i] = iq[qai].pr.max; minq=DMIN(minq,iq[qai].pr.max);break;
                case 3: maxvals_for_surface_calls[i] = minm=iq[m1i].pr.max;break;
                case 4: maxvals_for_surface_calls[i] = iq[m2i].pr.max; minm=DMIN(minm,iq[m2i].pr.max);break;
                }
            }
		else
			maxvals_for_surface_calls[i] = 0;
		} 
	for (i=0;i<BASICPARAMS;i++)
		{
        if (iq[i].integrate)
            {
			switch (i)
                {
                case 0: nestmaxvals[i] = minq;break;
                case 1: nestmaxvals[i] = minq;break;
                case 2: nestmaxvals[i] = minq;break;
                case 3: nestmaxvals[i] = minm;break;
                case 4: nestmaxvals[i] = minm;break;
                }
            }
		else
			nestmaxvals[i] = 0;
		} 
	FP"\n\nPEAK LOCATIONS AND PROBABILITES\n");
	FP"=================================\n\n\n");
	printf("Finding marginal peaks and probabilities \n");
    FP"\nMarginal Peak Locations and Probabilities\n");
	FP"------------------------------------------\n");
    FP" Set ");
    for (i=0;i< BASICPARAMS;i++)
        if (iq[i].integrate)
            {
            FP"   %s        P      ",iq[i].str);
            }
    FP"\n");
    if (treessaved > 10)
        {
        for (firsttree = 0,lasttree = (int) treessaved / NUMTREEINT,i=0;i<NUMTREEINT;i++)
            {
            marginalopt(firsttree,lasttree, mlval,peakloc);
            FP"  %2d ",i);
            for (j=0;j<BASICPARAMS;j++) 
				if (iq[j].integrate)
					FP"  %9.4lf %8.4lg ",peakloc[j],mlval[j]);
            FP"\n");
            firsttree = lasttree+1;
            lasttree += (int) treessaved / NUMTREEINT;
            if (lasttree > treessaved)
                lasttree = treessaved;
            }
        }
    marginalopt(0, treessaved, mlval,peakloc);
    FP" ALL ");
    for (j=0;j<BASICPARAMS;j++) 
		if (iq[j].integrate)
			FP"  %9.4lf %8.4lg ",peakloc[j],mlval[j]);
	FP"\n");
	for (i=0;i<BASICPARAMS;i++) 
		{
        temppeakloc[i] = peakloc[i];
		}
	FP"  95%%Lo");
    for (j=0;j<BASICPARAMS;j++) 
		if (iq[j].integrate)
			{
			temp=margin95(mlval,peakloc,j,0);
			if (temp <= DBL_MIN)
				FP"   <min              ");
			else
				{
				if (temp >= DBL_MAX)
					FP"    na               ");
				else
					FP" %9.4lf            ",temp);
				}
			}		
	FP"\n");
	FP"  95%%Hi");
    for (j=0;j<BASICPARAMS;j++) 
		if (iq[j].integrate)
			{
			temp=margin95(mlval,peakloc,j,1);
			if (temp <= DBL_MIN)
				FP"   >max              ");
			else
				{
				if (temp >= DBL_MAX)
					FP"    na               ");
				else
					FP" %9.4lf            ",temp);
				}
			}

    FP"\n\n");
	if (calcoptions[FINDJOINTPEAK] /*|| calcoptions[LOADRUN] */)
		{
		printf("Finding joint peak location and probability (could take awhile) ");
		FP"\nMultidimensional Peak Location and Posterior Probability\n");
		FP"--------------------------------------------------------\n");
		FP" Set   t       log(P)   ");
		/* ndim = # of integrable parameters */
		for (ndim = 0,i=0;i<BASICPARAMS;i++)
			{
			optconst[i] = -1;
			if (iq[i].integrate)
				{
				optconst[i] = -1;
				ndim++;
				FP"   %s    ",iq[i].str);
				}
			else
				{
				maxvals_for_surface_calls[i] = 0;
				}
			} 
		optinf[0] = ndim;
		optinf[1] = 0;
		FP"\n");
		if (treessaved > 10)
			{
			for (firsttree = 0,lasttree = (int) treessaved / NUMTREEINT,i=0;i<NUMTREEINT;i++)
				{
				closeopenout(outfile,outfilename);
				optinf[2] = firsttree;
				optinf[3] = lasttree;
				annealjointopt(outfile,&mlval[0], peakloc, ndim,30, -1, &t);
				FP"  %2d  %9.4lf %8.4lf ",i,t,log(mlval[0]));
				for (j=0;j<BASICPARAMS;j++) 
					if (iq[j].integrate)
						{
						if (peakloc[j] < 0.001)
							FP" %9.6lf ",peakloc[j]);
						else
							FP" %9.4lf ",peakloc[j]);
						}
				FP"\n");
				firsttree = lasttree+1;
				lasttree += (int) treessaved / NUMTREEINT;
				if (lasttree > treessaved)
					lasttree = treessaved;
				}
			} 
		optinf[2] = 0;
		optinf[3] = treessaved;
		closeopenout(outfile,outfilename);
		annealjointopt(outfile,&mlval[0], peakloc,ndim,30, -1, &t);
		FP" ALL  %9.4lf %8.4lf ",t,log(mlval[0]));
		for (i=0;i<BASICPARAMS;i++) 
			{
			if (iq[i].integrate)
				{
				if (peakloc[i] < 0.001)
					FP" %9.6lf ",peakloc[i]);
				else
					FP" %9.4lf ",peakloc[i]);
				temppeakloc[i] = peakloc[i];
				}
			}

		FP"\n\n");
		*holdmlval = mlval[0];
		for (i=0;i<BASICPARAMS;i++) 
			{
			holdpeakloc[i] = peakloc[i];
			}
		}
	optinf[1] = 0;  
	if (calcoptions[NESTEDMODELS] && (imodel == EFULL || imodel == FULL))
		{
		printf("\nFinding nested model peak locations and probabilities\n");
		FP"\nNested Models Peak Location and Posterior Probability\n");
		FP"------------------------------------------------------\n");
		FP"Model      t          log(P)   ");
		for (i=0;i<BASICPARAMS;i++)
			if (iq[i].integrate)
				FP"   %s     ",iq[i].str);
		FP"  df       2LLR\n");
		optinf[2] = 0;
		optinf[3] = treessaved;
		if (imodel == FULL)
			{
			for (nestedmodel = ABCDD ; nestedmodel <= ABB00; nestedmodel++)
			//for (nestedmodel = AAC00 ; nestedmodel <= ABB00; nestedmodel++)
				{
#ifdef HPDBG
// Clear the debug-heap flag, check memory 
CLEAR_CRT_DEBUG_FIELD( _CRTDBG_DELAY_FREE_MEM_DF );
_CrtCheckMemory( );
#endif
				closeopenout(outfile,outfilename);
				printf("\n model %s ",nestmodinfo[nestedmodel].name);
				annealjointopt(outfile,&mlval[0], temppeakloc,nestmodinfo[nestedmodel].dim,10, -1, &t);
				FP" %s %9.4lf  %10.4lf",nestmodinfo[nestedmodel].name,t,log(mlval[0]));
				for (i=0;i<BASICPARAMS;i++) 
					used[i] = 0;
				for (i=0,j=0;i<BASICPARAMS;i++) 
					{
					strncpy(ts,&(nestmodinfo[nestedmodel].istr[i]),1);
					ts[1] = '\0';
					j = atoi(ts);
					if (j==0)
						FP"[%9.4lf] ",MINPARAMVAL);
					else
						{
						if (used[j-1] == 1)
							{
							if (temppeakloc[j-1] < 0.001)
								FP"[%9.6lf] ",temppeakloc[j-1]);
							else
								FP"[%9.4lf] ",temppeakloc[j-1]);
							}
						else
							{
							if (temppeakloc[j-1] < 0.001)
								FP" %9.6lf  ",temppeakloc[j-1]);
							else
								FP" %9.4lf  ",temppeakloc[j-1]);
							used[j-1] = 1;
							}
						}
					}
				if (nestmodinfo[nestedmodel].dfstar==0)
					FP"   %d      %8.4lf \n", ndim-nestmodinfo[nestedmodel].dim, 2*(log(*holdmlval)-log(mlval[0])));
				else
					FP"   %d*     %8.4lf \n", ndim-nestmodinfo[nestedmodel].dim, 2*(log(*holdmlval)-log(mlval[0])));
				}
			FP"  * test distribution of 2LLR is a mixture \n");
			}
		if (imodel == EFULL)
		for (nestedmodel = AB_DD; nestedmodel <= AA_DD; nestedmodel++)
			{
			closeopenout(outfile,outfilename);
			printf("\n model %s ",nestmodinfo[nestedmodel].name);
			annealjointopt(outfile,&mlval[0], temppeakloc,nestmodinfo[nestedmodel].dim,10, -1, &t);
			FP" %s %8.6lf %10.4lf ",nestmodinfo[nestedmodel].name,mlval[0],log(mlval[0]));
			for (i=0,j=0;i<BASICPARAMS;i++) 
				{
				strncpy(ts,&(nestmodinfo[nestedmodel].istr[i]),1);
				ts[1] = '\0';
				j = atoi(ts);
				if (j==(i+1))
					{
					if (peakloc[i]  < 0.001)
						FP" %9.6lf  ",peakloc[i]);
					else
						FP" %9.4lf  ",peakloc[i]);
					j++;
					}
				else 
					{
					if (j==0)
						FP"[%9.4lf] ",MINPARAMVAL);
					else
						{
						if (peakloc[j-1] < 0.001)
							FP"[%9.6lf] ",peakloc[j-1]);
						else
							FP"[%9.4lf] ",peakloc[j-1]);
						}
					}

				}
			FP"   %d      %8.4lf \n", ndim-nestmodinfo[nestedmodel].dim, 2*(log(*holdmlval)-log(mlval[0])));
			}  
		}
	nestedmodel = imodel; 
	closeopenout(outfile,outfilename);				
	return ndim;
    } /* findpeaks */

#undef LOG2

