/* IMa   for IM_analytic    2007-2009  Jody Hey and Rasmus Nielsen*/ 
/* December 17, 2009 */



#undef GLOBVARS
#include "ima.h"


/* build starting genealogies */
/* revised extensively on 4/23/07

  now all these make.. functions call the same function addedge() to pick coalescent times

  There is a new makeJOINT_IS_SW() 

  now for JOINT_IS_SW makeIS() uses IS criteria to identify the set of pairs that have zero distance, and then uses a distance matrix based on 
	STR distance to pick the pair
 
   addA() is now called both from makeSW()  and from makeJOINT_IS_SW()  (when JOINT_IS_SW)  to add note values
	the node allele values are equal to the descentant allele values when they are identical
	when they are not,  a value from a distribution of lengths in the interval of the descent values is picked

Not really sure how best to do the SW trees.  here is the algorithm
- build a distance matrix
- pick pair with lowest distance
- make a node
- pack an ancestral allele, based on distribution of alleles sizes, given the mutation rate and the branck lengths
- build a new distance matrix and repeat


still not a very good algorithm because it separates coalescent events from migration events,  and the waiting times are not great. 

should simulate coalescence and migration at the same time. 
  */
/*** LOCAL STUFF *****/

static double q1, q2, qa, m1, m2; 
/* have these values set for each chain,  picked by the makeIS, makeHKY and makeSW  functions
the idea is that for any particular chain all the loci will come from a common set of parameter values
should cause the chains to start more spread out */



/* prototypes of local functions*/
int nummig(double startt, double endt, int startpop, int endpop, int tmode, double times[]);
void addedge(int ci, int li, int newedge, int c[], int curgenes, double divt, double *time);
void addA(int ci, int li, int newedge, int *nd0, int *nd1);

int nummig(double startt, double endt, int startpop, int endpop, int tmode, double times[])
	{
	int n, locpop;
	double t, startn;

	do{
		startn = 0;
		if (startpop != endpop  && tmode)
			{/*the first mig. time is simulated conditional on at least one migration event*/
			/*if (startpop == 0)
				ms0++;
			if (startpop == 1)
				ms1++; */
            if ((m1==0 && startpop == 0) || (m2==0 && startpop == 1))  
				return -1;
			if (startpop == 0)		/*this saves time if M is small*/
				//t = startt-(log(1.0-uniform()*(1.0-exp(-m1*(endt-startt)))))/m1;
				times[0] = startt-(log(1.0-uniform()*(1.0-exp(-m1*(endt-startt)))))/m1;
			else 
				//t = startt-(log(1.0-uniform()*(1.0-exp(-m2*(endt-startt)))))/m2;
				times[0] = startt-(log(1.0-uniform()*(1.0-exp(-m2*(endt-startt)))))/m2;
			t = times[0];
			startn++;
			}
		else
			t = startt;
		locpop = endpop;
		n = (int) startn;
		while (t<endt)
			{
			if (locpop == 0)
                {
                if (m1==0)
                    return n;
				else
                    t = t + expo(m1);
                }
			else
                {
                if (m2==0)
                    return n;
                else
                    t = t + expo(m2); 
                }
			if (t < endt)
				{
				locpop=1-locpop;
				times[n] = t;
				n++;
                if (n >= STARTMIGMAX)
                    {
                    printf("migration fault in nummig in step %li\n",step);
		            err(0,-1,30);
                    } 
				}
			}
		}while (locpop!=endpop);
    if (n >= STARTMIGMAX)
        {
        printf("migration fault in nummig in step %li\n",step);
		err(0,-1,30);
        } 
	return n;
	} /* nummig */

void addedge(int ci, int li, int newedge, int c[], int curgenes, double divt, double *time)
	{
	struct edge *tree = C[ci]->L[li].tree;
	double upt, t, q;
	int i,num,j;
	double times[STARTMIGMAX];

	if (*time < divt)
		{
		if (tree[c[0]].pop != tree[c[1]].pop && m1 == 0)
			{
			t = divt;
			q = qa;
			}
		else
			{
			t = *time;
			if (tree[c[0]].pop == 0 && tree[c[1]].pop == 0)
				q = q1;
			else
				if (tree[c[0]].pop == 1 && tree[c[1]].pop == 1)
					q = q2;
				else
					q = (q1+q2)/2; // just use the average if it is necessary to have a migration event
			}
		}
	else
		{
		t = *time;
		q = qa;
		}
	*time = t + expo(((double)(curgenes*(curgenes -1))/(q *C[ci]->L[li].h.val/2)));
    tree[c[0]].time = tree[c[1]].time = *time;
	tree[newedge].up[0] = c[0];
	tree[newedge].up[1] = c[1];
	tree[c[0]].down = tree[c[1]].down = newedge;
	if ((tree[c[0]].pop != tree[c[1]].pop) && *time < divt)
        {
        if (uniform() < 0.5)
           tree[newedge].pop = 0;
        else tree[newedge].pop = 1;
        }
	else 
        if (*time < divt)
            tree[newedge].pop = tree[c[0]].pop;
        else
            tree[newedge].pop = 0;

	for (i=0; i<2; i++)
		{
		if (tree[c[i]].up[0] != -1)
			upt = tree[tree[c[i]].up[0]].time;
		else upt = 0;
		if (upt < divt && m1 > 0)
			{
			if (*time < divt)
				t = *time - upt;
			else t = divt - upt;
			num=nummig(0.0, t, tree[c[i]].pop, tree[newedge].pop, *time < divt, times);
			C[ci]->L[li].mignum += num;
			for (j=0; j<num; j++)
				{
				checkmig(j,&(tree[c[i]].mig), &(tree[c[i]].cmm));
				//*(tree[c[i]].mig +j) = upt + ((double)(j+1))*t/(double)(num+1); 
				*(tree[c[i]].mig +j) = upt + times[j];
				}
			}
		else j=0;
		*(tree[c[i]].mig +j) = -1;	
		}
	} /* addedge */
/*
void oldaddedge(int ci, int li, int newedge, int c[], int curgenes, double divt, double *time)
	{
	struct edge *tree = C[ci]->L[li].tree;
	double upt, t, q;
	int i,num,j;
	if (*time < divt)
		{
		if (tree[c[0]].pop != tree[c[1]].pop && m1 == 0)
			{
			t = divt;
			q = qa;
			}
		else
			{
			t = *time;
			if (tree[c[0]].pop == 0 && tree[c[1]].pop == 0)
				q = q1;
			else
				if (tree[c[0]].pop == 1 && tree[c[1]].pop == 1)
					q = q2;
				else
					q = (q1+q2)/2; 
			}
		}
	else
		{
		t = *time;
		q = qa;
		}
	*time = t + expo(((double)(curgenes*(curgenes -1))/(q *C[ci]->L[li].h.val/2)));
    tree[c[0]].time = tree[c[1]].time = *time;
	tree[newedge].up[0] = c[0];
	tree[newedge].up[1] = c[1];
	tree[c[0]].down = tree[c[1]].down = newedge;
	if ((tree[c[0]].pop != tree[c[1]].pop) && *time < divt)
        {
        if (uniform() < 0.5)
           tree[newedge].pop = 0;
        else tree[newedge].pop = 1;
        }
	else 
        if (*time < divt)
            tree[newedge].pop = tree[c[0]].pop;
        else
            tree[newedge].pop = 0;

	for (i=0; i<2; i++)
		{
		if (tree[c[i]].up[0] != -1)
			upt = tree[tree[c[i]].up[0]].time;
		else upt = 0;
		if (upt < divt && m1 > 0)
			{
			if (*time < divt)
				t = *time - upt;
			else t = divt - upt;
			num=nummig(0.0, t, tree[c[i]].pop, tree[newedge].pop, *time < divt, times);
			C[ci]->L[li].mignum += num;
			for (j=0; j<num; j++)
				{
				checkmig(j,&(tree[c[i]].mig), &(tree[c[i]].cmm));
				*(tree[c[i]].mig +j) = upt + ((double)(j+1))*t/(double)(num+1); 
				}
			}
		else j=0;
		*(tree[c[i]].mig +j) = -1;	
		}
	}  oldaddedge */

/* under JOINT_IS_SW model, alleles states must be added for the SW portion of the genealogy at the beginning */
/* pick a number over the span of the interval between the descendant allele values (+1 on each side), following the bessel function distribution */
void addA(int ci, int li, int newedge, int *nd0, int *nd1)
    {
    int j, ai, aj, up[2], down, newA; 
	struct edge *tree = C[ci]->L[li].tree;
	int d0, d1;
	double u, t0, t1, r;
	double *p;

		
	if (C[ci]->L[li].model==STEPWISE)
		ai = 0;
	else
		ai = 1;
	for (;ai< C[ci]->L[li].nlinked ;ai++)
		{
		u = C[ci]->L[li].u[ai].mcinf.val;
		up[0] = tree[newedge].up[0];
		up[1] = tree[newedge].up[1];
		down = tree[newedge].down;
		p = malloc((abs(tree[up[0]].A[ai] - tree[up[1]].A[ai]) + 3)*sizeof(double));
		if(up[0] < C[ci]->L[li].numgenes)
			t0 = tree[up[0]].time;
		else
			t0 =  tree[up[0]].time - tree[tree[up[0]].up[0]].time;
		myassert(t0 > 0);
		if(up[1] < C[ci]->L[li].numgenes)
			t1 = tree[up[1]].time;
		else
			t1 =  tree[up[1]].time - tree[tree[up[1]].up[0]].time;
		myassert(t1 > 0);
		for (j = 0, aj = IMIN(tree[up[0]].A[ai],tree[up[1]].A[ai]) - 1; aj<= 1+IMAX(tree[up[0]].A[ai],tree[up[1]].A[ai]); aj++, j++)
			{
			d0 = abs(aj-tree[up[0]].A[ai]);
			d1 = abs(aj-tree[up[1]].A[ai]);
			p[j] = exp( -t0 * u + log(bessi(d0, t0*u)) +  -t1 * u + log(bessi(d1, t1*u)));
			if (j > 0) p[j] += p[j-1];
			}
		r = uniform() * p[j-1];
		j = 0;
		while (r > p[j]) j++;
		newA = IMIN(tree[up[0]].A[ai],tree[up[1]].A[ai]) - 1 + j;
		newA = IMAX(C[ci]->L[li].minA[ai],newA);
		newA = IMIN(C[ci]->L[li].maxA[ai],newA);
		*nd0 = abs(newA-tree[up[0]].A[ai]);
		*nd1= abs(newA-tree[up[1]].A[ai]);
		free(p);
		tree[newedge].A[ai] = newA;
		myassert(newA >= C[ci]->L[li].minA[ai]);
		}
    } /* addA */

/*** GLOBAL FUNCTIONS ***/

void makeHKYtree(int ci, int li)
	{
	int c[2], newedge, curgenes, i,j,k, *edgevec;
	double time;
	double divt = C[ci]->t.val;

	if (li == 0)
		{
		m1 = uniform() * (iq[m1i].pr.max /10);
		m2 = uniform() * (iq[m2i].pr.max /10);
		q1 = iq[q1i].pr.max/10 + uniform() * (iq[q1i].pr.max /3);
		q2 = iq[q2i].pr.max/10 + uniform() * (iq[q2i].pr.max /3);
		qa = iq[qai].pr.max/10 + uniform() * (iq[qai].pr.max /3);
		}

    edgevec=malloc((2*C[ci]->L[li].numgenes-1)*sizeof(int));
    for (i=0; i<C[ci]->L[li].numgenes; i++)
            edgevec[i]=1;
	for (i=C[ci]->L[li].numgenes; i<2*C[ci]->L[li].numgenes-1; i++)
            edgevec[i]=-1;



	for (i=0; i<C[ci]->L[li].numpop1; i++)
		C[ci]->L[li].tree[i].pop = 0;
    for (i=C[ci]->L[li].numpop1; i<C[ci]->L[li].numgenes; i++)
		if (modeloptions[ONEPOP])
            {
            C[ci]->L[li].tree[i].pop = 0;
            C[ci]->L[li].numpop1 += C[ci]->L[li].numpop2;
            C[ci]->L[li].numpop2 = 0;
            }
        else
            C[ci]->L[li].tree[i].pop = 1; 
	for (i=0; i<2*C[ci]->L[li].numgenes-1; i++)
		{
		C[ci]->L[li].tree[i].up[0] = C[ci]->L[li].tree[i].up[1] = C[ci]->L[li].tree[i].down = -1;
		}
	for (i=C[ci]->L[li].numgenes; i<2*C[ci]->L[li].numgenes-1; i++)
		{
		C[ci]->L[li].tree[i].hkyi.scalefactor=malloc( C[ci]->L[li].numsites * sizeof(double));
		C[ci]->L[li].tree[i].hkyi.oldscalefactor=malloc( C[ci]->L[li].numsites * sizeof(double));
		for (k=0; k<C[ci]->L[li].numsites; k++)
			{
            C[ci]->L[li].tree[i].hkyi.scalefactor[k]=0.0;
            C[ci]->L[li].tree[i].hkyi.oldscalefactor[k]=0.0;
            }
        C[ci]->L[li].tree[i].hkyi.frac=malloc(C[ci]->L[li].numsites * sizeof(double *));
        C[ci]->L[li].tree[i].hkyi.newfrac=malloc(C[ci]->L[li].numsites * sizeof(double *));
        for (j=0; j<C[ci]->L[li].numsites; j++)
			{
            C[ci]->L[li].tree[i].hkyi.frac[j]=malloc(4 * sizeof(double));
            C[ci]->L[li].tree[i].hkyi.newfrac[j]=malloc(4 *  sizeof(double));
            }
        }
	C[ci]->L[li].mignum  = 0;
	time = 0.0;
    curgenes = C[ci]->L[li].numgenes;
	while (curgenes > 1)
		{
        for (k=0; k<2; k++)
			{
            i= (int) ((curgenes-k) * uniform());
            c[k]=j=-1;
            do{
                c[k]++;
                if (edgevec[c[k]]==1)
                      j++;
                }while (j<i);
            edgevec[c[k]]=-1;
            }
		newedge = 2*C[ci]->L[li].numgenes-curgenes;
        edgevec[newedge]=1;

		addedge(ci,li, newedge, c,curgenes,divt, &time);
		curgenes--;
		}
	C[ci]->L[li].roottime = time;
	C[ci]->L[li].root = C[ci]->L[li].numlines - 1;
	*(C[ci]->L[li].tree[C[ci]->L[li].root].mig) = -1;
	C[ci]->L[li].tree[C[ci]->L[li].root].time = TIMEMAX;
    free(edgevec);
	C[ci]->L[li].hilike = -1e20; 
	} /* makeHKYtree */

/* Rasmus's original code,  but added stuff for SW model
 when the model is JOINT_IS_SW  the sets of pairs of genes are picked following the IS criteria as in Rasmus's code
 but the actual pair that is picked has the smallest squared STR distance among those pairs
 use a matrix of squared STR distances  that goes down one row and column each time thru the loop, using UPGMA-like contraction of matrix*/

void makeIStree( int ci, int li)
	{
	int c[2], newedge, cursites, curgenes, num,coalnum, i,j,k, site, *curid, **distmat, coal[2], *singletons, **tempseq;
	double time;
	double divt = C[ci]->t.val;
	struct edge *tree = C[ci]->L[li].tree;

	if (li == 0)
		{
		m1 = uniform() * (iq[m1i].pr.max /10);
		m2 = uniform() * (iq[m2i].pr.max /10);
		q1 = iq[q1i].pr.max/10 + uniform() * (iq[q1i].pr.max /3);
		q2 = iq[q2i].pr.max/10 + uniform() * (iq[q2i].pr.max /3);
		qa = iq[qai].pr.max/10 + uniform() * (iq[qai].pr.max /3);
		}

	distmat = malloc((C[ci]->L[li].numgenes)*(sizeof(int *)));
	for (i=0; i<C[ci]->L[li].numgenes; i++)
		distmat[i] = malloc((C[ci]->L[li].numgenes)*(sizeof(int)));
	tempseq = malloc(C[ci]->L[li].numgenes*(sizeof(int *)));
	for (i=0; i<C[ci]->L[li].numgenes; i++)
		tempseq[i]=malloc((C[ci]->L[li].numsites)*(sizeof(int)));
	curid = malloc((C[ci]->L[li].numgenes)*(sizeof(int)));
	singletons = malloc((C[ci]->L[li].numsites)*(sizeof(int)));
	curgenes = C[ci]->L[li].numgenes;
	cursites = C[ci]->L[li].numsites;
	for (i=0; i<C[ci]->L[li].numgenes; i++)
		curid[i] = i;
	for (i=0; i<C[ci]->L[li].numpop1; i++)
		tree[i].pop = 0;
	for (i=C[ci]->L[li].numpop1; i<C[ci]->L[li].numgenes; i++)
		if (modeloptions[ONEPOP])
            {
            tree[i].pop = 0;
            C[ci]->L[li].numpop1 += C[ci]->L[li].numpop2;
            C[ci]->L[li].numpop2 = 0;
            }
        else
            tree[i].pop = 1;  
	C[ci]->L[li].mignum  = 0;
	for (i=0; i<2*C[ci]->L[li].numgenes-1; i++)
		{
		tree[i].up[0] = tree[i].up[1] = tree[i].down = -1;
		}
	for (i=0; i<C[ci]->L[li].numgenes; i++)
		{
		for (j=0; j<C[ci]->L[li].numsites; j++)
			tempseq[i][j] = C[ci]->L[li].seq[i][j];
		}
	time = 0.0;
	while (curgenes > 1)
		{
		num = 0;
		for (i=0; i<curgenes; i++)
			{
			for (j=i+1; j<curgenes; j++)
				{
				distmat[i][j] = distmat[j][i] = 0;
				for (site=0; site<cursites; site++)
					{
					if (tempseq[i][site] != tempseq[j][site])
						{
						distmat[i][j]++;
						distmat[j][i]++;
						}
					}
				if (distmat[i][j] == 0)
					num++;
				}
			}
		if (num == 0)
			{
			for (i=0; i<cursites; i++)
				{
				num = 0;
				for (j=0; j<curgenes; j++)
					num = num + tempseq[j][i];
				if (num == 1 || num == (curgenes - 1))
					singletons[i] = 1;
				else singletons[i] = 0;
				}
			num = 0;
			for (i=0; i<curgenes; i++)
				{
				for (j=i+1; j<curgenes; j++)
					{
					distmat[i][j] = distmat[j][i] = 0;
					for (site=0; site<cursites; site++)
						{
						if (tempseq[i][site] != tempseq[j][site] && singletons[site] == 0)
							{
							distmat[i][j]++;
							distmat[j][i]++;
							}
						}
					if (distmat[i][j] == 0)
							num++;
					}
				}
			}
		if (num == 0)
			{
			printf("Data not compatible with infinite sites model in locus %d\n",li);
			for (i=0; i<curgenes; i++)
				{
				printf("seq %i: ",curid[i]);
				for (j=0; j<cursites; j++)
					printf("%i",tempseq[i][j]);
				printf("\n");
				}
			 err(ci, li,81);
			 }
		coalnum = (int)  (uniform()*num);
		num = 0;
		for (i=0; i<curgenes; i++)
			{
			for (j=i+1; j<curgenes; j++)
				{
				if (distmat[i][j] == 0)
					{
					num++;
					if (num > coalnum)
						{
						if (i < j)
							{
							coal[0] = i;
							coal[1] = j;
							}
						else 
							{
							coal[0] = j;
							coal[1] = i;							
							}
						i = curgenes;
						j = curgenes;
						}
					}
				}
			}
		for (i=0; i<cursites; i++)
			{
			if (tempseq[coal[0]][i]!=tempseq[coal[1]][i])
				{
				for (j=0; j<curgenes; j++)
					{
					for (k=i; k<cursites-1; k++)
						tempseq[j][k] = tempseq[j][k+1];
					}
				i--;
				cursites--;
				}
			}
		newedge = 2*C[ci]->L[li].numgenes-curgenes;
		c[0] = curid[coal[0]];
		c[1] = curid[coal[1]];
		addedge(ci,li, newedge, c,curgenes,divt, &time);

		for (i=coal[1]; i<curgenes-1; i++)
			{
			for (j=0; j<cursites; j++)
				tempseq[i][j] = tempseq[i+1][j];
			curid[i] = curid[i+1];
			}
		curid[coal[0]]=newedge;
		curgenes--;
		}
	C[ci]->L[li].roottime = time;
	C[ci]->L[li].root = C[ci]->L[li].numlines - 1;
	*(tree[C[ci]->L[li].root].mig) = -1;
	tree[C[ci]->L[li].root].time = TIMEMAX;
	for (i=0; i<C[ci]->L[li].numgenes; i++)
		free(tempseq[i]);
	free(tempseq);
	for (i=0; i<C[ci]->L[li].numgenes; i++)
		free(distmat[i]);
	free(distmat);
	free(curid);
	free(singletons);
	C[ci]->L[li].hilike = -1e20; 
	//treeprint(ci,li);
    } /* makeIStree */


void makeIStreetemp( int ci, int li)
	{
	int c[2], newedge, cursites, curgenes, num,coalnum, i,j,k, site, *curid, **distmat, coal[2], *singletons, **tempseq;
	double time;
	double divt = C[ci]->t.val;
	struct edge *tree = C[ci]->L[li].tree;

	/*if (li == 0)
		{
		m1 = uniform() * (iq[m1i].pr.max /10);
		m2 = uniform() * (iq[m2i].pr.max /10);
		q1 = iq[q1i].pr.max/10 + uniform() * (iq[q1i].pr.max /3);
		q2 = iq[q2i].pr.max/10 + uniform() * (iq[q2i].pr.max /3);
		qa = iq[qai].pr.max/10 + uniform() * (iq[qai].pr.max /3);
		} */

	m1 = 0.1;
	m2 = 0.1;
	q1 = 1;
	q2 = 1;
	qa = 1;

	distmat = malloc((C[ci]->L[li].numgenes)*(sizeof(int *)));
	for (i=0; i<C[ci]->L[li].numgenes; i++)
		distmat[i] = malloc((C[ci]->L[li].numgenes)*(sizeof(int)));
	tempseq = malloc(C[ci]->L[li].numgenes*(sizeof(int *)));
	for (i=0; i<C[ci]->L[li].numgenes; i++)
		tempseq[i]=malloc((C[ci]->L[li].numsites)*(sizeof(int)));
	curid = malloc((C[ci]->L[li].numgenes)*(sizeof(int)));
	singletons = malloc((C[ci]->L[li].numsites)*(sizeof(int)));
	curgenes = C[ci]->L[li].numgenes;
	cursites = C[ci]->L[li].numsites;
	for (i=0; i<C[ci]->L[li].numgenes; i++)
		curid[i] = i;
	for (i=0; i<C[ci]->L[li].numpop1; i++)
		tree[i].pop = 0;
	for (i=C[ci]->L[li].numpop1; i<C[ci]->L[li].numgenes; i++)
		if (modeloptions[ONEPOP])
            {
            tree[i].pop = 0;
            C[ci]->L[li].numpop1 += C[ci]->L[li].numpop2;
            C[ci]->L[li].numpop2 = 0;
            }
        else
            tree[i].pop = 1;  
	C[ci]->L[li].mignum  = 0;
	for (i=0; i<2*C[ci]->L[li].numgenes-1; i++)
		{
		tree[i].up[0] = tree[i].up[1] = tree[i].down = -1;
		}
	for (i=0; i<C[ci]->L[li].numgenes; i++)
		{
		for (j=0; j<C[ci]->L[li].numsites; j++)
			tempseq[i][j] = C[ci]->L[li].seq[i][j];
		}
	time = 0.0;
	while (curgenes > 1)
		{
		num = 0;
		for (i=0; i<curgenes; i++)
			{
			for (j=i+1; j<curgenes; j++)
				{
				distmat[i][j] = distmat[j][i] = 0;
				for (site=0; site<cursites; site++)
					{
					if (tempseq[i][site] != tempseq[j][site])
						{
						distmat[i][j]++;
						distmat[j][i]++;
						}
					}
				if (distmat[i][j] == 0)
					num++;
				}
			}
		if (num == 0)
			{
			for (i=0; i<cursites; i++)
				{
				num = 0;
				for (j=0; j<curgenes; j++)
					num = num + tempseq[j][i];
				if (num == 1 || num == (curgenes - 1))
					singletons[i] = 1;
				else singletons[i] = 0;
				}
			num = 0;
			for (i=0; i<curgenes; i++)
				{
				for (j=i+1; j<curgenes; j++)
					{
					distmat[i][j] = distmat[j][i] = 0;
					for (site=0; site<cursites; site++)
						{
						if (tempseq[i][site] != tempseq[j][site] && singletons[site] == 0)
							{
							distmat[i][j]++;
							distmat[j][i]++;
							}
						}
					if (distmat[i][j] == 0)
							num++;
					}
				}
			}
		if (num == 0)
			{
			printf("Data not compatible with infinite sites model in locus %d\n",li);
			for (i=0; i<curgenes; i++)
				{
				printf("seq %i: ",curid[i]);
				for (j=0; j<cursites; j++)
					printf("%i",tempseq[i][j]);
				printf("\n");
				}
			 err(ci, li,81);
			 }
		coalnum = (int)  (uniform()*num);
		num = 0;
		for (i=0; i<curgenes; i++)
			{
			for (j=i+1; j<curgenes; j++)
				{
				if (distmat[i][j] == 0)
					{
					num++;
					if (num > coalnum)
						{
						if (i < j)
							{
							coal[0] = i;
							coal[1] = j;
							}
						else 
							{
							coal[0] = j;
							coal[1] = i;							
							}
						i = curgenes;
						j = curgenes;
						}
					}
				}
			}
		for (i=0; i<cursites; i++)
			{
			if (tempseq[coal[0]][i]!=tempseq[coal[1]][i])
				{
				for (j=0; j<curgenes; j++)
					{
					for (k=i; k<cursites-1; k++)
						tempseq[j][k] = tempseq[j][k+1];
					}
				i--;
				cursites--;
				}
			}
		newedge = 2*C[ci]->L[li].numgenes-curgenes;
		c[0] = curid[coal[0]];
		c[1] = curid[coal[1]];
		addedge(ci,li, newedge, c,curgenes,divt, &time);

		for (i=coal[1]; i<curgenes-1; i++)
			{
			for (j=0; j<cursites; j++)
				tempseq[i][j] = tempseq[i+1][j];
			curid[i] = curid[i+1];
			}
		curid[coal[0]]=newedge;
		curgenes--;
		}
	C[ci]->L[li].roottime = time;
	C[ci]->L[li].root = C[ci]->L[li].numlines - 1;
	*(tree[C[ci]->L[li].root].mig) = -1;
	tree[C[ci]->L[li].root].time = TIMEMAX;
	for (i=0; i<C[ci]->L[li].numgenes; i++)
		free(tempseq[i]);
	free(tempseq);
	for (i=0; i<C[ci]->L[li].numgenes; i++)
		free(distmat[i]);
	free(distmat);
	free(curid);
	free(singletons);
	C[ci]->L[li].hilike = -1e20; 
	//treeprint(ci,li);
    } /* makeIStreetemp */


void makeJOINT_IS_SWtree( int ci, int li)
	{
	int c[2], newedge, cursites, curgenes, num,i,j,k, site, *curid, **distmat, *singletons, **tempseq;
	double time;
	double divt = C[ci]->t.val;
	struct edge *tree = C[ci]->L[li].tree;
	double **distmatA;  // for microsats if locus is JOINT_IS_SW
	double distAmax;
	int ai, aj, minA, maxA;
	int  found;  //debugging
	int sumd =0,nd0, nd1;

	if (li == 0)
		{
		m1 = uniform() * (iq[m1i].pr.max /10);
		m2 = uniform() * (iq[m2i].pr.max /10);
		q1 = iq[q1i].pr.max/10 + uniform() * (iq[q1i].pr.max /3);
		q2 = iq[q2i].pr.max/10 + uniform() * (iq[q2i].pr.max /3);
		qa = iq[qai].pr.max/10 + uniform() * (iq[qai].pr.max /3);
		}

	distmat = malloc((C[ci]->L[li].numgenes)*(sizeof(int *)));
	for (i=0; i<C[ci]->L[li].numgenes; i++)
		distmat[i] = malloc((C[ci]->L[li].numgenes)*(sizeof(int)));
	distmatA = malloc((C[ci]->L[li].numgenes)*(sizeof(double *)));
	for (i=0; i<C[ci]->L[li].numgenes; i++)
		{
		distmatA[i] = malloc((C[ci]->L[li].numgenes)*(sizeof(double)));
		}
	C[ci]->L[li].minA = calloc(C[ci]->L[li].nlinked, sizeof(double));
	C[ci]->L[li].maxA = calloc(C[ci]->L[li].nlinked, sizeof(double));
	for (i=C[ci]->L[li].numgenes; i<2*C[ci]->L[li].numgenes-1; i++)
		{
		tree[i].A = calloc(C[ci]->L[li].nlinked, sizeof(int));
		tree[i].dlikeA = calloc(C[ci]->L[li].nlinked, sizeof(double));
		}
	for (ai = 1;ai< C[ci]->L[li].nlinked ;ai++)
		{
		minA = 1000;
		maxA = 0;
		for (i=0;i < C[ci]->L[li].numgenes;i++)
			{
			if (minA > tree[i].A[ai])
				minA = tree[i].A[ai];
			if (maxA < tree[i].A[ai])
				maxA = tree[i].A[ai];
			}

		C[ci]->L[li].minA[ai] = IMAX(1, ((maxA+minA)/2) - (maxA-minA) );
		C[ci]->L[li].maxA[ai] = IMIN(1000, ((maxA+minA)/2) + (maxA-minA) );
		for (i=C[ci]->L[li].numgenes;i<2*C[ci]->L[li].numgenes-1;i++)
			tree[i].A[ai] = -1;
		}

	tempseq = malloc(C[ci]->L[li].numgenes*(sizeof(int *)));
	for (i=0; i<C[ci]->L[li].numgenes; i++)
		tempseq[i]=malloc((C[ci]->L[li].numsites)*(sizeof(int)));
	curid = malloc((C[ci]->L[li].numgenes)*(sizeof(int)));
	singletons = malloc((C[ci]->L[li].numsites)*(sizeof(int)));
	curgenes = C[ci]->L[li].numgenes;
	cursites = C[ci]->L[li].numsites;
	for (i=0; i<C[ci]->L[li].numgenes; i++)
		curid[i] = i;
	for (i=0; i<C[ci]->L[li].numpop1; i++)
		tree[i].pop = 0;
	for (i=C[ci]->L[li].numpop1; i<C[ci]->L[li].numgenes; i++)
		if (modeloptions[ONEPOP])
            {
            tree[i].pop = 0;
            C[ci]->L[li].numpop1 += C[ci]->L[li].numpop2;
            C[ci]->L[li].numpop2 = 0;
            }
        else
            tree[i].pop = 1;  
	C[ci]->L[li].mignum  = 0;
	for (i=0; i<2*C[ci]->L[li].numgenes-1; i++)
		{
		tree[i].up[0] = tree[i].up[1] = tree[i].down = -1;
		}
	for (i=0; i<C[ci]->L[li].numgenes; i++)
		{
		for (j=0; j<C[ci]->L[li].numsites; j++)
			tempseq[i][j] = C[ci]->L[li].seq[i][j];
		}
	time = 0.0;
	while (curgenes > 1)
		{
		num = 0;
		for (i=0; i<curgenes; i++)
			{
			for (j=i+1; j<curgenes; j++)
				{
				distmat[i][j] = distmat[j][i] = 0;
				for (site=0; site<cursites; site++)
					{
					if (tempseq[i][site] != tempseq[j][site])
						{
						distmat[i][j]++;
						distmat[j][i]++;
						}
					}
				if (distmat[i][j] == 0)
					num++;
				}
			}
		if (num == 0)
			{
			for (i=0; i<cursites; i++)
				{
				num = 0;
				for (j=0; j<curgenes; j++)
					num = num + tempseq[j][i];
				if (num == 1 || num == (curgenes - 1))
					singletons[i] = 1;
				else singletons[i] = 0;
				}
			num = 0;
			for (i=0; i<curgenes; i++)
				{
				for (j=i+1; j<curgenes; j++)
					{
					distmat[i][j] = distmat[j][i] = 0;
					for (site=0; site<cursites; site++)
						{
						if (tempseq[i][site] != tempseq[j][site] && singletons[site] == 0)
							{
							distmat[i][j]++;
							distmat[j][i]++;
							}
						}
					if (distmat[i][j] == 0)
							num++;
					}
				}
			}
		if (num == 0)
			{
			printf("Data not compatible with infinite sites model in locus %d\n", li);
			for (i=0; i<curgenes; i++)
				{
				printf("seq %i: ",curid[i]);
				for (j=0; j<cursites; j++)
					printf("%i",tempseq[i][j]);
				printf("\n");
				}
			 err(ci, li,81);
			 }
		for (i=0; i< C[ci]->L[li].numgenes - 1; i++)
			{
			distmatA[i][i] = 0;
			for (j=i+1; j< C[ci]->L[li].numgenes ; j++)
				distmatA[j][i] = distmatA[i][j] = 0;
			}

		for (i=0; i<curgenes - 1; i++)
			{
			distmatA[i][i] = 0;
			for (j=i+1; j<curgenes; j++)
				{
				distmatA[i][j] = distmatA[j][i] = 0;
				for (k = 1;k < C[ci]->L[li].nlinked; k++)
					distmatA[i][j] += SQR(abs(tree[curid[i]].A[k] - tree[curid[j]].A[k]));
				distmatA[j][i] = distmatA[i][j];
				}
			}

		distAmax = 1e20; // large value;	 
		num = 0;
		found = 0;
		for (i=0; i<curgenes -1; i++)
			{
			for (j=i+1; j<curgenes; j++)
				{
				if (distmat[i][j] == 0)
					{
					if (distAmax > distmatA[i][j])
						{
						distAmax = distmatA[i][j];
						ai = i;
						aj = j;
						found = 1;
						}
					}
				}
			}
		for (i=0; i<cursites; i++)
			{
			if (tempseq[ai][i]!=tempseq[aj][i])
				{
				for (j=0; j<curgenes; j++)
					{
					for (k=i; k<cursites-1; k++)
						tempseq[j][k] = tempseq[j][k+1];
					}
				i--;
				cursites--;
				}
			}
		c[0] = curid[ai];
		c[1] = curid[aj];
		myassert(found);
		newedge = 2*C[ci]->L[li].numgenes-curgenes;
		addedge(ci,li, newedge, c,curgenes,divt, &time);
		addA(ci,li, newedge, &nd0,&nd1);
		sumd += (nd0+nd1);

		for (i=aj; i<curgenes-1; i++)
			{
			for (j=0; j<cursites; j++)
				tempseq[i][j] = tempseq[i+1][j];
			curid[i] = curid[i+1];
			}
		curid[ai]=newedge;
		curgenes--;
		}
	C[ci]->L[li].roottime = time;
	C[ci]->L[li].root = C[ci]->L[li].numlines - 1;
	*(tree[C[ci]->L[li].root].mig) = -1;
	tree[C[ci]->L[li].root].time = TIMEMAX;
	for (i=0; i<C[ci]->L[li].numgenes; i++)
		free(tempseq[i]);
	free(tempseq);
	for (i=0; i<C[ci]->L[li].numgenes; i++)
		free(distmat[i]);
	free(distmat);
	if (C[ci]->L[li].model == JOINT_IS_SW)
		{
		for (i=0; i<C[ci]->L[li].numgenes; i++)
			{
			free(distmatA[i]);
			}
		free(distmatA);
		}
	free(curid);
	free(singletons);
	C[ci]->L[li].hilike = -1e20; 
    } /* makeJOINT_IS_SWtree */

void makeSWtree(int ci, int li)
	{
    int i, j, k, ai,aj;
    int curgenes, newedge, c[2];
	double time;
	struct edge *tree = C[ci]->L[li].tree;
	double divt = C[ci]->t.val;
	double **distmatA; 
	int *ids;
	double distAmax;
	int minA, maxA;
	int sumd = 0,nd0, nd1;
	
	if (li == 0)
		{
		m1 = uniform() * (iq[m1i].pr.max /10);
		m2 = uniform() * (iq[m2i].pr.max /10);
		q1 = iq[q1i].pr.max/10 + uniform() * (iq[q1i].pr.max /3);
		q2 = iq[q2i].pr.max/10 + uniform() * (iq[q2i].pr.max /3);
		qa = iq[qai].pr.max/10 + uniform() * (iq[qai].pr.max /3);
		}
	C[ci]->L[li].minA = calloc(C[ci]->L[li].nlinked, sizeof(double));
	C[ci]->L[li].maxA = calloc(C[ci]->L[li].nlinked, sizeof(double));
	for (i=C[ci]->L[li].numgenes; i<2*C[ci]->L[li].numgenes-1; i++)
		{
		tree[i].A = calloc(C[ci]->L[li].nlinked, sizeof(int));
		tree[i].dlikeA = calloc(C[ci]->L[li].nlinked, sizeof(double));
		}
	for (ai = 0;ai< C[ci]->L[li].nlinked ;ai++)
		{
		minA = 1000;
		maxA = 0;
		for (i=0;i < C[ci]->L[li].numgenes;i++)
			{
			if (minA > tree[i].A[ai])
				minA = tree[i].A[ai];
			if (maxA < tree[i].A[ai])
				maxA = tree[i].A[ai];
			}

		C[ci]->L[li].minA[ai] = IMAX(1, ((maxA+minA)/2) - (maxA-minA) );
		C[ci]->L[li].maxA[ai] = IMIN(1000, ((maxA+minA)/2) + (maxA-minA) );
		for (i=C[ci]->L[li].numgenes;i<2*C[ci]->L[li].numgenes-1;i++)
			tree[i].A[ai] = -1;
		}

	distmatA = malloc((C[ci]->L[li].numgenes)*(sizeof(double *)));
	ids = malloc((C[ci]->L[li].numgenes)*(sizeof(int)));
	for (i=0; i<C[ci]->L[li].numgenes; i++)
		{
		ids[i] = i;
		distmatA[i] = malloc((C[ci]->L[li].numgenes)*(sizeof(double)));
		}
	time = 0;
    curgenes = C[ci]->L[li].numgenes;
    for (i=0; i<C[ci]->L[li].numpop1; i++)
		tree[i].pop = 0;
	for (i=C[ci]->L[li].numpop1; i<C[ci]->L[li].numgenes; i++)
		tree[i].pop = 1;
	for (i=0; i<2*C[ci]->L[li].numgenes-1; i++)
        {
		tree[i].up[0] = tree[i].up[1] = tree[i].down = -1;
        tree[i].mig[0] = -1;
        }
	C[ci]->L[li].mignum  = 0;
    newedge = C[ci]->L[li].numgenes; 
    do  {
		for (i=0; i< C[ci]->L[li].numgenes - 1; i++)
			{
			distmatA[i][i] = 0;
			for (j=i+1; j< C[ci]->L[li].numgenes ; j++)
				distmatA[j][i] = distmatA[i][j] = 0;
			}

		for (i=0; i<curgenes - 1; i++)
			for (j=0; j<curgenes; j++)
				{
				distmatA[i][j] = distmatA[j][i] = 0;
				for (k = 0;k < C[ci]->L[li].nlinked ; k++)
					distmatA[i][j] += SQR(abs(tree[ids[i]].A[k] - tree[ids[j]].A[k]));
				distmatA[j][i] = distmatA[i][j];
				}
		distAmax = 1e20; // large value;	 
		for (i=0; i<curgenes; i++)
			for (j=i+1; j<curgenes; j++)
				{
				if (distAmax > distmatA[i][j])
					{
					distAmax = distmatA[i][j];
					ai = i;
					aj = j;
					}
				}
		/* give new ids to positions ai and aj */
		
		//replace columns and rows associated with coal[0] with the average of values involving coal[0] and coal[1];
			//like a upgma contraction of matrix
		c[0] = ids[ai];
		c[1] = ids[aj];
		addedge(ci,li, newedge, c,curgenes,divt, &time);
		addA(ci,li, newedge, &nd0,&nd1);
		ids[ai] = newedge;
		for (i = aj; i< curgenes - 1; i++)
			ids[i] = ids[i+1];
		sumd += (nd0+nd1);
		newedge++;
        curgenes--;
        }
    while (newedge < 2*C[ci]->L[li].numgenes-1);
	C[ci]->L[li].roottime = time;
	C[ci]->L[li].root = C[ci]->L[li].numlines - 1;
	*(tree[C[ci]->L[li].root].mig) = -1;
	tree[C[ci]->L[li].root].time = TIMEMAX;
	//treeweight(ci, li, C[ci]->t.val);
	for (i=0; i<C[ci]->L[li].numgenes; i++)
		{
		free(distmatA[i]);
		}
	free(distmatA);
	free(ids);
	C[ci]->L[li].hilike = -1e20; 
    } /* makeSWtree */


