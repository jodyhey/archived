/* IMa   for IM_analytic    2007-2009  Jody Hey and Rasmus Nielsen*/ 
/* December 17, 2009 */

#undef GLOBVARS
#include "ima.h"  // may not really be needed

/******** LOCAL STUFF ***********/

#define NRANSI
#define NR_END 1
#define FREE_ARG char*

/* local function prototypes */
float *vector(long nl, long nh);
void free_vector(float *v, long nl, long nh);
float **matrix(long nrl, long nrh, long ncl, long nch);
void free_matrix(float **m, long nrl, long nrh, long ncl, long nch);
static double sign(double a,double b);


float *vector(long nl, long nh)
/* allocate a float vector with subscript range v[nl..nh] */
{
	float *v;
	v=(float *)malloc((size_t) ((nh-nl+1+NR_END)*sizeof(float)));
	if (!v) nrerror("allocation failure in vector()");
	return v-nl+NR_END;
}

void free_vector(float *v, long nl, long nh)
/* free a float vector allocated with vector() */
{
	free((FREE_ARG) (v+nl-NR_END));
}

float **matrix(long nrl, long nrh, long ncl, long nch)
/* allocate a float matrix with subscript range m[nrl..nrh][ncl..nch] */
{
	long i, nrow=nrh-nrl+1,ncol=nch-ncl+1;
	float **m;

	/* allocate pointers to rows */
	m=(float **) malloc((size_t)((nrow+NR_END)*sizeof(float*)));
	if (!m) nrerror("allocation failure 1 in matrix()");
	m += NR_END;
	m -= nrl;

	/* allocate rows and set pointers to them */
	m[nrl]=(float *) malloc((size_t)((nrow*ncol+NR_END)*sizeof(float)));
	if (!m[nrl]) nrerror("allocation failure 2 in matrix()");
	m[nrl] += NR_END;
	m[nrl] -= ncl;

	for(i=nrl+1;i<=nrh;i++) m[i]=m[i-1]+ncol;

	/* return pointer to array of pointers to rows */
	return m;
}

void free_matrix(float **m, long nrl, long nrh, long ncl, long nch)
/* free a float matrix allocated by matrix() */
{
	free((FREE_ARG) (m[nrl]+ncl-NR_END));
	free((FREE_ARG) (m+nrl-NR_END));
}

static double sign(double a,double b)
{
  if (b > 0.0)
    return fabs(a);
  else
    return (-fabs(a));
}



/************ GLOBAL FUNCTIONS ******************/


/* NR stuff for finding minimum using golden section */


#define gold            1.618034
#define glimit          100.0
#define tiny            1.0e-20
#define r               0.61803399

/* modified mnbrak() and golden() from NR code.  used only for the one dimensional optimization */
void mnbrakmod(int ndim, int firsttree, int lasttree, double *ax,double *bx,double *cx,double *fa,double *fb,double *fc, double (*func)(int,int,int,double))
{
  /* Programs using routine MNBRAK must supply an EXTERNAL
  FUNCTION func(x:REAL):REAL FOR which a minimum is TO be found */
  /* I converted this to a function and included code to check for
     a failure to find a braket*/
  double ulim, u, rr, q, fu, dum;
  int found;

  *fa = func(ndim, firsttree, lasttree,*ax);
  *fb = func(ndim, firsttree, lasttree,*bx);
  if (*fb > *fa) {
    dum = *ax;
    *ax = *bx;
    *bx = dum;
    dum = *fb;
    *fb = *fa;
    *fa = dum;
  }
  *cx = fabs(*bx + gold * (*bx - *ax));
  *fc = func(ndim, firsttree, lasttree,*cx);
_L1:
  /* need to add some excapes for floating point problems */
  if (*fb >= *fc && *fb > -DBL_MAX && !(*fb==0 && *fc == 0)) {
    rr = (*bx - *ax) * (*fb - *fc);
    q = (*bx - *cx) * (*fb - *fa);
    u = (double) *bx - ((*bx - *cx) * q - (*bx - *ax) * rr) /
         (2.0 * sign(FMAX(fabs(q - rr), (float) tiny), q - rr));
    ulim = *bx + glimit * (*cx - *bx);
    if ((*bx - u) * (u - *cx) > 0.0) {
      fu = func(ndim, firsttree, lasttree,u);
      if (fu < *fc) {
   *ax = *bx;
   *fa = *fb;
   *bx = u;
   *fb = fu;
   goto _L1;
      }
      if (fu > *fb) {
   *cx = u;
   *fc = fu;
   goto _L1;
      }
      u = *cx + gold * (*cx - *bx);
      
      fu = func(ndim, firsttree, lasttree,u);
    } else if ((*cx - u) * (u - ulim) > 0.0) {
      
      fu = func(ndim, firsttree, lasttree,u);
      if (fu < *fc) {
   *bx = *cx;
   *cx = u;
   u = *cx + gold * (*cx - *bx);
   *fb = *fc;
   *fc = fu;
   
   fu = func(ndim, firsttree, lasttree,u);
      }
    } else if ((u - ulim) * (ulim - *cx) >= 0.0) {
      u = ulim;
      
      fu = func(ndim, firsttree, lasttree,u);
    } else {
      u = *cx + gold * (*cx - *bx);
      
      fu = func(ndim, firsttree, lasttree,u);
    }
    *ax = *bx;
    *bx = *cx;
    *cx = u;
    *fa = *fb;
    *fb = *fc;
    *fc = fu;
    goto _L1;
  }
  if (*fb < -DBL_MAX)
	  printf(" minus infinity in mnbrakmod \n");
  found = 1;
}

#undef gold
#undef glimit
#undef tiny

   

double goldenmod(int ndim, int firsttree, int lasttree, double ax,double  bx,double cx,double tol_,double *xmin, double (*func)(int,int,int,double))
{
  /* Programs using routine GOLDEN must supply an EXTERNAL
  FUNCTION func(x:REAL):REAL whose minimum is TO be found. */
  double Result, f1, f2, c, x0, x1, x2, x3;

  c = 1.0 - r;
  x0 = ax;
  x3 = cx;
  if (fabs(cx - bx) > fabs(bx - ax)) {
    x1 = bx;
    x2 = bx + c * (cx - bx);
  } else {
    x2 = bx;
    x1 = bx - c * (bx - ax);
  }
  f1 = func(ndim, firsttree, lasttree,x1);
  f2 = func(ndim, firsttree, lasttree,x2);
  while (fabs(x3 - x0) > tol_ * (fabs(x1) + fabs(x2)) && (x3 > -DBL_MAX)) {
    if (f2 < f1) {
      x0 = x1;
      x1 = x2;
      x2 = r * x1 + c * x3;
      f1 = f2;
      f2 = func(ndim, firsttree, lasttree,x2);
      continue;
    }
    x3 = x2;
    x2 = x1;
    x1 = r * x2 + c * x0;
    f2 = f1;
    f1 = func(ndim, firsttree, lasttree,x1);
  }
  if (f1 < f2) {
    Result = f1;
    *xmin = x1;
  } else {
    Result = f2;
    *xmin = x2;
  }
  if (x3 < -DBL_MAX)
	  printf(" minus infinity in goldenmod \n");
  return Result;
}                            

#undef r


// NR stuff for simulated annealing search 

#define GET_PSUM \
               for (n=1;n<=ndim;n++) {\
               for (sum=0.0,m=1;m<=mpts;m++) sum += p[m][n];\
               psum[n]=sum;}
float tt;

void amebsa(float **p, float y[], int ndim, float pb[], float *yb, float ftol,
   float (*funk)(float [], int code), int *iter, float temptr, int code)
{
   float amotsa(float **p, float y[], float psum[], int ndim, float pb[],
      float *yb, float (*funk)(float [], int code), int ihi, float *yhi, float fac, int code);
   //float ran1(long *idum);
   int i,ihi,ilo,j,m,n,mpts=ndim+1;
   float rtol,sum,swap,yhi,ylo,ynhi,ysave,yt,ytry,*psum;

   psum=vector(1,ndim);
   tt = -temptr;
   GET_PSUM
   for (;;) {
      ilo=1;
      ihi=2;
      //ynhi=ylo=y[1]+tt*log(ran1(&idum));
      //yhi=y[2]+tt*log(ran1(&idum));
	  ynhi=ylo=y[1]+ tt* (float) log(uniform());
      yhi=y[2]+tt* (float) log(uniform());
      if (ylo > yhi) {
         ihi=1;
         ilo=2;
         ynhi=yhi;
         yhi=ylo;
         ylo=ynhi;
      }
      for (i=3;i<=mpts;i++) {
         //yt=y[i]+tt*log(ran1(&idum));
		 yt=y[i]+tt* (float) log(uniform());
		 if (yt <= ylo) {
            ilo=i;
            ylo=yt;
         }
         if (yt > yhi) {
            ynhi=yhi;
            ihi=i;
            yhi=yt;
         } else if (yt > ynhi) {
            ynhi=yt;
         }
      }
      rtol= (double) 2.0*fabs(yhi-ylo)/(fabs(yhi)+fabs(ylo));
      if (rtol < ftol || *iter < 0) {
         swap=y[1];
         y[1]=y[ilo];
         y[ilo]=swap;
         for (n=1;n<=ndim;n++) {
            swap=p[1][n];
            p[1][n]=p[ilo][n];
            p[ilo][n]=swap;
         }
         break;
      }
      *iter -= 2;
//if (code) {printf("a1 ");}
      ytry=amotsa(p,y,psum,ndim,pb,yb,funk,ihi,&yhi,-1.0, code);
      if (ytry <= ylo) {
//if (code) {printf("a2 ");}
         ytry=amotsa(p,y,psum,ndim,pb,yb,funk,ihi,&yhi,2.0, code);
      } else if (ytry >= ynhi) {
         ysave=yhi;
//if (code) {printf("a3 ");}
         ytry=amotsa(p,y,psum,ndim,pb,yb,funk,ihi,&yhi,0.5, code);
         if (ytry >= ysave) {
            for (i=1;i<=mpts;i++) {
               if (i != ilo) {
                  for (j=1;j<=ndim;j++) {
                     psum[j]= (double) 0.5*(p[i][j]+p[ilo][j]);
                     p[i][j]=psum[j];
                  }
//if (code) {printf("a4 ");}
                  y[i]=(*funk)(psum, code);
               }
            }
            *iter -= ndim;
            GET_PSUM
         }
      } else ++(*iter);
   }
   free_vector(psum,1,ndim);
}
#undef GET_PSUM

extern long idum;
extern float tt;

__forceinline float amotsa(float **p, float y[], float psum[], int ndim, float pb[],
   float *yb, float (*funk)(float [], int code), int ihi, float *yhi, float fac, int code)
{
   //float ran1(long *idum);
   int j;
   float fac1,fac2,yflu,ytry,*ptry;

   ptry=vector(1,ndim);
   fac1=(1.0-fac)/ndim;
   fac2=fac1-fac;
   for (j=1;j<=ndim;j++)
      ptry[j]=psum[j]*fac1-p[ihi][j]*fac2;
//if (code) {printf("aa1 ");}
   ytry=(*funk)(ptry, code);
   if (ytry <= *yb) {
      for (j=1;j<=ndim;j++) pb[j]=ptry[j];
      *yb=ytry;
   }
   //yflu=ytry-tt*log(ran1(&idum));
//if (code) {printf("a2 ");}
   yflu=ytry-tt* (float) log(uniform());
   if (yflu < *yhi) {
      y[ihi]=ytry;
      *yhi=yflu;
      for (j=1;j<=ndim;j++) {
         psum[j] += ptry[j]-p[ihi][j];
         p[ihi][j]=ptry[j];
      }
   }
   free_vector(ptry,1,ndim);
   return yflu;
}
#undef NRANSI
