/* IMa   for IM_analytic    2007-2009  Jody Hey and Rasmus Nielsen*/ 
/* December 17, 2009 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <float.h>
#include <limits.h>
#include <time.h>
#include <ctype.h>
#include <assert.h>

/* Microsoft compilers use _findfirst and _findnext to search directories for files.  Most other compilers use a library called dirent.  It is not a formal standard
but is very widespread.  dirent does not have _findfirst or _findnext but instead uses functions called  opendir() closedir() readdir() and rewinddir().  
In order for this code to be portable,  I've included a file called sdirent that maps the usual dirent functions calls onto the microsoft functions.  If the compiler 
is not microsoft, then this file is not included, and the regular direct is used */

#ifdef _MSC_VER
#include <io.h>
#include "msdirent.h"
#include <errno.h> /* _findfirst and _findnext set errno iff they return -1 so these must be included*/
//#elif  __GNUC__
#else
#include <dirent.h>
#endif



#ifndef _MSC_VER
#ifndef __forceinline
#define __forceinline __attribute__((__always_inline__)) inline
#endif
#endif

/* microsft visual studio compiler stuff */
/* disable deprecate warning  C4996 */
#pragma warning( disable : 4996)

/***********************************************/
/******** DEBUG RELATED OPTIONS ****************/
/***********************************************/
/* debugging related definitions */
/*MVC++  defines _DEBUG  under debug version, and NDEBUG  under Release version*/
/* can define these to add extra debugging routines,*/
/* to use the myassert function define USE_MYASSERT */
/* under MVC++  do not turn on speed optimzation or if you do, be sure to retain inequality checking with /Op */ 

// use this for debugging dynamic memory stuff 
#undef HPDBG
//#define HPDBG

/* change this HPDBG section 4/2/08 */
#ifdef HPDBG
#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>
#define  SET_CRT_DEBUG_FIELD(a) \
            _CrtSetDbgFlag((a) | _CrtSetDbgFlag(_CRTDBG_REPORT_FLAG))
#define  CLEAR_CRT_DEBUG_FIELD(a) \
            _CrtSetDbgFlag(~(a) & _CrtSetDbgFlag(_CRTDBG_REPORT_FLAG))
#else
#define  SET_CRT_DEBUG_FIELD(a)   ((void) 0)
#define  CLEAR_CRT_DEBUG_FIELD(a) ((void) 0)
#endif

#ifdef _DEBUG
#define USE_MYASSERT 
#define MYDEBUG
#endif

//#define USE_MYASSERT 
#ifndef USE_MYASSERT
#define myassert(a)
#endif
// use this if need to address over multiple Gigs of RAM
// include /LARGEADDRESSAWARE 


/***********************************************/
/******** SIMPLE DEFINITIONS MACROS ************/
/***********************************************/

/* CONSTANTS */
#define MAXLOCI   150
#define MAXCHAINS 20000
#define FNSIZE    100  // max file name length
#define NAMELENGTH 151    // max length of population names
#define MAXLINKED 15 // largest number of linked loci with the same genealogy - each neads its own mutation rate
#define TIMEMAX 1000000.0  // no branch can have a bottom time greater than this 
#define MINPARAMVAL 0.0001        // smallest parameter value for parameters that are in the MCMC
#define STARTMIGMAX 1000 /* max number per edge when trees are first built */
#define ADDMIGMAX 1000 /* max of number of mirgrations that can be added by poisson generator */
#define ABSMIGMAX  5000  /* absolute maximum # of migration events allowed */ 
#define MIGINC 20 /* number of possbile migration events to add to branch migration array at a time */
#define BASICPARAMS  5   // the basic number of integrable parameters (3 thetas, 2 migration rates)
#define DEFCHAINS  1   // default # chains
#define RECORDINTDEFAULT 10   // default # of steps between recording values of things - used to call record()
#define SAVETREEINTDEFAULT 100  // default # of steps between recording information about the genealogies
#define AUTOCTERMS 12   // the number of lag values for which autocorrelations are recorded
#define CHECKAUTOCWAIT 10000   /* 100000 */  // number of steps before recording autocorrelation values
#define AUTOCINT 1000         // interval between measurements for autocorrelations when there is 1 chain - I don't think this can be changed easily
#define AUTOCNEXTARRAYLENGTH 1000  /* largest value in checkstep[] divided by AUTOCINT */
#define AUTOCCUTOFF 100  /*500 */  /* minimum number of measurements to have for autocorrelation before printing results */
#define NUMSTRL  11
#define gridsize 1000         // # of bins in histogram
#define TRENDDIM 500              // number of points saved for the trendline plots
#define margin2dgridsize 50    // # of bins on each axis in 2D histograms
#define profilegridsize 50 // 100 //30  // # points along single dimension profile curve
#define MAXTREESTOSAVE   500000   // the max to save in ram during a run
#define PRINTINTDEFAULT 10000      // default # steps between writing to the screen
#define MAXLOADFILES 500            // max # of files with tree information that can be loaded 
#define UMAX  10000     // highest value for u scalars  - can differ by UMAX^2 fold
#define HMAX  20       // highest value for h scalars, if HMAX=20 it gives a range of ratios for h scalars from 1/20  to 20  (i.e. they can differ by up to 400 fold)

/* MACROS  */
#define  MYDBL_MAX DBL_MAX/1e10    // these avoid some over- under-flow issues, I think.  Not used much. May not be necessary
#define  MYDBL_MIN DBL_MIN * 1e10
#define ROUND(a) (long) ((a)+0.5)  // crude rounding
#define ODD(a) ( ((a) & 1) == 1 ? 1 : 0 )  /* for nonnegative integers , if odd returns 1, else 0*/
#define FP fprintf(outfile,     // handy way to avoid retyping the same thing again and again
#define SP fpstri += sprintf(&fpstr[fpstri],   // used to add text to the long string (called 'fpstr') that goes at the beginning of the output files 
#define f_close(a)  fclose(a); (a) = NULL      //regular close() does not make the pointer null,  but it is useful to have this set to null
#define err(a,b,c) errr((a),(b),(c),(0),(0))    //usually simplest to call err(), but if more info is needed to close with,  can call errr()

// these are all bulletproof macros suggested by Melissa Hibnuz
static double sqrarg;
#define SQR(a) ((sqrarg=(a)) == 0.0 ? 0.0 : sqrarg*sqrarg)
static double dmaxarg1,dmaxarg2;
#define DMAX(a,b) (dmaxarg1=(a),dmaxarg2=(b),(dmaxarg1) > (dmaxarg2) ? (dmaxarg1) : (dmaxarg2))
static double dminarg1,dminarg2;
#define DMIN(a,b) (dminarg1=(a),dminarg2=(b),(dminarg1) < (dminarg2) ? (dminarg1) : (dminarg2))
static float maxarg1,maxarg2;
#define FMAX(a,b) (maxarg1=(a),maxarg2=(b),(maxarg1) > (maxarg2) ? (maxarg1) : (maxarg2))
static float minarg1,minarg2;
#define FMIN(a,b) (minarg1=(a),minarg2=(b),(minarg1) < (minarg2) ? (minarg1) : (minarg2))
static long lmaxarg1,lmaxarg2;
#define LMAX(a,b) (lmaxarg1=(a),lmaxarg2=(b),(lmaxarg1) > (lmaxarg2) ? (lmaxarg1) : (lmaxarg2))
static long lminarg1,lminarg2;
#define LMIN(a,b) (lminarg1=(a),lminarg2=(b),(lminarg1) < (lminarg2) ? (lminarg1) : (lminarg2))
static int imaxarg1,imaxarg2;
#define IMAX(a,b) (imaxarg1=(a),imaxarg2=(b),(imaxarg1) > (imaxarg2) ? (imaxarg1) : (imaxarg2))
static int iminarg1,iminarg2;
#define IMIN(a,b) (iminarg1=(a),iminarg2=(b),(iminarg1) < (iminarg2) ? (iminarg1) : (iminarg2))



/******************************************/
/****** ENUMERATED THINGS ************/
/******************************************/

/*  jhey personal options using -jh flag
	SWINPUTOPTION   alternate way of inputing SW data when there is just one SW portion for a given locus 
	LOADPARAM  read in a set of values at which to estimate the likelihood, in order q1, q2, qA, m1, m2
	ESTIMATEMAXLIKELIHOOD - try to estimate the maximum likelihood
	*/
enum  {SWINPUTOPTION = 0,LOADPARAM,ESTIMATEMAXLIKELIHOOD};


/*  model options  using the -j flag
    RETURNPRIOR - likelihood functions return 1 , i.e. no data - use for debugging
	POPSIZEPRIORSETMODE - default = = 0  use command line value as a scaler,  =1 use command line value as actual upper bound,
	UPDATEH  - treat inheritance scalar as parameters
	MUTATIONPRIORRANGE - include pior ranges on mutation rate scalrs, as included in input file
    EQUILIBRIUMMIGRATION  - fix t to a v. large value and qa to a v. small value 
    ONEPOP - set t=0 so that the model is just a single population
		remove this:  COMMONTHETA - set theta1 = theta2 = thetaA
		remove this:  COMMONMIGRATION - set m1=m2
*/
enum  {RETURNPRIOR =0,POPSIZEPRIORSETMODE,UPDATEH,MUTATIONPRIORRANGE,EQUILIBRIUMMIGRATION,ONEPOP};

/* output options -p
   DONTSAVETREES  - save tree information for analytical integration  
   PRINTTMRCA - print a table of the TMRCA distribution 
   DEMOGHIST - print out distributions on demographic scales - requires mutation rates and generation times 
   MIGRATEDIST - print out distributions of numbers and times of migration events
   PRINTASCIITREND - print ascii trend lines
   PRINTASCIICURVE - print ascii curves
   PRINT2DMARGINALS  - print a file with mathematica listplot function for plotting 2d marginal distributions
// these values are not set using -p flags 
   CHECKPOINTFILEWRITE - write to checkpoint file, details in -e and -d options 
   CHECKPOINTFILEREAD - start run from a checkpoint file
   RESTARTBURN - restart as if the burn had just ended
*/
enum  {DONTSAVETREES=0,PRINTTMRCA, DEMOGHIST, MIGRATEDIST, PRINTASCIITREND, PRINTASCIICURVE,PRINT2DMARGINALS,CHECKPOINTFILEWRITE,CHECKPOINTFILEREAD,RESTARTBURN};

/* calculation options -c
	LOADRUN  - load tree and t information saved in a previous run 
    FINDJOINTPEAK  - find the joint peak
	NESTEDMODELS  - search surface for nested models (assumes no commontheta or commonmigration terms)
    PRINTPEAKFINDDETAILS
	PROFILECURVE - print out profiled likelihood distributions - single parameter
    PROFILE95CONF - print out profiled 95% confidence limits on main model parameters individually

*/
enum {LOADRUN = 0, FINDJOINTPEAK,NESTEDMODELS, PRINTPEAKFINDDETAILS, PROFILECURVE, PROFILE95CONF};

/* mutation models */
/* INFINITESITES
	HKY
	STEPWISE  - one or more linked stepwise loci, no IS portion
	JOINT_IS_SW  - one IS portion and one or more STEPWISE portions
 */
enum {INFINITESITES,HKY,STEPWISE,JOINT_IS_SW};


/*  different ways that the length of the run can be specified using the '-L' flag
	TIMESTEPS - time counted in # of steps
    TIMEINF  - run until first charcater in 'IMrun' is not 'y' */
enum  {TIMESTEPS,TIMEINF};

/* heating modes */
enum {HLINEAR,HTWOSTEP,HADAPT,HGEOMETRIC};

/*nested models in FULL A=Q1  B=Q2  C=QA  D=M1  E=M2    The order of positions is Q1,Q2,QA,M1,M2 in each model
Full  Q1,Q2,QA,M1,M2    5
ABCDD Q1,Q2,QA,M,M      4
ABCD0 Q1,Q2,QA,M,0      4
ABC0D Q1,Q2,QA,0,M      4
ABC00 Q1,Q2,QA,0,0      3
AACDE Q,Q,QA,M1,M2      4 
AAADE Q,Q,Q,M1,M2       3
AACDE Q,Q,QA,M,M        3
AAC00 Q,Q,QA,0,0        2
AAADD Q,Q,Q,M,M         2
AAA00 Q,Q,Q,0,0         1 
ABADE Q,Q2,Q,M1,M2      4
ABADD Q,Q2,Q,M1,M1      3
ABA00 Q,Q2,Q,0,0		4
ABBDE Q,QA,QA,M1,M2     4   - useful for models in which one species buds off of the other, so that one descendant is the same as the ancestor
ABBDD Q,QA,QA,M,M       3
ABB00 Q,QA,QA,0,0       2  

  
For equilibrium model,  list of nested models 
FullEq
Name    List          # params
EFull  Q1,Q2,M1,M2    4
AB_DD  Q1,Q2,M,M      3
AA_DE  Q,Q,M1,M2      3
AA_DD  Q,Q,M,M        2 

just one populaton t=0
QONEPOP  Q 
*/

enum {FULL, ABCDD, ABCD0, ABC0D, ABC00, AACDE, AAADE, AACDD, AAC00, AAADD, AAA00, ABADE, ABADD, ABA00, ABBDE, ABBDD, ABB00, EFULL, AB_DD, AA_DE, AA_DD, QONEPOP};

/*paramtypes */
enum {Q1,Q2,QA,M1,M2,T,U,KA,H};

/* treeinfo arrays contains values for calculating the probability of the tree, to make it easy these are 
enumerated as follows
terms up to  cm2 are used by each locus and kept in treeinfo
sums of terms up to cm2, as well as terms from q1k to m2k are kept in jointtree 
the last 3 terms (h1k,h2k and hak) are required for calculating the joint probability when there is variation in
the values of the inheritance scalars.  during the run these values are kept in hterms
but they are stored with the tree information in gsampinf  and used for calculating the marginal probabilities */
/* t terms are not used, but are there to keep sync with other arrays */
/*       0  1   2   3   4   5   6   7   8   9  10  11  12  13  14   15  16  17  18 19  20*/
enum {cc1,cc2,cca,cm1,cm2,fc1,fc2,fca,fm1,fm2,q1k,q2k,qak,m1k,m2k,pdg,prob,h1k,h2k,hak,tval};
/*
all these are in treeinfo and jointtreeinfo
cc1  = count of coalescent events in pop1, across loci
cc2  = count of coalescent events in pop2, across loci
cca  = count of coalescent events in popa, across loci
cm1  = count of migration events from pop1, across loci
cm2  = count of migration events from pop2, across loci
fc1  = total coalescent rate in pop1, all loci
fc2  = total coalescent rate in pop2, all loci
fca  = total coalescent rate in popa, all loci
fm1  = total migration rate from pop1 to pop2, all loci
fm2  = total migration rate from pop2 to pop1, all loci
q1k = integration of genealogy over theta1
q2k = integration of genealogy over theta2
qak = integration of genealogy over thetaa
m1k = integration of genealogy over m1
m2k = integration of genealogy over m2
pdg = log probably of data given genealogy (summed over loci) 
prob = log of prior prob  - integration over all parameters

these are jointtreeinfo,  for the individual chains,  the terms are in C[ci]->hterms
h1k = log of inheritance scalar term for pop1 if not all inheritance scalars are the same
h2k = log of inheritance scalar term for pop2 if not all inheritance scalars are the same
hak = log of inheritance scalar term for popa if not all inheritance scalars are the same
tval = the current value of the time parameter
*/


/******************************************/
/***** STRUCTURES  ************/
/******************************************/

// nest structures are used to hold information about each of the different nested models 
struct nest
	{
	char  name[6];
	int   dim;
	char  istr[6];
	int   dfstar;  // =0 if no parameters in nested model are set at boundary,  = 1 otherise (e.g. if m1=0)
	};

/* eevent contains info needed to calculate the mean and variance of the time of an event */ 
// eevents are a basic structure that accumulates information over the run for calculating correlations or autocorrelations
struct eevent
	{
	double s; /* sum of times */
    double ss; /* in case need to sum a second variable */
	double s2; /* sum of squares of times*/
	int n; /* number of events */
	};

// for calculating autocorrelations 
struct autoc
	{
	struct eevent cov;
	struct eevent var[2]; 
	double vals[AUTOCNEXTARRAYLENGTH];
	};

// used for calculating 90% HPD intervals 
struct hlists
    {
    double v;
    double p;
    };

/*Main data structures: edge, locus, parameter */

/* an edge is a node in the genealogy
each edge gets a number.  the n sequences are numbers 0 thru n-1.  The remaining n-1 edges are numbered after that.
For edge i.
up[2] - contains the numbers of the edges to which edge i connects to  (i.e. the numbers of its descendants in the tree).
down - contains the number of the edge to which edge i connects down to  (i.e. the immediate ancestor in the tree
time - contains the time at the bottom of the edge, that is the time at the top of the ancestral edge (down). 
      the root edge has a negative value for time. 
*mig - pointer to an array that contains the times of migration on edge i, these times are on the same scale as time, 
   and thus must be less than the population splitting time
cmm - current length of the memory available to hold migration times 
mut - used for labeling under INFINITESITES
A - an allele state for stepwise or other allelic model.  This is the state of the node at the top.
dlike - the likelihood of the distance between A, the allele state at the top of the node, and the allele state at the top
of the down edge 
pop - contains the population that the edge is in at its top, which may be different than 
    the one it is in at the bottom, depending on migration.
frac, newfrac, scalefactor, oldscalefactor - used for the HKY mutation model
*/

struct hkyinfo
	{
	double **frac;
    double **newfrac;
    double *scalefactor;
    double *oldscalefactor;
	};

struct edge
    {
	int up[2];
	int down;
	double time;
	double *mig; 
	int cmm; //current size of mig array
	int mut;
	int *A;
    double *dlikeA;
	int pop;
	struct hkyinfo  hkyi;  // only use if the mutation model for the locus is HKY
	};	

// used in treeweight() which sorts all of the events in a tree
struct treeevent 
    {
    double time;
    int pop;
    int cmt; /* coalesce =0 or  migrate=1  or process reaches divT = -1 */
  /*  int num0;
    int num1;  don't need these */
    } ;

/* treevals only used in treeprint() for debugging */
struct treevals
    {
    int nodenum;
    int up1;
    int up2;
    int down;
    double time;
    double timei;
    int migcount;
    int pop;
    int mut;
	int A[MAXLINKED];
    double dlikeA[MAXLINKED];
    };

/*
name - locus name
numgenes - total # sampled gene copies
numpop1, numpop2  - sample sizes by population
model - mutation model
numlines - number of branches on tree = 2*numgenes -1
numsites - # of polymorphic sites for IS model,  length of sequence for HKY model
pop1sites, pop2sites - # of variable sites in pop under IS model
numbases - length of sequence - used for IS model 
root - edge number of root 
mignum - current # of migration events in tree
roottime - time of root
length - length of tree
tlength -  length of tree for part with time < t
oldlike - current P(X|G)
oldlike_a current P(X|G) for STR part of the data, if this locus has an STR portion
maxA, minA   largest and smallest allele lengths if STR locus
*tree  pointer to array of branch info
treeinfo - array of info that is saved when the genealogy is sampled
totsites  - used for HKY model
**seg, *mult, *badsite  - used for reading sequences
pi - used for HKY model
*/


struct upairlist
	{
	int l;
	int u;
	}  ul[2*MAXLOCI];  // listing of mutation rate scalars  not clear how big to make it,  because not clear how many portions each locus will have


struct priorrange
	{
	double min;
	double max;
	};

struct plotpoint //(x axis are the possible values,  y axis is the counts)
	{
	double x;
	double y;
	};

struct update_rate_calc
	{
	double accp;
	double tries;
	};

struct i_param
	{
	struct priorrange pr;
	struct plotpoint *xy;  // if used, this points to an array of gridize elements, each a plotpoint
	char str[6];
	int integrate;  // do or do not integrate
	};

struct mc_param
	{
	double val;
	struct priorrange pr;
	double win;
	struct update_rate_calc *upinf; // pointer because all chains point to the same place for recording purposes
	struct plotpoint *xy;  // if used points to an array of gridize elements, each a plotpoint
	double *trend;
	int *beforemin;
	int *aftermax;
	char str[6];
	};

struct u_mc_param
	{
	int umodel;
	struct mc_param mcinf;
	struct mc_param uperyear;
	struct update_rate_calc *Aupinf; // pointer because all chains point to the same place for recording purposes
	int uii;
	int uprior_failedupdate;
	};

struct locus 
	{
// basic info obtained from infile - same for all chains 
	char name[NAMELENGTH];
	int numgenes;
	int numpop1;
	int numpop2;
	int numlines;
	int nlinked; // # of linked portions, if jount_is_sw =  1 + # linked SW portions, if SW = # linked SW portions
    int *maxA; // points to an array of length nlinked
    int *minA; // points to an array of length nlinked
	int model;  // the overall mutation model for the locus
	int totsites;
	int numbases;
	int numsites;
	int pop1sites;
	int pop2sites;
	int **seq;
	int *mult;
	int *badsite;

	// things that are in the mcmc - parameters associated with locus - some info in these structures comes from the infile 
	struct u_mc_param *u;  // point to an array of nlinked mcparamrecs,  one for each portion of the locus that has a mutation rate
	struct mc_param h;
	struct mc_param kappa;
	double pi[4];

// genealogy stuff  - different for each chain
	struct edge *tree;
	double treeinfo[fm2+1];
	int root;
    int mignum;
	double roottime;
    double length;
    double tlength;
	double *oldlike; // points to an array of of length nlinked
	double hilike;

// update info and results,  for chain # != 0,  these all point to corresponding locations in chain # 0	
	struct update_rate_calc *gupdate;
	struct update_rate_calc *topolupdate;
	struct update_rate_calc *tmrcaupdate;
	struct plotpoint *tmrcaxy;  // point to an array of gridsize  x and y values (x axis are the possible values,  y axis is the counts) ;
	struct plotpoint *migcountxy[2]; // each pointer points to an array of gridsize+1  x and y values ;
	struct plotpoint *migtimexy[2]; // each pointer points to an array of gridsize  x and y values ;
	};

struct chain
	{
	struct mc_param t;
	double hterms[3];
	double jointtreeinfo[tval+1];
	struct locus *L; // points to an array of locus 
	};

/******************************************/
/***** GLOBAL VARIABLES ************/
/******************************************/


/* if GLOBVARS is defined then gextern is ignored. This
causes the corresponding variable declarations to be definitions.
GLOBVARS is only defined in front.c.  If GLOBVARS is not defined,
as is the case at the beginning of the other files, then gextern
gets replaced by extern and the variable declarations are simply
declarations */

#ifdef GLOBVARS
#define gextern
#else
#define gextern extern
#endif

gextern int q1i,q2i,qai,m1i,m2i;  //q1i = Q1 = 0; q2i = Q2 = 1; qai = QA = 2; m1i = M1 = 3; m2i = M2 = 4; 
gextern struct i_param iq[M2 + 1];
gextern struct chain **C;  //points to an array of pointers to chains 
gextern int nurates;
gextern int numchains;
gextern long int step;
gextern int  nloci;
gextern int jheyoptions[ESTIMATEMAXLIKELIHOOD+1];
gextern int modeloptions[ONEPOP+1];
gextern int calcoptions[PROFILE95CONF+1];
gextern int printoptions[RESTARTBURN+1];
gextern int multipleh;
gextern double paramprior;
gextern double beta[MAXCHAINS];
gextern double **gsampinf;
gextern int nestedmodel;
gextern double maxvals_for_surface_calls[BASICPARAMS];
gextern int maxedouttreesave;
gextern int treessaved;
gextern int somestepwise;
struct edge *copyedge;
gextern double beta[MAXCHAINS];
gextern int countuprior;
gextern int optinf[4];  /* information used for finding surface peaks and max likelihoods */
  /*optinf[0]  # parameters in the model that are not constants
	optinf[1]  # parameters in the model that are constants
    optinf[2]  the number of the first tree to include
    optinf[3]  the number of the last tree to include
    */
gextern float optconst[BASICPARAMS];  /* values to hold constant when using optimization routines */
	/*    if a parameter is not being used in the model, then optconst[] = 0,
		if value is < 0, it means it is either a regular variable parameter being maximized or is not in the model
		if it is > 0,  it is a const to be used in calculations, but not in maximization */

// if debugging heap
#ifdef HPDBG
gextern int tmpFlag;
#endif


/******************************************/
/***** GLOBAL FUNCTION PROTOTYPES *********/
/******************************************/

/* functions in  ima_main.c   
/* all functions are local in ima_main.c 
void start(int argc, char *argv[]);
void fillautoc(struct autoc *a, int n, double v);
void checkautoc(void);
void Qupdate(void);
int run(void);
void savetreeinfo(void);
void inctrend(int m, int t, double trendarray[], double v);
void record(void);
void loadtreevalues(void);
void intervaloutput(int burnsteps);
void printoutput(void);
*/

/**** Global Functions in File: upate_genealogy.c */
void ginit(void);
void treeweight(int ci, int li, double divt);
double integrate_tree_prob (int  ci, double *treeinfo);
void copyfraclike(int ci, int li);
void storescalefactors(int ci, int li);
double finishSWupdateA(int ci, int li, int ai, int edge, int downedge, int sisedge, int newsisedge, double u, double *Aterm);
double updateA(int ci, int li, int ai, double u, int *count);
void restorescalefactors(int ci, int li);
int updategenealogy( int ci, int li, int *topolchange, int *tmrcachange);


/**** Global Functions in File: calc_prob_data.c */
extern void labeltree(int ci, int li, int edge);
double likelihoodHKY(int ci, int li, double mutrate, double kappa, int e1, int e2, int e3, int e4);
void calc_sumlogk( int ci, int li, double *sumlogk);
double likelihoodIS( int ci, int li, double mutrate);
double likelihoodSW(int ci, int li, int ai, double u, double tr);
void checklikelihoodSW(int ci, int li, int ai, double u);

/**** Global Functions in File: get_data_initialize.c */
//void setupchains(char infilename[],FILE *infile,int fpstri, char fpstr[], struct mc_param ttemp);
void setupchains(char infilename[],int fpstri, char fpstr[], struct mc_param ttemp);

/**** Global Functions in File: surface_call_functions.c */
float jointp(float x1[], int code);
float jointpsmoothed(float x1[], double *t);
void profile95(FILE *outfile,int ndim,double holdmlval, double holdpeakloc[], double hold95lo[],double hold95hi[]);
void annealjointopt(FILE *outfile,double *mlval, double peakloc[], int ndim, int atry, int constval, double *t);
double margincalc(double x, double yadust, int pi, int logi);
void marginalopt(int firsttree, int lasttree, double mlval[], double peakloc[]);
double margin95(double mlval[], double peakloc[], int pi, int UL);
double twodmargincalc(double xi, double xj, int pi, int pj, int logi, double yadjust);
int findpeaks(FILE *outfile,int imodel, char outfilename[], double *holdmlval, double holdpeakloc[]); // find peaks of surface

/**** Global Functions in File: build_genealogy.c */

void makeHKYtree(int ci, int li);
void makeIStree( int ci, int li);
void makeSWtree(int ci, int li);
void makeJOINT_IS_SWtree( int ci, int li);

/**** Global Functions in File: utilities.c */

#ifdef USE_MYASSERT
void myassert(int isit);
#endif

void errr(int ci, int li, int i, double val1, double val2);
void nrerror(char error_text[]);
double mylogcosh(double x);
double mylogsinh(double x);
void setseeds(int seed_for_ran1);
double uniform();
double expo(double c);
extern int bitran(void);    
double normprob(double mean, double stdev, double val);
double normdev(double mean, double stdev);
int poisson(double param, int condition);
int geometric(double p);
void hpsort(struct treeevent *lptr,int  n);
//void hpsortreg(double list[],int  n);
void sort(double arr[], unsigned long n);
void shellhist(struct hlists *hptr, int length);
void indexx(unsigned long n, struct treeevent *arr, unsigned long *indx);
double gammln(double xx);
void gcf(double *gammcf, double a, double x, double *gln);
void gser(double *gamser, int a, double x, double *gln);
double expint(int n, double x);
double uppergamma(int a, double x);
double lowergamma(int a, double x);
char *nextwhite(char *c);
char *nextnonspace(char *textline);
void strdelete(char *s,int pos,int len);
void strremove(char *s, char c);
void strtrunc(char *s, char c);
int IsWildcardMatch (char *wildcardString, char *stringToCheck, int caseSensitive);
extern void checkmig(int i, double **mig, int *nmig);
void setlogfact(void);
void ieevent(struct eevent *a);
void iautoc(struct autoc *a);
double  rnd(double x, int n);
double bessi(int n, double x);
double ****alloc4Ddouble (int d1, int d2, int d3, int d4);
int ****alloc4Dint (int d1, int d2, int d3, int d4);
void free4D (void ****a, int d1, int d2, int d3);
double ***alloc3Ddouble (int layers, int rows, int cols);
int ***alloc3Dint (int layers, int rows, int cols);
void free3D (void ***a, int layers, int rows);
int **alloc2Dint (int rows, int cols);
double **alloc2Ddouble (int rows, int cols);
void free2D (void **a, int rows);

/**** Global Functions in File: update_mc_params.c */
void setuinfo(double summut);
int changet(int ci); // change all times by a scalar
int changet2(int ci);
int changeu(int ci, int j, int *k);
int changekappa(int ci);
int changeh(int ci, int li);


/**** Global Functions in File: surface_search_functions.c */

void mnbrakmod(int ndim, int firsttree, int lasttree, double *ax,double *bx,double *cx,double *fa,double *fb,double *fc, double (*func)(int,int,int,double));
double goldenmod(int ndim, int firsttree, int lasttree, double ax,double  bx,double cx,double tol_,double *xmin, double (*func)(int,int,int,double));
void amebsa(float **p, float y[], int ndim, float pb[], float *yb, float ftol, float (*funk)(float [], int code), int *iter, float temptr, int code);
float amotsa(float **p, float y[], float psum[], int ndim, float pb[], float *yb, float (*funk)(float [], int code), int ihi, float *yhi, float fac, int code);


/**** Global Functions in File: output.c */

void closeopenout(FILE *outfile, char outfilename[]);
void checkhighs(int ci, int printint, double *hilike, double *hiprob, double *like);
void printrunbasics(FILE *outfile, int loadrun, char *fpstr, int burnsteps, int recordint, int recordstep, int savetreeint,
					time_t endtime,time_t starttime, double hilike, double hiprob);
void asciicurve(FILE *outfile,struct plotpoint *a, char *qlabel, int logscale,int recordstep);
void asciitrend(FILE *outfile, double *y,char *qlabel, int xlen, int ylen, int logscale);
void printacceptancerates(FILE *outto);
void savetreefile(char treeinfosavefilename[], FILE *treeinfosavefile, int multipleh);
void printprofile95(FILE *outfile,double holdpeakloc[], double hold95lo[],double hold95hi[]);//print the 95% conficence intervals  for the surface profile
void printhist(FILE *outfile, int mode, long int recordstep, double uscaleinput, double generationtime);
void printmigratehist(FILE *outfile,int recordstep);
void printtmrcahist(FILE *outfile,int recordstep);
void printcurrentvals();
void printautoc(FILE *outto, int checkstep[], struct autoc autoc_t[],struct autoc autoc_lpg[], struct autoc autoc_tmrca[][AUTOCTERMS]);
void profilelike1Dcurve(FILE *outfile, int ndim,double holdpeakloc[],double holdmlval,int imodel);
void twodmarginallistplot(char margin2dfilename[],char outfilename[]);

/**** Global Functions in File: swapchains */
void setheat(double hval1, double hval2, int heatmode);
int swapchains(int swaptries, int heatmode, int adaptcheck, double hval1, double hval2);
void printchaininfo(FILE *outto, int heatmode, double hval1, double hval2);


/**** Global Functions in File: checkpoint */
/* not used
#if 0
void readdck(char *dckfilename, char *fpstr, char *infilename, char *outfilename, char *oldoutfilename, time_t *checktimer);
void writedck(char dckfilename[], char *fpstr, char infilename[], char outfilename[], char oldoutfilename[], time_t checktimer);
void reinitialize(void);
#endif 
*/

/**** Global Functions in File: treeprint */
void treeprint(int ci, int li);

/**** Global Functions in File: mcmcfile 
void writemcmc(int ci, int forIMamp);  // if forIMamp  then write migration arrays as used by that program, else do it as for IMa
void readmcmc(int ci, int writtenforIMamp); // if writtenforIMamp  then the file was written with migration arrays as used by IMamp
*/

/**** Global Functions in File: msdirent.c */

#ifdef _MSC_VER
	DIR *opendir(const char *name);
	int closedir(DIR *dir);
	struct dirent *readdir(DIR *dir);
	void rewinddir(DIR *dir);
#endif


void makeIStreetemp( int ci, int li);
void resetseeds(int seed);





